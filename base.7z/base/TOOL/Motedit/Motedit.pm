#!/usr/bin/perl
# --------------------------------------------------------------
# Title: Motolora format file edit class package     (Ver.1.01)
# --------------------------------------------------------------
# Usage: 
#    use Motedit;
# 
#    $object = new Motedit( $filename );
#    $filename : input file name (motorola format file)
# 
# Description:
# 
#    This package provids Motorola S-record forcused edit feature.
# 
# Object methods and properties:
# 
#    [Methods]
# 
#        $object->Align  ({size => n});
#        $object->Merge  ( $object );
#        $object->Write  ( $filename );
#        $object->Chksum ({byte => n, size => n});
#        $object->Patch  ({addr => "X", data => "X"});
#        $object->Cut    ({s_addr => "X", e_addr => "X"});
#        $object->Paste  ({s_addr => "X"});
#        $object->Trim   ({s_addr => "X", e_addr => "X"});
#        $object->Search ( $address ); for internal sub routine.
# 
#        $object->DBG_DumpProperty();  for debug dump properties.
#        $object->DBG_DumpData();      for debug dump record data.
# 
#    [Properties]
# 
#        $object->{file} : file name
#        $object->{clip} : clip board  (reference to clipboard hash *1)
#        $object->{type} : record type (S1,S2,S3)
#        $object->{data} : record data (reference to data record hash *1)
#        $object->{Sx}   : supplementary record (x:0,4,5,6,7,8,9)
# 
#        *1) Hash key is start address of each record.
# 
#     Please don't access object properties directly.
#     Please refer to method description on top of each method
#     to learn more detailed usage of method.
# 
# Note:
#    S-record format
#    ---------------------------------------------------------
#    | S | type | length | address |      data    | checksum |
#    ---------------------------------------------------------
#    
#    S          : The first charactor should be 'S'
#    type      0: Start record
#              1: Data record (16bit address : by 4 charactors)
#              2: Data record (24bit address : by 6 charactors)
#              3: Data record (32bit address : by 8 charactors)
#              4: Symbol record
#              5: The number of data records by 2bytes
#              6: The number of data records by 3bytes
#              7: End of S3 data format
#              8: End of S2 data format
#              9: End of S1 data format
#    length     : Length of address + data + checksum
#    address    : Start address of this record
#    data       : 2 charactor per 1 byte data
#    checksum   : 2 charactor checksum data
#                 Total of each 2 charactor in length, address
#                 data and checksum should be 0xFF.
#    
# Revision Histry:
#    1.01	Chksum() Bug fix: wrong big endian data calculation.
#    
# --------------------------------------------------------------
package Motedit;
use     SRec;

# --------------------------------------------------------------
# Begin / End function
# --------------------------------------------------------------
BEGIN {
}
END {
}
# --------------------------------------------------------------
# Constructor	: create this object
# --------------------------------------------------------------
sub new {

	# Create new object
	my $this_object;
	my $this_class_name = shift;		# Class name
	my $this_file_name  = shift;		# Instance file name
	my %this_property   = ();			# property hash
	my %data_list       = ();			# data record hash
	my %clip_board      = ();			# clip board hash
	
	# Check argument
	if ($this_file_name eq "") { die "[Error] new() - Invalid argument\n";}
	if (!(-e $this_file_name)) { die "[Error] new() - $this_file_name is not found\n";}
	
	# Set and initialize object properties. (file name and clip board)
	$this_property{file} = $this_file_name;
	$this_property{clip} = \%clip_board;
	
	# Open file if existing.
	open(IN, "< $this_file_name") or die "[Error] new() - $this_file_name can't be opened\n";
	while (<IN>) {
		# Analyze input record.
		my ($typ, $len, $adr, $dat, $cs) = SRecAnalyze($_);
		
		# S1, S2, S3 - data record
		if (($typ eq "S1") or ($typ eq "S2") or ($typ eq "S3")) {
			
			# set object properties. (record type)
			$this_property{type} = $typ if !exists( $this_property{rec_type} );
			$data_list{$adr}     = $dat;
		}
		else {
			# set object properties (supplementary record)
			$this_property{$typ} = join("", ($len, $adr, $dat, $cs)) if ($typ ne "");
		}
	}
	# set object property. (data record)
	$this_property{data} = \%data_list;
	
	close(IN);							# Close input file.
	
	# Set reference to object properties.
	$this_object = \%this_property;

	# Return reference to this object.
	return bless $this_object, $this_class_name;
}
# --------------------------------------------------------------
# Destructor	: destroy this object
# --------------------------------------------------------------
sub DESTROY {
	
	my $this = shift;					# get this object
	%{$this->{clip}} = ();				# delete clip board
	%{$this->{data}} = ();				# delete {data}
	%{$this} = ();						# delete this object
}
# --------------------------------------------------------------
# Method		: Align ( {size => n} )
# Description	: Align all s-record length with specified size.
# Arguments		: size : number of data in a s-record.
# Return		: None
# Note			: None
# --------------------------------------------------------------
sub Align {

	my $this = shift;					# get this object
	my %para = %{shift()};				# get arguments
	my %data = %{$this->{data}};		# de-reference data hash
	my $size = $para{size};				# record data size
	my $type = $this->{type};			# record type
	my @buff = ("");					# temporary work buffer
	my $c_adr;							# current address
	
	#DBG_DumpProperty($this,  "Align() This Object");
	#DBG_DumpProperty(\%para, "Align() Parameter");
	if (!exists($para{size}) or ($size < 1) or ($size > 32)) {
		die "[Error] Align() - Invalid argument\n";
	}
	# each data record.
	foreach $key ( sort keys %data ) {
		
		# setup current address if not defined.
		$c_adr    = hex($key) if !defined $c_adr;
		
		# align record.
		$buff[0] .= $data{$key};
		@buff     = SRecAlign($buff[0], $size);
		
		# delete current record.
		delete     %{$this->{data}}->{$key};
		
		# create new record based on aligned list.
		while ( $#buff >= 0 ) {
			if ( length($buff[0]) < $size * 2 ) {
				# next record size is less than align size.
				last;
			}
			else {
				# set aligned new record.
				my $adr = SRecAddrStr($c_adr, $type);
				%{$this->{data}}->{$adr} = shift( @buff );
				$c_adr += $size;
			}
		}
	}
}
# --------------------------------------------------------------
# Method		: Merge ( $object )
# Description	: Merge data with another Motedit object.
# Arguments		: $object : reference of object to be merged
# Return		: None
# Note			: None
# --------------------------------------------------------------
sub Merge {

	my $this = shift;					# get this object
	my %data = %{$this->{data}};		# de-reference data hash
	my $sobj = shift();					# get source object
	my %sdat = %{%{$sobj}->{data}};		# data record of source object

	#DBG_DumpProperty($this, "Merge() This Object");
	#DBG_DumpProperty($sobj, "Merge() Parameter");
	if (ref($sobj) ne "Motedit") {
		die "[Error] Merge() - Invalid argument\n";
	}
	# copy data record from source object to this object.
	foreach $key ( sort keys %sdat ) {
		%{$this->{data}}->{$key} = $sdat{$key};
	}
}
# --------------------------------------------------------------
# Method		: Write ( $file_name )
# Description	: Write this object instance to the specified file.
# Arguments		: $file_name : file name to be output.
# Return		: None
# Note			: None
# --------------------------------------------------------------
sub Write {

	my $this = shift;					# get this object
	my $file = shift;					# get argument (file name)
	my %data = %{$this->{data}};		# de-reference data hash

	#DBG_DumpProperty($this,  "Write() - $file - This Object");
	if ($file eq "") { die "[Error] Write() - Invalid argument\n";}
	
	# Create empty file.
	open(OUT, "> $file") or die "[Error] Write() - open $file\n";
	
	print OUT "S0",$this->{S0},"\n";	# S0 record
	
	# data record (S1, S2 or S3)
	foreach $adr ( sort keys %data ) {
		my $len  = (length($adr) + length($data{$adr}))/2 + 1;
		my $line = sprintf("%02X",$len).$adr.$data{$adr};
		print OUT $this->{type},$line,SRecCS($line),"\n";
	}
	# end of data record type corresponding data record.
	my $end  = SRecEndType($this->{type}); 
	print OUT $end,$this->{$end},"\n";	# S7, S8 or S9 record
	close(OUT);
}
# --------------------------------------------------------------
# Method		: Chksum ( {byte => n, size => n, endn => c} )
# Description	: Calculate check sum of this object instance.
# Arguments		: byte : data size to be calculated. (n = 1,2,4)
#				: size : data size of check sum result. (n = 1..4)
#				: endn : endian ('l' = little endian, 'b' or other = big endian)
# Return		: $checksum : as string.
# Note			: None
# --------------------------------------------------------------
sub Chksum {

	my $this = shift;					# get this object
	my %para = %{shift()};				# get arguments
	my %data = %{$this->{data}};		# de-reference data hash
	my @wght_l = (0x1, 0x100, 0x1, 0x100); # weight coefficent for each 4 bytes (little endian)
	my @wght_b = (0x100, 0x1, 0x100, 0x1); # weight coefficent for each 4 bytes (big endian)
	my $suml = 0;						# lower 2 byte check sum
	my $sumu = 0;						# upper 2 byte check sum
	
	#DBG_DumpProperty($this,  "Chksum() This Object");
	#DBG_DumpProperty(\%para, "Chksum() Parameter");
	if (!exists($para{byte}) or !exists($para{size}) or
		($para{byte} < 1) or ($para{byte} > 4) or 
		($para{size} < 1) or ($para{size} > 4)) {
		die "[Error] Chksum() - Invalid argument\n";
	}
	# each data record.
	foreach $key ( sort keys %data ) {
		my $pos = 0;					# sub string position
		my $adr = hex($key);			# record address
		my $len = length($data{$key})/2;# data length
		
		# each byte data
		for (my $i = 0; $i < $len; $i ++) {
			my $raw = hex( substr( $data{$key}, $pos, 2) ); $pos += 2;
			my $mod = $adr%($para{byte});
			
			# add to check sum.
			if (($para{endn} eq "l") or # little endian
				($para{byte} == 1)) {	# 1 byte check sum
				if ($mod < 2) { $suml += $raw * $wght_l[$mod]; }
				else 		  { $sumu += $raw * $wght_l[$mod]; }
			}
			else {						# big endian
				if ($mod < 2) { $sumu += $raw * $wght_b[$mod]; }
				else 		  { $suml += $raw * $wght_b[$mod]; }
			}
			$adr ++;
		}
		# over flow check
		while ($suml > 0xFFFF) {
			$suml -= 0x10000;
			$sumu ++;
		}
		while ($sumu > 0xFFFF) {
			$sumu -= 0x10000;
		}
	}
	# convert to hex string.
	my $cs_str = SRecHexStr(($sumu * 0x10000) + $suml, ($para{size} * 2));
	if ($para{endn} eq "l") {	# little endian
		$cs_str = SRecChgEndian($cs_str);
	}
	return $cs_str;
}
# --------------------------------------------------------------
# Method		: Patch ( {addr => "X", data => "X"} )
# Description	: Replace data of specified address.
# Arguments		: addr : start address of data.
#				: data : data to be replaced.
# Return		: None
# Note			: The operation that need to replace 2 or more 
# 				: record is not supported.
# 				: Specified address may not exist as hash key.
# --------------------------------------------------------------
sub Patch {

	my $this = shift;					# get this object
	my %para = %{shift()};				# get arguments

	#DBG_DumpProperty($this,  "Patch() This Object");
	#DBG_DumpProperty(\%para, "Patch() Parameter");
	if (!exists($para{addr}) or !exists($para{data})) {
		die "[Error] Patch() - Invalid argument\n";
	}
	my $s_addr = $para{addr};			# start address of data
	my $data   = $para{data};			# patch data
	my $e_addr = SRecAddrStr(		 	# end address of data
		hex($s_addr) + (length($data) / 2) - 1, $this->{type});
	my $s_key  = Search($this, $s_addr);# search start address
	my $e_key  = Search($this, $e_addr);# search end address
	
	if (($s_key eq "") and ($e_key eq "")) {
		# Out of record address -> just add this data.
		%{$this->{data}}->{$s_addr} = $data;
	}
	elsif ($s_key eq $e_key) {
		# data can be replaced within 1 record.
		my $rec   = %{$this->{data}}->{$s_key}; # current record
		my $r_len = length($rec);				# record length
		my $n_rec = "";							# new record
		my $s_pos = (hex($s_addr) - hex($s_key)) * 2;
		my $e_pos = $s_pos + length($data);
		my $e_len = $r_len - $e_pos;
		
		# create new record data and replace hash record.
		$n_rec  = substr($rec, 0, $s_pos) if (0 < $s_pos);
		$n_rec .= $data;
		$n_rec .= substr($rec, $e_pos, $e_len) if (0 < $e_len);
		%{$this->{data}}->{$s_key} = $n_rec;
	}
	else { die "[Error] Patch() - This operation is not supported\n";}
}
# --------------------------------------------------------------
# Method		: Cut ( {s_addr => "X", e_addr => "X"} )
# Description	: Cut the specified area and move the cut data
# 				: to clip board. The cut data is stored by 
# 				: Paste() method.
# Arguments		: s_addr : start address
# 				: e_addr : end address
# Return		: None
# Note			: Specified address should exist as hash key.
# --------------------------------------------------------------
sub Cut {

	my $this = shift;					# get this object
	my %para = %{shift()};				# get arguments
	my %data = %{$this->{data}};		# de-reference data hash
	my %clip = ();						# temporary clip board
	my $s_addr = hex($para{s_addr});	# start address of cut
	my $e_addr = hex($para{e_addr});	# end address of cut
	
	#DBG_DumpProperty($this,  "Cut() This Object");
	#DBG_DumpProperty(\%para, "Cut() Parameter");
	if (!exists($para{s_addr}) or !exists($para{e_addr})) {
		die "[Error] Cut() - Invalid argument\n";
	}
	%{$this->{clip}} = ();				# clear clip board
	
	# search cut area
	foreach $key ( sort keys %data ) {
		$c_addr = hex($key);			# current address
		
		# check if crrent address is within cut area.
		if (($s_addr <= $c_addr) and ($c_addr <= $e_addr)) {
			
			# cut and move to temporary clip board.
			$clip{$key} = $data{$key};
			delete %{$this->{data}}->{$key};
		}
	}
	%{$this->{clip}} = %clip;			# copy to clip board
}
# --------------------------------------------------------------
# Method		: Paste ( {s_addr => "X"} )
# Description	: Paste data stored to clip board to specified
# 				: location.
# Arguments		: s_addr : start address of data pasted.
# Return		: None
# Note			: Specified address should exist as hash key.
# --------------------------------------------------------------
sub Paste {

	my $this = shift;					# get this object
	my %para = %{shift()};				# get arguments
	my %clip = %{$this->{clip}};		# clip board
	my $type = $this->{type};			# record type

	#DBG_DumpProperty($this,  "Paste() This Object");
	#DBG_DumpProperty(\%para, "Paste() Parameter");
	if (!exists($para{s_addr})) {
		die "[Error] Paste() - Invalid argument\n";
	}
	my $s_addr = hex($para{s_addr});	# start address of paste
	
	# each clip board record
	foreach $key ( sort keys %clip ) {
		my $len = length($clip{$key})/2;
		my $adr = SRecAddrStr($s_addr, $type);
		
		# move record data to specified address.
		%{$this->{data}}->{$adr} = $clip{$key};
		$s_addr += $len;
	}
	%{$this->{clip}} = ();				# clear clip board
}
# --------------------------------------------------------------
# Method		: Trim ( {s_addr => "X", e_addr => "X"} )
# Description	: Trim specified area. The data between start
# 				: and end address remains, all the other part
# 				: will be removed.
# Arguments		: s_addr : start address
# 				: e_addr : end address
# Return		: None
# Note			: Specified address should exist as hash key.
# --------------------------------------------------------------
sub Trim {

	my $this = shift;					# get this object
	my %para = %{shift()};				# get arguments
	my %data = %{$this->{data}};		# de-reference data hash

	#DBG_DumpProperty($this,  "Trim() This Object");
	#DBG_DumpProperty(\%para, "Trim() Parameter");
	if (!exists($para{s_addr}) or !exists($para{e_addr})) {
		die "[Error] Trim() - Invalid argument\n";
	}
	my $s_addr = hex($para{s_addr});	# start address of cut
	my $e_addr = hex($para{e_addr});	# end address of cut
	
	# search cut area
	foreach $key ( sort keys %data ) {
		$c_addr = hex($key);			# current address
		
		# check if crrent address is out of area.
		if (($c_addr < $s_addr) or ($e_addr < $c_addr)) {
			
			# remove record.
			delete %{$this->{data}}->{$key};
		}
	}
}
# --------------------------------------------------------------
# Method		: Search ( $address )
# Description	: Search $address from data record hash. and 
# 				: returns the hash key that it is included in.
# Arguments		: $address : serch address
# Return		: $result  : hash key of data record that address 
# 				:            is included.
# Note			: None
# --------------------------------------------------------------
sub Search {

	my $this = shift;					# get this object
	my $para = shift;					# get arguments
	my %data = %{$this->{data}};		# de-reference data hash
	my $result;

	#DBG_DumpProperty($this,  "Search() - $para - This Object");
	if ($para eq "") { die "[Error] Search() - Invalid argument\n"; }
	
	# Check if the address is just hash key.
	if (exists $data{$para}) { $result = $para; }
	
	# Not hash key.
	else {
		my @key  = sort( keys( %data ) );
		my $num  = $#key;
		my ($min, $mid, $max) = (0, 0, $num);
		my $r_min = SRecComp($para, $key[0], $data{$key[0]});
		my $r_max = SRecComp($para, $key[$num], $data{$key[$num]});
		
		# address is out of data record.
		if (($r_min < 0) or (0 < $r_max)) { $result = ""; }
		
		# address is included the first record.
		elsif ($r_min == 0) { $result = $key[0]; }
		
		# address is included the last record.
		elsif ($r_max == 0) { $result = $key[$num]; }
		
		# while key is not found.
		while (!defined $result) {
			
			$mid = $min + int(($max - $min)/2); # set middle
			my $r_mid = SRecComp($para, $key[$mid], $data{$key[$mid]});
			if    ($r_mid < 0) { $max = $mid; } # less   than middle
			elsif ($r_mid > 0) { $min = $mid; } # grater than middle
			else      { $result = $key[$mid]; } # found.
		}
	}
	return $result;
}
# --------------------------------------------------------------
# DEBUG data dump functions
# --------------------------------------------------------------
sub DBG_DumpProperty {
	my $para = shift;
	print "\n", shift, "\n";
	DBG_PrHash($para);
}
sub DBG_DumpData {
	my $para = shift;
	print "\n", shift, "\n";
	DBG_PrHash($para->{data});
}
sub DBG_PrHash {
	my %para = %{shift()};
	foreach $key ( sort keys %para ) {
		print "key{ $key } = $para{$key}\n";
	}
}
# --------------------------------------------------------------
return 1;
