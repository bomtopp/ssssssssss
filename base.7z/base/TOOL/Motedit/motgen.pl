#!/usr/bin/perl
# --------------------------------------------------------------
# Title: Motorola hex file generate tool             (Ver.01.01)
# --------------------------------------------------------------
# Usage:
#	perl motgen.pl [options]
#
#	[options] short format follows after '/'.
#		--gen=[abc] / -g
#				a = generate application (A) mot file
#				b = generate bootloader  (B) mot file
#				c = generate appl+boot   (C) mot file
#		
#		--input=(a:filename) | (b:filename) / -i
#				a:filename = input application mot file
#				b:filename = input bootloader mot file
#		
#		--output=(a:filename) | (b:filename) | (c:filename) / -o
#				a:filename = output application mot file
#				b:filename = output bootloader mot file
#				c:filename = output appl+boot mot file
#		
#		--align=[1..32] / -a
#				specify alignment data size (default = 16)
#		
#		--chksum=address:size:[lb] / -c
#				address = address that check sum is located.
#				size    = check sum calculation data size
#				l       = little endian (start address = MSB)
#				b       = big endian    (start address = LSB)
#		
#		--ram=s_address:e_address:d_address / -r
#				s_address = start address of ram code
#				e_address = end address of ram code
#				d_address = destination address for ram code to be moved
#		
#		--trim=s_address:e_address / -t
#				s_address = start address to be removed from mot file
#				e_address = end address to be removed from mot file
#
#		--embed=s_address:data / -e
#				s_address = start address of the data to be embeded
#				data      = data to be embeded
#		
#		--msg | --nomsg / -m
#				display progress message or not (default = no message)
#		
# Description:
#	This script is used to generate Motolora S-record format
#	program code for application, bootloader and combined app + boot.
# 
# Revision Histry:
# 	1.01	Support -e option to enable to embed program ID.
# 			Bug fix: Chksum() function.
# 			Bug fix: @opt_out initialization.
# 
# --------------------------------------------------------------
use Getopt::Long;
use Motedit;
# --------------------------------------------------------------
# Initialize
# --------------------------------------------------------------
my $opt_gen   = "";		# gen option

# input file name options 
my @opt_in    = ();
my $in_a_mot  = "";		# input file name - application
my $in_b_mot  = "";		# input file name - bootloader

# output file name options 
my @opt_out   = ();
my $out_a_mot = "";		# output file name - application
my $out_b_mot = "";		# output file name - bootloader
my $out_c_mot = "";		# output file nama - appl+boot

# check sum options
my $opt_cs    = "";
my $cs_addr   = "";		# check sum address
my $cs_size   = 1;		# check sum size
my $cs_endn   = "b";	# check sum endian 'b'=big/'l'=little endian

# misc options
my $opt_align = 16;		# alignment size
my @opt_ram   = ();		# ram code option
my @opt_trim  = ();		# trim code option
my @opt_emb   = ();		# embed data options
my $opt_msg   = 0;		# display progress message

# debug option
my $debug     = 0;		# debug print 0=off / 1=on
# --------------------------------------------------------------
# Get command line options
# --------------------------------------------------------------
GetOptions('gen=s'    => \$opt_gen,		# gen option
           'input=s'  => \@opt_in,		# input file name options 
           'output=s' => \@opt_out,		# output file name options 
           'chksum=s' => \$opt_cs,		# check sum options
           'align=i'  => \$opt_align,	# alignment size
           'ram=s'    => \@opt_ram,		# ram code option
           'trim=s'   => \@opt_trim,	# trim code option
           'embed=s'  => \@opt_emb,		# embeded data option
           'msg!'     => \$opt_msg,		# display progress message
           'debug!'   => \$debug);		# debug print

# --input option
foreach (@opt_in) {
	if (/a:/) { ($in_a_mot) = (/a:(.*)/); }		# input file name - application
	if (/b:/) { ($in_b_mot) = (/b:(.*)/); }		# input file name - bootloader
}
# --output option
foreach (@opt_out) {
	if (/a:/) { ($out_a_mot) = (/a:(.*)/); }	# output file name - application
	if (/b:/) { ($out_b_mot) = (/b:(.*)/); }	# output file name - bootloader
	if (/c:/) { ($out_c_mot) = (/c:(.*)/); }	# output file name - appl+boot
}
# --chksum options
if ($opt_cs =~ /[0-9a-fA-F]{4,8}:[0-9]+:[lb]/) {
	($cs_addr, $cs_size, $cs_endn) = split(/:/, $opt_cs);
}

# --debug display
if ($debug) {
	print "Gen option       = $opt_gen\n";
	print "Input  file appl = $in_a_mot\n";
	print "            boot = $in_b_mot\n";
	print "Output file appl = $out_a_mot\n";
	print "            boot = $out_b_mot\n";
	print "            a+b  = $out_c_mot\n";
	print "Checksum address = $cs_addr\n";
	print "Checksum size    = $cs_size\n";
	print "Checksum endian  = $cs_endn\n";
	print "Align size       = $opt_align\n";
foreach (@opt_ram) {
	print "Ram code         = $_\n";
}
foreach (@opt_trim) {
	print "Trim code        = $_\n";
}
foreach (@opt_emb) {
	print "Embeded data     = $_\n";
}
	print "Display message  = $opt_msg\n";
}
# --------------------------------------------------------------
# error check of command line options
# --------------------------------------------------------------
if ($opt_gen =~ /a/) {
	if (($in_a_mot eq "") or ($out_a_mot eq "") or ($cs_addr eq "")) {
		die "[Error] invalid option for --gen=a\n";
	}
}
if ($opt_gen =~ /b/) {
	if (($in_b_mot eq "") or ($out_b_mot eq "")) {
		die "[Error] invalid option for --gen=b\n";
	}
}
if ($opt_gen =~ /c/) {
	if (($in_a_mot eq "") or ($in_b_mot eq "") or ($out_c_mot eq "")) {
		die "[Error] invalid option for --gen=c\n";
	}
}
# --------------------------------------------------------------
# Main procedure
# --------------------------------------------------------------
print("\nmotgen.pl started\n") if ($opt_msg);

my $mot_a;
my $mot_b;
if ($opt_gen =~ /[ac]/) {
	
	# create mot object for application
	$mot_a = new Motedit( $in_a_mot );
	if ($opt_gen =~ /a/) {
		my $chksum;
		
		print("Format appl start(input =$in_a_mot)\n") if ($opt_msg);

		# triming operation
		foreach (@opt_trim) {
			if (/[0-9a-fA-F]{4,8}:[0-9a-fA-F]{4,8}/) {
				my ($t_s_addr, $t_e_addr) = split(/:/, $_);
				$mot_a->Cut({s_addr => $t_s_addr, e_addr => $t_e_addr});
			}
		}
		# embed data
		foreach (@opt_emb) {
			if (/[0-9a-fA-F]{4,8}:[0-9a-fA-F]{2,}/) {
				my ($emb_addr, $emb_data) = split(/:/, $_);
				$mot_a->Patch({addr => $emb_addr, data => $emb_data});
			}
		}
		# check sum calculation
		$chksum = $mot_a->Chksum({byte => $cs_size, size => 2, endn => $cs_endn});
		$mot_a->Patch({addr => $cs_addr, data => $chksum});

		# align data length
		$mot_a->Align({size => $opt_align});
		
		# write application mot file
		$mot_a->Write( $out_a_mot );
		print("Format appl done (output=$out_a_mot)\n") if ($opt_msg);
	}
}
if ($opt_gen =~ /[bc]/) {

	# create mot object for bootloader
	$mot_b = new Motedit( $in_b_mot );
	if ($opt_gen =~ /b/) {
		
		print("Format boot start(input =$in_b_mot)\n") if ($opt_msg);

		# align data length
		$mot_b->Align({size => $opt_align});
		
		# triming operation
		foreach (@opt_trim) {
			if (/[0-9a-fA-F]{4,8}:[0-9a-fA-F]{4,8}/) {
				my ($t_s_addr, $t_e_addr) = split(/:/, $_);
				$mot_b->Cut({s_addr => $t_s_addr, e_addr => $t_e_addr});
			}
		}
		# move RAM code to ROM area.
		foreach (@opt_ram) {
			if (/[0-9a-fA-F]{4,8}:[0-9a-fA-F]{4,8}:[0-9a-fA-F]{4,8}/) {
				my ($s_s_addr, $s_e_addr, $d_s_addr) = split(/:/, $_);
				$mot_b->Cut(  {s_addr => $s_s_addr, e_addr => $s_e_addr});
				$mot_b->Paste({s_addr => $d_s_addr});
			}
		}
		# write bootloader mot file
		$mot_b->Write( $out_b_mot );
		print("Format boot done (output=$out_b_mot)\n") if ($opt_msg);
	}
}
if ($opt_gen =~ /c/) {
	print("Merge appl+boot start(a mot =$in_a_mot)\n") if ($opt_msg);
	print("                     (b mot =$in_b_mot)\n") if ($opt_msg);

	# merge application and bootloader
	$mot_a->Merge( $mot_b );

	# write application + bootloader mot file
	$mot_a->Write( $out_c_mot );
	print("Merge appl+boot done (output=$out_c_mot)\n") if ($opt_msg);
}
print("motgen.pl finished\n") if ($opt_msg);
