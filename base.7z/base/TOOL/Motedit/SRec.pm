#!/usr/bin/perl
# --------------------------------------------------------------
# Title: Motolora format file edit class package     (Ver.1.00)
# --------------------------------------------------------------
# Usage: 
#    use Motedit;
# 
# Description:
# 
#    This package provides Motorola S-record format related
#    sub-routines.
# 
# Note:
# 
# --------------------------------------------------------------
package SRec;
use Exporter;
@ISA         = (Exporter);
@EXPORT      = qw(SRecAnalyze   SRecAlign SRecEndType SRecCS 
                  SRecChgEndian SRecComp  SRecHexStr  SRecAddrStr);
@EXPORT_OK   = qw();
@EXPORT_FAIL = qw();

%adr_size = ("S0" => 4, "S1" => 4, "S2" => 6, "S3" => 8, "S4" => 4, 
		     "S5" => 4, "S6" => 4, "S7" => 8, "S8" => 6, "S9" => 4);
%type_end = ("S1" => "S9", "S2" => "S8", "S3" => "S7");

# --------------------------------------------------------------
# Function		: SRecAnalyze ($record)
# Description	: SRecAnalyze a S-record format
# Arguments		: $record : S-record
# Return		: @result [0]: record type ("S1", "S2" or "S3")
#				:         [1]: length
#				:         [2]: address
#				:         [3]: record data
#				:         [4]: check sum
# Note			: None
# --------------------------------------------------------------
sub SRecAnalyze ($) {
	
	my $rec = shift;
	my $pos = 0;
	my ($typ, $len, $adr, $dat, $cs) = ("", "", "", "", "");
	
	chomp $rec;
	if ($rec =~ /^S[0-9]/) {
		
		# Get s-record type and data length
		$typ = substr($rec, $pos, 2); $pos += 2;
		$len = substr($rec, $pos, 2); $pos += 2;
		$adr = substr($rec, $pos, $adr_size{$typ}); $pos += $adr_size{$typ};
		my $siz = hex($len) - 1 - ($adr_size{$typ}/2);
		if ($siz > 0) {
			$siz    = $siz * 2;
			$dat = substr($rec, $pos, $siz); $pos += $siz;
		}
		$cs = substr($rec, $pos, 2);
	}
	return ($typ, $len, $adr, $dat, $cs);
}
# --------------------------------------------------------------
# Function		: SRecAlign ($data, $size)
# Description	: Align S-record length
# Arguments		: $data : record data as string
# 				: $size : data length (= number of record data)
# Return		: @aligned data
# Note			: If data size in $data is less or equal $size,
#				: return 1 aligned data. Else $data is devided
#				: into some aligned data.
# --------------------------------------------------------------
sub SRecAlign ($$) {
	my $rec  = shift;
	my $size = shift;
	my @line = ();
	my $len  = length($rec)/2;
	
	for (my $i = 0; 0 < $len; $i ++) {
		my $pos = $i * $size * 2;
		for (my $j = 0; ($j < $size) and (0 < $len); $j ++) {
			$line[$i] .= substr($rec, $pos, 2); $pos += 2;
			$len --;
		}
	}
	return @line;
}
# --------------------------------------------------------------
# Function		: SRecEndType ($type)
# Description	: This function returns data end type correspinding
#				: data record type.
# Arguments		: $type : data record type
# Return		: $type : data end record type
# Note			: correspondance:
# 				: S1 -> S9, S2 -> S8, S3 -> S7
# --------------------------------------------------------------
sub SRecEndType ($) {
	$type = shift;
	return $type_end{$type};
}
# --------------------------------------------------------------
# Function		: SRecCS ($data)
# Description	: This function calculates record check sum.
# Arguments		: $data : data to be calculated.
# Return		: $sum  : check sum.
# Note			: None
# --------------------------------------------------------------
sub SRecCS ($) {
	my $rec = shift;
	my $num = length($rec)/2;
	my ($pos, $sum) = (0, 0);

	for (my $i = 0; $i < $num; $i ++) {
		$sum += hex( substr($rec, $pos, 2) ); $pos += 2;
	}
	return sprintf("%02X", 255 - ($sum % 256));
}
# --------------------------------------------------------------
# Function		: SRecChgEndian ($data)
# Description	: This function change endian of input data.
# Arguments		: $i_data : input data
# Return		: $o_data : output data
# Note			: None
# --------------------------------------------------------------
sub SRecChgEndian ($) {
	my $i_data = shift;
	my $len    = length($i_data) / 2;
	my $pos    = length($i_data) - 2;
	my $o_data = "";
	
	for (my $i = 0; $i < $len; $i ++) {
		$o_data .= substr($i_data, $pos, 2); $pos -= 2;
	}
	return $o_data;
}
# --------------------------------------------------------------
# Function		: SRecComp ($addr1, $addr2, $data2)
# Description	: This function compares $addr1 with $addr2 and
# 				: returns the result.
# Arguments		: $addr1 : address 1 as string
# 				: $addr2 : address 2 as string
# 				: $data2 : data belonging address 2
# Return		: $result: 0=$address 1 is included in $address 2
# 				:          1=$address 1 is bigger than $address 2
# 				:         -1=$address 1 is smaller than $address 2
# Note			: None
# --------------------------------------------------------------
sub SRecComp ($$$) {
	my $addr1   = hex( shift() );
	my $s_addr2 = hex( shift() );
	my $e_addr2 = $s_addr2 + length( shift() )/2 - 1;
	my $result;
	
	if    ($addr1 < $s_addr2) { $result = -1;}
	elsif ($addr1 > $e_addr2) { $result =  1;}
	else                      { $result =  0;}
	return $result;
}
# --------------------------------------------------------------
# Function		: SRecHexStr($value, $size)
# Description	: This function returns hex format string with
# 				: specified length and without zero suppress.
# Arguments		: $value : value to be converted.
# 				: $size  : string length (1..8)
# Return		: $string: hex format string.
# Note			: None
# --------------------------------------------------------------
sub SRecHexStr ($$) {
	my $valu = shift;
	my $size = shift;
	my $hex_string = sprintf("%08X", $valu);
	return substr($hex_string, 8 - $size, $size);
}
# --------------------------------------------------------------
# Function		: SRecAddrStr($address, $rec_type)
# Description	: This function returns hex format string with
# 				: correspnding length with record type.
# Arguments		: $address  : record address
# 				: $rec_type : record type
# Return		: $string   : hex format string.
# Note			: None
# --------------------------------------------------------------
sub SRecAddrStr ($$) {
	my $valu = shift;
	my $type = shift;
	return SRecHexStr($valu, $adr_size{$type});
}
# --------------------------------------------------------------
return 1;
