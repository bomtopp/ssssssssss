/************************************************************************************************/
/* Customer		: �W�����W���[��																*/
/* Project Name	: SSFT																			*/
/* Theme Name	: PF																			*/
/*----------------------------------------------------------------------------------------------*/
/* File name	: SSFTxxx_main_Inc.h															*/
/* Description	: main �w�b�_																	*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          : RL78 Series																	*/
/*----------------------------------------------------------------------------------------------*/
/* Note 		: �C���N���[�h����w�b�_��OEM�ˑ�												*/
/*----------------------------------------------------------------------------------------------*/
/* Update by	: $Author: B08A000060 $													*/
/* Date 		: $Date: 2018/12/24 09:02:44ICT $												*/
/* Version		: $Revision: 1.2 $															*/
/************************************************************************************************/
#ifndef __SSFTXXX_MAIN_INC_H__
#define __SSFTXXX_MAIN_INC_H__

/* START_INC */
#include "SSFTSTD_MacroFunc.h"
#include "SSFTSTD_Type.h"

#include "SSFTSTD_Framework_ObjMng.h"
#include "SSFTSTD_RL78Wdt_Drv_001.h"
#include "SSFTSTD_RL78FreeRunTm_Drv_001.h"		/* FreeRunTimer�h���C�o */
#include "SSFTSTD_Framework_ObjMng_Config.h"

#include "SKAM0102_main.h"

/* END_INC */
#endif  /* __SSFTXXX_MAIN_INC_H__ */
