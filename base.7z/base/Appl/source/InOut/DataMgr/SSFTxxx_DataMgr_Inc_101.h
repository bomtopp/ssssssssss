/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SSFT																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: K.Wada																	*/
/* Date 			: 2018/03/13																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: �f�[�^�Ǘ��@�\�C���N���[�h�w�b�_											*/
/*************************************************************************************************/
#ifndef	__XXX_DATAMGR_INC_H__
#define	__XXX_DATAMGR_INC_H__

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	DATAMGR_C_INTERNAL

#include "SSFTSTD_Com_P5_101.h"
#include "SKAMxxx_DataMgr_Config_101.h"
#include "SKAM0087_DataMgr_IF_101.h"
#include "SKAM0087_DataMgr_Main_101.h"
#include "SKAM0087_DataMgr_P5_101.h"
#include "SSFTSTD_Nvm_IF.h"

#endif	/* DATAMGR_C_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	DATAMGR_MAIN_INTERNAL

#include "SKAMxxx_DataMgr_Config_101.h"
#include "SKAM0087_DataMgr_IF_101.h"
#include "SKAM0087_DataMgr_P5_101.h"
#include "SKAM0087_DataMgr_Main_101.h"
#include "SSFTSTD_OdoTrip_IF_101.h"
#if DATAMGR_SHIFT == DATAMGR_ENABLE
//#include "SSZVxxx_ShiftUp_IF.h"		/* ShiftTmming�҂� */
#endif
#include "SKAM0087_ProdTest_Main_102.h"
#include "SKAM0087_DispCtrl_Main_101.h"

#endif	/* DATAMGR_MAIN_INTERNAL */

#endif	/* __XXX_DATAMGR_INC_H__ */

