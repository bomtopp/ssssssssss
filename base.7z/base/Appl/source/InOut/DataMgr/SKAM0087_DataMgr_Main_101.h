/************************************************************************************************/
/* Customer		: �W�����W���[��																*/
/* Project Name	: SSFT																			*/
/* Theme Name	: PF																			*/
/*----------------------------------------------------------------------------------------------*/
/* File name	: SKAM0087_DataMgr_Main_101.h													*/
/* Description	: �f�[�^�Ǘ� ���W���[��															*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          : 2R�W��																		*/
/*----------------------------------------------------------------------------------------------*/
/* Update by	: $Author: Wada Kohei(42861) (A01A042861) $											*/
/* Date 		: $Date: 2018/03/14 15:38:20ICT $												*/
/* Version		: $Revision: 1.1 $																*/
/* Update by	: $Author: Wada Kohei(42861) (A01A042861) $														*/
/* Date 		: $Date: 2018/03/14 15:38:20ICT $												*/
/* Version		: $Revision: 1.1 $												*/
/* Update by	: $Author: Wada Kohei(42861) (A01A042861) $													*/
/* Date 		: $Date: 2018/03/14 15:38:20ICT $															*/
/* Version		: $Revision: 1.1 $												*/
/************************************************************************************************/
#ifndef DATAMGR_MAIN_H
#define DATAMGR_MAIN_H

/*** START_INC ***/
/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/


/*==============================================================================*/
/*	�}�N����`�i�@�\�����J)														*/
/*==============================================================================*/
/* ���� */


/*==============================================================================*/
/*	typedef��`(�@�\�����J)														*/
/*==============================================================================*/
/* ���� */


/*==============================================================================*/
/*	���JRAM��`�i�@�\�����J)													*/
/*==============================================================================*/
/* �e�@�\�̑召�`�F�b�N�G���[���(RAM�L����) */
#if DATAMGR_SHIFT == DATAMGR_ENABLE
extern UI_8 G_DataMgrShiftEcoErr;				/* SHIFT ECO */
extern UI_8 G_DataMgrShiftPwrErr;				/* SHIFT POWER */
/* ADD-S�yREQ-0101�z*/
extern UI_8 G_DataMgrShiftInitNormalErr;		/* SHIFT Init Normal */
extern UI_8 G_DataMgrShiftNormalErr;			/* SHIFT Normal */
extern UI_8 G_DataMgrIllLeverNormalErr;			/* SHIFT Ill Lever */
extern UI_8 G_DataMgrRevNormalErr;				/* SHIFT Rev */
#endif
extern UI_8 G_DataMgrBrightDutyErr;				/* BRIGHT DUTY */
extern UI_8 G_DataMgrWaterTempErr;				/* Water Temp */
/* ADD-E�yREQ-0101�z*/
extern UI_8 G_DataMgrFuelAdjAdErr;				/* FUEL �w�x����A/D�l */
extern UI_8 G_DataMgrVoltageIgnErr;				/* VOLTAGE IGN A/D�l */
extern UI_8 G_DataMgrVoltageBattErr;			/* VOLTAGE BATT A/D�l */

extern UI_8 G_DataMgrRngFuelTankCapaErr;		/* �召�`�F�b�N�G���[���(Range�̈��FUEL�^���N�e��) */
extern UI_8 G_DataMgrRngFuelTankAdErr;			/* �召�`�F�b�N�G���[���(Range�̈��FUEL A/D) */
extern UI_8 G_DataMgrOutTempErr;				/* �召�`�F�b�N�G���[���(OutTemp) */
extern UI_8 G_DataMgrBattIndicatorErr;			/* �召�`�F�b�N�G���[���(Batt Indicator) */
extern UI_8 G_DataMgrOilErr;					/* �召�`�F�b�N�G���[���(IndicatorAd) */
extern UI_8 G_DataMgrUpSwErr;					/* �召�`�F�b�N�G���[���(Up Sw) */
extern UI_8 G_DataMgrDownSwErr;					/* �召�`�F�b�N�G���[���(Down S��) */

/*==============================================================================*/
/*	�����萔(�@��ˑ���)														*/
/*==============================================================================*/

/* Range�̈��FUEL�^���N�e��*/
static const UI_16 C_DataMgrRngFuelTankCapaRangeChkTbl[DATAMGR_RNG_FUEL_TANK_CAPA_NUM] = 
{
 DATAMGR_INDEX_RANGE_CHAR_P16_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P15_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P14_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P13_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P12_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P11_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P10_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P09_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P08_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P07_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P06_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P05_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P04_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P03_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P02_QNTY,
 DATAMGR_INDEX_RANGE_CHAR_P01_QNTY
};
/* Range�̈��FUELA/D */
static const UI_16 C_DataMgrRngFuelTankAdRangeChkTbl[DATAMGR_RNG_FUEL_TANK_AD_NUM] = 
{
 DATAMGR_INDEX_RANGE_CHAR_P01_AD,
 DATAMGR_INDEX_RANGE_CHAR_P02_AD,
 DATAMGR_INDEX_RANGE_CHAR_P03_AD,
 DATAMGR_INDEX_RANGE_CHAR_P04_AD,
 DATAMGR_INDEX_RANGE_CHAR_P05_AD,
 DATAMGR_INDEX_RANGE_CHAR_P06_AD,
 DATAMGR_INDEX_RANGE_CHAR_P07_AD,
 DATAMGR_INDEX_RANGE_CHAR_P08_AD,
 DATAMGR_INDEX_RANGE_CHAR_P09_AD,
 DATAMGR_INDEX_RANGE_CHAR_P10_AD,
 DATAMGR_INDEX_RANGE_CHAR_P11_AD,
 DATAMGR_INDEX_RANGE_CHAR_P12_AD,
 DATAMGR_INDEX_RANGE_CHAR_P13_AD,
 DATAMGR_INDEX_RANGE_CHAR_P14_AD,
 DATAMGR_INDEX_RANGE_CHAR_P15_AD,
 DATAMGR_INDEX_RANGE_CHAR_P16_AD
};

#ifdef DATAMGR_C_INTERNAL
/*-------------------------------------------*/
/* �f�[�^�擾�p�e�[�u��(�w�x�␳�A�w�j�␳) */
/*-------------------------------------------*/
static const T_DataMgrOffset C_OffsetDataTbl[DATAMGR_OFFSET_NUM] = 
{
	/* SP �w�x�␳(�P��1) */
	{ DATAMGR_INDEX_SP_OFFSET1,			&G_DataMgrSpOffset1,		DATAMGR_SP_OFFSET_UNIT },
	/* SP �w�x�␳(�P��2) */
	{ DATAMGR_INDEX_SP_OFFSET2,			&G_DataMgrSpOffset2,		DATAMGR_SP_OFFSET_UNIT },
	/* SP�X�C�[�v�p�␳ */
	{ DATAMGR_INDEX_SWEEP_ADJ_SP,		&G_DataMgrSpSweepAdj,		DATAMGR_SP_OFFSET_UNIT },
	/* TA �w�x�␳ */
	{ DATAMGR_INDEX_TA_OFFSET,			&G_DataMgrTaOffset,			DATAMGR_TA_OFFSET_UNIT },
	/* TA�X�C�[�v�p�␳ */
	{ DATAMGR_INDEX_SWEEP_ADJ_TA,		&G_DataMgrTaSweepAdj,		DATAMGR_TA_OFFSET_UNIT },
	/* SP �w�j�␳ */
	{ DATAMGR_INDEX_SP_OFFSET_POINTER,	&G_DataMgrSpOffsetPointer,	DATAMGR_SP_OFFSET_POINTER_UNIT },
	/* TA �w�j�␳ */
	{ DATAMGR_INDEX_TA_OFFSET_POINTER,	&G_DataMgrTaOffsetPointer,	DATAMGR_TA_OFFSET_POINTER_UNIT }
};

/*-----------------------------*/
/* �召�`�F�b�N�pIndex�e�[�u�� */
/* [0]��[1]���E�E�E            */
/*-----------------------------*/
#if DATAMGR_SHIFT == DATAMGR_ENABLE
/* SHIFT ECO */
static const UI_16 C_DataMgrShiftEcoRangeChkTbl[4] = 
{
	DATAMGR_INDEX_SHIFT_ECO1_OFF,
	DATAMGR_INDEX_SHIFT_ECO1_ON,
	DATAMGR_INDEX_SHIFT_ECO2_OFF,
	DATAMGR_INDEX_SHIFT_ECO2_ON
};

/* SHIFT POWER */
static const UI_16 C_DataMgrShiftPwrRangeChkTbl[2] = 
{
	DATAMGR_INDEX_SHIFT_PWR_OFF,
	DATAMGR_INDEX_SHIFT_PWR_ON
};

/* ADD-S�yREQ-0101�z*/
/* SHIFT NORMAL */
static const UI_16 C_DataMgrShiftNormalRangeChkTbl[2] = 
{
	DATAMGR_INDEX_STORE_USER_SHIFT_ON,
	DATAMGR_INDEX_STORE_USER_SHIFT_OFF
};
/* ADD-E�yREQ-0101�z*/

/* ADD-S�yREQ-0104�z*/

/* SHIFT INIT NORMAL */
static const UI_16 C_DataMgrShiftInitNormalRangeChkTbl[2] = 
{
	DATAMGR_INDEX_INIT_USER_SHIFT_ON,
	DATAMGR_INDEX_INIT_USER_SHIFT_OFF
};

/* SHIFT ILL LEVEL */
static const UI_16 C_DataMgrShiftIllLevelRangeChkTbl[6] = 
{
	DATAMGR_INDEX_SHIFT_ILL_LEVEL1,
	DATAMGR_INDEX_SHIFT_ILL_LEVEL2,
	DATAMGR_INDEX_SHIFT_ILL_LEVEL3,
	DATAMGR_INDEX_SHIFT_ILL_LEVEL4,
	DATAMGR_INDEX_SHIFT_ILL_LEVEL5,
	DATAMGR_INDEX_SHIFT_ILL_LEVEL6
};

/* SHIFT REV */
static const UI_16 C_DataMgrShiftRevRangeChkTbl[2] = 
{
	DATAMGR_INDEX_SHIFT_REV_MIN,
	DATAMGR_INDEX_SHIFT_REV_MAX
};
/* ADD-E�yREQ-0104�z*/
#endif

/* ADD-S�yREQ-0104�z*/
/* BRIGHT DUTY */
#if 0
static const UI_16 C_DataMgrBrightDutyRangeChkTbl[6] = 
{
	DATAMGR_INDEX_BRIGHT_DUTY1,
	DATAMGR_INDEX_BRIGHT_DUTY2,
	DATAMGR_INDEX_BRIGHT_DUTY3,
	DATAMGR_INDEX_BRIGHT_DUTY4,
	DATAMGR_INDEX_BRIGHT_DUTY5,
	DATAMGR_INDEX_BRIGHT_DUTY6
};
#endif
/* ADD-E�yREQ-0104�z*/

/* ADD-S�yREQ-0101�z*/
	/* WATER TEMP */
static const UI_16 C_DataMgrWaterTempRangeChkTbl[6] = 
{
//	DATAMGR_INDEX_HTW_RELEASE_AD,
//	DATAMGR_INDEX_HTW_DETECT_AD
	DATAMGR_INDEX_WTEMP_CHNG_CHAR_1,
	DATAMGR_INDEX_WTEMP_CHNG_CHAR_2,
	DATAMGR_INDEX_WTEMP_CHNG_CHAR_3,
	DATAMGR_INDEX_WTEMP_CHNG_CHAR_4,
	DATAMGR_INDEX_WTEMP_CHNG_CHAR_5,
	DATAMGR_INDEX_WTEMP_CHNG_CHAR_6
};

static const UI_32 C_DataMgrWaterTempRangeDefTbl[2] = 
{
	0x8CU,
	0x91U
};
/* ADD-E�yREQ-0101�z*/

/* FUEL A/D�l */
static const UI_16 C_DataMgrFuelAdjAdRangeChkTbl[8] = 
{
	DATAMGR_INDEX_FUEL_SHORT_THRESHOLD,
#if DATAMGR_FUEL_SEG_NUM > 5
	DATAMGR_INDEX_FUEL_ADJ_AD6,
#endif
#if DATAMGR_FUEL_SEG_NUM > 4
	DATAMGR_INDEX_FUEL_ADJ_AD5,
#endif
	DATAMGR_INDEX_FUEL_ADJ_AD4,
	DATAMGR_INDEX_FUEL_ADJ_AD3,
	DATAMGR_INDEX_FUEL_ADJ_AD2,
	DATAMGR_INDEX_FUEL_ADJ_AD1,
	DATAMGR_INDEX_FUEL_OPEN_THRESHOLD
};

/* VOLTAGE BATT A/D�l */
static const UI_16 C_DataMgrVoltageBattRangeChkTbl[4] = 
{
	DATAMGR_INDEX_VOLTAGE_LO_DETECTION,
	DATAMGR_INDEX_VOLTAGE_LO_RLSE,
	DATAMGR_INDEX_VOLTAGE_HI_RLSE,
	DATAMGR_INDEX_VOLTAGE_HI_DETECTION
};

/* OUT TEMP */
static const UI_16 C_DataMgrOutTempRangeChkTbl[2] = 
{
	DATAMGR_INDEX_OTEMP_WARN_DETECT,
	DATAMGR_INDEX_OTEMP_WARN_CANCEL
};
/* VOLTAGE INDICATOR */
static const UI_16 C_DataMgrBattIndicatorRangeChkTbl[3] = 
{
 DATAMGR_INDEX_BATT_IND_LO_DETECTION,
 DATAMGR_INDEX_BATT_IND_LO_RLSE,
 DATAMGR_INDEX_BATT_IND_HI_DETECTION

};
/* INDICATOR AD */
static const UI_16 C_DataMgrIndicatorAdRangeChkTbl[2] = 
{
 DATAMGR_INDEX_OIL_IND_AD_DETECTION,
 DATAMGR_INDEX_OIL_IND_AD_RLSE
};
/* UP SWITCH */
static const UI_16 C_DataMgrUpSwRangeChkTbl[2] = 
{
 DATAMGR_INDEX_UP_SW_ON_AD,
 DATAMGR_INDEX_UP_SW_OFF_AD
};
/* DOWN SWITCH */
static const UI_16 C_DataMgrDownSwRangeChkTbl[2] = 
{
 DATAMGR_INDEX_DOWN_SW_ON_AD,
 DATAMGR_INDEX_DOWN_SW_OFF_AD
};


/*------------------------*/
/* �召�`�F�b�N�p�e�[�u�� */
/*------------------------*/
static const T_DataMgrRangeChk C_RangeChkTbl[] = 
{
	/* �i���Ӂj�`�F�b�N���ʊi�[��̃G���[RAM�͕K���ʂ�RAM���g�p���邱�ƁB */
	/* 			���ʂ�RAM��ݒ肷��ƁA�G���[��񂪏㏑������Ă��܂��܂� */
	/* �`�F�b�N�Ώۂ�Index�e�[�u��			�`�F�b�N���ʊi�[��		�f�[�^�� */
#if DATAMGR_SHIFT == DATAMGR_ENABLE
	/* SHIFT ECO */
	{ &C_DataMgrShiftEcoRangeChkTbl[0],			&G_DataMgrShiftEcoErr,		4U,		1U},
	/* SHIFT POWER */
	{ &C_DataMgrShiftPwrRangeChkTbl[0],			&G_DataMgrShiftPwrErr,		2U,		1U},
/* ADD-S�yREQ-0101�z*/
	/* SHIFT NORMAL */
	{ &C_DataMgrShiftNormalRangeChkTbl[0],		&G_DataMgrShiftNormalErr,	2U,		1U},
	{ &C_DataMgrShiftInitNormalRangeChkTbl[0],	&G_DataMgrShiftInitNormalErr,	2U,		1U},		/* ADD-SE�yREQ-0104�z */
/* ADD-E�yREQ-0101�z*/
/* ADD-S�yREQ-0104�z*/
	/* SHIFT ILL LEVER */
	{ &C_DataMgrShiftIllLevelRangeChkTbl[0],	&G_DataMgrIllLeverNormalErr,	6U,		1U},
	{ &C_DataMgrShiftRevRangeChkTbl[0],			&G_DataMgrRevNormalErr,			2U,		1U},
/* ADD-E�yREQ-0104�z*/
#endif
#if 0
	{ &C_DataMgrBrightDutyRangeChkTbl[0],	&G_DataMgrBrightDutyErr,	6U,		1U},		/* ADD-SE�yREQ-0104�z */
#endif
/* ADD-S�yREQ-0101�z*/
	/* WATER TEMP */
	{ &C_DataMgrWaterTempRangeChkTbl[0],		&G_DataMgrWaterTempErr,		6U,		1U},

	/* Range�̈��FUEL�^���N�e��*/
	{ &C_DataMgrRngFuelTankCapaRangeChkTbl[0], &G_DataMgrRngFuelTankCapaErr, 16U,		2U },
	/* Range�̈��FUELA/D */
	{ &C_DataMgrRngFuelTankAdRangeChkTbl[0], &G_DataMgrRngFuelTankAdErr, 16U,		2U },
	/* OUT TEMP */
	{ &C_DataMgrOutTempRangeChkTbl[0], &G_DataMgrOutTempErr, 2U,		1U },
	/* VOLTAGE INDICATOR*/
	{ &C_DataMgrBattIndicatorRangeChkTbl[0], &G_DataMgrBattIndicatorErr, 3U,		2U },
	/* INDICATOR AD */
	{ &C_DataMgrIndicatorAdRangeChkTbl[0], &G_DataMgrOilErr, 2U,		2U },
	/* UP SWITCH */
	{ &C_DataMgrUpSwRangeChkTbl[0], &G_DataMgrUpSwErr, 2U,		2U },
	/* DOWN SWITCH */
	{ &C_DataMgrDownSwRangeChkTbl[0], &G_DataMgrDownSwErr, 2U,		2U },

	/* ADD-E�yREQ-0101�z*/
	/* FUEL A/D�l */
	{ &C_DataMgrFuelAdjAdRangeChkTbl[0],		&G_DataMgrFuelAdjAdErr,		(DATAMGR_FUEL_SEG_NUM + 2U),		2U},
	/* VOLTAGE BATT A/D�l */
	{ &C_DataMgrVoltageBattRangeChkTbl[0],		&G_DataMgrVoltageBattErr,	2U,		2U}
};

/* ADD-S�yREQ-0101�z*/
static const T_DataMgrRangeDefault C_RangeDefTbl[] = 
{
	/* WATER TEMP */
	{ &C_DataMgrWaterTempRangeChkTbl[0],		&C_DataMgrWaterTempRangeDefTbl[0],		RANGE_CHK_TBL_BYTE,		2U }
};
/* ADD-E�yREQ-0101�z*/
#endif

/* ADD-S�yREQ-0102�z*/
/*----------------------------------------------------------------------------------------------*/
/* definition of data table																		*/
/*----------------------------------------------------------------------------------------------*/
#if 0
static const T_DataMgrApplDataInterface C_DataMgrApplDataInterfaceTbl[] = 
{
	{	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_PCB_ASSY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* IMMB_FUNC  */
//	{	RANGE_CHK_TBL_NONE_X,	0U	},	/* VAR_ODO_UNIT_YA */			/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE_X,	1U	},	/* VAR_GEAR_DISP_MODE */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE_X,	2U	},	/* VAR_FUEL_UNIT_GAL_MODE */	/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE_X,	3U	},	/* VAR_YA_COMMUNICATION */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE_X,	4U	},	/* VAR_SHIFT_MODE_ENA */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE_X,	5U	},	/* VAR_OPEN_ANIMATION */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE_X,	6U	},	/* VAR_ENG_EUR4_ENA */			/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE_X,	7U	},	/* VAR_VVA_ENA */				/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_TA_REV_MAX */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_TA_BAR_MODE */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_ODO_INTEGRATED_RATE */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* MOVING_JDG_SP_KM  */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_OUT_OFFSET  */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_DELAY */
	{	RANGE_CHK_TBL_BYTE,		0U	},	/* SP_POINTER_OFFSET */
	{	RANGE_CHK_TBL_BYTE,		1U	},	/* SP_SLOPE_ADJ */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_DGTL_CHNG_RATE_KM */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_DGTL_CHNG_RATE_MPH */
//	{	RANGE_CHK_TBL_BYTE,		0U	},	/* SP_COMMUNICATION_BOX */
//	{	RANGE_CHK_TBL_BYTE,		1U	},	/* BK6_SP_DISPLAY_HOLD_TIME */
//	{	RANGE_CHK_TBL_BYTE,		2U	},	/* SP_ZERODISP_KM */
//	{	RANGE_CHK_TBL_BYTE,		3U	},	/* SP_ZERODISP_MPH */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_ANLG_IN_ADJ1_KM */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_ANLG_IN_ADJ2_KM */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_ANLG_IN_ADJ3_KM */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_ANLG_IN_ADJ4_KM */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_ANLG_OUT_ADJ1_KM */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_ANLG_OUT_ADJ2_KM */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_ANLG_OUT_ADJ3_KM */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* SP_ANLG_OUT_ADJ4_KM */
//	{	RANGE_CHK_TBL_WORD,		9U	},	/* SP_DGTL_IN_ADJ1_MPH */
//	{	RANGE_CHK_TBL_WORD,		10U	},	/* SP_DGTL_IN_ADJ2_MPH */
//	{	RANGE_CHK_TBL_WORD,		11U	},	/* SP_DGTL_IN_ADJ3_MPH */
//	{	RANGE_CHK_TBL_WORD,		12U	},	/* SP_DGTL_IN_ADJ4_MPH */
//	{	RANGE_CHK_TBL_WORD,		13U	},	/* SP_DGTL_OUT_ADJ1_MPH */
//	{	RANGE_CHK_TBL_WORD,		14U	},	/* SP_DGTL_OUT_ADJ2_MPH */
//	{	RANGE_CHK_TBL_WORD,		15U	},	/* SP_DGTL_OUT_ADJ3_MPH */
//	{	RANGE_CHK_TBL_WORD,		16U	},	/* SP_DGTL_OUT_ADJ4_MPH */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_CHNG_RATE */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_DELAY */
	{	RANGE_CHK_TBL_BYTE,		2U	},	/* TA_POINTER_OFFSET */
	{	RANGE_CHK_TBL_BYTE,		3U	},	/* TA_SLOPE_ADJ */
//	{	RANGE_CHK_TBL_BYTE,		4U	},	/* TA_COMMUNICATION_BOX */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IN_ADJ1 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IN_ADJ2 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IN_ADJ3 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IN_ADJ4 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_OUT_ADJ1 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_OUT_ADJ2 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_OUT_ADJ3 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_OUT_ADJ4 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE */		/* CHG-SE�yREQ-0103�z*/
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE1_START */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE1_RANGE */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE1_DELAY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE234_RANGE */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE2_DELAY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_CUT_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_SHORT_AD */
//	{	RANGE_CHK_TBL_BYTE,		10U	},	/* FUEL_LFW_ON_DLY */
//	{	RANGE_CHK_TBL_BYTE,		11U	},	/* FUEL_LFW_OFF_DLY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_DISP_TIME_YA */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_CHNG_AD1 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_CHNG_AD2 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_CHNG_AD3 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_CHNG_AD4 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_CHNG_AD5 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_CHNG_AD6 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* HTW_DETECT_AD */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* HTW_RELEASE_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* INSTFUEL_DISP_PERIOD */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INSTFUEL_DISP_KM */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INSTFUEL_DISP_MILE */
//	{	RANGE_CHK_TBL_BYTE,		14U	},	/* AVGFUEL_DISP_DIST */			/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_BYTE,		15U	},	/* AVGFUEL_DISP_START */		/* CHG-SE�yREQ-0103�z*/
	{	RANGE_CHK_TBL_NONE,		0U	},	/* AVE_FUEL_DISP_CYCLE  */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* INST_FUEL_CALC_DATA_CNT */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_QNTY_FULL */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_QNTY_INVALID */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_QNTY_FULL_FLOCK */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_SAMPLING_COUNT_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_SAMPLE_COUNT_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_FUEL_CALC_CYCLE */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_DISP_PERIOD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P01_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P02_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P03_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P04_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P05_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P06_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P07_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P08_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P09_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P10_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P11_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P12_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P13_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P14_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P15_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P16_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P01_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P02_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P03_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P04_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P05_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P06_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P07_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P08_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P09_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P10_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P11_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P12_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P13_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P14_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P15_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* RANGE_CHAR_P16_QNTY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_DISP_PERIOD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_1 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_2 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_3 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_4 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_5 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_6 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OTEMP_DISP_PERIOD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OTEMP_UPDATE_ELAP_TIME */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OTEMP_UPDATA_JDG_SP_KM */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OTEMP_INC_DLY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OTEMP_DEC_DLY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OTEMP_DISP_ADJ */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OTEMP_WARN_DETECT */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OTEMP_WARN_CANCEL */
	{	RANGE_CHK_TBL_WORD,		0U	},	/* VOLTAGE_LO_DETECTION */
	{	RANGE_CHK_TBL_WORD,		1U	},	/* VOLTAGE_LO_RLSE */
	{	RANGE_CHK_TBL_WORD,		2U	},	/* BATT_IND_HI_DETECTION */
	{	RANGE_CHK_TBL_WORD,		3U	},	/* BATT_IND_LO_RLSE */
	{	RANGE_CHK_TBL_WORD,		4U	},	/* BATT_IND_LO_DETECTION */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* BATT_IND_DLY_DETECTION */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* BATT_IND_DLY_RLSE */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OIL_IND_DLY_DETECTION */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* OIL_IND_DLY_RLSE */
	{	RANGE_CHK_TBL_WORD,		5U	},	/* OIL_IND_AD_DETECTION */
	{	RANGE_CHK_TBL_WORD,		6U	},	/* OIL_IND_AD_RLSE */
	{	RANGE_CHK_TBL_WORD,		7U	},	/* UP_SW_ON_AD */
	{	RANGE_CHK_TBL_WORD,		8U	},	/* UP_SW_OFF_AD */
	{	RANGE_CHK_TBL_WORD,		9U	},	/* DOWN_SW_ON_AD */
	{	RANGE_CHK_TBL_WORD,		10U	},	/* DOWN_SW_OFF_AD */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* IMMB_AD */
	{	RANGE_CHK_TBL_BYTE,		4U	},	/* SWEEP_ADJ_SP */
	{	RANGE_CHK_TBL_BYTE,		5U	},	/* SWEEP_ADJ_TA */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* USR_SETTING1_CLK_UNIT */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* USR_SETTING1_UNIT */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* USR_SETTING2_CLK_UNIT */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* USR_SETTING2_UNIT */
//	{	RANGE_CHK_TBL_BYTE,		16U	},	/* AVGSP_DISP_PERIOD */			/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_WORD,		33U	},	/* AVGSP_REV_JDG */				/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_WORD,		34U	},	/* AVESP_DGTL_OUT_ADJ1_KM */
//	{	RANGE_CHK_TBL_WORD,		35U	},	/* AVESP_DGTL_OUT_ADJ2_KM */
//	{	RANGE_CHK_TBL_WORD,		36U	},	/* AVESP_DGTL_OUT_ADJ3_KM */
//	{	RANGE_CHK_TBL_WORD,		37U	},	/* AVESP_DGTL_OUT_ADJ4_KM */
//	{	RANGE_CHK_TBL_WORD,		38U	},	/* AVESP_DGTL_OUT_ADJ1_MPH */
//	{	RANGE_CHK_TBL_WORD,		39U	},	/* AVESP_DGTL_OUT_ADJ2_MPH */
//	{	RANGE_CHK_TBL_WORD,		40U	},	/* AVESP_DGTL_OUT_ADJ3_MPH */
//	{	RANGE_CHK_TBL_WORD,		41U	},	/* AVESP_DGTL_OUT_ADJ4_MPH */
//	{	RANGE_CHK_TBL_BYTE,		17U	},	/* SHIFT_ILL_LEVEL1 */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_BYTE,		18U	},	/* SHIFT_ILL_LEVEL2 */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_BYTE,		19U	},	/* SHIFT_ILL_LEVEL3 */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_BYTE,		20U	},	/* SHIFT_ILL_LEVEL4 */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_BYTE,		21U	},	/* SHIFT_ILL_LEVEL5 */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_BYTE,		22U	},	/* SHIFT_ILL_LEVEL6 */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_BYTE,		23U	},	/* SHIFT_REV_ON_HYS */
//	{	RANGE_CHK_TBL_BYTE,		24U	},	/* SHIFT_REV_OFF_HYS */
//	{	RANGE_CHK_TBL_BYTE,		25U	},	/* SHIFT_REV_MIN */
//	{	RANGE_CHK_TBL_BYTE,		26U	},	/* SHIFT_REV_MAX */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INIT_USER_FUEL_UNIT */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INIT_USER_ODO_UNIT */
//	{	RANGE_CHK_TBL_BYTE,		27U	},	/* INIT_USER_SHIFT_MODE */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_BYTE,		28U	},	/* INIT_USER_SHIFT_ON */
//	{	RANGE_CHK_TBL_BYTE,		29U	},	/* INIT_USER_SHIFT_OFF */
//	{	RANGE_CHK_TBL_BYTE,		30U	},	/* INIT_USER_SHIFT_ILL */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INIT_BRIGHT_SETTING_STATE */		/* ADD-SE�yREQ-0101�z*/
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INIT_USER_CHAR1 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INIT_USER_CHAR2 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INIT_USER_CHAR3 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INIT_USER_CHAR4 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INIT_USER_CHAR5 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* INIT_USER_CHAR6 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* BRIGHT_DUTY1 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* BRIGHT_DUTY2 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* BRIGHT_DUTY3 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* BRIGHT_DUTY4 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* BRIGHT_DUTY5 */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* BRIGHT_DUTY6 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_1 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_2 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_3 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_4 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_5 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_6 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_7 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_8 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_9 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_10 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_11 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_12 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_13 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_14 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_15 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_16 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_17 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_18 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_19 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_20 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_21 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_22 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_23 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_24 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_25 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_26 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_27 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_28 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_29 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_30 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_31 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_32 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_1 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_1_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_2 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_2_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_3 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_3_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_4 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_4_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_5 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_5_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_6 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_6_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_7 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_7_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_8 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_8_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_9 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_9_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_10 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_10_PARITY */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATE_TRIP1 */		/* CHG-SE�yREQ-0103�z*/
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIP1 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATE_TRIP2 */		/* CHG-SE�yREQ-0103�z*/
	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIP2 */
//	{	RANGE_CHK_TBL_DWORD,	2U	},	/* ODO_INTEGRATE_TRIPF */		/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIPF */
//	{	RANGE_CHK_TBL_DWORD,	3U	},	/* ODO_INTEGRATE_TRIPF_LFW */	/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIPF_LFW */
//	{	RANGE_CHK_TBL_BYTE,		31U	},	/* TRIPF_RESERVE_DELAY_COUNT */	/* CHG-SE�yREQ-0103�z*/
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* TRIPF_RESERVE_MODE */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* STORE_USER_DISP_MODE */
//	{	RANGE_CHK_TBL_NONE,		0U	},	/* STORE_USER_DISP_MODE_OLD */
//	{	RANGE_CHK_TBL_X,		0U	},	/* STORE_USER_FUEL_UNIT */
//	{	RANGE_CHK_TBL_X,		1U	},	/* STORE_USER_ODO_UNIT */
//	{	RANGE_CHK_TBL_BYTE,		32U	},	/* STORE_USER_SHIFT_MODE */
//	{	RANGE_CHK_TBL_BYTE,		33U	},	/* STORE_USER_SHIFT_ON */
//	{	RANGE_CHK_TBL_BYTE,		34U	},	/* STORE_USER_SHIFT_OFF */
//	{	RANGE_CHK_TBL_BYTE,		35U	},	/* STORE_USER_SHIFT_ILL */
//	{	RANGE_CHK_TBL_BYTE,		36U	},	/* BACKLIGHT_SETTING_STATE */
//	{	RANGE_CHK_TBL_BYTE,		37U	},	/* STORE_USER_CHAR1 */
//	{	RANGE_CHK_TBL_BYTE,		38U	},	/* STORE_USER_CHAR2 */
//	{	RANGE_CHK_TBL_BYTE,		39U	},	/* STORE_USER_CHAR3 */
//	{	RANGE_CHK_TBL_BYTE,		40U	},	/* STORE_USER_CHAR4 */
//	{	RANGE_CHK_TBL_BYTE,		41U	},	/* STORE_USER_CHAR5 */
//	{	RANGE_CHK_TBL_BYTE,		42U	},	/* STORE_USER_CHAR6 */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* EEP_VER_FORMAT */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* EEP_VER_DATA */
	{	RANGE_CHK_TBL_NONE,		0U	},	/* EEP_VER_MAP */
	{	RANGE_CHK_TBL_NONE,		0U	}	/* END_NVMID_INDEX */
};

/* ADD-S�yREQ-0103�z*/
static const UI_8 C_NoneXTbl[] = 
{
	{	0x00	},	/* VAR_ODO_UNIT_YA */
	{	0x00	},	/* VAR_GEAR_DISP_MODE */
	{	0x00	},	/* VAR_FUEL_UNIT_GAL_MODE */
	{	0x00	},	/* VAR_YA_COMMUNICATION */
	{	0x00	},	/* VAR_SHIFT_MODE_ENA */
	{	0x00	},	/* VAR_OPEN_ANIMATION */
	{	0x00	},	/* VAR_ENG_EUR4_ENA */
	{	0x00	},	/* VAR_VVA_ENA */
	{	0x00	}	/* TA_DGTL_IDLE */
};
/* ADD-E�yREQ-0103�z*/

static const T_DataMgrApplRangeCheckUix C_RangeCheckXTbl[] = 
{
//	{	0x01U,	0x02U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_FUEL_UNIT	},	/* STORE_USER_FUEL_UNIT */
//	{	0x01U,	0x02U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_ODO_UNIT	}	/* STORE_USER_ODO_UNIT */
	{	0x00U,	0x00U,	RANGE_CHK_TYPE_DEF_0,	0x00U	}	/* dummy */
};

static const T_DataMgrApplRangeCheckUi8 C_RangeCheck8Tbl[] = 
{
	{	0xDDU,	0x23U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SP_POINTER_OFFSET */
	{	0x8EU,	0x72U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SP_SLOPE_ADJ */
	{	0xDDU,	0x23U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* TA_POINTER_OFFSET */
	{	0x8EU,	0x72U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* TA_SLOPE_ADJ */
	{	0x8EU,	0x72U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SWEEP_ADJ_SP */
	{	0x8EU,	0x72U,	RANGE_CHK_TYPE_DEF_0,	0x00U	}	/* SWEEP_ADJ_TA */
//	{	0x10U,	0x60U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SP_COMMUNICATION_BOX */
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* BK6_SP_DISPLAY_HOLD_TIME */
//	{	0x00U,	0x0AU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SP_ZERODISP_KM */
//	{	0x00U,	0x0AU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SP_ZERODISP_MPH */
//	{	0x00U,	0x03U,	RANGE_CHK_TYPE_DEF_1,	0x00U	},	/* TA_COMMUNICATION_BOX */
//	{	0x01U,	0x14U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* TA_DGTL_IDLE1_START */
//	{	0x01U,	0x0AU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* TA_DGTL_IDLE1_RANGE */
//	{	0x04U,	0xFEU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* TA_DGTL_IDLE1_DELAY */
//	{	0x01U,	0x0AU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* TA_DGTL_IDLE234_RANGE */
//	{	0x04U,	0xFEU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* TA_DGTL_IDLE2_DELAY */
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* FUEL_LFW_ON_DLY */
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* FUEL_LFW_OFF_DLY */
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* FUEL_DISP_TIME_YA */
//	{	0x01U,	0xF0U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* INSTFUEL_DISP_PERIOD */		/* ADD-SE�yREQ-0103�z*/
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* AVGFUEL_DISP_DIST */			/* ADD-SE�yREQ-0103�z*/
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* AVGFUEL_DISP_START */		/* ADD-SE�yREQ-0103�z*/
//	{	0x01U,	0xF0U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* AVGSP_DISP_PERIOD */			/* ADD-SE�yREQ-0103�z*/
/* ADD-S�yREQ-0103�z*/
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_ILL_LEVEL1 */
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_ILL_LEVEL2 */
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_ILL_LEVEL3 */
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_ILL_LEVEL4 */
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_ILL_LEVEL5 */
//	{	0x01U,	0xFFU,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_ILL_LEVEL6 */
//	{	0x00U,	0x04U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_REV_ON_HYS */
//	{	0x00U,	0x04U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_REV_OFF_HYS */
/* ADD-E�yREQ-0103�z*/
//	{	0x14U,	0x34U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_REV_MIN */
//	{	0x14U,	0x34U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* SHIFT_REV_MAX */
//	{	0x01U,	0x03U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* INIT_USER_SHIFT_MODE */		/* ADD-SE�yREQ-0103�z*/
//	{	0x14U,	0x34U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* INIT_USER_SHIFT_ON */
//	{	0x14U,	0x34U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* INIT_USER_SHIFT_OFF */
//	{	0x01U,	0x06U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* INIT_USER_SHIFT_ILL */		/* ADD-SE�yREQ-0103�z*/
//	{	0x00U,	0x01U,	RANGE_CHK_TYPE_DEF_0,	0x00U	},	/* TRIPF_RESERVE_DELAY_COUNT */	/* ADD-SE�yREQ-0103�z*/
//	{	0x01U,	0x03U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_SHIFT_MODE	},	/* STORE_USER_SHIFT_MODE */
//	{	0x14U,	0x34U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_SHIFT_ON	},	/* STORE_USER_SHIFT_ON */
//	{	0x14U,	0x34U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_SHIFT_OFF	},	/* STORE_USER_SHIFT_OFF */
//	{	0x01U,	0x06U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_SHIFT_ILL	},	/* STORE_USER_SHIFT_ILL */
//	{	0x01U,	0x06U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_BRIGHT_SETTING_STATE	},	/* BACKLIGHT_SETTING_STATE */
//	{	0x01U,	0x26U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_CHAR1	},	/* STORE_USER_CHAR1 */
//	{	0x01U,	0x26U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_CHAR2	},	/* STORE_USER_CHAR2 */
//	{	0x01U,	0x26U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_CHAR3	},	/* STORE_USER_CHAR3 */
//	{	0x01U,	0x26U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_CHAR4	},	/* STORE_USER_CHAR4 */
//	{	0x01U,	0x26U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_CHAR5	},	/* STORE_USER_CHAR5 */
//	{	0x01U,	0x26U,	RANGE_CHK_TYPE_DEF_2,	DATAMGR_INDEX_INIT_USER_CHAR6	}	/* STORE_USER_CHAR6 */
};

static const T_DataMgrApplRangeCheckUi16 C_RangeCheck16Tbl[] = 
{
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* VOLTAGE_LO_DETECTION */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0001U	},	/* VOLTAGE_LO_RLSE */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x03FFU	},	/* BATT_IND_HI_DETECTION */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0001U	},	/* BATT_IND_LO_RLSE */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* BATT_IND_LO_DETECTION */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* OIL_IND_AD_DETECTION */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0001U	},	/* OIL_IND_AD_RLSE */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* UP_SW_ON_AD */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x03FFU	},	/* UP_SW_OFF_AD */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* DOWN_SW_ON_AD */
	{	0x0000U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x03FFU	},	/* DOWN_SW_OFF_AD */
//	{	0x000AU,	0xFEFFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* VAR_ODO_INTEGRATED_RATE */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_IN_ADJ1_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_IN_ADJ2_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_IN_ADJ3_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_IN_ADJ4_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_OUT_ADJ1_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_OUT_ADJ2_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_OUT_ADJ3_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_OUT_ADJ4_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_IN_ADJ1_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_IN_ADJ2_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_IN_ADJ3_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_IN_ADJ4_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_OUT_ADJ1_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_OUT_ADJ2_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_OUT_ADJ3_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* SP_DGTL_OUT_ADJ4_MPH */
//	{	0x0001U,	0x4E20U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* TA_DGTL_IN_ADJ1 */
//	{	0x0001U,	0x4E20U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* TA_DGTL_IN_ADJ2 */
//	{	0x0001U,	0x4E20U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* TA_DGTL_IN_ADJ3 */
//	{	0x0001U,	0x4E20U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* TA_DGTL_IN_ADJ4 */
//	{	0x0001U,	0x4E20U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* TA_DGTL_OUT_ADJ1 */
//	{	0x0001U,	0x4E20U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* TA_DGTL_OUT_ADJ2 */
//	{	0x0001U,	0x4E20U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* TA_DGTL_OUT_ADJ3 */
//	{	0x0001U,	0x4E20U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* TA_DGTL_OUT_ADJ4 */
//	{	0x0001U,	0x03FEU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* FUEL_CUT_AD */
//	{	0x0001U,	0x03FEU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* FUEL_SHORT_AD */
//	{	0x0001U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* FUEL_CHNG_AD1 */
//	{	0x0001U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* FUEL_CHNG_AD2 */
//	{	0x0001U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* FUEL_CHNG_AD3 */
//	{	0x0001U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* FUEL_CHNG_AD4 */
//	{	0x0001U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* FUEL_CHNG_AD5 */
//	{	0x0001U,	0x03FFU,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* FUEL_CHNG_AD6 */
//	{	0x0001U,	0x00C8U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* AVGSP_REV_JDG */				/* ADD-SE�yREQ-0103�z*/
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* AVESP_DGTL_OUT_ADJ1_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* AVESP_DGTL_OUT_ADJ2_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* AVESP_DGTL_OUT_ADJ3_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* AVESP_DGTL_OUT_ADJ4_KM */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* AVESP_DGTL_OUT_ADJ1_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* AVESP_DGTL_OUT_ADJ2_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	},	/* AVESP_DGTL_OUT_ADJ3_MPH */
//	{	0x0001U,	0x0C80U,	RANGE_CHK_TYPE_DEF_0,	0x0000U	}	/* AVESP_DGTL_OUT_ADJ4_MPH */
};

static const T_DataMgrApplRangeCheckUi32 C_RangeCheck32Tbl[] = 
{
//	{	0x00000000UL,	0x0018B820UL,	RANGE_CHK_TYPE_DEF_0,	0x00000000UL	},	/* ODO_INTEGRATE_TRIP1 */		/* ADD-SE�yREQ-0103�z*/
//	{	0x00000000UL,	0x0018B820UL,	RANGE_CHK_TYPE_DEF_0,	0x00000000UL	},	/* ODO_INTEGRATE_TRIP2 */		/* ADD-SE�yREQ-0103�z*/
//	{	0x00000000UL,	0x0018B820UL,	RANGE_CHK_TYPE_DEF_0,	0x00000000UL	},	/* ODO_INTEGRATE_TRIPF */		/* ADD-SE�yREQ-0103�z*/
//	{	0x00000000UL,	0x0018B820UL,	RANGE_CHK_TYPE_DEF_0,	0x00000000UL	},	/* ODO_INTEGRATE_TRIPF_LFW */	/* ADD-SE�yREQ-0103�z*/
	{	0x00000000UL,	0xFFFFFFFFUL,	RANGE_CHK_TYPE_DEF_0,	0x00000000UL	}	/* dummy */
};
/* ADD-E�yREQ-0102�z*/
#endif
/*==============================================================================*/
/*	�֐��������ߐ錾�i�t�����g�G���h)											*/
/*==============================================================================*/
UI_32 DataMgr_GetOdo(void);				/* �I�h�l�擾���� */
#if DATAMGR_PULSE == DATAMGR_ENABLE
UI_16 DataMgr_GetOdoPulse(void);		/* �I�h�����p���X�擾���� */
#endif
#if DATAMGR_SHIFT == DATAMGR_ENABLE
UI_8 DataMgr_GetShiftUpMode(void);		/* �V�t�g�A�b�v�C���W�P�[�^�\�����[�h�擾���� */
#endif

/* ���Y�ݔ��֘A */
UI_32 DataMgr_GetWriteData(void);		/* �������݃f�[�^�擾���� */
UI_16 DataMgr_GetNvmAddr(void);			/* �������݃A�h���X�擾���� */
UI_16 DataMgr_GetNvmId(void);			/* NVM ID�擾���� */
UI_8 DataMgr_GetNvmDataType(void);		/* NVM DataType�擾���� */
UI_8 DataMgr_GetNvmDataSize(void);		/* NVM DataSize�擾���� */
UI_8 DataMgr_ChkAddrBlockSect(UI_16 addr);	/* �u���b�N�̈攻�菈�� */


/*==============================================================================*/
/*	�֐��������ߐ錾�i�o�b�N�G���h)												*/
/*==============================================================================*/
void DataMgr_SetDispModeOdo(void);								/* �\����ʏ��ʒm���� */
void DataMgr_SetOdoData(void);									/* �I�h�l�ݒ菈�� */
void DataMgr_SetOdoPulse(void);									/* �I�h�����p���X�ݒ菈�� */
void DataMgr_SetTripData(void);									/* Trip�ݒ菈�� */
void DataMgr_OdoResetEnd(UI_8 err_info);						/* �I�h�������I���ʒm���� */
void DataMgr_NvmWriteEnd(UI_16 read_data, UI_16 success);		/* 1Word�������ݏI���ʒm���� */
void DataMgr_NvmReadEnd(UI_16 read_data);						/* 1Word�ǂݍ��ݏI���ʒm���� */
void DataMgr_NvmPidWriteEnd(UI_8 err_info);						/* PID�w�菑�����ݏI���ʒm���� */
void DataMgr_ContinuousRead(const UI_16 *address, UI_16 data);	/* 1Word�A���ǂݍ��ݒʒm���� */

#endif
