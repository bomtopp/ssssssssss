/************************************************************************************************/
/* Customer			: -																			*/
/* Model(Theme No.)	: SSFT																		*/
/*----------------------------------------------------------------------------------------------*/
/* CPU				: -																			*/
/* Date				: 2013/05/05																*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Masato Koide																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/*----------------------------------------------------------------------------------------------*/
/* update by		: 35973_y_sato																*/
/* date				: 2016/11/02																*/
/************************************************************************************************/
#ifndef SSFTXXX_NVM_CONFIG_H
#define SSFTXXX_NVM_CONFIG_H

/************************************************************************************************/
/* Definition of Macro																			*/
/************************************************************************************************/
/*----------------------------------------------------------------------------------------------*/
/* Version information																			*/
/*----------------------------------------------------------------------------------------------*/
#define NVM_CONFIG_H_VERSION			( 0x0203U )				/* NVM function Version = 0203 */

/*----------------------------------------------------------------------------------------------*/
/* APPL/BOOT information																		*/
/*----------------------------------------------------------------------------------------------*/
#define NVM_CONFIG_APPL											/* NVM function for APPL */

/*----------------------------------------------------------------------------------------------*/
/* NVMID																						*/
/*----------------------------------------------------------------------------------------------*/
#define NVMID_VAR_PCB_ASSY				( 0x0000U )				/* 0	PCB ASSY��� */
#define NVMID_IMMB_FUNC					( 0x0001U )				/* 1	���ދ@�\ */
#define NVMID_VAR_ODO_INTEGRATED_RATE	( 0x0002U )				/* 2	ODO�ώZ��km */
#define NVMID_SP_ANLG_CHNG_RATE_KM		( 0x0003U )				/* 3	SP�ԑ��ϊ��W��km/h */
#define NVMID_MOVING_JDG_SP_KM			( 0x0004U )				/* 4	���s����ԑ� km/h */
#define NVMID_SP_OUT_OFFSET				( 0x0005U )				/* 5	SP�w�x�␳ */
#define NVMID_SP_DELAY					( 0x0006U )				/* 6	SP�x���萔 */
#define NVMID_SP_POINTER_OFFSET			( 0x0007U )				/* 7	SP�w�j�␳ */
#define NVMID_SP_SLOPE_ADJ				( 0x0008U )				/* 8	SP�X���␳ */
#define NVMID_SP_ANLG_IN_ADJ1_KM		( 0x0009U )				/* 9	SP�w�x(����)�����_1 km/h */
#define NVMID_SP_ANLG_IN_ADJ2_KM		( 0x000AU )				/* 10	SP�w�x(����)�����_2 km/h */
#define NVMID_SP_ANLG_IN_ADJ3_KM		( 0x000BU )				/* 11	SP�w�x(����)�����_3 km/h */
#define NVMID_SP_ANLG_IN_ADJ4_KM		( 0x000CU )				/* 12	SP�w�x(����)�����_4 km/h */
#define NVMID_SP_ANLG_OUT_ADJ1			( 0x000DU )				/* 13	SP�U�p(�o��)�����_1 */
#define NVMID_SP_ANLG_OUT_ADJ2			( 0x000EU )				/* 14	SP�U�p(�o��)�����_2 */
#define NVMID_SP_ANLG_OUT_ADJ3			( 0x000FU )				/* 15	SP�U�p(�o��)�����_3 */
#define NVMID_SP_ANLG_OUT_ADJ4			( 0x0010U )				/* 16	SP�U�p(�o��)�����_4 */
#define NVMID_TA_ANLG_CHNG_RATE			( 0x0011U )				/* 17	TA��]���Z�o�W�� */
#define NVMID_TA_ANLG_OUT_OFFSET		( 0x0012U )				/* 18	TA�w�x�␳ */
#define NVMID_TA_DELAY					( 0x0013U )				/* 19	TA�x���萔 */
#define NVMID_TA_POINTER_OFFSET			( 0x0014U )				/* 20	TA�w�j�␳ */
#define NVMID_TA_SLOPE_ADJ				( 0x0015U )				/* 21	TA�X���␳ */
#define NVMID_TA_ANLG_IN_ADJ1			( 0x0016U )				/* 22	TA��]��(����)�����_1 */
#define NVMID_TA_ANLG_IN_ADJ2			( 0x0017U )				/* 23	TA��]��(����)�����_2 */
#define NVMID_TA_ANLG_IN_ADJ3			( 0x0018U )				/* 24	TA��]��(����)�����_3 */
#define NVMID_TA_ANLG_IN_ADJ4			( 0x0019U )				/* 25	TA��]��(����)�����_4 */
#define NVMID_TA_ANLG_OUT_ADJ1			( 0x001AU )				/* 26	TA�U�p(�o��)�����_1 */
#define NVMID_TA_ANLG_OUT_ADJ2			( 0x001BU )				/* 27	TA�U�p(�o��)�����_2 */
#define NVMID_TA_ANLG_OUT_ADJ3			( 0x001CU )				/* 28	TA�U�p(�o��)�����_3 */
#define NVMID_TA_ANLG_OUT_ADJ4			( 0x001DU )				/* 29	TA�U�p(�o��)�����_4 */
#define NVMID_TA_ANLG_IDLE				( 0x001EU )				/* 30	����ٗL�� */
#define NVMID_TA_ANLG_IDLE1_ANGLE_E0	( 0x001FU )				/* 31	�����ݸސݒ���1�J�n�p�x */
#define NVMID_TA_ANLG_IDLE1_ANGLE		( 0x0020U )				/* 32	�����ݸސݒ���1�p�x */
#define NVMID_TA_ANLG_IDLE1_DELAY		( 0x0021U )				/* 33	�����ݸސݒ���1�x���萔 */
#define NVMID_TA_ANLG_IDLE234_ANGLE		( 0x0022U )				/* 34	�����ݸސݒ���2,3,4�p�x */
#define NVMID_TA_ANLG_IDLE2_DELAY		( 0x0023U )				/* 35	�����ݸސݒ���2�x���萔 */
#define NVMID_FUEL_CUT_AD				( 0x0024U )				/* 36	FUEL�f�����oAD */
#define NVMID_FUEL_SHORT_AD				( 0x0025U )				/* 37	FUEL�Z�����oAD */
#define NVMID_FUEL_DISP_TIME			( 0x0026U )				/* 38	FUEL�\���ێ����� */
#define NVMID_FUEL_CHNG_AD1				( 0x0027U )				/* 39	FUEL����臒l [ 1��E A/D ] */
#define NVMID_FUEL_CHNG_AD2				( 0x0028U )				/* 40	FUEL����臒l [ 2��1 A/D ] */
#define NVMID_FUEL_CHNG_AD3				( 0x0029U )				/* 41	FUEL����臒l [ 3��2 A/D ] */
#define NVMID_FUEL_CHNG_AD4				( 0x002AU )				/* 42	FUEL����臒l [ 4��3 A/D ] */
#define NVMID_FUEL_CHNG_AD5				( 0x002BU )				/* 43	FUEL����臒l [ 5��4 A/D ] */
#define NVMID_FUEL_CHNG_AD6				( 0x002CU )				/* 44	FUEL����臒l [ 6��5 A/D ] */
#define NVMID_INST_FUEL_DISP_CYCLE		( 0x002DU )				/* 45	�u�ԔR��\���X�V���� */
#define NVMID_AVE_FUEL_DISP_CYCLE		( 0x002EU )				/* 46	���ϔR��\���X�V���� */
#define NVMID_INST_FUEL_CALC_DATA_CNT	( 0x002FU )				/* 47	�u�ԔR��Z�o�f�[�^�� */
#define NVMID_RANGE_QNTY_FULL			( 0x0030U )				/* 48	���ݗ� */
#define NVMID_RANGE_QNTY_FLOCK			( 0x0031U )				/* 49	����F-LOCK�_�R���� */
#define NVMID_RANGE_QNTY_WARN			( 0x0032U )				/* 50	FUEL�x�����R���� */
#define NVMID_RANGE_QNTY_INVALID		( 0x0033U )				/* 51	�����R���� */
#define NVMID_RANGE_QNTY_FULL_FLOCK		( 0x0034U )				/* 52	���݁`����F-LOCK�_�ԔR���� */
#define NVMID_RANGE_SAMPLING_COUNT_AD	( 0x0035U )				/* 53	�̈攻������ݸމ� */
#define NVMID_RANGE_SAMPLE_COUNT_QNTY	( 0x0036U )				/* 54	�c�ʔ�������ݸމ� */
#define NVMID_RANGE_FUEL_CALC_CYCLE		( 0x0037U )				/* 55	�R��Z�o���� */
#define NVMID_RANGE_DISP_PERIOD			( 0x0038U )				/* 56	�\���X�V���� */
#define NVMID_RANGE_CHAR_P01_AD			( 0x0039U )				/* 57	FUEL�Z���_���� P1 AD�l */
#define NVMID_RANGE_CHAR_P02_AD			( 0x003AU )				/* 58	FUEL�Z���_���� P2 AD�l */
#define NVMID_RANGE_CHAR_P03_AD			( 0x003BU )				/* 59	FUEL�Z���_���� P3 AD�l */
#define NVMID_RANGE_CHAR_P04_AD			( 0x003CU )				/* 60	FUEL�Z���_���� P4 AD�l */
#define NVMID_RANGE_CHAR_P05_AD			( 0x003DU )				/* 61	FUEL�Z���_���� P5 AD�l */
#define NVMID_RANGE_CHAR_P06_AD			( 0x003EU )				/* 62	FUEL�Z���_���� P6 AD�l */
#define NVMID_RANGE_CHAR_P07_AD			( 0x003FU )				/* 63	FUEL�Z���_���� P7 AD�l */
#define NVMID_RANGE_CHAR_P08_AD			( 0x0040U )				/* 64	FUEL�Z���_���� P8 AD�l */
#define NVMID_RANGE_CHAR_P09_AD			( 0x0041U )				/* 65	FUEL�Z���_���� P9 AD�l */
#define NVMID_RANGE_CHAR_P10_AD			( 0x0042U )				/* 66	FUEL�Z���_���� P10 AD�l */
#define NVMID_RANGE_CHAR_P11_AD			( 0x0043U )				/* 67	FUEL�Z���_���� P11 AD�l */
#define NVMID_RANGE_CHAR_P12_AD			( 0x0044U )				/* 68	FUEL�Z���_���� P12 AD�l */
#define NVMID_RANGE_CHAR_P13_AD			( 0x0045U )				/* 69	FUEL�Z���_���� P13 AD�l */
#define NVMID_RANGE_CHAR_P14_AD			( 0x0046U )				/* 70	FUEL�Z���_���� P14 AD�l */
#define NVMID_RANGE_CHAR_P15_AD			( 0x0047U )				/* 71	FUEL�Z���_���� P15 AD�l */
#define NVMID_RANGE_CHAR_P16_AD			( 0x0048U )				/* 72	FUEL�Z���_���� P16 AD�l */
#define NVMID_RANGE_CHAR_P01_QNTY		( 0x0049U )				/* 73	FUEL�Z���_���� P1 �R���� */
#define NVMID_RANGE_CHAR_P02_QNTY		( 0x004AU )				/* 74	FUEL�Z���_���� P2 �R���� */
#define NVMID_RANGE_CHAR_P03_QNTY		( 0x004BU )				/* 75	FUEL�Z���_���� P3 �R���� */
#define NVMID_RANGE_CHAR_P04_QNTY		( 0x004CU )				/* 76	FUEL�Z���_���� P4 �R���� */
#define NVMID_RANGE_CHAR_P05_QNTY		( 0x004DU )				/* 77	FUEL�Z���_���� P5 �R���� */
#define NVMID_RANGE_CHAR_P06_QNTY		( 0x004EU )				/* 78	FUEL�Z���_���� P6 �R���� */
#define NVMID_RANGE_CHAR_P07_QNTY		( 0x004FU )				/* 79	FUEL�Z���_���� P7 �R���� */
#define NVMID_RANGE_CHAR_P08_QNTY		( 0x0050U )				/* 80	FUEL�Z���_���� P8 �R���� */
#define NVMID_RANGE_CHAR_P09_QNTY		( 0x0051U )				/* 81	FUEL�Z���_���� P9 �R���� */
#define NVMID_RANGE_CHAR_P10_QNTY		( 0x0052U )				/* 82	FUEL�Z���_���� P10 �R���� */
#define NVMID_RANGE_CHAR_P11_QNTY		( 0x0053U )				/* 83	FUEL�Z���_���� P11 �R���� */
#define NVMID_RANGE_CHAR_P12_QNTY		( 0x0054U )				/* 84	FUEL�Z���_���� P12 �R���� */
#define NVMID_RANGE_CHAR_P13_QNTY		( 0x0055U )				/* 85	FUEL�Z���_���� P13 �R���� */
#define NVMID_RANGE_CHAR_P14_QNTY		( 0x0056U )				/* 86	FUEL�Z���_���� P14 �R���� */
#define NVMID_RANGE_CHAR_P15_QNTY		( 0x0057U )				/* 87	FUEL�Z���_���� P15 �R���� */
#define NVMID_RANGE_CHAR_P16_QNTY		( 0x0058U )				/* 88	FUEL�Z���_���� P16 �R���� */
#define NVMID_WTEMP_DISP_PERIOD			( 0x0059U )				/* 89	�\���X�V���� */
#define NVMID_WTEMP_CHNG_CHAR_1			( 0x005AU )				/* 90	�w�x���� [ 1��0 ���� ] */
#define NVMID_WTEMP_CHNG_CHAR_2			( 0x005BU )				/* 91	�w�x���� [ 2��1 ���� ] */
#define NVMID_WTEMP_CHNG_CHAR_3			( 0x005CU )				/* 92	�w�x���� [ 3��2 ���� ] */
#define NVMID_WTEMP_CHNG_CHAR_4			( 0x005DU )				/* 93	�w�x���� [ 4��3 ���� ] */
#define NVMID_WTEMP_CHNG_CHAR_5			( 0x005EU )				/* 94	�w�x���� [ 5��4 ���� ] */
#define NVMID_WTEMP_CHNG_CHAR_6			( 0x005FU )				/* 95	�w�x���� [ 6��5 ���� ] */
#define NVMID_OTEMP_DISP_PERIOD			( 0x0060U )				/* 96	�\���X�V���� */
#define NVMID_OTEMP_UPDATA_JDG_SP_KM	( 0x0061U )				/* 97	�O�C���㏸���\���X�V����ԑ�[km/h] */
#define NVMID_OTEMP_DISP_ADJ			( 0x0062U )				/* 98	�\�����x�␳�l */
#define NVMID_OTEMP_WARN_DETECT			( 0x0063U )				/* 99	�ቷ�x�����o���x */
#define NVMID_OTEMP_WARN_CANCEL			( 0x0064U )				/* 100	�ቷ�x���������x */
#define NVMID_VOLTAGE_LO_DETECTION		( 0x0065U )				/* 101	��d�� ���o�d��A/D */
#define NVMID_VOLTAGE_LO_RLSE			( 0x0066U )				/* 102	��d�� ���A�d��A/D */
#define NVMID_BATT_IND_HI_DETECTION		( 0x0067U )				/* 103	���d�����_���d��A/D */
#define NVMID_BATT_IND_LO_RLSE			( 0x0068U )				/* 104	��d���������d��A/D */
#define NVMID_BATT_IND_LO_DETECTION		( 0x0069U )				/* 105	��d�����_���d��A/D */
#define NVMID_BATT_IND_DLY_DETECTION	( 0x006AU )				/* 106	�x���萔 [ BATT���o ] */
#define NVMID_BATT_IND_DLY_RLSE			( 0x006BU )				/* 107	�x���萔 [ BATT���� ] */
#define NVMID_OIL_IND_DLY_DETECTION		( 0x006CU )				/* 108	�x���萔 [ OIL���o ] */
#define NVMID_OIL_IND_DLY_RLSE			( 0x006DU )				/* 109	�x���萔 [ OIL���� ] */
#define NVMID_OIL_IND_AD_DETECTION		( 0x006EU )				/* 110	OIL�ݼ޹���_���d��A/D */
#define NVMID_OIL_IND_AD_RLSE			( 0x006FU )				/* 111	OIL�ݼ޹�������d��A/D */
#define NVMID_UP_SW_ON_AD				( 0x0070U )				/* 112	UP SW ON���oA/D */
#define NVMID_UP_SW_OFF_AD				( 0x0071U )				/* 113	UP SW OFF���oA/D */
#define NVMID_DOWN_SW_ON_AD				( 0x0072U )				/* 114	DOWN SW ON���oA/D */
#define NVMID_DOWN_SW_OFF_AD			( 0x0073U )				/* 115	DOWN SW OFF���oA/D */
#define NVMID_IMMB_AD					( 0x0074U )				/* 116	LOW BATT ���oA/D�l */
#define NVMID_SWEEP_ADJ_SP				( 0x0075U )				/* 117	SP�X�C�[�v�p�␳ */
#define NVMID_SWEEP_ADJ_TA				( 0x0076U )				/* 118	TA�X�C�[�v�p�␳ */
#define NVMID_USR_SETTING1_CLK_UNIT		( 0x0077U )				/* 119	12h/24h�ݒ� */
#define NVMID_USR_SETTING1_UNIT			( 0x0078U )				/* 120	�����E�R��E���x�P�� */
#define NVMID_USR_SETTING2_CLK_UNIT		( 0x0079U )				/* 121	12h/24h�ݒ� */
#define NVMID_USR_SETTING2_UNIT			( 0x007AU )				/* 122	�����E�R��E���x�P�� */
#define NVMID_ODO_INTEGRATED_1			( 0x007BU )				/* 123	ODO�ώZ�l1 */
#define NVMID_ODO_INTEGRATED_2			( 0x007CU )				/* 124	ODO�ώZ�l2 */
#define NVMID_ODO_INTEGRATED_3			( 0x007DU )				/* 125	ODO�ώZ�l3 */
#define NVMID_ODO_INTEGRATED_4			( 0x007EU )				/* 126	ODO�ώZ�l4 */
#define NVMID_ODO_INTEGRATED_5			( 0x007FU )				/* 127	ODO�ώZ�l5 */
#define NVMID_ODO_INTEGRATED_6			( 0x0080U )				/* 128	ODO�ώZ�l6 */
#define NVMID_ODO_INTEGRATED_7			( 0x0081U )				/* 129	ODO�ώZ�l7 */
#define NVMID_ODO_INTEGRATED_8			( 0x0082U )				/* 130	ODO�ώZ�l8 */
#define NVMID_ODO_INTEGRATED_9			( 0x0083U )				/* 131	ODO�ώZ�l9 */
#define NVMID_ODO_INTEGRATED_10			( 0x0084U )				/* 132	ODO�ώZ�l10 */
#define NVMID_ODO_INTEGRATED_11			( 0x0085U )				/* 133	ODO�ώZ�l11 */
#define NVMID_ODO_INTEGRATED_12			( 0x0086U )				/* 134	ODO�ώZ�l12 */
#define NVMID_ODO_INTEGRATED_13			( 0x0087U )				/* 135	ODO�ώZ�l13 */
#define NVMID_ODO_INTEGRATED_14			( 0x0088U )				/* 136	ODO�ώZ�l14 */
#define NVMID_ODO_INTEGRATED_15			( 0x0089U )				/* 137	ODO�ώZ�l15 */
#define NVMID_ODO_INTEGRATED_16			( 0x008AU )				/* 138	ODO�ώZ�l16 */
#define NVMID_ODO_INTEGRATED_17			( 0x008BU )				/* 139	ODO�ώZ�l17 */
#define NVMID_ODO_INTEGRATED_18			( 0x008CU )				/* 140	ODO�ώZ�l18 */
#define NVMID_ODO_INTEGRATED_19			( 0x008DU )				/* 141	ODO�ώZ�l19 */
#define NVMID_ODO_INTEGRATED_20			( 0x008EU )				/* 142	ODO�ώZ�l20 */
#define NVMID_ODO_INTEGRATED_21			( 0x008FU )				/* 143	ODO�ώZ�l21 */
#define NVMID_ODO_INTEGRATED_22			( 0x0090U )				/* 144	ODO�ώZ�l22 */
#define NVMID_ODO_INTEGRATED_23			( 0x0091U )				/* 145	ODO�ώZ�l23 */
#define NVMID_ODO_INTEGRATED_24			( 0x0092U )				/* 146	ODO�ώZ�l24 */
#define NVMID_ODO_INTEGRATED_25			( 0x0093U )				/* 147	ODO�ώZ�l25 */
#define NVMID_ODO_INTEGRATED_26			( 0x0094U )				/* 148	ODO�ώZ�l26 */
#define NVMID_ODO_INTEGRATED_27			( 0x0095U )				/* 149	ODO�ώZ�l27 */
#define NVMID_ODO_INTEGRATED_28			( 0x0096U )				/* 150	ODO�ώZ�l28 */
#define NVMID_ODO_INTEGRATED_29			( 0x0097U )				/* 151	ODO�ώZ�l29 */
#define NVMID_ODO_INTEGRATED_30			( 0x0098U )				/* 152	ODO�ώZ�l30 */
#define NVMID_ODO_INTEGRATED_31			( 0x0099U )				/* 153	ODO�ώZ�l31 */
#define NVMID_ODO_INTEGRATED_32			( 0x009AU )				/* 154	ODO�ώZ�l32 */
#define NVMID_ODO_LESS_1				( 0x009BU )				/* 155	ODO�����l1 */
#define NVMID_ODO_LESS_1_PARITY			( 0x009CU )				/* 156	ODO�����l1���è */
#define NVMID_ODO_LESS_2				( 0x009DU )				/* 157	ODO�����l2 */
#define NVMID_ODO_LESS_2_PARITY			( 0x009EU )				/* 158	ODO�����l2���è */
#define NVMID_ODO_LESS_3				( 0x009FU )				/* 159	ODO�����l3 */
#define NVMID_ODO_LESS_3_PARITY			( 0x00A0U )				/* 160	ODO�����l3���è */
#define NVMID_ODO_LESS_4				( 0x00A1U )				/* 161	ODO�����l4 */
#define NVMID_ODO_LESS_4_PARITY			( 0x00A2U )				/* 162	ODO�����l4���è */
#define NVMID_ODO_LESS_5				( 0x00A3U )				/* 163	ODO�����l5 */
#define NVMID_ODO_LESS_5_PARITY			( 0x00A4U )				/* 164	ODO�����l5���è */
#define NVMID_ODO_LESS_6				( 0x00A5U )				/* 165	ODO�����l6 */
#define NVMID_ODO_LESS_6_PARITY			( 0x00A6U )				/* 166	ODO�����l6���è */
#define NVMID_ODO_LESS_7				( 0x00A7U )				/* 167	ODO�����l7 */
#define NVMID_ODO_LESS_7_PARITY			( 0x00A8U )				/* 168	ODO�����l7���è */
#define NVMID_ODO_LESS_8				( 0x00A9U )				/* 169	ODO�����l8 */
#define NVMID_ODO_LESS_8_PARITY			( 0x00AAU )				/* 170	ODO�����l8���è */
#define NVMID_ODO_LESS_9				( 0x00ABU )				/* 171	ODO�����l9 */
#define NVMID_ODO_LESS_9_PARITY			( 0x00ACU )				/* 172	ODO�����l9���è */
#define NVMID_ODO_LESS_10				( 0x00ADU )				/* 173	ODO�����l10 */
#define NVMID_ODO_LESS_10_PARITY		( 0x00AEU )				/* 174	ODO�����l10���è */
#define NVMID_ODO_INTEGRATE_TRIP_A		( 0x00AFU )				/* 175	TRIP METER Aؾ�Ď�ODO�ώZ�l [km] */
#define NVMID_ODO_LESS_TRIP_A			( 0x00B0U )				/* 176	TRIP METER Aؾ�Ď�ODO�����l [km] */
#define NVMID_ODO_INTEGRATE_TRIP_B		( 0x00B1U )				/* 177	TRIP METER Bؾ�Ď�ODO�ώZ�l [km] */
#define NVMID_ODO_LESS_TRIP_B			( 0x00B2U )				/* 178	TRIP METER Bؾ�Ď�ODO�����l [km] */
#define NVMID_EEP_VER_FORMAT			( 0x00B3U )				/* 179	̫�ϯ�Ver */
#define NVMID_EEP_VER_DATA				( 0x00B4U )				/* 180	�ް�Ver */
#define NVMID_EEP_VER_MAP				( 0x00B5U )				/* 181	EEPROMϯ��Ver */
#define END_NVMID_INDEX					( 0x00B6U )				/* 182 */

/*----------------------------------------------------------------------------------------------*/
/* Project-dependent (for NVM, EEPROM)															*/
/*----------------------------------------------------------------------------------------------*/
/* Internal definition for SSFTSTD_Nvm_Main, SSFTSTD_Nvm_EepMgr, SSFTSTD_Nvm_EepDrvCtrl */
#if defined(NVM_MAIN_000_INTERNAL_DEFINE)||defined(NVM_EEPMGR_000_INTERNAL_DEFINE)||defined(NVM_EEPDRVCTRL_INTERNAL_DEFINE)

#define ENABLE_DF_ACCESS				( 0U )					/* DataFlash access fuction (1:Apply, 0:Not apply) */

#endif

/*----------------------------------------------------------------------------------------------*/
/* Project-dependent (for NVM)																	*/
/*----------------------------------------------------------------------------------------------*/
#ifdef NVM_MAIN_000_INTERNAL_DEFINE	/* Internal definition for SSFTSTD_Nvm_Main */

#define NVM_DEVICE_EEPROM										/* NVM device:EEPROM */
#define ENABLE_SIGNED_RANGECHK			( 1U )					/* Signed range check (1:Apply, 0:Not apply) */
#define NVM_TBL_SIZE_MIN										/* ROM reduced Version */
#define ENABLE_NVM_BYTE_ACCESS									/* Apply BYTE access interface fuction */
#define ENABLE_NVM_WORD_ACCESS									/* Apply WORD access interface fuction */
#define ENABLE_NVM_DWORD_ACCESS									/* Apply DWORD access interface fuction */

/*----------------------------------------------------------------------------------------------*/
/* Fixed definition for NVM table																*/
/*----------------------------------------------------------------------------------------------*/
#define UNSIGN							( 0U )					/* Unsigned NVM data */
#define SIGN							( 1U )					/* Signed NVM data */
#define RANGE_CHK_TBL_NONE				( 0U )					/* No range check */
#define RANGE_CHK_TBL_X					( 1U )					/* range check table (less than 1Byte) */
#define RANGE_CHK_TBL_BYTE				( 2U )					/* range check table (1Byte) */
#define RANGE_CHK_TBL_WORD				( 3U )					/* range check table (2Byte) */
#define RANGE_CHK_TBL_DWORD				( 4U )					/* range check table (4Byte) */

/************************************************************************************************/
/* Definition of Internal Data Type																*/
/************************************************************************************************/
/* Range check table (less than 1Byte) */
typedef struct {
	UI_8	x_min;
	UI_8	x_max;
	UI_8	x_value;
} T_Nvm_appl_range_check_uix;

/* Range check table (1Byte) */
typedef struct {
	UI_8	byte_min;
	UI_8	byte_max;
	UI_8	byte_value;
} T_Nvm_appl_range_check_ui8;

/* Range check table (2Byte) */
typedef struct {
	UI_16	word_min;
	UI_16	word_max;
	UI_16	word_value;
} T_Nvm_appl_range_check_ui16;

/* Range check table (4Byte) */
typedef struct {
	UI_32	dword_min;
	UI_32	dword_max;
	UI_32	dword_value;
} T_Nvm_appl_range_check_ui32;

#ifdef NVM_TBL_SIZE_MIN
/* NVM access table (ROM reduced Version) */
typedef struct {
	UI_16		e_id;					/* 0-0xFFFF:Max 64K[Byte address] */
	BITFIELD	start_bit:3;			/* 0-7 */
	BITFIELD	length:6;				/* 0-32 */
	BITFIELD	type:3;					/* 1-4 */
	BITFIELD	shift_val:3;			/* 0-7 */
	BITFIELD	sign:2;					/* 0-1 */
	BITFIELD	default_data_table:3;	/* 0-4 */
	UI_16		default_data_index;		/* 0-0xFFFF:Mak 64K[Data] */
} T_Nvm_appl_data_interface;
#else
/* NVM access table (Standard Version) */
typedef struct {
	UI_16	e_id;
	UI_8	start_bit;
	UI_8	length;
	UI_8	type;
	UI_8	shift_val;
	UI_8	sign;
	UI_8	default_data_table;
	UI_16	default_data_index;
} T_Nvm_appl_data_interface;
#endif

/************************************************************************************************/
/* Definition of Internal Constant Data															*/
/************************************************************************************************/
/*----------------------------------------------------------------------------------------------*/
/* definition of data table																		*/
/*----------------------------------------------------------------------------------------------*/
static const T_Nvm_appl_data_interface C_Nvm_appldata_interface_tbl[] = 
{
	{	0x0000U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_PCB_ASSY */
	{	0x0003U,	6U,	2U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* IMMB_FUNC */
	{	0x0004U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		0U	},	/* VAR_ODO_INTEGRATED_RATE */
	{	0x000CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* SP_ANLG_CHNG_RATE_KM */
	{	0x000EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		1U	},	/* MOVING_JDG_SP_KM */
	{	0x0010U,	0U,	8U,		1U,	0U,	SIGN,	RANGE_CHK_TBL_BYTE,		0U	},	/* SP_OUT_OFFSET */
	{	0x0011U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		1U	},	/* SP_DELAY */
	{	0x0012U,	0U,	8U,		1U,	0U,	SIGN,	RANGE_CHK_TBL_BYTE,		2U	},	/* SP_POINTER_OFFSET */
	{	0x0013U,	0U,	8U,		1U,	0U,	SIGN,	RANGE_CHK_TBL_BYTE,		3U	},	/* SP_SLOPE_ADJ */
	{	0x0016U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		2U	},	/* SP_ANLG_IN_ADJ1_KM */
	{	0x0018U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		3U	},	/* SP_ANLG_IN_ADJ2_KM */
	{	0x001AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		4U	},	/* SP_ANLG_IN_ADJ3_KM */
	{	0x001CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		5U	},	/* SP_ANLG_IN_ADJ4_KM */
	{	0x0020U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		6U	},	/* SP_ANLG_OUT_ADJ1 */
	{	0x0022U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		7U	},	/* SP_ANLG_OUT_ADJ2 */
	{	0x0024U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		8U	},	/* SP_ANLG_OUT_ADJ3 */
	{	0x0026U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		9U	},	/* SP_ANLG_OUT_ADJ4 */
	{	0x002AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_CHNG_RATE */
	{	0x002EU,	0U,	8U,		1U,	0U,	SIGN,	RANGE_CHK_TBL_BYTE,		4U	},	/* TA_ANLG_OUT_OFFSET */
	{	0x002FU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		5U	},	/* TA_DELAY */
	{	0x0030U,	0U,	8U,		1U,	0U,	SIGN,	RANGE_CHK_TBL_BYTE,		6U	},	/* TA_POINTER_OFFSET */
	{	0x0031U,	0U,	8U,		1U,	0U,	SIGN,	RANGE_CHK_TBL_BYTE,		7U	},	/* TA_SLOPE_ADJ */
	{	0x0034U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		10U	},	/* TA_ANLG_IN_ADJ1 */
	{	0x0036U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		11U	},	/* TA_ANLG_IN_ADJ2 */
	{	0x0038U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		12U	},	/* TA_ANLG_IN_ADJ3 */
	{	0x003AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		13U	},	/* TA_ANLG_IN_ADJ4 */
	{	0x003EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		14U	},	/* TA_ANLG_OUT_ADJ1 */
	{	0x0040U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		15U	},	/* TA_ANLG_OUT_ADJ2 */
	{	0x0042U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		16U	},	/* TA_ANLG_OUT_ADJ3 */
	{	0x0044U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		17U	},	/* TA_ANLG_OUT_ADJ4 */
	{	0x0048U,	0U,	1U,		1U,	7U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE */
	{	0x004AU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE1_ANGLE_E0 */
	{	0x004CU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE1_ANGLE */
	{	0x004DU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		8U	},	/* TA_ANLG_IDLE1_DELAY */
	{	0x004EU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* TA_ANLG_IDLE234_ANGLE */
	{	0x004FU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		9U	},	/* TA_ANLG_IDLE2_DELAY */
	{	0x0052U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		18U	},	/* FUEL_CUT_AD */
	{	0x0054U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		19U	},	/* FUEL_SHORT_AD */
	{	0x0059U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		10U	},	/* FUEL_DISP_TIME */
	{	0x005CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		20U	},	/* FUEL_CHNG_AD1 */
	{	0x005EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		21U	},	/* FUEL_CHNG_AD2 */
	{	0x0060U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		22U	},	/* FUEL_CHNG_AD3 */
	{	0x0062U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		23U	},	/* FUEL_CHNG_AD4 */
	{	0x0066U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		24U	},	/* FUEL_CHNG_AD5 */
	{	0x0068U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		25U	},	/* FUEL_CHNG_AD6 */
	{	0x0070U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		11U	},	/* INST_FUEL_DISP_CYCLE */
	{	0x0071U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		12U	},	/* AVE_FUEL_DISP_CYCLE */
	{	0x0072U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		13U	},	/* INST_FUEL_CALC_DATA_CNT */
	{	0x007AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		26U	},	/* RANGE_QNTY_FULL */
	{	0x007CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		27U	},	/* RANGE_QNTY_FLOCK */
	{	0x007EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		28U	},	/* RANGE_QNTY_WARN */
	{	0x0080U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		29U	},	/* RANGE_QNTY_INVALID */
	{	0x0084U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		30U	},	/* RANGE_QNTY_FULL_FLOCK */
	{	0x0086U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		31U	},	/* RANGE_SAMPLING_COUNT_AD */
	{	0x0088U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		14U	},	/* RANGE_SAMPLE_COUNT_QNTY */
	{	0x008AU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		15U	},	/* RANGE_FUEL_CALC_CYCLE */
	{	0x008BU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		16U	},	/* RANGE_DISP_PERIOD */
	{	0x008EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		32U	},	/* RANGE_CHAR_P01_AD */
	{	0x0090U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		33U	},	/* RANGE_CHAR_P02_AD */
	{	0x0092U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		34U	},	/* RANGE_CHAR_P03_AD */
	{	0x0094U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		35U	},	/* RANGE_CHAR_P04_AD */
	{	0x0098U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		36U	},	/* RANGE_CHAR_P05_AD */
	{	0x009AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		37U	},	/* RANGE_CHAR_P06_AD */
	{	0x009CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		38U	},	/* RANGE_CHAR_P07_AD */
	{	0x009EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		39U	},	/* RANGE_CHAR_P08_AD */
	{	0x00A2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		40U	},	/* RANGE_CHAR_P09_AD */
	{	0x00A4U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		41U	},	/* RANGE_CHAR_P10_AD */
	{	0x00A6U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		42U	},	/* RANGE_CHAR_P11_AD */
	{	0x00A8U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		43U	},	/* RANGE_CHAR_P12_AD */
	{	0x00ACU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		44U	},	/* RANGE_CHAR_P13_AD */
	{	0x00AEU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		45U	},	/* RANGE_CHAR_P14_AD */
	{	0x00B0U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		46U	},	/* RANGE_CHAR_P15_AD */
	{	0x00B2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		47U	},	/* RANGE_CHAR_P16_AD */
	{	0x00B6U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		48U	},	/* RANGE_CHAR_P01_QNTY */
	{	0x00B8U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		49U	},	/* RANGE_CHAR_P02_QNTY */
	{	0x00BAU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		50U	},	/* RANGE_CHAR_P03_QNTY */
	{	0x00BCU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		51U	},	/* RANGE_CHAR_P04_QNTY */
	{	0x00C0U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		52U	},	/* RANGE_CHAR_P05_QNTY */
	{	0x00C2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		53U	},	/* RANGE_CHAR_P06_QNTY */
	{	0x00C4U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		54U	},	/* RANGE_CHAR_P07_QNTY */
	{	0x00C6U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		55U	},	/* RANGE_CHAR_P08_QNTY */
	{	0x00CAU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		56U	},	/* RANGE_CHAR_P09_QNTY */
	{	0x00CCU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		57U	},	/* RANGE_CHAR_P10_QNTY */
	{	0x00CEU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		58U	},	/* RANGE_CHAR_P11_QNTY */
	{	0x00D0U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		59U	},	/* RANGE_CHAR_P12_QNTY */
	{	0x00D4U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		60U	},	/* RANGE_CHAR_P13_QNTY */
	{	0x00D6U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		61U	},	/* RANGE_CHAR_P14_QNTY */
	{	0x00D8U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		62U	},	/* RANGE_CHAR_P15_QNTY */
	{	0x00DAU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		63U	},	/* RANGE_CHAR_P16_QNTY */
	{	0x00DEU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		17U	},	/* WTEMP_DISP_PERIOD */
	{	0x00E0U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_1 */
	{	0x00E1U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_2 */
	{	0x00E2U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_3 */
	{	0x00E3U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_4 */
	{	0x00E4U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_5 */
	{	0x00E5U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* WTEMP_CHNG_CHAR_6 */
	{	0x00E8U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		18U	},	/* OTEMP_DISP_PERIOD */
	{	0x00EAU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		64U	},	/* OTEMP_UPDATA_JDG_SP_KM */
	{	0x00EEU,	0U,	8U,		1U,	0U,	SIGN,	RANGE_CHK_TBL_BYTE,		19U	},	/* OTEMP_DISP_ADJ */
	{	0x00F2U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		20U	},	/* OTEMP_WARN_DETECT */
	{	0x00F3U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		21U	},	/* OTEMP_WARN_CANCEL */
	{	0x00FCU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		65U	},	/* VOLTAGE_LO_DETECTION */
	{	0x00FEU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		66U	},	/* VOLTAGE_LO_RLSE */
	{	0x0106U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		67U	},	/* BATT_IND_HI_DETECTION */
	{	0x010AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		68U	},	/* BATT_IND_LO_RLSE */
	{	0x010CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		69U	},	/* BATT_IND_LO_DETECTION */
	{	0x0110U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		22U	},	/* BATT_IND_DLY_DETECTION */
	{	0x0111U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		23U	},	/* BATT_IND_DLY_RLSE */
	{	0x0112U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		24U	},	/* OIL_IND_DLY_DETECTION */
	{	0x0113U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		25U	},	/* OIL_IND_DLY_RLSE */
	{	0x011AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		70U	},	/* OIL_IND_AD_DETECTION */
	{	0x011CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		71U	},	/* OIL_IND_AD_RLSE */
	{	0x0124U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		72U	},	/* UP_SW_ON_AD */
	{	0x0126U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		73U	},	/* UP_SW_OFF_AD */
	{	0x0128U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		74U	},	/* DOWN_SW_ON_AD */
	{	0x012AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		75U	},	/* DOWN_SW_OFF_AD */
	{	0x012EU,	0U,	16U,	2U,	0U,	SIGN,	RANGE_CHK_TBL_WORD,		76U	},	/* IMMB_AD */
	{	0x0138U,	0U,	8U,		1U,	0U,	SIGN,	RANGE_CHK_TBL_BYTE,		26U	},	/* SWEEP_ADJ_SP */
	{	0x0139U,	0U,	8U,		1U,	0U,	SIGN,	RANGE_CHK_TBL_BYTE,		27U	},	/* SWEEP_ADJ_TA */
	{	0x0143U,	5U,	1U,		1U,	2U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* USR_SETTING1_CLK_UNIT */
	{	0x0143U,	6U,	2U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* USR_SETTING1_UNIT */
	{	0x014DU,	5U,	1U,		1U,	2U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* USR_SETTING2_CLK_UNIT */
	{	0x014DU,	6U,	2U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* USR_SETTING2_UNIT */
	{	0x0156U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_1 */
	{	0x0158U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_2 */
	{	0x015AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_3 */
	{	0x015CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_4 */
	{	0x015EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_5 */
	{	0x0160U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_6 */
	{	0x0162U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_7 */
	{	0x0164U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_8 */
	{	0x0166U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_9 */
	{	0x0168U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_10 */
	{	0x016AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_11 */
	{	0x016CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_12 */
	{	0x016EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_13 */
	{	0x0170U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_14 */
	{	0x0172U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_15 */
	{	0x0174U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_16 */
	{	0x0176U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_17 */
	{	0x0178U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_18 */
	{	0x017AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_19 */
	{	0x017CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_20 */
	{	0x017EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_21 */
	{	0x0180U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_22 */
	{	0x0182U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_23 */
	{	0x0184U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_24 */
	{	0x0186U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_25 */
	{	0x0188U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_26 */
	{	0x018AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_27 */
	{	0x018CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_28 */
	{	0x018EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_29 */
	{	0x0190U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_30 */
	{	0x0192U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_31 */
	{	0x0194U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_32 */
	{	0x0196U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_1 */
	{	0x0198U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_1_PARITY */
	{	0x019AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_2 */
	{	0x019CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_2_PARITY */
	{	0x019EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_3 */
	{	0x01A0U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_3_PARITY */
	{	0x01A2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_4 */
	{	0x01A4U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_4_PARITY */
	{	0x01A6U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_5 */
	{	0x01A8U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_5_PARITY */
	{	0x01AAU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_6 */
	{	0x01ACU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_6_PARITY */
	{	0x01AEU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_7 */
	{	0x01B0U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_7_PARITY */
	{	0x01B2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_8 */
	{	0x01B4U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_8_PARITY */
	{	0x01B6U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_9 */
	{	0x01B8U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_9_PARITY */
	{	0x01BAU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_10 */
	{	0x01BCU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_10_PARITY */
	{	0x01BEU,	0U,	24U,	3U,	0U,	UNSIGN,	RANGE_CHK_TBL_DWORD,	0U	},	/* ODO_INTEGRATE_TRIP_A */
	{	0x01C2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIP_A */
	{	0x01C8U,	0U,	24U,	3U,	0U,	UNSIGN,	RANGE_CHK_TBL_DWORD,	1U	},	/* ODO_INTEGRATE_TRIP_B */
	{	0x01CCU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIP_B */
	{	0x01D2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* EEP_VER_FORMAT */
	{	0x01D4U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* EEP_VER_DATA */
	{	0x01D5U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	}	/* EEP_VER_MAP */
};

static const T_Nvm_appl_range_check_uix C_Range_Check_X_Tbl[] = 
{
	{	0x00U,	0x00U,	0x00U	}	/* dummy */
};

static const T_Nvm_appl_range_check_ui8 C_Range_Check_8_Tbl[] = 
{
	{	0x8EU,	0x72U,	0x00U	},	/* SP_OUT_OFFSET */
	{	0x04U,	0xFAU,	0x04U	},	/* SP_DELAY */
	{	0xDDU,	0x23U,	0x00U	},	/* SP_POINTER_OFFSET */
	{	0x8EU,	0x72U,	0x00U	},	/* SP_SLOPE_ADJ */
	{	0x8EU,	0x72U,	0x00U	},	/* TA_ANLG_OUT_OFFSET */
	{	0x04U,	0xFAU,	0x04U	},	/* TA_DELAY */
	{	0xDDU,	0x23U,	0x00U	},	/* TA_POINTER_OFFSET */
	{	0x8EU,	0x72U,	0x00U	},	/* TA_SLOPE_ADJ */
	{	0x10U,	0xFFU,	0x10U	},	/* TA_ANLG_IDLE1_DELAY */
	{	0x10U,	0xFFU,	0x10U	},	/* TA_ANLG_IDLE2_DELAY */
	{	0x01U,	0xFFU,	0x01U	},	/* FUEL_DISP_TIME */
	{	0x01U,	0x0EU,	0x01U	},	/* INST_FUEL_DISP_CYCLE */
	{	0x01U,	0x0EU,	0x01U	},	/* AVE_FUEL_DISP_CYCLE */
	{	0x01U,	0xFEU,	0x01U	},	/* INST_FUEL_CALC_DATA_CNT */
	{	0x01U,	0x32U,	0x01U	},	/* RANGE_SAMPLE_COUNT_QNTY */
	{	0x02U,	0xF0U,	0x02U	},	/* RANGE_FUEL_CALC_CYCLE */
	{	0x01U,	0x3CU,	0x01U	},	/* RANGE_DISP_PERIOD */
	{	0x01U,	0x0FU,	0x01U	},	/* WTEMP_DISP_PERIOD */
	{	0x01U,	0x0FU,	0x01U	},	/* OTEMP_DISP_PERIOD */
	{	0xD0U,	0x30U,	0xD0U	},	/* OTEMP_DISP_ADJ */
	{	0x00U,	0xA0U,	0xA0U	},	/* OTEMP_WARN_DETECT */
	{	0x00U,	0xA0U,	0xA0U	},	/* OTEMP_WARN_CANCEL */
	{	0x00U,	0x3CU,	0x00U	},	/* BATT_IND_DLY_DETECTION */
	{	0x00U,	0x3CU,	0x3CU	},	/* BATT_IND_DLY_RLSE */
	{	0x00U,	0x3CU,	0x00U	},	/* OIL_IND_DLY_DETECTION */
	{	0x00U,	0x3CU,	0x3CU	},	/* OIL_IND_DLY_RLSE */
	{	0x8EU,	0x72U,	0x00U	},	/* SWEEP_ADJ_SP */
	{	0x8EU,	0x72U,	0x00U	}	/* SWEEP_ADJ_TA */
};

static const T_Nvm_appl_range_check_ui16 C_Range_Check_16_Tbl[] = 
{
	{	0x000AU,	0xFEFFU,	0x000AU	},	/* VAR_ODO_INTEGRATED_RATE */
	{	0x0000U,	0x5000U,	0x0000U	},	/* MOVING_JDG_SP_KM */
	{	0x0001U,	0x7D00U,	0x7D00U	},	/* SP_ANLG_IN_ADJ1_KM */
	{	0x0001U,	0x7D00U,	0x7D00U	},	/* SP_ANLG_IN_ADJ2_KM */
	{	0x0001U,	0x7D00U,	0x7D00U	},	/* SP_ANLG_IN_ADJ3_KM */
	{	0x0001U,	0x7D00U,	0x7D00U	},	/* SP_ANLG_IN_ADJ4_KM */
	{	0x0001U,	0x1FFFU,	0x1FFFU	},	/* SP_ANLG_OUT_ADJ1 */
	{	0x0001U,	0x1FFFU,	0x1FFFU	},	/* SP_ANLG_OUT_ADJ2 */
	{	0x0001U,	0x1FFFU,	0x1FFFU	},	/* SP_ANLG_OUT_ADJ3 */
	{	0x0001U,	0x1FFFU,	0x1FFFU	},	/* SP_ANLG_OUT_ADJ4 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_ANLG_IN_ADJ1 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_ANLG_IN_ADJ2 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_ANLG_IN_ADJ3 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_ANLG_IN_ADJ4 */
	{	0x0001U,	0x1FFFU,	0x1FFFU	},	/* TA_ANLG_OUT_ADJ1 */
	{	0x0001U,	0x1FFFU,	0x1FFFU	},	/* TA_ANLG_OUT_ADJ2 */
	{	0x0001U,	0x1FFFU,	0x1FFFU	},	/* TA_ANLG_OUT_ADJ3 */
	{	0x0001U,	0x1FFFU,	0x1FFFU	},	/* TA_ANLG_OUT_ADJ4 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CUT_AD */
	{	0x0001U,	0x03FFU,	0x03FFU	},	/* FUEL_SHORT_AD */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD1 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD2 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD3 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD4 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD5 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD6 */
	{	0x0001U,	0xFFFEU,	0x0001U	},	/* RANGE_QNTY_FULL */
	{	0x0001U,	0xFFFEU,	0x0001U	},	/* RANGE_QNTY_FLOCK */
	{	0x0001U,	0xFFFEU,	0x0001U	},	/* RANGE_QNTY_WARN */
	{	0x0001U,	0x0BB8U,	0x0001U	},	/* RANGE_QNTY_INVALID */
	{	0x0001U,	0xFFFEU,	0x0001U	},	/* RANGE_QNTY_FULL_FLOCK */
	{	0x0001U,	0x04B0U,	0x0001U	},	/* RANGE_SAMPLING_COUNT_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P01_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P02_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P03_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P04_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P05_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P06_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P07_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P08_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P09_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P10_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P11_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P12_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P13_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P14_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P15_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* RANGE_CHAR_P16_AD */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P01_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P02_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P03_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P04_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P05_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P06_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P07_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P08_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P09_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P10_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P11_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P12_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P13_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P14_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P15_QNTY */
	{	0x0000U,	0xFFFEU,	0x0000U	},	/* RANGE_CHAR_P16_QNTY */
	{	0x0000U,	0x5000U,	0x0000U	},	/* OTEMP_UPDATA_JDG_SP_KM */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* VOLTAGE_LO_DETECTION */
	{	0x0000U,	0x03FFU,	0x0001U	},	/* VOLTAGE_LO_RLSE */
	{	0x0000U,	0x03FFU,	0x03FFU	},	/* BATT_IND_HI_DETECTION */
	{	0x0000U,	0x03FFU,	0x0001U	},	/* BATT_IND_LO_RLSE */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* BATT_IND_LO_DETECTION */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* OIL_IND_AD_DETECTION */
	{	0x0000U,	0x03FFU,	0x0001U	},	/* OIL_IND_AD_RLSE */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* UP_SW_ON_AD */
	{	0x0000U,	0x03FFU,	0x03FFU	},	/* UP_SW_OFF_AD */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* DOWN_SW_ON_AD */
	{	0x0000U,	0x03FFU,	0x03FFU	},	/* DOWN_SW_OFF_AD */
	{	0x0000U,	0x03FFU,	0x03FFU	}	/* IMMB_AD */
};

static const T_Nvm_appl_range_check_ui32 C_Range_Check_32_Tbl[] = 
{
	{	0x00000000UL,	0x0018B820UL,	0x00000000UL	},	/* ODO_INTEGRATE_TRIP_A */
	{	0x00000000UL,	0x0018B820UL,	0x00000000UL	}	/* ODO_INTEGRATE_TRIP_B */
};

#endif	/* #ifdef NVM_MAIN_000_INTERNAL_DEFINE */

#endif	/* #ifndef SSFTXXX_NVM_CONFIG_H */
