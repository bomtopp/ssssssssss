/************************************************************************************************/
/* �q�於		:	�W�����W���[��																*/
/* �@�햼		:	SSFT																		*/
/* ϲ�ݿ��ðϖ�	:	PF																			*/
/*==============================================================================================*/
/* �쐬̧�ٖ�	:	SSFTxxx_DispCtrl_Inc_101.h													*/
/* 				:	�\������@�\�@�\�O���t�@�C���C���N���[�w�b�_								*/
/*==============================================================================================*/
/* �Ώ�ϲ��		:	2R�W��																		*/
/*==============================================================================================*/
/* �쐬�ް�ޮ�	:	010101																		*/
/* �쐬�N����	:	2014.10.xx																	*/
/* �쐬��		:	NSCS																		*/
/*----------------------------------------------------------------------------------------------*/
/* �ύX����		:																				*/
/* [010101]		:	�V�K�쐬																	*/
/************************************************************************************************/
#ifndef	__XXX_DISPCTRL_INC_H__
#define	__XXX_DISPCTRL_INC_H__


/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include <string.h>
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Com_P5_101.h"				/* ���ʋ@�\ */

#include "SKAMxxx_DispCtrl_Config_101.h"
#include "SKAM0087_Fuel_P5_101.h"			/* FUEL�@�\ */
#include "SSFTSTD_Sp_IF_102.h"				/* SPEED�@�\ */
#include "SSFTSTD_SysIn_IF_101.h"			/* �V�X�e�����͋@�\ */
#include "SKAM0087_SysCtrl_IF_101.h"		/* �V�X�e������@�\ */
#include "SKAM0087_DataMgr_IF_101.h"		/* �f�[�^�Ǘ��@�\ */
#include "SSFTSTD_OdoTrip_IF_101.h"			/* ODOTRIP�@�\ */
#include "SKAM0087_LcdOut_Main_P5_101.h"	/* LCD�o�͋@�\ */

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	DISPCTRL_P5_INTERNAL

#include "SKAM0087_DispCtrl_Main_101.h"

#define	DEFINITION_VARIABLES
#include "SKAM0087_DispCtrl_P5_101.h"

#endif	/* DISPCTRL_P5_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	DISPCTRL_MAIN_INTERNAL

#include "SKAM0087_DispCtrl_P5_101.h"

/* #include "SSFTxxx_Gauge_Config_101.h" */			/* DEL REQ-00 */
/* #include "SSFTSTD_Gauge_IF_101.h" */				/* DEL REQ-00 */
#include "SSFTxxx_Gear_Config_101.h"
#include "SSFTSTD_Gear_IF_101.h"
#include "SKAMSTD_UartCtrl_IF_101.h"
#include "SKAMSTD_Diag_IF_101.h"

#define	DEFINITION_VARIABLES
#include "SKAM0087_DispCtrl_Main_101.h"
#include "SKAMSTD_AvgFuel_IF_101.h"
#include "SKAMSTD_InstFuel_IF_101.h"
#include "SKAMxxx_InstFuel_Config_101.h"
#include "SKAMSTD_Range_IF_101.h"
#include "SKAMxxx_Range_Config_101.h"
#include "SSFTSTD_Ta_IF_102.h"
#include "SKAM0087_WaterTemp_IF_101.h"
/* ADD-S REQ-00 1������ */
#include "SSFTSTD_RL78IoReg_CpuType_001.h"
#include "SSFTSTD_RL78Port_Drv_001.h"				/* CHG REQ-0001 */
/* ADD-E REQ-00 1������ */
#include "SSFTSTD_Clock_Main_001.h"		/* ADD�yREQ-2201�z*/
#include "SKAMxxx_LedOut_Config_101.h"		/* ADD�yREQ-1901�z*/
#include "SKAM0087_ProdTest_Main_102.h"		/* ADD�yREQ-1505�z*/
#include "SKAM0102_Warn_IF_000.h"
#include "SKAM0087_Immb_IF_101.h"

#endif	/* DISPCTRL_MAIN_INTERNAL */


#endif	/* __XXX_DISPCTRL_INC_H__ */

