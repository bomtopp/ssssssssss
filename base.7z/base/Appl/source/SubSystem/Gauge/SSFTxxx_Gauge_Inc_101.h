/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SSFT																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: K.Wada																	*/
/* Date 			: 2018/03/13																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: �Q�[�W�@�\�C���N���[�h�w�b�_												*/
/*************************************************************************************************/
#ifndef	__XXX_GAUGE_INC_H__
#define	__XXX_GAUGE_INC_H__

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
/* -���ʃw�b�_- */
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Type.h"

/* -���@�\�w�b�_- */
#include "SSFTSTD_Com_P5_101.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	GAUGE_INTERNAL

/* -���@�\�w�b�_- */
#include "SSFTSTD_RL78Motor_CtrlDrv_001.h"

/* -���@�\�w�b�_- */
#include "SSFTxxx_Gauge_Config_101.h"
#include "SSFTSTD_Gauge_IF_101.h"
#include "SSFTSTD_Gauge_P5_101.h"
#include "SKAM0087_Gauge_Main_101.h"

#if GAUGE_TYPE == GAUGE_VS2
#include "SSFTSTD_GaugeCmnFullDutyPwmData_Out_101.h"	/* FullDuty PWM�e�[�u�� */
#include "SSFTSTD_GaugeCmnHalfDutyPwmData_Out_101.h"	/* HalfDuty PWM�e�[�u�� */
#endif

#if GAUGE_TYPE == GAUGE_STS
#define	DEFINITION_VARIABLES
#include "SKAMSTD01_sts_reset_data_CTRL.h"	/* �P���^�E�����Z�b�g(1R)�f�[�^ */

#define	DEFINITION_VARIABLES
#include "SKAMSTD01_sts_ddd_data_CTRL.h"	/* �_�_�_���Z�b�g�f�[�^ */

#define	DEFINITION_VARIABLES
#include "SKAMSTD01_melexis_data_CTRL.h"	/* Melexis 10407�쓮�f�[�^ */
#endif

#endif	/* GAUGE_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	GAUGE_MAIN_INTERNAL

/* -���@�\�w�b�_- */
#include "SSFTSTD_SysIn_IF_101.h"
#include "SKAM0087_DataMgr_IF_101.h"
#include "SSFTSTD_Sp_IF_102.h"
#include "SSFTSTD_Ta_IF_102.h"
#include "SKAM0087_ProdTest_Main_102.h"

/* -���@�\�w�b�_- */
#include "SSFTxxx_Gauge_Config_101.h"
#include "SSFTSTD_Gauge_IF_101.h"
#include "SSFTSTD_Gauge_P5_101.h"
#include "SKAM0087_Gauge_Main_101.h"

#endif	/* GAUGE_MAIN_INTERNAL */

#endif	/* __XXX_GAUGE_INC_H__ */

