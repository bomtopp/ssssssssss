/************************************************************************************************/
/* File name		: SSFTSTD_GaugeCmnHalfDutyPwmData_Out_101.h										*/
/* Description		: Half�f���[�e�BPWM�e�[�u��													*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Kazuhiko Okamura	 														*/
/* Date 			: 2008/09/22																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Note 			: 																			*/
/*----------------------------------------------------------------------------------------------*/
/* Update by		: $Author: IntegrityAdmin (INTEADMIN) $													*/
/* Date 			: $Date: 2015/07/09 19:46:30ICT $											*/
/* Version			: $Revision: 1.0 $														*/
/************************************************************************************************/
#ifndef __GAUGECMN_HALFDUTY_PWMDATA__
#define __GAUGECMN_HALFDUTY_PWMDATA__

/************************************************************************************************/
/* Include File																					*/
/************************************************************************************************/
#include "SSFTSTD_Type.h"		/* �f�[�^�^��` */

#if HALF_DUTY_GAUGE_APPLY	/* Half Duty�쓮�Q�[�W�L�� */

#if GAUGE_NP_APPLY
/* HalfDuty NP�`�� Sin�pPWM�e�[�u�� */
extern const UI_8 C_Gauge_NpHalfOffsetOfSinPwm;
extern const UI_16 C_Gauge_NpHalfSinDiff[256];
extern const SI_16 C_Gauge_NpHalfSinPoint[64];

/* HalfDuty NP�`�� Cos�pPWM�e�[�u�� */
extern const UI_8 C_Gauge_NpHalfOffsetOfCosPwm;
extern const UI_16 C_Gauge_NpHalfCosDiff[256];
extern const SI_16 C_Gauge_NpHalfCosPoint[64];
#endif

#if GAUGE_NA_APPLY
/* HalfDuty NA�`�� Sin�pPWM�e�[�u�� */
extern const UI_8 C_Gauge_NaHalfOffsetOfSinPwm;
extern const UI_16 C_Gauge_NaHalfSinDiff[256];
extern const SI_16 C_Gauge_NaHalfSinPoint[64];

/* HalfDuty NA�`�� Cos�pPWM�e�[�u�� */
extern const UI_8 C_Gauge_NaHalfOffsetOfCosPwm;
extern const UI_16 C_Gauge_NaHalfCosDiff[256];
extern const SI_16 C_Gauge_NaHalfCosPoint[64];
#endif

#endif /* Half Duty�쓮�Q�[�W�L�� */

#endif /* __GAUGECMN_HALFDUTY_PWMDATA__ */
