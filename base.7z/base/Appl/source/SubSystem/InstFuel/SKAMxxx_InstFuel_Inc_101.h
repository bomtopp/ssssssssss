/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SKAM																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: K.Wada																	*/
/* Date 			: 2018/03/13																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: �u�ԔR��@�\�C���N���[�h�w�b�_											*/
/*************************************************************************************************/
#ifndef	SKAMXXX_INSTFUEL_INC_H
#define	SKAMXXX_INSTFUEL_INC_H

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include "string.h"
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	INSTFUEL_P5_INTERNAL

#include "SKAMSTD_Trcom_IF_101.h"
#include "SKAM0087_DataMgr_IF_101.h"
#include "SKAMxxx_InstFuel_Config_101.h"
#include "SKAMSTD_InstFuel_P5_101.h"

#endif	/* INSTFUEL_P5_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	INSTFUEL_MAIN_INTERNAL

#include "SKAMSTD_Trcom_IF_101.h"
#include "SKAMSTD_UartCtrl_IF_101.h"
#include "SSFTSTD_SysIn_IF_101.h"
#include "SSFTSTD_Sp_P5_102.h"
#include "SSFTSTD_Sp_IF_102.h"
#include "SKAM0087_DataMgr_IF_101.h"
#include "SKAMxxx_InstFuel_Config_101.h"
#include "SKAMSTD_InstFuel_IF_101.h"
#include "SKAMSTD_InstFuel_Main_101.h"
#include "SKAMSTD_InstFuel_P5_101.h"

#endif	/* INSTFUEL_MAIN_INTERNAL */

#endif	/* SKAMXXX_INSTFUEL_INC_H */

