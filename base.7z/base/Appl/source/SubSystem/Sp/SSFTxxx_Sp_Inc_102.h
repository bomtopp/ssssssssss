/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SSFT																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: K.Wada																	*/
/* Date 			: 2018/03/13																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: SPEED�@�\�C���N���[�h�w�b�_												*/
/*************************************************************************************************/
#ifndef	SSFTXXX_SP_INC_H
#define	SSFTXXX_SP_INC_H

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include <string.h>
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Com_P5_101.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	SP_P5_INTERNAL

#include "SSFTSTD_Sp_IF_102.h"
#include "SSFTxxx_Sp_Config_102.h"
#include "SSFTSTD_Sp_P5_102.h"

#endif	/* SP_P5_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	SP_MAIN_INTERNAL

#include "SKAM0087_DataMgr_IF_101.h"				/* CHG REQ-0101 */
#include "SSFTSTD_SysIn_IF_101.h"

#include "SSFTxxx_Sp_Config_102.h"

#if SP_INPUT_TYPE == SP_INCAPT_PERIODICAL_PULSE		/* �������͎� */
#include "SKAM0087_InCapt_Main_101.h"
#include "SSFTSTD_InCapt_P5_101.h"
#endif

#if SP_INPUT_TYPE == SP_UART_COMMUNICATION_PULSE	/* SP�p���X���͎� */
#include "SKAMSTD_UartCtrl_IF_101.h"
#endif

#if SP_JDG_COMMUNICATION_MODE == SP_ENABLE			/* �ʐM���[�h����L���� */
#include "SKAMSTD_UartCtrl_IF_101.h"
#endif

#if SP_PROC_FORCEDOUT == SP_ENABLE					/* �w�x�������L���� */
#include "SKAM0087_SysCtrl_IF_101.h"
#endif

#if SP_OUTPUT_TYPE == SP_ANALOG_OUTPUT				/* �A�i���O�o�͎��L�� */
#include "SSFTSTD_Gauge_IF_101.h"
#endif

#include "SSFTSTD_Sp_P5_102.h"
#include "SSFTSTD_Sp_IF_102.h"
#include "SSFTSTD_Sp_Main_102.h"

#endif	/* SP_MAIN_INTERNAL */

#endif	/* SSFTXXX_SP_INC_H */
