/************************************************************************************************/
/* File name		: SSFTSTD_RL78IoReg_CpuType_001.h											*/
/* Description		: RL78 SFR Definition Header File											*/
/*----------------------------------------------------------------------------------------------*/
/* Customer			: SSFT																		*/
/* Model(Theme No.)	: S_SS0006																	*/
/*----------------------------------------------------------------------------------------------*/
/* CPU				: RL78 D1A																	*/
/* Date				: 2015/10/29																*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: A.Izu																		*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Note				: 																			*/
/*----------------------------------------------------------------------------------------------*/
/* Update by        : $Author: Miyaguti Yoko (A01A038020) $                                               */
/* Date             : $Date: 2017/09/19 06:20:24ICT $                                           */
/* Version          : $Revision: 1.1 $                                                       */
/************************************************************************************************/
#ifndef RL78IOREG_CPUTYPE_001_H
#define RL78IOREG_CPUTYPE_001_H

/************************************************************************************************/
/* Header files																					*/
/************************************************************************************************/
/* 48pin - 48KB (R5F10CGD) */
#if defined(__F10CGD_)
	#include "SSFTSTD_RL78IoReg_F10CGD_001.h"

/* 64pin - 48KB (R5F10CLD) */
#elif defined(__F10CLD_)
	#include "SSFTSTD_RL78IoReg_F10CLD_001.h"

/* 64pin - 64KB (R5F10DLE) */
#elif defined(__F10DLE_)
	#include "SSFTSTD_RL78IoReg_F10DLE_001.h"

/* 80pin - 64KB (R5F10CME) */
#elif defined(__F10CME_)
	#include "SSFTSTD_RL78IoReg_F10CME_001.h"

/* 80pin - 96KB (R5F10DMF) */
#elif defined(__F10DMF_)
	#include "SSFTSTD_RL78IoReg_F10DMF_001.h"

#else
	#error "The I/O register file of the specified CPU option does not exist"
#endif

#endif /* RL78IOREG_CPUTYPE_001_H */
