# encoding: utf-8
from __future__ import print_function
from collections import OrderedDict
import re
import sys
import traceback


def skip_if0(line_iter):
    """ ``#if 0`` block should be ignore"""
    while True:
        line = next(line_iter)
        if line.startswith('#') and ("endif" in line or "else" in line):
            return


def get_section_map(map_path):
    """read .map file for ram sections"""

    with open(map_path) as fi:
        for line in fi:
            if line.startswith("-STARt"):
                sections_txt = line.strip().split('=')[1]
                break
        else:
            return

    sections = re.findall(r'.*?/[0-9A-F]{5}', sections_txt)

    section = OrderedDict()
    for item in sections:
        name, address = item.split("/")
        section[name.strip(',')] = address

    return section


def get_ram_config(config_path):
    """read config.h file for ram sections"""

    with open(config_path) as fi:
        ram = OrderedDict()
        for line in fi:
            # skip "if 0" block
            if re.match(r"# *if *0", line):
                skip_if0(fi)
                continue

            # skip non-define line
            if not re.match(r'# *define\s+RAM\d.+\(', line):
                continue

            res = re.search(r"RAM(\d).+START.+(0x[0-9A-Fa-f]+)", line)
            if res:
                sec_no, start_addr = res.groups()
                sec_no = "RAM{}".format(sec_no)
                if sec_no not in ram:
                    ram[sec_no] = start_addr
                else:
                    ram[sec_no] = min(ram[sec_no], start_addr)

        return ram


def main(argv=None):
    """raise error if min(config.h) != min(.map)"""

    if not argv:
        argv = sys.argv[1:]
    try:
        mapdata = get_section_map(argv[0])
        config = get_ram_config(argv[1])

        for section in config:
            map_addr = [mapdata[x] for x in mapdata if section in x]
            if int(config[section], 16) != min(int(x, 16) for x in map_addr):
                raise ValueError("\n\nError: {} section definition miss match\n\n".format(section))
        else:
            print("RAM section OK")
    except Exception as e:
        traceback.print_exc()
        raise RuntimeError


if __name__ == '__main__':
    main()



