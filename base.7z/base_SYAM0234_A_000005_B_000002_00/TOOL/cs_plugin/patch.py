# -*- encoding: utf-8 -*-
from __future__ import (absolute_import, division, print_function, unicode_literals)
import sys
import re

""" A monkey patch for python2
    Write code as in py3 that can run in py2! 
    patch for ``bytes`` and ``bytearray`` object
"""

__all__ = ['bytes', 'bytearray']


class BaseByteType(object):
    __slots__ = ["_data", '_container']

    def __init__(self, cls, sequence=None, encoding=None):
        self._container = cls
        if not sequence:
            self._data = cls()
        elif isinstance(sequence, int):
            self._data = cls([0] * sequence)
        elif isinstance(sequence, (str, unicode)):
            if not encoding:
                raise TypeError("string argument without an encoding")
            self._data = cls(ord(c) for c in sequence.encode(encoding))
        elif isinstance(sequence, (list, tuple)):
            if all((type(x) is int and 0 <= x <= 255) for x in sequence):
                self._data = cls(sequence)
            else:
                raise ValueError("an integer in range(0,256) is required")
        elif isinstance(sequence, BaseByteType):
            self._data = cls(sequence)
        elif isinstance(sequence, old_bytes):
            self._data = cls(map(ord, sequence))
        elif isinstance(sequence, old_bytearray):
            self._data = cls(map(int, sequence))
        else:
            raise TypeError("unexpected type: {}".format(type(sequence)))

    def hex(self):
        return ''.join(map(chr, self._data)).encode('hex')

    @classmethod
    def fromhex(cls, sequence):
        not_valid = re.search(r"([^0-9a-fA-F ])+", sequence)
        if not_valid:
            pos = not_valid.span()[0]
            raise ValueError('non-hexadecimal number found at position {}'.format(pos))
        else:
            txt = sequence.replace(' ', '').decode('hex')
        return cls(tuple(ord(c) for c in txt))

    def count(self, item, start=0, end=None):
        cls = self._container
        if not end:
            end = len(self)

        d = self._data[start:end]
        if type(item) is int:
            return d.count(item)
        elif isinstance(item, (BaseByteType, old_bytearray)):
            length = len(item)
            item = cls(item)
            return sum(d[i:i + length] == item for i in range(len(d) - length + 1))
        elif isinstance(item, old_bytes):
            length = len(item)
            item = cls(map(ord, item))
            return sum(d[i:i + length] == item for i in range(len(d) - length + 1))
        else:
            raise TypeError(" a py3bytes-like object is required, not {}".format(type(item)))

    def __add__(self, other):
        cls = self._container
        if isinstance(other, BaseByteType):
            code = cls(other)
        elif isinstance(other, old_bytes):
            code = cls(map(ord, other))
        elif isinstance(other, old_bytearray):
            code = cls(map(int, other))
        else:
            raise TypeError(" can't concat {} to 'bytes'".format(type(other)))

        new_code = self._data + code
        return self.__class__(new_code)

    def __radd__(self, left):
        cls = self._container
        if isinstance(left, BaseByteType):
            code = cls(left)
        elif isinstance(left, old_bytes):
            code = cls(map(ord, left))
        elif isinstance(left, old_bytearray):
            code = cls(map(int, left))
        else:
            raise TypeError('Expected bytes-like object, got {}'.format(type(left)))

        new_code = code + self._data
        return self.__class__(new_code)

    def __getitem__(self, item):
        if isinstance(item, slice):
            return self.__class__(self._data[item])
        elif isinstance(item, int):
            return self._data[item]
        else:
            raise TypeError("Expected type of 'slice' or 'int'!")

    def __len__(self):
        return len(self._data)

    def __str__(self):
        txt = []
        for x in self._data:
            if 0x20 <= x <= 0x7E:
                txt.append(chr(x))
            else:
                txt.append(r"\x{:02x}".format(x))
        txt = ''.join(txt)
        return txt

    def __contains__(self, item):
        cls = self._container
        if isinstance(item, int):
            return item in self._data

        elif isinstance(item, (BaseByteType, old_bytearray)):
            item = cls(item)
        elif isinstance(item, old_bytes):
            item = cls(map(ord, item))
        else:
            raise TypeError(" a bytes-like object is required, not <>".format(type(item)))

        for i in range(len(self) - len(item) + 1):
            if self._data[i:i + len(item)] == cls(item):
                return True
        else:
            return False

    def __eq__(self, other):
        if isinstance(other, BaseByteType):
            return other._data == self._data
        else:
            return False


class py3bytes(BaseByteType):
    """ mimic python3 ``bytes`` type for python2.7
        data type is a tuple of number in range(256)
    """

    def __init__(self, sequence=None, encoding=None):
        super(py3bytes, self).__init__(tuple, sequence, encoding)

    def __repr__(self):
        txt = str(self)
        c1 = '"' in txt
        c2 = "'" in txt

        if c1 and c2:
            txt = txt.replace("'", "\\'")

        template = "b'{}'" if c1 else 'b"{}"'
        return template.format(txt)


class py3bytearray(BaseByteType):
    """ mimic python3 ``bytearray`` type for python2.7
        a list of integer
    """

    def __init__(self, sequence=None, encoding=None, *arg, **kwarg):
        super(py3bytearray, self).__init__(list, sequence, encoding)

    def append(self, item):
        if isinstance(item, int) and 0 <= item <= 255:
            self._data.append(item)
        else:
            raise TypeError("an integer in range(256) is required")

    def extend(self, sequence):
        if isinstance(sequence, (py3bytes, py3bytearray)):
            self._data += list(sequence)
        elif isinstance(sequence, old_bytes):
            self._data += list(map(ord, sequence))
        elif isinstance(sequence, old_bytearray):
            self._data += list(map(int, sequence))
        elif isinstance(sequence, (list, tuple)):
            if all((type(x) is int and 0 <= x <= 255) for x in sequence):
                self._data += list(sequence)
            else:
                raise TypeError(" an integer is required")
        else:
            raise TypeError('expected a sequence of integer')

    def __setitem__(self, key, value):
        if isinstance(key, int):
            if isinstance(value, int):
                self._data[key] = value
            else:
                raise TypeError('an integer is required')
        elif isinstance(key, slice):
            if isinstance(value, (str, unicode)):
                raise TypeError("can't concat 'str' to 'bytes'")
            elif isinstance(value, (list, tuple)):
                if not all((type(x) is int and 0 <= x <= 255) for x in value):
                    raise TypeError("Expected an iterable of ints")
                self._data[key] = value
            elif isinstance(value, BaseByteType):
                self._data[key] = value
            elif isinstance(value, old_bytes):
                self._data[key] = [ord(x) for x in value]
            elif isinstance(value, old_bytearray):
                self._data[key] = [int(x) for x in value]
            else:
                raise TypeError("can assign only bytes, buffers, or iterables of ints in range(256)")
        else:
            raise TypeError("can assign only bytes, buffers, or iterables of ints in range(256)")

    def __repr__(self):
        txt = str(self)
        c1 = '"' in txt
        c2 = "'" in txt

        if c1 and c2:
            txt = txt.replace("'", "\\'")

        template = "bytearray(b'{}')" if c1 else 'bytearray(b"{}")'
        return template.format(txt)


old_bytes = bytes
old_bytearray = bytearray

if sys.version_info < (3, 5):
    bytes = py3bytes
    bytearray = py3bytearray
else:
    bytes = old_bytes
    bytearray = old_bytearray

if __name__ == '__main__':
    import unittest, binascii


    class Test_py3bytes(unittest.TestCase):

        def test_init(self):
            # null bytes sequence
            a = bytes(3)
            self.assertEqual(a._data, (0, 0, 0))

            # normal str
            with self.assertRaises(TypeError):
                a = bytes("no encoding")

            a = bytes("with encoding", encoding='utf8')
            self.assertEqual(a._data, tuple(map(ord, "with encoding")))

            # a sequence of number
            with self.assertRaises(ValueError):
                a = bytes([1, 2, 3, 256])

            with self.assertRaises(ValueError):
                a = bytes(['1', 2, 3, 256])

            a = bytes([1, 2, 3])
            self.assertEqual(a._data, (1, 2, 3))

            # a py2 bytes object
            a = bytes(b'aaa')
            self.assertEqual(a._data, (97, 97, 97))

            # a py2 bytearray object
            a = bytes(old_bytearray('aaa', 'utf8'))
            self.assertEqual(a._data, (97, 97, 97))

        def test_hex(self):
            a = bytes(b'aaa')
            res = a.hex()
            self.assertEqual(res, '616161')

        def test_fromhex(self):
            txt = '61 6161'
            a = bytes.fromhex(txt)
            self.assertEqual(a._data, (97, 97, 97))

            txt = 'Ab cd efe'
            with self.assertRaises(binascii.Error):
                a = bytes.fromhex(txt)

            txt = 'Ab cg ef'
            with self.assertRaises(ValueError):
                a = bytes.fromhex(txt)

        def test_count(self):
            a = bytes(b'aa123sdf5aasdf5485b')

            # count py2 type
            res = a.count(b'aa')
            self.assertEqual(res, 2)
            res = a.count(old_bytearray('aa', 'utf8'))
            self.assertEqual(res, 2)

            # count py3 type
            res = a.count(bytes('aa', 'utf8'))
            self.assertEqual(res, 2)
            res = a.count(bytearray('aa', 'utf8'))
            self.assertEqual(res, 2)

            # count other type
            with self.assertRaises(TypeError):
                a.count('aa')

        def test_add(self):
            a = bytes(b'ABCD')
            b = bytes(b'aaa')
            c = bytearray('aaa', 'utf8')
            d = old_bytearray('aaa', 'utf8')
            e = b'aaa'

            res = a + b
            self.assertEqual(res._data, (65, 66, 67, 68, 97, 97, 97))
            res = a + c
            self.assertEqual(res._data, (65, 66, 67, 68, 97, 97, 97))
            res = a + d
            self.assertEqual(res._data, (65, 66, 67, 68, 97, 97, 97))
            res = a + e
            self.assertEqual(res._data, (65, 66, 67, 68, 97, 97, 97))

            with self.assertRaises(TypeError):
                a + 'aaa'

        def test_radd(self):
            a = bytes(b'ABCD')
            d = old_bytearray('aaa', 'utf8')
            e = b'aaa'

            res = d + a
            self.assertEqual(res._data, (97, 97, 97, 65, 66, 67, 68))
            res = e + a
            self.assertEqual(res._data, (97, 97, 97, 65, 66, 67, 68))

            with self.assertRaises(TypeError):
                'aaa' + a

        def test_getitem(self):
            a = bytes(b'aaa')

            res = a[0]
            self.assertEqual(res, 97)

            res = a[:2]
            self.assertEqual(res, bytes(b'aa'))

            with self.assertRaises(TypeError):
                res = a['a']

        def test_contains(self):
            a = bytes(b'aabcd')
            b = bytes(b'aa')
            c = bytearray('aa', 'utf8')
            d = old_bytearray('aa', 'utf8')
            e = b'aa'
            f = b'ef'

            self.assertTrue(b in a)
            self.assertTrue(c in a)
            self.assertTrue(d in a)
            self.assertTrue(e in a)
            self.assertTrue(97 in a)  # hex('a') == 97
            self.assertTrue(b'b' in a)
            self.assertFalse(f in a)

            with self.assertRaises(TypeError):
                res = 'aa' in a


    class Test_py3bytearray(unittest.TestCase):

        def test_init(self):
            # null bytes sequence
            a = bytearray(3)
            self.assertEqual(a._data, [0, 0, 0])

            # normal str
            with self.assertRaises(TypeError):
                a = bytearray("no encoding")

            a = bytearray("with encoding", encoding='utf8')
            self.assertEqual(a._data, list(map(ord, "with encoding")))

            # a sequence of number
            with self.assertRaises(ValueError):
                a = bytearray([1, 2, 3, 256])

            with self.assertRaises(ValueError):
                a = bytearray(['1', 2, 3, 256])

            a = bytearray([1, 2, 3])
            self.assertEqual(a._data, [1, 2, 3])

            # a py2 bytes object
            a = bytearray(b'aaa')
            self.assertEqual(a._data, [97, 97, 97])

            # a py2 bytearray object
            a = bytearray(old_bytearray('aaa', 'utf8'))
            self.assertEqual(a._data, [97, 97, 97])

        def test_hex(self):
            a = bytearray(b'aaa')
            res = a.hex()
            self.assertEqual(res, '616161')

        def test_fromhex(self):
            txt = '61 6161'
            a = bytearray.fromhex(txt)
            self.assertEqual(a._data, [97, 97, 97])

            txt = 'Ab cd efe'
            with self.assertRaises(binascii.Error):
                a = bytearray.fromhex(txt)

            txt = 'Ab cg ef'
            with self.assertRaises(ValueError):
                a = bytearray.fromhex(txt)

        def test_count(self):
            a = bytearray(b'aa123sdf5aasdf5485b')

            # count py2 type
            res = a.count(b'aa')
            self.assertEqual(res, 2)
            res = a.count(old_bytearray('aa', 'utf8'))
            self.assertEqual(res, 2)

            # count py3 type
            res = a.count(bytearray('aa', 'utf8'))
            self.assertEqual(res, 2)
            res = a.count(bytearray('aa', 'utf8'))
            self.assertEqual(res, 2)

            # count other type
            with self.assertRaises(TypeError):
                a.count('aa')

        def test_add(self):
            a = bytearray(b'ABCD')
            b = bytes(b'aaa')
            c = bytearray('aaa', 'utf8')
            d = old_bytearray('aaa', 'utf8')
            e = b'aaa'

            res = a + b
            self.assertEqual(res._data, [65, 66, 67, 68, 97, 97, 97])
            res = a + c
            self.assertEqual(res._data, [65, 66, 67, 68, 97, 97, 97])
            res = a + d
            self.assertEqual(res._data, [65, 66, 67, 68, 97, 97, 97])
            res = a + e
            self.assertEqual(res._data, [65, 66, 67, 68, 97, 97, 97])

            with self.assertRaises(TypeError):
                a + 'aaa'

        def test_radd(self):
            a = bytearray(b'ABCD')
            d = old_bytearray('aaa', 'utf8')
            e = b'aaa'

            res = d + a
            self.assertEqual(res._data, [97, 97, 97, 65, 66, 67, 68])
            res = e + a
            self.assertEqual(res._data, [97, 97, 97, 65, 66, 67, 68])

            with self.assertRaises(TypeError):
                'aaa' + a

        def test_getitem(self):
            a = bytearray(b'aaa')

            res = a[0]
            self.assertEqual(res, 97)

            res = a[:2]
            self.assertEqual(res, bytearray(b'aa'))

            with self.assertRaises(TypeError):
                res = a['a']

        def test_contains(self):
            a = bytearray(b'aabcd')
            b = bytes(b'aa')
            c = bytearray('aa', 'utf8')
            d = old_bytearray('aa', 'utf8')
            e = b'aa'
            f = b'ef'

            self.assertTrue(b in a)
            self.assertTrue(c in a)
            self.assertTrue(d in a)
            self.assertTrue(e in a)
            self.assertTrue(97 in a)  # hex('a') == 97
            self.assertTrue(b'b' in a)
            self.assertFalse(f in a)

            with self.assertRaises(TypeError):
                res = 'aa' in a

        def test_append(self):
            a = bytearray(b'aaa')

            a.append(3)
            self.assertEqual(a._data, [97, 97, 97, 3])

            with self.assertRaises(TypeError):
                a.append(b'3')

        def test_extend(self):
            a = bytearray(b'aaa')
            b = bytes(b'b')
            c = bytearray(b'c')
            d = b'd'
            e = old_bytearray('e', 'utf8')

            a.extend(b)
            self.assertEqual(a._data, [97, 97, 97, 98])
            a.extend(c)
            self.assertEqual(a._data, [97, 97, 97, 98, 99])
            a.extend(d)
            self.assertEqual(a._data, [97, 97, 97, 98, 99, 100])
            a.extend(e)
            self.assertEqual(a._data, [97, 97, 97, 98, 99, 100, 101])
            a.extend([102, 103])
            self.assertEqual(a._data, [97, 97, 97, 98, 99, 100, 101, 102, 103])
            a.extend((104, 105))
            self.assertEqual(a._data, [97, 97, 97, 98, 99, 100, 101, 102, 103, 104, 105])

            with self.assertRaises(TypeError):
                a.extend('string')

            with self.assertRaises(TypeError):
                a.extend([1, 2, 'a'])

        def test_setitem(self):
            a = bytearray(b'aaaaa')

            with self.assertRaises(TypeError):
                a[0] = b'b'
            with self.assertRaises(TypeError):
                a[0] = bytes('b')

            a[0] = 98
            self.assertEqual(a._data, [98, 97, 97, 97, 97])
            a[:2] = b'b'
            self.assertEqual(a._data, [98, 97, 97, 97])
            a[2:3] = b'bcd'
            self.assertEqual(a._data, [98, 97, 98, 99, 100, 97])
            a[:-1] = bytes(b'aaa')
            self.assertEqual(a._data, [97, 97, 97, 97])
            a[:-1] = bytearray(b'bbb')
            self.assertEqual(a._data, [98, 98, 98, 97])
            a[:-1] = old_bytearray(b'ccc')
            self.assertEqual(a._data, [99, 99, 99, 97])

            a[:-1] = [100, 100, 100]
            self.assertEqual(a._data, [100, 100, 100, 97])

            with self.assertRaises(TypeError):
                a[:-1] = [100, 100, '1']


    suite = unittest.TestLoader().loadTestsFromTestCase(Test_py3bytes)
    unittest.TextTestRunner(verbosity=3).run(suite)

    suite = unittest.TestLoader().loadTestsFromTestCase(Test_py3bytearray)
    unittest.TextTestRunner(verbosity=3).run(suite)
