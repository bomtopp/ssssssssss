# -*- encoding: utf-8 -*-
from __future__ import (absolute_import, division, print_function, unicode_literals)
import argparse
import traceback
import re
from patch import *

""" Check and merge Appl and Boot's hex files. 
    Generate key file for CAN reprogramming 
    Generate checksum file.
"""

__date__ = "2020/07/16"
__version__ = "1.3.1"
__author__ = "Nguyen Ba Duc Tin"


CRC32_Tab = [
    0x00000000, 0x04c11db7, 0x09823b6e, 0x0d4326d9, 0x130476dc, 0x17c56b6b, 0x1a864db2, 0x1e475005,
    0x2608edb8, 0x22c9f00f, 0x2f8ad6d6, 0x2b4bcb61, 0x350c9b64, 0x31cd86d3, 0x3c8ea00a, 0x384fbdbd,
    0x4c11db70, 0x48d0c6c7, 0x4593e01e, 0x4152fda9, 0x5f15adac, 0x5bd4b01b, 0x569796c2, 0x52568b75,
    0x6a1936c8, 0x6ed82b7f, 0x639b0da6, 0x675a1011, 0x791d4014, 0x7ddc5da3, 0x709f7b7a, 0x745e66cd,
    0x9823b6e0, 0x9ce2ab57, 0x91a18d8e, 0x95609039, 0x8b27c03c, 0x8fe6dd8b, 0x82a5fb52, 0x8664e6e5,
    0xbe2b5b58, 0xbaea46ef, 0xb7a96036, 0xb3687d81, 0xad2f2d84, 0xa9ee3033, 0xa4ad16ea, 0xa06c0b5d,
    0xd4326d90, 0xd0f37027, 0xddb056fe, 0xd9714b49, 0xc7361b4c, 0xc3f706fb, 0xceb42022, 0xca753d95,
    0xf23a8028, 0xf6fb9d9f, 0xfbb8bb46, 0xff79a6f1, 0xe13ef6f4, 0xe5ffeb43, 0xe8bccd9a, 0xec7dd02d,
    0x34867077, 0x30476dc0, 0x3d044b19, 0x39c556ae, 0x278206ab, 0x23431b1c, 0x2e003dc5, 0x2ac12072,
    0x128e9dcf, 0x164f8078, 0x1b0ca6a1, 0x1fcdbb16, 0x018aeb13, 0x054bf6a4, 0x0808d07d, 0x0cc9cdca,
    0x7897ab07, 0x7c56b6b0, 0x71159069, 0x75d48dde, 0x6b93dddb, 0x6f52c06c, 0x6211e6b5, 0x66d0fb02,
    0x5e9f46bf, 0x5a5e5b08, 0x571d7dd1, 0x53dc6066, 0x4d9b3063, 0x495a2dd4, 0x44190b0d, 0x40d816ba,
    0xaca5c697, 0xa864db20, 0xa527fdf9, 0xa1e6e04e, 0xbfa1b04b, 0xbb60adfc, 0xb6238b25, 0xb2e29692,
    0x8aad2b2f, 0x8e6c3698, 0x832f1041, 0x87ee0df6, 0x99a95df3, 0x9d684044, 0x902b669d, 0x94ea7b2a,
    0xe0b41de7, 0xe4750050, 0xe9362689, 0xedf73b3e, 0xf3b06b3b, 0xf771768c, 0xfa325055, 0xfef34de2,
    0xc6bcf05f, 0xc27dede8, 0xcf3ecb31, 0xcbffd686, 0xd5b88683, 0xd1799b34, 0xdc3abded, 0xd8fba05a,
    0x690ce0ee, 0x6dcdfd59, 0x608edb80, 0x644fc637, 0x7a089632, 0x7ec98b85, 0x738aad5c, 0x774bb0eb,
    0x4f040d56, 0x4bc510e1, 0x46863638, 0x42472b8f, 0x5c007b8a, 0x58c1663d, 0x558240e4, 0x51435d53,
    0x251d3b9e, 0x21dc2629, 0x2c9f00f0, 0x285e1d47, 0x36194d42, 0x32d850f5, 0x3f9b762c, 0x3b5a6b9b,
    0x0315d626, 0x07d4cb91, 0x0a97ed48, 0x0e56f0ff, 0x1011a0fa, 0x14d0bd4d, 0x19939b94, 0x1d528623,
    0xf12f560e, 0xf5ee4bb9, 0xf8ad6d60, 0xfc6c70d7, 0xe22b20d2, 0xe6ea3d65, 0xeba91bbc, 0xef68060b,
    0xd727bbb6, 0xd3e6a601, 0xdea580d8, 0xda649d6f, 0xc423cd6a, 0xc0e2d0dd, 0xcda1f604, 0xc960ebb3,
    0xbd3e8d7e, 0xb9ff90c9, 0xb4bcb610, 0xb07daba7, 0xae3afba2, 0xaafbe615, 0xa7b8c0cc, 0xa379dd7b,
    0x9b3660c6, 0x9ff77d71, 0x92b45ba8, 0x9675461f, 0x8832161a, 0x8cf30bad, 0x81b02d74, 0x857130c3,
    0x5d8a9099, 0x594b8d2e, 0x5408abf7, 0x50c9b640, 0x4e8ee645, 0x4a4ffbf2, 0x470cdd2b, 0x43cdc09c,
    0x7b827d21, 0x7f436096, 0x7200464f, 0x76c15bf8, 0x68860bfd, 0x6c47164a, 0x61043093, 0x65c52d24,
    0x119b4be9, 0x155a565e, 0x18197087, 0x1cd86d30, 0x029f3d35, 0x065e2082, 0x0b1d065b, 0x0fdc1bec,
    0x3793a651, 0x3352bbe6, 0x3e119d3f, 0x3ad08088, 0x2497d08d, 0x2056cd3a, 0x2d15ebe3, 0x29d4f654,
    0xc5a92679, 0xc1683bce, 0xcc2b1d17, 0xc8ea00a0, 0xd6ad50a5, 0xd26c4d12, 0xdf2f6bcb, 0xdbee767c,
    0xe3a1cbc1, 0xe760d676, 0xea23f0af, 0xeee2ed18, 0xf0a5bd1d, 0xf464a0aa, 0xf9278673, 0xfde69bc4,
    0x89b8fd09, 0x8d79e0be, 0x803ac667, 0x84fbdbd0, 0x9abc8bd5, 0x9e7d9662, 0x933eb0bb, 0x97ffad0c,
    0xafb010b1, 0xab710d06, 0xa6322bdf, 0xa2f33668, 0xbcb4666d, 0xb8757bda, 0xb5365d03, 0xb1f740b4]

# address size in byte
# S4 S5 S6 haven't been listed below!
record_type = {'S0': 0,  # header
               'S1': 2,  # data
               'S2': 3,  # data
               'S3': 4,  # data
               'S7': 4,  # no data, terminate S3 series
               'S8': 3,  # no data, terminate S2 series
               'S9': 2,  # no data, This is used to terminate a series of S1 records
               }


def check_sum(data, bit_length=8):
    """ data      : hex string
        bit_length: int, 8|16|32
    """
    if bit_length == 8:
        """crc on 1 line, 8bits checksum"""
        cksum = 0
        for i in range(0, len(data), 2):
            cksum += int(data[i:i + 2], 16)

        # take 8 LSB and do 1 complement
        mask = 0xFF
        cksum &= mask

        return 0xFF - cksum

    elif bit_length == 16:
        """arithmetic  16bits checksum"""
        cksum = 0xffff - (sum(bytes.fromhex(data)) & 0xffff) + 1
        return cksum

    elif bit_length == 32:
        """crc32, follow the renesas' implementation for FL-PRv5"""
        crc_accum = 0xffffffff
        for c in bytes.fromhex(data):
            i = ((crc_accum >> 24) ^ c) & 0xff
            crc_accum = ((crc_accum << 8) ^ CRC32_Tab[i]) & 0xFFFfFFFF

        return crc_accum


def trivial_sum(data, bytes=2, byte_order='little'):
    """Return the sum of hex data in ``data`` string,
    assume that each unit of data is ``bytes`` byte length and the endian order is ``byte_order``.
    The sum is return in human readable order, 'big endian'
    """
    assert bytes in [1, 2, 4], "Error: number of bytes must in 1, 2, 4"
    assert byte_order in ['big', 'little'], "Error: byte_order must be either 'big' or 'little'"
    assert len(data) % (2 * bytes) == 0, "Error: Data len mismatch bytes number"
    if byte_order == 'little':
        d = [data[i:i + 2] for i in range(0, len(data), 2)]
        if bytes == 2:
            d0 = d[::2]
            d1 = d[1::2]
            d_little = (int(''.join(x), 16) for x in zip(d1, d0))
        elif bytes == 4:
            d0 = d[::4]
            d1 = d[1::4]
            d2 = d[2::4]
            d3 = d[3::4]
            d_little = (int(''.join(x), 16) for x in zip(d3, d2, d1, d0))
        else:
            d_little = (int(x, 16) for x in d)

        return sum(d_little)

    else:
        d_big = [data[i:i + bytes * 2] for i in range(0, len(data), 2 * bytes)]
        return sum(d_big)


def is_line_check_sum_ok(data_line):
    """Re calculate sum of the ``data_line`` and compare with computed data at the end of line"""
    data = data_line[2:-2]
    cksum = data_line[-2:]
    cksum_ = check_sum(data, 8)

    if cksum_ == int(cksum[-2:], 16):
        return True
    else:
        return False


class ROM_Data(object):
    """ Fill empty addresses with 0xff, check checksum, readout metadata, export to different file formats"""

    def __init__(self, file_path, ROM_size_in_KB):
        self.filename = file_path
        self.start_addr = 0
        self.end_addr = ROM_size_in_KB * 1024

        self.data = bytearray()

        self.version_pattern = re.compile(b'[A-Z]\d{6}[A-Z]{3}\d{4}')        # Old pattern for UART boot
        self.version_pattern2 = re.compile(b'[A-Z]{3}\d{4}[AC-Z]\d{6}')      # New pattern for CAN boot: App
        self.version_pattern3 = re.compile(b'[A-Z]{3}\d{4}B\d{6}')           # New pattern for CAN boot: Boot
        self.security_id_region = slice(0xC4, 0xCD+1)
        self._parse()

    def fill_missing(self, addr):
        assert addr <= self.end_addr, "Data address 0x{:X} is bigger than configured rom_size".format(addr)
        if addr > len(self.data):
            missing_bytes = addr - len(self.data)
            self.data.extend(b'\xff' * missing_bytes)

    def add_data(self, S123_line):
        """ check each line of mot file and read in hex data"""
        data_len = int(S123_line[2:4], 16) * 2
        addr_len = record_type[S123_line[0:2]] * 2

        assert len(S123_line[4:]) == data_len, "Hex file error: length mismatch"
        assert is_line_check_sum_ok(S123_line), "Hex file error: line check sum wrong!"

        addr = int(S123_line[4: 4 + addr_len], 16)
        data = S123_line[4 + addr_len:-2]

        self.fill_missing(addr)
        self.start_addr = addr
        self.data.extend(bytes.fromhex(data))

    def _parse(self, verbose=False):
        with open(self.filename) as data:
            line = data.readline().strip()

            if line[0:2] == 'S0':
                data_len = int(line[2:4], 16) * 2
                assert len(line[4:]) == data_len, "Hex file error: length mismatch at first line"
                assert is_line_check_sum_ok(line), "Hex file error: check sum wrong at first line!"
                file_name = line[8:-2]
                if verbose:
                    print(bytes.fromhex(file_name), '\n')
            else:
                data.seek(0)

            for ind, line in enumerate(data):
                my_line = line.strip()
                assert my_line[0:2] in record_type, "Hex file error: Don't know record type: '{}'".format(my_line[0:2])

                if my_line[0:2] in ('S1', 'S2', 'S3'):
                    # try:
                    self.add_data(my_line)
                # except Exception as e:
                #     print('{}: {}'.format(data.name, ind + 2))
                #     raise e
            else:
                self.fill_missing(self.end_addr)

    def get_chksum_appl(self):
        """UART Boot, Appl's sum"""
        # 0x800 ~ 0xBFF, 1KB, the first app block, except 4bytes of sum result area
        start_sum_zone = self.data[0x00804:0x00C00].hex()

        # 0xC00 ~ the rest, the second app block to the end
        end_sum_zone = self.data[0x000C00:].hex()

        start_chksum = trivial_sum(start_sum_zone, bytes=2, byte_order='little') & 0xffff
        end_chksum = trivial_sum(end_sum_zone, bytes=2, byte_order='little') & 0xffff

        a = '{:04X}'.format(start_chksum)
        b = '{:04X}'.format(end_chksum)
        str_ssm = a[2:] + a[:2]
        str_esm = b[2:] + b[:2]
        print('start_chksum: ' + str_ssm)
        print('end_chksum  : ' + str_esm)
        return str_ssm + str_esm

    def add_appl_sum(self):
        """Add appl's sum to 0x800, UART Boot only!"""
        sum_str = self.get_chksum_appl()
        self.data[0x00800:0x00804] = bytes.fromhex(sum_str)

    @staticmethod
    def _srec_head_footer(rec_type):
        """create a prefix-template and footer for specified srecord type and byte alignment number"""
        addr_size = record_type[rec_type]
        head = "{}{{:02X}}{{:0{:d}X}}".format(rec_type, addr_size * 2)  # S214Addr

        # the last newline character is needed
        footer = {"S1": "S9030000FC\n",
                  "S2": "S804000000FB\n",
                  "S3": "S70500000000FA\n"}

        return head, footer[rec_type]

    def export(self, filename, format="mot", start=0, end=0, **kwargs):
        """Export specified range of memory to ``mot``/``intel``/``bin`` format"""
        if start == end == 0:
            end = self.end_addr

        if format == "bin":
            with open(filename, 'wb+') as fo:
                fo.write(self.data[start:end])

        elif format == "intel":
            # todo: support Intel format, delay implementation until needed!
            raise NotImplementedError("Please use 'mot' or 'bin' format instead!")

        else:
            # create header line
            name = re.split(r'[/\\]', filename)[-1]
            hex_name = b'\x00\x00' + bytes(name, encoding='mbcs')
            chksum_data = (bytes([len(hex_name) + 1]) + hex_name).hex().upper()
            line_data = "S0" + chksum_data + "{:02X}\n".format(check_sum(chksum_data))

            # get format option
            align = kwargs.get("alignment", 16)
            r_type = kwargs.get("recordType", "S2")
            header = kwargs.get("header", True)

            assert r_type in "S1 S2 S3".split(), "Expect record_type in S1, S2, S3, got {}".format(r_type)
            max_hold = 2 ** (record_type[r_type] * 8)

            # write out
            head, foot = self._srec_head_footer(r_type)
            with open(filename, 'w+') as fo:
                if header:
                    fo.write(line_data)

                data = self.data[start:end]
                assert end <= max_hold, "Last address 0x{:X} is bigger than" \
                                        " maximum of S-record {}: 0x{:X}".format(end, r_type, max_hold)
                # content
                for addr in range(0, len(data), align):
                    line_data = data[addr:addr + align].hex()
                    byte_count = record_type[r_type] + len(line_data) // 2 + 1
                    prefix = head.format(byte_count, start + addr)
                    chksum = check_sum(prefix[2:] + line_data)
                    line = prefix + line_data + "{:02X}\n".format(chksum)
                    fo.write(line.upper())

                # footer, end of S record
                fo.write(foot)

    @property
    def have_boot(self):
        sample = self.data[0x1A0:0x5A0]  # 1024 byte
        return False if sample.count(b'\xff') > 768 else True

    @property
    def have_app(self):
        sample = self.data[0x3000:0x3400]  # 1024 byte
        return False if sample.count(b'\xff') > 768 else True

    @property
    def size(self):
        size = self.end_addr // 1024
        return size
    
    @property
    def app_version(self):
        # In python 2, bytes is alias for str, we have to convert back to str
        res = re.findall(self.version_pattern, str(self.data))
        if res:
            version = res[0].decode()
            return 'S{}_{}_{}'.format(version[7:], version[0], version[1:7])

        res = self.version_pattern2.findall(str(self.data))
        if res:
            version = res[0].decode()
            return 'S{}_{}_{}'.format(version[:7], version[7], version[8:])
            
        return 'unknown'
    
    @property
    def boot_version(self):
        res = self.version_pattern3.findall(str(self.data))
        if res:
            version = res[0].decode()
            return 'B_{}'.format(version[-6:])
        else:
            return 'unknown or specified manually in filename'

    @property
    def security_id(self):
        return self[self.security_id_region].hex().upper()

    @property
    def checksum(self):
        check_data = self.data.hex()
        crc32 = check_sum(check_data, 32)
        arithmetic = check_sum(check_data, 16)

        return {'crc32': '{:08X}h'.format(crc32), 'arithmetic': '{:04X}h'.format(arithmetic)}

    def __getitem__(self, item):
        return self.data[item]

    def __setitem__(self, key, value):
        self.data[key] = value

    def __str__(self):
        addr = "Address: 000000h - {:06X}h    {}KB".format(self.end_addr - 1, self.size)
        content = "Contain: boot   {}\n         appl   {}".format(self.have_boot, self.have_app)
        appl_ver = "Appl version: {}".format(self.app_version)
        boot_ver = "Boot version: {}".format(self.boot_version)
        sec_id = "Security ID : {} -> {}".format(self.security_id, repr(bytes.fromhex(self.security_id)))
        chksum = "crc32 chksum: {crc32}\narith chksum: {arithmetic}\n".format(**self.checksum)

        return '\n'.join([addr, content, appl_ver, boot_ver, sec_id, chksum])


def export_keyfile(map, rom_data, outname):
    """ export password KEY file for CAN Boot """
    section = "CAN_PASS_f"
    with open(map) as fi:
        for line in fi:
            if line.startswith(section):
                region = next(fi).strip().split()
                start_addr = int(region[0], 16)
                end_addr = int(region[1], 16)
                break
        else:
            raise RuntimeError("Section '{}' not found!".format(section))
    rom_data.export(outname, 'mot', start_addr, end_addr + 1, recordType='S3', header=False)


def export_checksum_file(rom_data, outname, inname=None):
    if not inname:
        inname = outname
    inname = re.split(r'[/\\]', inname)[-1]
    with open(outname, 'w+') as fo:
        fo.write('___ {} ___\n'.format(inname))
        fo.write(str(rom_data))


def int_16(x):
    if '0x' not in x and '0X' not in x:
        raise RuntimeError("Boundary must be in the form '0x\d+'")

    return int(x, 16)


def file_hex(x):
    if not x:
        return None
    if x[-4:].lower() not in ['.hex', '.mot']:
        raise TypeError("Filename not ended with either '.hex' or '.mot'")
    return x


def tuple_range(x):
    if not re.match(r"0x[0-9a-fA-F]+:0x[0-9a-fA-F]+", x):
        raise ValueError("Address range must in form of 0x1234:0xABCD")

    a, b = map(int_16, x.split(':'))
    return a, b


def bool_str(x):
    if x in ('0', 'False', 'false'):
        return False
    elif x in ('1', 'True', 'true'):
        return True
    else:
        raise ValueError("Bool type must be True/False or 0/1")


def required_length(nmin, nmax):
    class RequiredLength(argparse.Action):
        def __call__(self, parser, args, values, option_string=None):
            if not nmin <= len(values) <= nmax:
                msg = 'argument "{f}" requires between {nmin} and {nmax} arguments'.format(
                    f=self.dest, nmin=nmin, nmax=nmax)
                raise argparse.ArgumentTypeError(msg)
            setattr(args, self.dest, values)

    return RequiredLength


def get_parser():
    parser = argparse.ArgumentParser(description=" App and Boot's hex files merger for CS+ project\n"
                                                 "Also automatically generate KEY file for CAN Reprogramming.",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     epilog="Example: AB_merger.py boot.hex app.mot --boundary=0xD20 "
                                            "--romSize=96 --outName=AppBoot_xxyyzz.hex")
    parser.add_argument("--version", action='version', version="%(prog)s " + __version__)
    parser.add_argument("hexFiles", type=file_hex, nargs='+',
                        action=required_length(1, 2), help="hex file path(s). One of following pattern: "
                                                           "'appl.hex' or 'boot.hex' or 'appl.hex boot.hex'."
                                                           " If there are 2 files, the first file must be appl.")
    parser.add_argument("--boundary", type=int_16, help="hex address from where appl's data begin")
    parser.add_argument("--romSize", type=int, default=-1, required=True, help="MCU ROM size in KB")
    parser.add_argument("--outName", type=str, required=True, help="name of output file")
    parser.add_argument("--outType", type=str, default='mot', help="format of output file: mot/intel/bin")
    parser.add_argument("--recordType", type=str, default='S2', help="SRecord format: S1/S2/S3")
    parser.add_argument("--alignment", type=int, default=16, help="number of byte for each line")
    parser.add_argument("--range", type=tuple_range, default=(0, 0),
                        help="export data within this range of address only"
                             ", example:  --range 0x123:0xABC")
    parser.add_argument("--isUART", type=bool_str, default='False', help="calculate and add Appl's sum to hex file")

    return parser


def main(argv=None):
    parser = get_parser()
    have = vars(parser.parse_args(argv))
    print("AB_Merger ver{} {}".format(__version__, __date__))

    rom_size = have['romSize']
    try:
        if len(have["hexFiles"]) == 1:
            appl_data = ROM_Data(have['hexFiles'][0], rom_size)
            name = have['outName'].format(appl_ver=appl_data.app_version)
            appl_data.export(name, **have)
            print(" ROM Exported to: {}".format(name))

        elif len(have["hexFiles"]) == 2 and have["boundary"]:
            is_can_boot = not have['isUART']
            appl_data = ROM_Data(have['hexFiles'][0], rom_size)
            cut_addr = have['boundary']
            boot_data = ROM_Data(have['hexFiles'][1], rom_size)

            # export aligned boot hex file _____________________________________
            name = have['hexFiles'][1][:-4] + '_aligned.hex'
            boot_data.export(name, **have)
            print(" ROM Exported to: {}".format(name))
            
            # export merged file _______________________________________________
            # integrate boot to appl
            appl_data[:cut_addr] = boot_data[:cut_addr]

            # add checksum for UART boot
            if have['isUART']:
                appl_data.add_appl_sum()
            
            name = have['outName'].format(appl_ver=appl_data.app_version, 
                                          boot_ver=boot_data.boot_version)
            appl_data.export(name, **have)
            print(" ROM Exported to: {}".format(name))

            # export checksum, security ________________________________________
            csname = name[:-4] + '_chksum.txt'
            export_checksum_file(appl_data, csname, name)
            print(" Sum Exported to:", csname)

            # export key file for CAN Boot _____________________________________
            if is_can_boot:
                name = name[:-3] + 'key'
                export_keyfile(have['hexFiles'][1][:-3] + 'map', boot_data, name)
                print(" Key Exported to: {}".format(name))
        else:
            parser.print_usage()
            raise ValueError("The following arguments are required: boundary")

    except Exception as e:
        traceback.print_exc()
        raise RuntimeError


if __name__ == '__main__':
    main()
