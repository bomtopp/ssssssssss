# encoding: utf-8
import sys
import re
import traceback

def main(argv=None):
    """ Read [ProjectName].mtpj file for using device and macros """

    if not argv:
        argv = sys.argv[1:]
    try:
        mtpj = argv[0]

        with open(mtpj) as fi:
            data = fi.read()

        # find all devices and macros that exist in mtpj
        devices = re.findall(r"(?<=<DeviceName>R5).+?(?=</DeviceName>)", data)          # (R5)F10DMF
        macros = re.findall(r"(?<=__).{6}(?=_)", data)                                  # (__)F10DMF(_)

        if devices and macros:
            # current applying device and macro is the last found one
            last_dev = devices[-1]
            last_mac = macros[-1]
            assert last_dev == last_mac, "Project device and macro miss match!"
            print("Macro OK")
        else:
            raise ValueError("No device or macros found!")
    except Exception as e:
        traceback.print_exc()
        raise RuntimeError


if __name__ == '__main__':
    main()
