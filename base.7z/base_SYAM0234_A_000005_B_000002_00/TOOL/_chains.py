# -*- encoding: utf-8 -*-
import sys
import os
from subprocess import check_output, STDOUT, CalledProcessError


def reimport(module):
    """ While CS+ is running, enforce updating all changes in ``module``"""
    if sys.version_info >= (3, 3):
        from importlib import reload
    else:
        from imp import reload

    if module in sys.modules:
        reload(sys.modules[module])
    else:
        globals()[module] = __import__(module, globals(), locals(), [], 0)


def call(cmdline):
    """ call external program. Avoid polluting current namespace """

    cmdline = cmdline.replace("%ProjectName%", ProjectName)
    cmdline = cmdline.replace("%ProjectDir%", ProjectDir)
    cmdline = cmdline.replace("%OutputDir%", OutputDir)
    print(cmdline.replace("/", "\\"))

    CREATE_NO_WINDOW = 0x08000000

    # allow batch file to use %ProjectName%, %ProjectDir% and %OutputDir%
    env = dict(os.environ, ProjectName=ProjectName,
               ProjectDir=ProjectDir,
               OutputDir=OutputDir)
    try:
        res = check_output(cmdline, stderr=STDOUT, universal_newlines=True,
                           creationflags=CREATE_NO_WINDOW, env=env)
    except CalledProcessError as e:
        raise RuntimeError(str(e.output))
    except Exception as e:
        raise RuntimeError(str(e))
    else:
        print(res.decode('cp932').replace('\n\n', '\n'))


# _____________________________Preparation_____________________________________________
pyTOOL1 = "../TOOL/cs_plugin/"
otTOOL1 = "../TOOL/other/"
pyTOOL2 = "../../TOOL/cs_plugin/"   # because CAN boot program (IBL) path is one level
otTOOL2 = "../../TOOL/other/"       # deeper than UART boot program, we need 2 paths
pyEXE = os.path.join(os.__file__.split("Lib\\")[0], "ipyw.exe")
if pyTOOL1 not in sys.path:
    sys.path.insert(0, pyTOOL1)
if pyTOOL2 not in sys.path:
    sys.path.insert(0, pyTOOL2)

# extract project's information
ProjectDir = os.path.abspath('.')
ProjectName = sys.argv[0].replace('.mtpj', '')
OutputDir = os.path.abspath('.') + '/' + sys.argv[1]
RomSize = sys.argv[2]
AppName = sys.argv[3]  # boot or IBL needs to specify Appl project name
ApplBoundary = sys.argv[4]  # boot or IBL needs to specify Appl boundary address


# _____________________________Call external tools_____________________________________
print("\n* Check project's macro")
reimport("cpu_macro_check")
if 'IBL' not in ProjectName:
    argv = ["{}.mtpj".format(ProjectName)]
    cpu_macro_check.main(argv)
else:
    print("Skipped")


print("\n* Check ram section address")  # ______________________________________________
reimport('ram_sec_check')
if not AppName:
    mp = "DefaultBuild/{}.map".format(ProjectName)
    cp = "source/InOut/RamBackup/SSFTxxx_Rambackup_Config.h"
    argv = [mp, cp]
    # call([pyEXE, pyTOOL+"ram_sec_check.py"] + argv)
    ram_sec_check.main(argv)
else:
    print("Skipped")


print("\n* Create standard hex file")  # ______________________________________________
reimport('AB_merger')
if not AppName:  # called from Appl
    app_hex = OutputDir + "/{}.hex".format(ProjectName)
    out_name = "DefaultBuild/{appl_ver}.mot"
    argv = [app_hex,
            '--romSize', RomSize,
            '--outName', out_name,
            # '--outType', 'mot',       # mot|intel|bin: default to Motorola format
            # '--recordType', 'S2',     # S1|S2|S3     : default to S2
            # '--alignment', '16',      # default to 16 bits per line
            ]

else:  # called from uart_boot or IBL
    boot_hex = OutputDir + "/{}.hex".format(ProjectName)
    if os.path.exists("../../Appl/DefaultBuild/"):
        app_prefix = "../../Appl/DefaultBuild/"     # for CAN Boot, 1 level deeper
    else:
        app_prefix = "../Appl/DefaultBuild/"        # for UART Boot, same level as Appl
        
    app_hex = app_prefix + "{}.mot".format(AppName)
    out_name = app_prefix + "{appl_ver}_{boot_ver}.mot"
    
    is_uart = 'True' if 'Boot' in ProjectName else 'False'
    argv = [app_hex, boot_hex,
            '--romSize', RomSize,
            '--outName', out_name,
            '--isUART', is_uart,
            '--boundary', ApplBoundary,
            # '--outType', 'mot',       # mot|intel|bin: default to Motorola format
            # '--recordType', 'S2',     # S1|S2|S3     : default to S2
            # '--alignment', '16',      # default to 16 bits per line
            ]

# call([pyEXE, pyTOOL+"AB_merger.py"] + argv)
AB_merger.main(argv)

#print("\nCalling Motgen script ")
#if not AppName:     # called from Appl
#    argv = r"%ProjectDir%\..\Tool\Motedit\batch\marge_batch_RL78_Appl.bat 96K %ProjectName%.hex %ProjectName%_Boot.hex %ProjectName%_A_xxyyzz.mot"
#    call(argv)

#    argv = r"%ProjectDir%\..\Tool\CpuMacroCheck\cpu_macro_check.exe %ProjectDir%\%ProjectName%"
#    call(argv)

#    argv = r"%ProjectDir%\..\Tool\BackupRamAreaCheck\rangecheck_batch_RL78.bat %ProjectName%.map %ProjectDir%\..\Appl\source\InOut\RamBackup\SSFTxxx_Rambackup_Config.h"
#    call(argv)

#else:
#    argv = r"%ProjectDir%\..\Tool\Motedit\batch\marge_batch_RL78_Boot.bat 96K {app}_A_xxyyzz.mot %ProjectName%.hex {app}_A_xxyyzz_B_xxyyzz.mot".format(app=AppName)
#    call(argv)

#    argv = r"%ProjectDir%\..\Tool\CpuMacroCheck\cpu_macro_check.exe %ProjectDir%\%ProjectName%"
#    call(argv)

# _____________________________Toolchains finished_____________________________________
print("\nBuild completed successfully")




