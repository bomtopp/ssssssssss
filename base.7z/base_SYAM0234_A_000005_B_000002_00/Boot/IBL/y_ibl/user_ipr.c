/* CA78K0R C Source Converter V1.00.01.01 [25 Aug 2016] */
/*****************************************************************************
 DISCLAIMER
 This software is supplied by Renesas Electronics Corporation and is only
 intended for use with Renesas products. No other uses are authorized. This
 software is owned by Renesas Electronics Corporation and is protected under
 all applicable laws, including copyright laws.
 THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
 LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
 TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
 ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
 FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
 ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
 BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 Renesas reserves the right, without notice, to make changes to this software
 and to discontinue the availability of this software. By using this software,
 you agree to the additional terms and conditions found by accessing the
 following link:
 http://www.renesas.com/disclaimer
 Copyright (C) 2016 Renesas Electronics Corporation. All rights reserved.
******************************************************************************/
//[CcnvCA78K0R] 
#pragma inline_asm __inline_asm_func_00000
static void __inline_asm_func_00000(void)
{
	nop
}
#pragma inline_asm __inline_asm_func_00001
static void __inline_asm_func_00001(void)
{
	nop
}
#pragma inline_asm __inline_asm_func_00002
static void __inline_asm_func_00002(void)
{
	nop
}
#pragma inline_asm __inline_asm_func_00003
static void __inline_asm_func_00003(void)
{
	nop
}

/*============================================================================
//  user_ipr.c
//
//  Copyright (c) DTS INSIGHT CORPORATION.
//  2018 All rights reserved.
//
//  հ��IPR�������۸���
//  �Œ���̏������������s��YDC��IBL��ق��܂��B
//
//  ���۰�Ӽޭ�� : FC839-S2
//  �Ώ�ϲ��     : RL78/D1A
//
// �ύX�����F
//  +-------------- ����ԍ� (000 �` 999)
//  |    +--------- �V�X�e���o�[�W����
//  |    |    +--- �V�K�A�ύX�A�ǉ��A�폜�̕���
//  v    v    v
//  No  Ver  ����  �N����  ���O ����
// ---+-----+----+--------+----+----------------------------------------------
// 000|01.00|�V�K|18/05/24|DIST|�V�K�쐬
//==========================================================================*/
//[CcnvCA78K0R] #pragma section @@CODEL	IPR_C
#include "SSFTxxx_y_init_Config_001.h"

#pragma section const CAN_PASS
char const __far CANPASS[PASS_LEN] = NS_PASS;

/* BOOT_VERSION */
#pragma section const BOOT_VERSION
char const __far BOOT_VERSION_DATA[15] = 
{
	B_MAKER_MODEL_CODE1			,
	B_MAKER_MODEL_CODE2			,
	B_MAKER_MODEL_CODE3			,
	B_MAKER_MODEL_CODE4			,
	B_MAKER_MODEL_CODE5			,
	B_MAKER_MODEL_CODE6			,
	B_MAKER_MODEL_CODE7			,
	B_MAKER_MODEL_CODE8			,
	B_SOFTWARE_DISCRIMINATION	,
	B_SOFTWARE_VERSION1			,
	B_SOFTWARE_VERSION2			,
	B_SOFTWARE_VERSION3			,
	B_SOFTWARE_VERSION4			,
	B_SOFTWARE_VERSION5			,
	B_SOFTWARE_VERSION6			
};

#pragma section text	IPR_C

#define		SFRBASE			0x0FFF00																				/* SFR�̈��ް����ڽ */
#define		SFR2BASE		0x0F0000																				/* 2nd SFR�̈��ް����ڽ */

#define		CMC				*(volatile __far BYTE*)(SFRBASE+0x00A0)													/* �ۯ�����Ӱ�ސ���ڼ޽� */
#define		CSC				*(volatile __far BYTE*)(SFRBASE+0x00A1)													/* �ۯ�����ð��ڼ޽� */
#define		OSTC			*(volatile __far BYTE*)(SFRBASE+0x00A2)													/* ���U���莞�Զ������ڼ޽� */
#define		OSTS			*(volatile __far BYTE*)(SFRBASE+0x00A3)													/* ���U���莞�ԑI��ڼ޽� */
#define		CKC				*(volatile __far BYTE*)(SFRBASE+0x00A4)													/* ���сE�ۯ�����ڼ޽� */
#define		PLLCTL			*(volatile __far BYTE*)(SFR2BASE+0x0129)												/* PLL����ڼ޽� */
#define		PLLSTS			*(volatile __far BYTE*)(SFR2BASE+0x0128)												/* PLL���ڼ޽� */
#define		MDIV			*(volatile __far BYTE*)(SFR2BASE+0x00F8)												/* fMP�ۯ�����ڼ޽� */

/****************************************************************************/
/*                                 �^��`                                   */
/****************************************************************************/
typedef unsigned long  DWORD;																						/* 32bit�ް� */
typedef unsigned short WORD;																						/* 16bit�ް� */
typedef unsigned char  BYTE;																						/*  8bit�ް� */

/****************************************************************************/
/*                             ڼ޽���`	                                */
/****************************************************************************/

/****************************************************************************/
/*																			*/
/*		Ҳݏ���																*/
/*																			*/
/*		[�֐���]	main													*/
/*																			*/
/*		[���e]		հ��IPRҲ݊֐�											*/
/*																			*/
/*		[����]		none													*/
/*																			*/
/*		[�ߒl]		none													*/
/*																			*/
/****************************************************************************/
void main(void)
{
#if 1
	CMC = INIT_CMC;																										/* X1�ۯ����U��H����  */
	OSTS = INIT_OSTS;																									/* ���U���莞�� 2^13/fx�܂Ŷ��� */
	CSC = INIT_CSC;																										/* X1���U��H���U�J�n */
	while( (OSTC & OSTC_WAIT) != OSTC_WAIT ){;}																				/* ���U���莞�� 2^13/fx�o�߂܂ő҂� */
	CKC = INIT_CKC;																										/* CPU/���Ӹۯ���X1�ۯ��ɐݒ� */
	PLLCTL = INIT_PLLCTL;																									/* wait 2^8/fmain */
//[CcnvCA78K0R] 	__asm("nop");
	__inline_asm_func_00000();
//[CcnvCA78K0R] 	__asm("nop");
	__inline_asm_func_00001();
//[CcnvCA78K0R] 	__asm("nop");
	__inline_asm_func_00002();
//[CcnvCA78K0R] 	__asm("nop");
	__inline_asm_func_00003();
	PLLCTL |= PLL_ON_MASK;																									/* PLL ON      */
	while(!(PLLSTS & PLLSTS_LOCK_MASK));																						/* PLL unlock  */
	MDIV = INIT_MDIV;																									/* fMP�����Ȃ� */
	PLLCTL |= PLL_SEL_MASK;																									/* PLL Clock select mode */
#else
	CMC = 0x00;																										/* ���������ߵ�ڰ��g�p */
	CKC = 0x00;																										/* CPU/���Ӹۯ�������ߵ�ڰ��ۯ��ɐݒ� */
#endif
}
