/*============================================================================
//	y_ibl.h
//
//  Copyright (c) DTS INSIGHT CORPORATION.
//  2018 All rights reserved.
//  
//  ibl�ŗL��`̧��
//	IBL�ŗL�l��`̧�قł��BWCP�ł��{̧�ق��g�p���܂��B
//
//  ���۰�Ӽޭ�� : FC839-S2
//  �Ώ�ϲ��     : RL78/D1A
//
// �ύX�����F
//  +-------------- ����ԍ� (000 �` 999)
//  |    +--------- �V�X�e���o�[�W����
//  |    |    +--- �V�K�A�ύX�A�ǉ��A�폜�̕���
//  v    v    v
//  No  Ver  ����  �N����  ���O ����
// ---+-----+----+--------+----+----------------------------------------------
// 001|01.00|�V�K|18/08/24|DIST|�V�K�쐬
//==========================================================================*/

#ifndef _Y_IBL_H
#define _Y_IBL_H
#include	"SSFTxxx_y_init_Config_001.h"

/****************************************************************************/
/*                              Data Types                                  */
/****************************************************************************/
typedef unsigned long  DWORD;												/* 32bit�ް� */
typedef unsigned short WORD;												/* 16bit�ް� */
typedef unsigned char  BYTE;												/*  8bit�ް� */


typedef	struct mod_state_tag{												/* ��ԕϐ� */
	WORD	IOS_Div;														/* I/O���޽����*/
	WORD	IOS_WDT_Div;													/* ����WDT�ر�p���޽���� */
	BYTE	SendData[8];													/* ���M�ް��p�ޯ̧ */
	BYTE	RecvData[8];													/* ��M�ް��p�ޯ̧ */
	BYTE	SRD;															/* �ð��ڼ޽�1 */
	BYTE	SRD1;															/* �ð��ڼ޽�1 */
	BYTE	ToutFlag;														/* ��M��ѱ��(3s)�L���׸� 0=OFF,1=ON */
	BYTE	session;														/* �ȸľ���݊m��  0=session off, >0 session on */
} tMod_State;																

/****************************************************************************/
/*                        RL78/F13 ڼ޽���`                                */
/****************************************************************************/
#define		SFRBASE			0x0FFF00										/* SFR�̈��ް����ڽ */
#define		SFR2BASE		0x0F0000										/* 2nd SFR�̈��ް����ڽ */
#define		CAN0BASE		(SFR2BASE+0x0500)								/* CAN0�ް����ڽ */

#define		STSEL0			*(volatile __far BYTE*)(SFRBASE+0x003C)				/* �رْʐM�[�q�I��ڼ޽�0 */
#define		STSEL1			*(volatile __far BYTE*)(SFRBASE+0x003D)				/* �رْʐM�[�q�I��ڼ޽�1 */
#define		CMC				*(volatile __far BYTE*)(SFRBASE+0x00A0)				/* �ۯ�����Ӱ�ސ���ڼ޽� */
#define		CSC				*(volatile __far BYTE*)(SFRBASE+0x00A1)				/* �ۯ�����ð��ڼ޽� */
#define		OSTC			*(volatile __far BYTE*)(SFRBASE+0x00A2)				/* ���U���莞�Զ������ڼ޽� */
#define		OSTS			*(volatile __far BYTE*)(SFRBASE+0x00A3)				/* ���U���莞�ԑI��ڼ޽� */
#define		CKC				*(volatile __far BYTE*)(SFRBASE+0x00A4)				/* ���ѥ�ۯ�����ڼ޽� */
#define		RESF			*(volatile __far BYTE*)(SFRBASE+0x00A8)				/* ؾ�ĥ���۰٥�׸ޥڼ޽� */

#define		MK0L			*(volatile __far BYTE*)(SFRBASE+0x00E4)				/* ���荞��Ͻ��׸�ڼ޽�0L */
#define		MK0H			*(volatile __far BYTE*)(SFRBASE+0x00E5)				/* ���荞��Ͻ��׸�ڼ޽�0H */
#define		MK1L			*(volatile __far BYTE*)(SFRBASE+0x00E6)				/* ���荞��Ͻ��׸�ڼ޽�1L */
#define		MK1H			*(volatile __far BYTE*)(SFRBASE+0x00E7)				/* ���荞��Ͻ��׸�ڼ޽�1H */
#define		MK2L			*(volatile __far BYTE*)(SFRBASE+0x00D4)				/* ���荞��Ͻ��׸�ڼ޽�2L */
#define		MK2H			*(volatile __far BYTE*)(SFRBASE+0x00D5)				/* ���荞��Ͻ��׸�ڼ޽�2H */
#define		MK3L			*(volatile __far BYTE*)(SFRBASE+0x00D6)				/* ���荞��Ͻ��׸�ڼ޽�3L */

#define		IF1L			*(volatile __far BYTE*)(SFRBASE+0x00E2)				/* ���荞�ݗv���׸�ڼ޽�1L */
#define		IF2L			*(volatile __far BYTE*)(SFRBASE+0x00D0)				/* ���荞�ݗv���׸�ڼ޽�2L */

#define		IAWCTL			*(volatile __far BYTE*)(SFR2BASE+0x0078)				/* �s����ر������o����ڼ޽� */

#define		PER0			*(volatile __far BYTE*)(SFR2BASE+0x00F0)				/* ���ӲȰ���ڼ޽�0 */
#define		PER1			*(volatile __far BYTE*)(SFR2BASE+0x00F1)				/* ���ӲȰ���ڼ޽�1 */
#define		RPECTL			*(volatile __far BYTE*)(SFR2BASE+0x00F5)				/* RAM Parity�װ���۰�ڼ޽� */
#define		PLLCTL			*(volatile __far BYTE*)(SFR2BASE+0x0129)				/* PLL����ڼ޽� */
#define		PLLSTS			*(volatile __far BYTE*)(SFR2BASE+0x0128)				/* PLL���ڼ޽� */
#define		MDIV			*(volatile __far BYTE*)(SFR2BASE+0x00F8)				/* fMP�ۯ�����ڼ޽� */
#define		OSMC			*(volatile __far BYTE*)(SFR2BASE+0x00F3)				/* ���ӲȰ���ڼ޽�0 */
#define		HIOTRM			*(volatile __far BYTE*)(SFR2BASE+0x00A0)				/* ���������ߥ��ڰ����ݸ�ڼ޽� */

#define		WDTE			*(volatile __far BYTE*)(SFRBASE+0x00AB)				/* ����WDT�Ȱ���ڼ޽� */
#define		P0				*(volatile __far BYTE*)(SFRBASE+0x0000)				/* �߰�0ڼ޽� */
#define		P7				*(volatile __far BYTE*)(SFRBASE+0x0007)				/* �߰�7ڼ޽� */
#define		PM0				*(volatile __far BYTE*)(SFRBASE+0x0020)				/* �߰�0Ӱ��ڼ޽� */
#define		PM7				*(volatile __far BYTE*)(SFRBASE+0x0027)				/* �߰�7Ӱ��ڼ޽� */
#define		PIM0			*(volatile __far BYTE*)(SFR2BASE+0x0040)				/* �߰�0����Ӱ��ڼ޽� */
#define		PIM7			*(volatile __far BYTE*)(SFR2BASE+0x0047)				/* �߰�7����Ӱ��ڼ޽� */

#define		POM				*(volatile __far BYTE*)(SFR2BASE+0x006F)				/* �߰ďo��Ӱ��ڼ޽� */
#define		PMC				*(volatile __far BYTE*)(SFRBASE+0x00FE)				/* �߰�Ӱ�޺��۰�ڼ޽� */

#define		PCKSEL			*(volatile __far BYTE*)(SFR2BASE+0x00F2)				/* CAN�ۯ��I��ڼ޽� */

#define		ADPC			*(volatile __far BYTE*)(SFR2BASE+0x006E)				/* A/D�߰ĺ�̨�ޭڰ���ڼ޽� */

#define		TCR00			*(volatile __far WORD*)(SFR2BASE+0x0180)				/* ��ϥ����ڼ޽�00 */
#define		TDR00			*(volatile __far WORD*)(SFRBASE+0x0018)				/* ��ϥ�ް�ڼ޽�00 */
#define		TPS0			*(volatile __far WORD*)(SFR2BASE+0x01B6)				/* ��ϥ�ۯ��I��ڼ޽�0 */
#define		TMR00			*(volatile __far WORD*)(SFR2BASE+0x0190)				/* ��ϥӰ��ڼ޽�00 */
#define		TSR00			*(volatile __far WORD*)(SFR2BASE+0x01A0)				/* ��ϥ�ð��ڼ޽�00 */
#define		TE0				*(volatile __far WORD*)(SFR2BASE+0x01B0)				/* ��ϥ���ً��½ð��ڼ޽�0 */
#define		TS0				*(volatile __far WORD*)(SFR2BASE+0x01B2)				/* ��ϥ���يJ�nڼ޽�0 */
#define		TT0				*(volatile __far WORD*)(SFR2BASE+0x01B4)				/* ��ϥ���ْ�~ڼ޽�0 */
#define		TIS0			*(volatile __far BYTE*)(SFR2BASE+0x0070)				/* ��ϓ��͑I��ڼ޽�00 */
#define		TOE0			*(volatile __far WORD*)(SFR2BASE+0x01BA)				/* ��Ϗo�͋���ڼ޽�0 */
#define		TOE1			*(volatile __far WORD*)(SFR2BASE+0x01FA)				/* ��Ϗo�͋���ڼ޽�1 */
#define		TO0				*(volatile __far WORD*)(SFR2BASE+0x01B8)				/* ��Ϗo��ڼ޽�0 */
#define		TO1				*(volatile __far WORD*)(SFR2BASE+0x01F8)				/* ��Ϗo��ڼ޽�1 */
#define		TDR07			*(volatile __far WORD*)(SFRBASE+0x006E)				/* ��ϥ�ް�ڼ޽�07 */
#define		TMR07			*(volatile __far WORD*)(SFR2BASE+0x019E)				/* ��ϥӰ��ڼ޽�07 */

/* CAN */
#define		CAN_C0GMCTRL  		*(volatile __far WORD*)(CAN0BASE+0x00C0)				/* CAN0 global module control register					*/
#define		CAN_C0GMABT   		*(volatile __far WORD*)(CAN0BASE+0x00C6)				/* CAN0 global block transmission control register		*/
#define		CAN_C0GMABTD  		*(volatile __far BYTE*)(CAN0BASE+0x00C8)				/* CAN0 global block transmission delay setting register*/
#define		CAN_C0GMCS    		*(volatile __far BYTE*)(CAN0BASE+0x00CE)				/* CAN0 global module clock select register				*/
#define		CAN_C0MASK1L  		*(volatile __far WORD*)(CAN0BASE+0x00D0)				/* CAN0 module mask 1 register L 						*/
#define		CAN_C0MASK1H  		*(volatile __far WORD*)(CAN0BASE+0x00D2)				/* CAN0 module mask 1 register H 						*/
#define		CAN_C0MASK2L  		*(volatile __far WORD*)(CAN0BASE+0x00D4)				/* CAN0 module mask 2 register L 						*/
#define		CAN_C0MASK2H  		*(volatile __far WORD*)(CAN0BASE+0x00D6)				/* CAN0 module mask 2 register H 						*/
#define		CAN_C0MASK3L  		*(volatile __far WORD*)(CAN0BASE+0x00D8)				/* CAN0 module mask 3 register L 						*/
#define		CAN_C0MASK3H  		*(volatile __far WORD*)(CAN0BASE+0x00DA)				/* CAN0 module mask 3 register H 						*/
#define		CAN_C0MASK4L  		*(volatile __far WORD*)(CAN0BASE+0x00DC)				/* CAN0 module mask 4 register L 						*/
#define		CAN_C0MASK4H  		*(volatile __far WORD*)(CAN0BASE+0x00DE)				/* CAN0 module mask 4 register H 						*/
#define		CAN_C0CTRL    		*(volatile __far WORD*)(CAN0BASE+0x00E0)				/* CAN0 module control register 						*/
#define		CAN_C0LEC     		*(volatile __far BYTE*)(CAN0BASE+0x00E2)				/* CAN0 module last error information register	 		*/
#define		CAN_C0INFO    		*(volatile __far BYTE*)(CAN0BASE+0x00E3)				/* CAN0 module information register 					*/
#define		CAN_C0ERC     		*(volatile __far WORD*)(CAN0BASE+0x00E4)				/* CAN0 module error counter register 					*/
#define		CAN_C0IE      		*(volatile __far WORD*)(CAN0BASE+0x00E6)				/* CAN0 module interrupt enable register 				*/
#define		CAN_C0INTS    		*(volatile __far WORD*)(CAN0BASE+0x00E8)				/* CAN0 module interrupt status register 				*/
#define		CAN_C0BRP     		*(volatile __far BYTE*)(CAN0BASE+0x00EA)				/* CAN0 module bit rate prescaler register	 			*/
#define		CAN_C0BTR     		*(volatile __far WORD*)(CAN0BASE+0x00EC)				/* CAN0 module bit rate register 						*/
#define		CAN_C0LIPT    		*(volatile __far BYTE*)(CAN0BASE+0x00EE)				/* CAN0 module last in-pointer register 				*/
#define		CAN_C0RGPT    		*(volatile __far WORD*)(CAN0BASE+0x00F0)				/* CAN0 module receive history list register 			*/
#define		CAN_C0LOPT    		*(volatile __far BYTE*)(CAN0BASE+0x00F2)				/* CAN0 module last out-pointer register 				*/
#define		CAN_C0TGPT    		*(volatile __far WORD*)(CAN0BASE+0x00F4)				/* CAN0 module transmit history list register 			*/
#define		CAN_C0TS      		*(volatile __far WORD*)(CAN0BASE+0x00F6)				/* CAN0 module time stamp register	 					*/
#define		CAN_C0MDB0100  		*(volatile __far WORD*)(CAN0BASE+0x0100)				/* CAN0 message data byte 01 register 00				*/
#define		CAN_C0MDB000  		*(volatile __far BYTE*)(CAN0BASE+0x0100)				/* CAN0 message data byte 0 register  00				*/
#define		CAN_C0MDB100  		*(volatile __far BYTE*)(CAN0BASE+0x0101)				/* CAN0 message data byte 1 register  00				*/
#define		CAN_C0MDB2300  		*(volatile __far WORD*)(CAN0BASE+0x0102)				/* CAN0 message data byte 23 register 00				*/
#define		CAN_C0MDB200  		*(volatile __far BYTE*)(CAN0BASE+0x0102)				/* CAN0 message data byte 2 register  00				*/
#define		CAN_C0MDB300  		*(volatile __far BYTE*)(CAN0BASE+0x0103)				/* CAN0 message data byte 3 register  00				*/
#define		CAN_C0MDB4500  		*(volatile __far WORD*)(CAN0BASE+0x0104)				/* CAN0 message data byte 45 register 00				*/
#define		CAN_C0MDB400  		*(volatile __far BYTE*)(CAN0BASE+0x0104)				/* CAN0 message data byte 4 register  00				*/
#define		CAN_C0MDB500  		*(volatile __far BYTE*)(CAN0BASE+0x0105)				/* CAN0 message data byte 5 register  00				*/
#define		CAN_C0MDB6700  		*(volatile __far WORD*)(CAN0BASE+0x0106)				/* CAN0 message data byte 67 register 00				*/
#define		CAN_C0MDB600  		*(volatile __far BYTE*)(CAN0BASE+0x0106)				/* CAN0 message data byte 6 register  00				*/
#define		CAN_C0MDB700  		*(volatile __far BYTE*)(CAN0BASE+0x0107)				/* CAN0 message data byte 7 register  00				*/
#define		CAN_C0MDLC0  		*(volatile __far BYTE*)(CAN0BASE+0x0108)				/* CAN0 message data length register  00 				*/
#define		CAN_C0MCONF0 		*(volatile __far BYTE*)(CAN0BASE+0x0109)				/* CAN0 message configuration register00  				*/
#define		CAN_C0MIDL0  		*(volatile __far WORD*)(CAN0BASE+0x010A)				/* CAN0 message ID register 00L 						*/
#define		CAN_C0MIDH0  		*(volatile __far WORD*)(CAN0BASE+0x010C)				/* CAN0 message ID register 00H 						*/
#define		CAN_C0MCTRL0 		*(volatile __far WORD*)(CAN0BASE+0x010E)				/* CAN0 message control register 00 					*/

#define		CAN_C0MDB0101  		*(volatile __far WORD*)(CAN0BASE+0x0110)				/* CAN0 message data byte 01 register 01				*/
#define		CAN_C0MDB001  		*(volatile __far BYTE*)(CAN0BASE+0x0110)				/* CAN0 message data byte 0 register  01				*/
#define		CAN_C0MDB101  		*(volatile __far BYTE*)(CAN0BASE+0x0111)				/* CAN0 message data byte 1 register  01				*/
#define		CAN_C0MDB2301  		*(volatile __far WORD*)(CAN0BASE+0x0112)				/* CAN0 message data byte 23 register 01				*/
#define		CAN_C0MDB201  		*(volatile __far BYTE*)(CAN0BASE+0x0112)				/* CAN0 message data byte 2 register  01				*/
#define		CAN_C0MDB301  		*(volatile __far BYTE*)(CAN0BASE+0x0113)				/* CAN0 message data byte 3 register  01				*/
#define		CAN_C0MDB4501  		*(volatile __far WORD*)(CAN0BASE+0x0114)				/* CAN0 message data byte 45 register 01				*/
#define		CAN_C0MDB401  		*(volatile __far BYTE*)(CAN0BASE+0x0114)				/* CAN0 message data byte 4 register  01				*/
#define		CAN_C0MDB501  		*(volatile __far BYTE*)(CAN0BASE+0x0115)				/* CAN0 message data byte 5 register  01				*/
#define		CAN_C0MDB6701  		*(volatile __far WORD*)(CAN0BASE+0x0116)				/* CAN0 message data byte 67 register 01				*/
#define		CAN_C0MDB601  		*(volatile __far BYTE*)(CAN0BASE+0x0116)				/* CAN0 message data byte 6 register  01				*/
#define		CAN_C0MDB701  		*(volatile __far BYTE*)(CAN0BASE+0x0117)				/* CAN0 message data byte 7 register  01				*/
#define		CAN_C0MDLC1  		*(volatile __far BYTE*)(CAN0BASE+0x0118)				/* CAN0 message data length register  01 				*/
#define		CAN_C0MCONF1 		*(volatile __far BYTE*)(CAN0BASE+0x0119)				/* CAN0 message configuration register01  				*/
#define		CAN_C0MIDL1  		*(volatile __far WORD*)(CAN0BASE+0x011A)				/* CAN0 message ID register 01L 						*/
#define		CAN_C0MIDH1  		*(volatile __far WORD*)(CAN0BASE+0x011C)				/* CAN0 message ID register 01H 						*/
#define		CAN_C0MCTRL1 		*(volatile __far WORD*)(CAN0BASE+0x011E)				/* CAN0 message control register 01 					*/

#define		CAN_C0MDB0102  		*(volatile __far WORD*)(CAN0BASE+0x0120)				/* CAN0 message data byte 01 register 02				*/
#define		CAN_C0MDB002  		*(volatile __far BYTE*)(CAN0BASE+0x0120)				/* CAN0 message data byte 0 register  02				*/
#define		CAN_C0MDB102  		*(volatile __far BYTE*)(CAN0BASE+0x0121)				/* CAN0 message data byte 1 register  02				*/
#define		CAN_C0MDB2302  		*(volatile __far WORD*)(CAN0BASE+0x0122)				/* CAN0 message data byte 23 register 02				*/
#define		CAN_C0MDB202  		*(volatile __far BYTE*)(CAN0BASE+0x0122)				/* CAN0 message data byte 2 register  02				*/
#define		CAN_C0MDB302  		*(volatile __far BYTE*)(CAN0BASE+0x0123)				/* CAN0 message data byte 3 register  02				*/
#define		CAN_C0MDB4502  		*(volatile __far WORD*)(CAN0BASE+0x0124)				/* CAN0 message data byte 45 register 02				*/
#define		CAN_C0MDB402  		*(volatile __far BYTE*)(CAN0BASE+0x0124)				/* CAN0 message data byte 4 register  02				*/
#define		CAN_C0MDB502  		*(volatile __far BYTE*)(CAN0BASE+0x0125)				/* CAN0 message data byte 5 register  02				*/
#define		CAN_C0MDB6702  		*(volatile __far WORD*)(CAN0BASE+0x0126)				/* CAN0 message data byte 67 register 02				*/
#define		CAN_C0MDB602  		*(volatile __far BYTE*)(CAN0BASE+0x0126)				/* CAN0 message data byte 6 register  02				*/
#define		CAN_C0MDB702  		*(volatile __far BYTE*)(CAN0BASE+0x0127)				/* CAN0 message data byte 7 register  02				*/
#define		CAN_C0MDLC2  		*(volatile __far BYTE*)(CAN0BASE+0x0128)				/* CAN0 message data length register  02 				*/
#define		CAN_C0MCONF2 		*(volatile __far BYTE*)(CAN0BASE+0x0129)				/* CAN0 message configuration register02  				*/
#define		CAN_C0MIDL2  		*(volatile __far WORD*)(CAN0BASE+0x012A)				/* CAN0 message ID register 02L 						*/
#define		CAN_C0MIDH2  		*(volatile __far WORD*)(CAN0BASE+0x012C)				/* CAN0 message ID register 02H 						*/
#define		CAN_C0MCTRL2 		*(volatile __far WORD*)(CAN0BASE+0x012E)				/* CAN0 message control register 02 					*/

#define		CAN_C0MDB0103  		*(volatile __far WORD*)(CAN0BASE+0x0130)				/* CAN0 message data byte 01 register 03				*/
#define		CAN_C0MDB003  		*(volatile __far BYTE*)(CAN0BASE+0x0130)				/* CAN0 message data byte 0 register  03				*/
#define		CAN_C0MDB103  		*(volatile __far BYTE*)(CAN0BASE+0x0131)				/* CAN0 message data byte 1 register  03				*/
#define		CAN_C0MDB2303  		*(volatile __far WORD*)(CAN0BASE+0x0132)				/* CAN0 message data byte 23 register 03				*/
#define		CAN_C0MDB203  		*(volatile __far BYTE*)(CAN0BASE+0x0132)				/* CAN0 message data byte 2 register  03				*/
#define		CAN_C0MDB303  		*(volatile __far BYTE*)(CAN0BASE+0x0133)				/* CAN0 message data byte 3 register  03				*/
#define		CAN_C0MDB4503  		*(volatile __far WORD*)(CAN0BASE+0x0134)				/* CAN0 message data byte 45 register 03				*/
#define		CAN_C0MDB403  		*(volatile __far BYTE*)(CAN0BASE+0x0134)				/* CAN0 message data byte 4 register  03				*/
#define		CAN_C0MDB503  		*(volatile __far BYTE*)(CAN0BASE+0x0135)				/* CAN0 message data byte 5 register  03				*/
#define		CAN_C0MDB6703  		*(volatile __far WORD*)(CAN0BASE+0x0136)				/* CAN0 message data byte 67 register 03				*/
#define		CAN_C0MDB603  		*(volatile __far BYTE*)(CAN0BASE+0x0136)				/* CAN0 message data byte 6 register  03				*/
#define		CAN_C0MDB703  		*(volatile __far BYTE*)(CAN0BASE+0x0137)				/* CAN0 message data byte 7 register  03				*/
#define		CAN_C0MDLC3  		*(volatile __far BYTE*)(CAN0BASE+0x0138)				/* CAN0 message data length register  03 				*/
#define		CAN_C0MCONF3 		*(volatile __far BYTE*)(CAN0BASE+0x0139)				/* CAN0 message Configuration register03 				*/
#define		CAN_C0MIDL3  		*(volatile __far WORD*)(CAN0BASE+0x013A)				/* CAN0 message ID register 03L 						*/
#define		CAN_C0MIDH3  		*(volatile __far WORD*)(CAN0BASE+0x013C)				/* CAN0 message ID register 03H 						*/
#define		CAN_C0MCTRL3 		*(volatile __far WORD*)(CAN0BASE+0x013E)				/* CAN0 message control register 03 					*/

#define		CAN_C0MDB0104  		*(volatile __far WORD*)(CAN0BASE+0x0140)				/* CAN0 message data byte 01 register 04				*/
#define		CAN_C0MDB004  		*(volatile __far BYTE*)(CAN0BASE+0x0140)				/* CAN0 message data byte 0 register  04				*/
#define		CAN_C0MDB104  		*(volatile __far BYTE*)(CAN0BASE+0x0141)				/* CAN0 message data byte 1 register  04				*/
#define		CAN_C0MDB2304  		*(volatile __far WORD*)(CAN0BASE+0x0142)				/* CAN0 message data byte 23 register 04				*/
#define		CAN_C0MDB204  		*(volatile __far BYTE*)(CAN0BASE+0x0142)				/* CAN0 message data byte 2 register  04				*/
#define		CAN_C0MDB304  		*(volatile __far BYTE*)(CAN0BASE+0x0143)				/* CAN0 message data byte 3 register  04				*/
#define		CAN_C0MDB4504  		*(volatile __far WORD*)(CAN0BASE+0x0144)				/* CAN0 message data byte 45 register 04				*/
#define		CAN_C0MDB404  		*(volatile __far BYTE*)(CAN0BASE+0x0144)				/* CAN0 message data byte 4 register  04				*/
#define		CAN_C0MDB504  		*(volatile __far BYTE*)(CAN0BASE+0x0145)				/* CAN0 message data byte 5 register  04				*/
#define		CAN_C0MDB6704  		*(volatile __far WORD*)(CAN0BASE+0x0146)				/* CAN0 message data byte 67 register 04				*/
#define		CAN_C0MDB604  		*(volatile __far BYTE*)(CAN0BASE+0x0146)				/* CAN0 message data byte 6 register  04				*/
#define		CAN_C0MDB704  		*(volatile __far BYTE*)(CAN0BASE+0x0147)				/* CAN0 message data byte 7 register  04				*/
#define		CAN_C0MDLC4  		*(volatile __far BYTE*)(CAN0BASE+0x0148)				/* CAN0 message data length register  04				*/
#define		CAN_C0MCONF4 		*(volatile __far BYTE*)(CAN0BASE+0x0149)				/* CAN0 message Configuration register04 				*/
#define		CAN_C0MIDL4  		*(volatile __far WORD*)(CAN0BASE+0x014A)				/* CAN0 message ID register 04L 						*/
#define		CAN_C0MIDH4  		*(volatile __far WORD*)(CAN0BASE+0x014C)				/* CAN0 message ID register 04H 						*/
#define		CAN_C0MCTRL4 		*(volatile __far WORD*)(CAN0BASE+0x014E)				/* CAN0 message control register 04 					*/

#define		CAN_C0MDB0105  		*(volatile __far WORD*)(CAN0BASE+0x0150)				/* CAN0 message data byte 01 register 05				*/
#define		CAN_C0MDB005  		*(volatile __far BYTE*)(CAN0BASE+0x0150)				/* CAN0 message data byte 0 register  05				*/
#define		CAN_C0MDB105  		*(volatile __far BYTE*)(CAN0BASE+0x0151)				/* CAN0 message data byte 1 register  05				*/
#define		CAN_C0MDB2305  		*(volatile __far WORD*)(CAN0BASE+0x0152)				/* CAN0 message data byte 23 register 05				*/
#define		CAN_C0MDB205  		*(volatile __far BYTE*)(CAN0BASE+0x0152)				/* CAN0 message data byte 2 register  05				*/
#define		CAN_C0MDB305  		*(volatile __far BYTE*)(CAN0BASE+0x0153)				/* CAN0 message data byte 3 register  05				*/
#define		CAN_C0MDB4505  		*(volatile __far WORD*)(CAN0BASE+0x0154)				/* CAN0 message data byte 45 register 05				*/
#define		CAN_C0MDB405  		*(volatile __far BYTE*)(CAN0BASE+0x0154)				/* CAN0 message data byte 4 register  05				*/
#define		CAN_C0MDB505  		*(volatile __far BYTE*)(CAN0BASE+0x0155)				/* CAN0 message data byte 5 register  05				*/
#define		CAN_C0MDB6705  		*(volatile __far WORD*)(CAN0BASE+0x0156)				/* CAN0 message data byte 67 register 05				*/
#define		CAN_C0MDB605  		*(volatile __far BYTE*)(CAN0BASE+0x0156)				/* CAN0 message data byte 6 register  05				*/
#define		CAN_C0MDB705  		*(volatile __far BYTE*)(CAN0BASE+0x0157)				/* CAN0 message data byte 7 register  05				*/
#define		CAN_C0MDLC5  		*(volatile __far BYTE*)(CAN0BASE+0x0158)				/* CAN0 message data length register  05 				*/
#define		CAN_C0MCONF5  		*(volatile __far BYTE*)(CAN0BASE+0x0159)				/* CAN0 message Configuration register05 				*/
#define		CAN_C0MIDL5  		*(volatile __far WORD*)(CAN0BASE+0x015A)				/* CAN0 message ID register 05L 						*/
#define		CAN_C0MIDH5  		*(volatile __far WORD*)(CAN0BASE+0x015C)				/* CAN0 message ID register 05H 						*/
#define		CAN_C0MCTRL5 		*(volatile __far WORD*)(CAN0BASE+0x015E)				/* CAN0 message control register 05  					*/

#define		CAN_C0MDB0106  		*(volatile __far WORD*)(CAN0BASE+0x0160)				/* CAN0 message data byte 01 register 06				*/
#define		CAN_C0MDB006  		*(volatile __far BYTE*)(CAN0BASE+0x0160)				/* CAN0 message data byte 0 register  06				*/
#define		CAN_C0MDB106  		*(volatile __far BYTE*)(CAN0BASE+0x0161)				/* CAN0 message data byte 1 register  06				*/
#define		CAN_C0MDB2306  		*(volatile __far WORD*)(CAN0BASE+0x0162)				/* CAN0 message data byte 23 register 06				*/
#define		CAN_C0MDB20  		*(volatile __far BYTE*)(CAN0BASE+0x0162)				/* CAN0 message data byte 2 register  06				*/
#define		CAN_C0MDB306  		*(volatile __far BYTE*)(CAN0BASE+0x0163)				/* CAN0 message data byte 3 register  06				*/
#define		CAN_C0MDB4506  		*(volatile __far WORD*)(CAN0BASE+0x0164)				/* CAN0 message data byte 45 register 06				*/
#define		CAN_C0MDB406  		*(volatile __far BYTE*)(CAN0BASE+0x0164)				/* CAN0 message data byte 4 register  06				*/
#define		CAN_C0MDB506  		*(volatile __far BYTE*)(CAN0BASE+0x0165)				/* CAN0 message data byte 5 register  06				*/
#define		CAN_C0MDB6706  		*(volatile __far WORD*)(CAN0BASE+0x0166)				/* CAN0 message data byte 67 register 06				*/
#define		CAN_C0MDB606  		*(volatile __far BYTE*)(CAN0BASE+0x0166)				/* CAN0 message data byte 6 register  06				*/
#define		CAN_C0MDB706  		*(volatile __far BYTE*)(CAN0BASE+0x0167)				/* CAN0 message data byte 7 register  06				*/
#define		CAN_C0MDLC6  		*(volatile __far BYTE*)(CAN0BASE+0x0168)				/* CAN0 message data length register 06  				*/
#define		CAN_C0MCONF6  		*(volatile __far BYTE*)(CAN0BASE+0x0169)				/* CAN0 message Configuration register 06  				*/
#define		CAN_C0MIDL6  		*(volatile __far WORD*)(CAN0BASE+0x016A)				/* CAN0 message ID register 06L  						*/
#define		CAN_C0MIDH6  		*(volatile __far WORD*)(CAN0BASE+0x016C)				/* CAN0 message ID register 06H  						*/
#define		CAN_C0MCTRL6 		*(volatile __far WORD*)(CAN0BASE+0x016E)				/* CAN0 message control register 06  					*/

#define		CAN_C0MDB0107  		*(volatile __far WORD*)(CAN0BASE+0x0170)				/* CAN0 message data byte 01 register 07				*/
#define		CAN_C0MDB007  		*(volatile __far BYTE*)(CAN0BASE+0x0170)				/* CAN0 message data byte 0 register  07				*/
#define		CAN_C0MDB107  		*(volatile __far BYTE*)(CAN0BASE+0x0171)				/* CAN0 message data byte 1 register  07				*/
#define		CAN_C0MDB2307  		*(volatile __far WORD*)(CAN0BASE+0x0172)				/* CAN0 message data byte 23 register 07				*/
#define		CAN_C0MDB207  		*(volatile __far BYTE*)(CAN0BASE+0x0172)				/* CAN0 message data byte 2 register  07				*/
#define		CAN_C0MDB307  		*(volatile __far BYTE*)(CAN0BASE+0x0173)				/* CAN0 message data byte 3 register  07				*/
#define		CAN_C0MDB4507  		*(volatile __far WORD*)(CAN0BASE+0x0174)				/* CAN0 message data byte 45 register 07				*/
#define		CAN_C0MDB407 		*(volatile __far BYTE*)(CAN0BASE+0x0174)				/* CAN0 message data byte 4 register  07				*/
#define		CAN_C0MDB507  		*(volatile __far BYTE*)(CAN0BASE+0x0175)				/* CAN0 message data byte 5 register  07				*/
#define		CAN_C0MDB6707  		*(volatile __far WORD*)(CAN0BASE+0x0176)				/* CAN0 message data byte 67 register 07				*/
#define		CAN_C0MDB607  		*(volatile __far BYTE*)(CAN0BASE+0x0176)				/* CAN0 message data byte 6 register  07				*/
#define		CAN_C0MDB707  		*(volatile __far BYTE*)(CAN0BASE+0x0177)				/* CAN0 message data byte 7 register  07				*/
#define		CAN_C0MDLC7  		*(volatile __far BYTE*)(CAN0BASE+0x0178)				/* CAN0 message data length register 07  				*/
#define		CAN_C0MCONF7 		*(volatile __far BYTE*)(CAN0BASE+0x0179)				/* CAN0 message Configuration register 07  				*/
#define		CAN_C0MIDL7  		*(volatile __far WORD*)(CAN0BASE+0x017A)				/* CAN0 message ID register 07L  						*/
#define		CAN_C0MIDH7  		*(volatile __far WORD*)(CAN0BASE+0x017C)				/* CAN0 message ID register 07H  						*/
#define		CAN_C0MCTRL7 		*(volatile __far WORD*)(CAN0BASE+0x017E)				/* CAN0 message control register 07  					*/

#define		CAN_C0MDB0108  		*(volatile __far WORD*)(CAN0BASE+0x0180)				/* CAN0 message data byte 01 register 08				*/
#define		CAN_C0MDB008  		*(volatile __far BYTE*)(CAN0BASE+0x0180)				/* CAN0 message data byte 0 register  08				*/
#define		CAN_C0MDB108  		*(volatile __far BYTE*)(CAN0BASE+0x0181)				/* CAN0 message data byte 1 register  08				*/
#define		CAN_C0MDB2308  		*(volatile __far WORD*)(CAN0BASE+0x0182)				/* CAN0 message data byte 23 register 08				*/
#define		CAN_C0MDB208  		*(volatile __far BYTE*)(CAN0BASE+0x0182)				/* CAN0 message data byte 2 register  08				*/
#define		CAN_C0MDB308  		*(volatile __far BYTE*)(CAN0BASE+0x0183)				/* CAN0 message data byte 3 register  08				*/
#define		CAN_C0MDB4508  		*(volatile __far WORD*)(CAN0BASE+0x0184)				/* CAN0 message data byte 45 register 08				*/
#define		CAN_C0MDB408  		*(volatile __far BYTE*)(CAN0BASE+0x0184)				/* CAN0 message data byte 4 register  08				*/
#define		CAN_C0MDB508  		*(volatile __far BYTE*)(CAN0BASE+0x0185)				/* CAN0 message data byte 5 register  08				*/
#define		CAN_C0MDB6708  		*(volatile __far WORD*)(CAN0BASE+0x0186)				/* CAN0 message data byte 67 register 08				*/
#define		CAN_C0MDB608  		*(volatile __far BYTE*)(CAN0BASE+0x0186)				/* CAN0 message data byte 6 register  08				*/
#define		CAN_C0MDB708  		*(volatile __far BYTE*)(CAN0BASE+0x0187)				/* CAN0 message data byte 7 register  08				*/
#define		CAN_C0MDLC8  		*(volatile __far BYTE*)(CAN0BASE+0x0188)				/* CAN0 message data length register 08  				*/
#define		CAN_C0MCONF8 		*(volatile __far BYTE*)(CAN0BASE+0x0189)				/* CAN0 message Configuration register 08  				*/
#define		CAN_C0MIDL8  		*(volatile __far WORD*)(CAN0BASE+0x018A)				/* CAN0 message ID register 08L  						*/
#define		CAN_C0MIDH8  		*(volatile __far WORD*)(CAN0BASE+0x018C)				/* CAN0 message ID register 08H  						*/
#define		CAN_C0MCTRL8 		*(volatile __far WORD*)(CAN0BASE+0x018E)				/* CAN0 message control register 08  					*/

#define		CAN_C0MDB0109  		*(volatile __far WORD*)(CAN0BASE+0x0190)				/* CAN0 message data byte 01 register 09				*/
#define		CAN_C0MDB009  		*(volatile __far BYTE*)(CAN0BASE+0x0190)				/* CAN0 message data byte 0 register  09				*/
#define		CAN_C0MDB109  		*(volatile __far BYTE*)(CAN0BASE+0x0191)				/* CAN0 message data byte 1 register  09				*/
#define		CAN_C0MDB2309  		*(volatile __far WORD*)(CAN0BASE+0x0192)				/* CAN0 message data byte 23 register 09				*/
#define		CAN_C0MDB209  		*(volatile __far BYTE*)(CAN0BASE+0x0192)				/* CAN0 message data byte 2 register  09				*/
#define		CAN_C0MDB309  		*(volatile __far BYTE*)(CAN0BASE+0x0193)				/* CAN0 message data byte 3 register  09				*/
#define		CAN_C0MDB4509  		*(volatile __far WORD*)(CAN0BASE+0x0194)				/* CAN0 message data byte 45 register 09				*/
#define		CAN_C0MDB409  		*(volatile __far BYTE*)(CAN0BASE+0x0194)				/* CAN0 message data byte 4 register  09				*/
#define		CAN_C0MDB509  		*(volatile __far BYTE*)(CAN0BASE+0x0195)				/* CAN0 message data byte 5 register  09				*/
#define		CAN_C0MDB6709  		*(volatile __far WORD*)(CAN0BASE+0x0196)				/* CAN0 message data byte 67 register 09				*/
#define		CAN_C0MDB609  		*(volatile __far BYTE*)(CAN0BASE+0x0196)				/* CAN0 message data byte 6 register  09				*/
#define		CAN_C0MDB709  		*(volatile __far BYTE*)(CAN0BASE+0x0197)				/* CAN0 message data byte 7 register  09				*/
#define		CAN_C0MDLC9  		*(volatile __far BYTE*)(CAN0BASE+0x0198)				/* CAN0 message data length register 09  				*/
#define		CAN_C0MCONF9 		*(volatile __far BYTE*)(CAN0BASE+0x0199)				/* CAN0 message Configuration register 09  				*/
#define		CAN_C0MIDL9  		*(volatile __far WORD*)(CAN0BASE+0x019A)				/* CAN0 message ID register 09L  						*/
#define		CAN_C0MIDH9  		*(volatile __far WORD*)(CAN0BASE+0x019C)				/* CAN0 message ID register 09H  						*/
#define		CAN_C0MCTRL9 		*(volatile __far WORD*)(CAN0BASE+0x019E)				/* CAN0 message control register 09  					*/

#define		CAN_C0MDB0110  		*(volatile __far WORD*)(CAN0BASE+0x01A0)				/* CAN0 message data byte 01 register 10				*/
#define		CAN_C0MDB010  		*(volatile __far BYTE*)(CAN0BASE+0x01A0)				/* CAN0 message data byte 0 register  10				*/
#define		CAN_C0MDB110  		*(volatile __far BYTE*)(CAN0BASE+0x01A1)				/* CAN0 message data byte 1 register  10				*/
#define		CAN_C0MDB2310  		*(volatile __far WORD*)(CAN0BASE+0x01A2)				/* CAN0 message data byte 23 register 10				*/
#define		CAN_C0MDB210  		*(volatile __far BYTE*)(CAN0BASE+0x01A2)				/* CAN0 message data byte 2 register  10				*/
#define		CAN_C0MDB310  		*(volatile __far BYTE*)(CAN0BASE+0x01A3)				/* CAN0 message data byte 3 register  10				*/
#define		CAN_C0MDB4510  		*(volatile __far WORD*)(CAN0BASE+0x01A4)				/* CAN0 message data byte 45 register 10				*/
#define		CAN_C0MDB410  		*(volatile __far BYTE*)(CAN0BASE+0x01A4)				/* CAN0 message data byte 4 register  10				*/
#define		CAN_C0MDB510  		*(volatile __far BYTE*)(CAN0BASE+0x01A5)				/* CAN0 message data byte 5 register  10				*/
#define		CAN_C0MDB6710 		*(volatile __far WORD*)(CAN0BASE+0x01A6)				/* CAN0 message data byte 67 register 10				*/
#define		CAN_C0MDB610  		*(volatile __far BYTE*)(CAN0BASE+0x01A6)				/* CAN0 message data byte 6 register  10				*/
#define		CAN_C0MDB710  		*(volatile __far BYTE*)(CAN0BASE+0x01A7)				/* CAN0 message data byte 7 register  10				*/
#define		CAN_C0MDLC10  		*(volatile __far BYTE*)(CAN0BASE+0x01A8)				/* CAN0 message data length register 10  				*/
#define		CAN_C0MCONF10 		*(volatile __far BYTE*)(CAN0BASE+0x01A9)				/* CAN0 message Configuration register 10  				*/
#define		CAN_C0MIDL10  		*(volatile __far WORD*)(CAN0BASE+0x01AA)				/* CAN0 message ID register 10L  						*/
#define		CAN_C0MIDH10  		*(volatile __far WORD*)(CAN0BASE+0x01AC)				/* CAN0 message ID register 10H  						*/
#define		CAN_C0MCTRL10 		*(volatile __far WORD*)(CAN0BASE+0x01AE)				/* CAN0 message control register 10  					*/

#define		CAN_C0MDB0111  		*(volatile __far WORD*)(CAN0BASE+0x01B0)				/* CAN0 message data byte 01 register 11				*/
#define		CAN_C0MDB011  		*(volatile __far BYTE*)(CAN0BASE+0x01B0)				/* CAN0 message data byte 0 register  11				*/
#define		CAN_C0MDB111  		*(volatile __far BYTE*)(CAN0BASE+0x01B1)				/* CAN0 message data byte 1 register  11				*/
#define		CAN_C0MDB2311  		*(volatile __far WORD*)(CAN0BASE+0x01B2)				/* CAN0 message data byte 23 register 11				*/
#define		CAN_C0MDB211  		*(volatile __far BYTE*)(CAN0BASE+0x01B2)				/* CAN0 message data byte 2 register  11				*/
#define		CAN_C0MDB311  		*(volatile __far BYTE*)(CAN0BASE+0x01B3)				/* CAN0 message data byte 3 register  11				*/
#define		CAN_C0MDB4511  		*(volatile __far WORD*)(CAN0BASE+0x01B4)				/* CAN0 message data byte 45 register 11				*/
#define		CAN_C0MDB411  		*(volatile __far BYTE*)(CAN0BASE+0x01B4)				/* CAN0 message data byte 4 register  11				*/
#define		CAN_C0MDB511  		*(volatile __far BYTE*)(CAN0BASE+0x01B5)				/* CAN0 message data byte 5 register  11				*/
#define		CAN_C0MDB6711 		*(volatile __far WORD*)(CAN0BASE+0x01B6)				/* CAN0 message data byte 67 register 11				*/
#define		CAN_C0MDB611  		*(volatile __far BYTE*)(CAN0BASE+0x01B6)				/* CAN0 message data byte 6 register  11				*/
#define		CAN_C0MDB711  		*(volatile __far BYTE*)(CAN0BASE+0x01B7)				/* CAN0 message data byte 7 register  11				*/
#define		CAN_C0MDLC11  		*(volatile __far BYTE*)(CAN0BASE+0x01B8)				/* CAN0 message data length register 11  				*/
#define		CAN_C0MCONF11 		*(volatile __far BYTE*)(CAN0BASE+0x01B9)				/* CAN0 message Configuration register 11  				*/
#define		CAN_C0MIDL11  		*(volatile __far WORD*)(CAN0BASE+0x01BA)				/* CAN0 message ID register 11L  						*/
#define		CAN_C0MIDH11  		*(volatile __far WORD*)(CAN0BASE+0x01BC)				/* CAN0 message ID register 11H  						*/
#define		CAN_C0MCTRL11 		*(volatile __far WORD*)(CAN0BASE+0x01BE)				/* CAN0 message control register 11  					*/

#define		CAN_C0MDB0112  		*(volatile __far WORD*)(CAN0BASE+0x01C0)				/* CAN0 message data byte 01 register 12				*/
#define		CAN_C0MDB012  		*(volatile __far BYTE*)(CAN0BASE+0x01C0)				/* CAN0 message data byte 0 register  12				*/
#define		CAN_C0MDB112  		*(volatile __far BYTE*)(CAN0BASE+0x01C1)				/* CAN0 message data byte 1 register  12				*/
#define		CAN_C0MDB2312  		*(volatile __far WORD*)(CAN0BASE+0x01C2)				/* CAN0 message data byte 23 register 12				*/
#define		CAN_C0MDB212  		*(volatile __far BYTE*)(CAN0BASE+0x01C2)				/* CAN0 message data byte 2 register  12				*/
#define		CAN_C0MDB312  		*(volatile __far BYTE*)(CAN0BASE+0x01C3)				/* CAN0 message data byte 3 register  12				*/
#define		CAN_C0MDB4512  		*(volatile __far WORD*)(CAN0BASE+0x01C4)				/* CAN0 message data byte 45 register 12				*/
#define		CAN_C0MDB412  		*(volatile __far BYTE*)(CAN0BASE+0x01C4)				/* CAN0 message data byte 4 register  12				*/
#define		CAN_C0MDB512  		*(volatile __far BYTE*)(CAN0BASE+0x01C5)				/* CAN0 message data byte 5 register  12				*/
#define		CAN_C0MDB6712 		*(volatile __far WORD*)(CAN0BASE+0x01C6)				/* CAN0 message data byte 67 register 12				*/
#define		CAN_C0MDB612  		*(volatile __far BYTE*)(CAN0BASE+0x01C6)				/* CAN0 message data byte 6 register  12				*/
#define		CAN_C0MDB712  		*(volatile __far BYTE*)(CAN0BASE+0x01C7)				/* CAN0 message data byte 7 register  12				*/
#define		CAN_C0MDLC12  		*(volatile __far BYTE*)(CAN0BASE+0x01C8)				/* CAN0 message data length register 12  				*/
#define		CAN_C0MCONF12 		*(volatile __far BYTE*)(CAN0BASE+0x01C9)				/* CAN0 message Configuration register 12  				*/
#define		CAN_C0MIDL12  		*(volatile __far WORD*)(CAN0BASE+0x01CA)				/* CAN0 message ID register 12L  						*/
#define		CAN_C0MIDH12  		*(volatile __far WORD*)(CAN0BASE+0x01CC)				/* CAN0 message ID register 12H  						*/
#define		CAN_C0MCTRL12 		*(volatile __far WORD*)(CAN0BASE+0x01CE)				/* CAN0 message control register 12  					*/

#define		CAN_C0MDB0113  		*(volatile __far WORD*)(CAN0BASE+0x01D0)				/* CAN0 message data byte 01 register 13				*/
#define		CAN_C0MDB013  		*(volatile __far BYTE*)(CAN0BASE+0x01D0)				/* CAN0 message data byte 0 register  13				*/
#define		CAN_C0MDB113  		*(volatile __far BYTE*)(CAN0BASE+0x01D1)				/* CAN0 message data byte 1 register  13				*/
#define		CAN_C0MDB2313  		*(volatile __far WORD*)(CAN0BASE+0x01D2)				/* CAN0 message data byte 23 register 13				*/
#define		CAN_C0MDB213  		*(volatile __far BYTE*)(CAN0BASE+0x01D2)				/* CAN0 message data byte 2 register  13				*/
#define		CAN_C0MDB313  		*(volatile __far BYTE*)(CAN0BASE+0x01D3)				/* CAN0 message data byte 3 register  13				*/
#define		CAN_C0MDB4513  		*(volatile __far WORD*)(CAN0BASE+0x01D4)				/* CAN0 message data byte 45 register 13				*/
#define		CAN_C0MDB413  		*(volatile __far BYTE*)(CAN0BASE+0x01D4)				/* CAN0 message data byte 4 register  13				*/
#define		CAN_C0MDB513  		*(volatile __far BYTE*)(CAN0BASE+0x01D5)				/* CAN0 message data byte 5 register  13				*/
#define		CAN_C0MDB6713 		*(volatile __far WORD*)(CAN0BASE+0x01D6)				/* CAN0 message data byte 67 register 13				*/
#define		CAN_C0MDB613  		*(volatile __far BYTE*)(CAN0BASE+0x01D6)				/* CAN0 message data byte 6 register  13				*/
#define		CAN_C0MDB713  		*(volatile __far BYTE*)(CAN0BASE+0x01D7)				/* CAN0 message data byte 7 register  13				*/
#define		CAN_C0MDLC13  		*(volatile __far BYTE*)(CAN0BASE+0x01D8)				/* CAN0 message data length register 13  				*/
#define		CAN_C0MCONF13 		*(volatile __far BYTE*)(CAN0BASE+0x01D9)				/* CAN0 message Configuration register 13  				*/
#define		CAN_C0MIDL13  		*(volatile __far WORD*)(CAN0BASE+0x01DA)				/* CAN0 message ID register 13L  						*/
#define		CAN_C0MIDH13  		*(volatile __far WORD*)(CAN0BASE+0x01DC)				/* CAN0 message ID register 13H  						*/
#define		CAN_C0MCTRL13 		*(volatile __far WORD*)(CAN0BASE+0x01DE)				/* CAN0 message control register 13  					*/

#define		CAN_C0MDB0114  		*(volatile __far WORD*)(CAN0BASE+0x01E0)				/* CAN0 message data byte 01 register 14				*/
#define		CAN_C0MDB014  		*(volatile __far BYTE*)(CAN0BASE+0x01E0)				/* CAN0 message data byte 0 register  14				*/
#define		CAN_C0MDB114  		*(volatile __far BYTE*)(CAN0BASE+0x01E1)				/* CAN0 message data byte 1 register  14				*/
#define		CAN_C0MDB2314  		*(volatile __far WORD*)(CAN0BASE+0x01E2)				/* CAN0 message data byte 23 register 14				*/
#define		CAN_C0MDB214  		*(volatile __far BYTE*)(CAN0BASE+0x01E2)				/* CAN0 message data byte 2 register  14				*/
#define		CAN_C0MDB314  		*(volatile __far BYTE*)(CAN0BASE+0x01E3)				/* CAN0 message data byte 3 register  14				*/
#define		CAN_C0MDB4514  		*(volatile __far WORD*)(CAN0BASE+0x01E4)				/* CAN0 message data byte 45 register 14				*/
#define		CAN_C0MDB414  		*(volatile __far BYTE*)(CAN0BASE+0x01E4)				/* CAN0 message data byte 4 register  14				*/
#define		CAN_C0MDB514  		*(volatile __far BYTE*)(CAN0BASE+0x01E5)				/* CAN0 message data byte 5 register  14				*/
#define		CAN_C0MDB6714 		*(volatile __far WORD*)(CAN0BASE+0x01E6)				/* CAN0 message data byte 67 register 14				*/
#define		CAN_C0MDB614  		*(volatile __far BYTE*)(CAN0BASE+0x01E6)				/* CAN0 message data byte 6 register  14				*/
#define		CAN_C0MDB714  		*(volatile __far BYTE*)(CAN0BASE+0x01E7)				/* CAN0 message data byte 7 register  14				*/
#define		CAN_C0MDLC14  		*(volatile __far BYTE*)(CAN0BASE+0x01E8)				/* CAN0 message data length register 14  				*/
#define		CAN_C0MCONF14 		*(volatile __far BYTE*)(CAN0BASE+0x01E9)				/* CAN0 message Configuration register 14  				*/
#define		CAN_C0MIDL14  		*(volatile __far WORD*)(CAN0BASE+0x01EA)				/* CAN0 message ID register 14L  						*/
#define		CAN_C0MIDH14  		*(volatile __far WORD*)(CAN0BASE+0x01EC)				/* CAN0 message ID register 14H  						*/
#define		CAN_C0MCTRL14 		*(volatile __far WORD*)(CAN0BASE+0x01EE)				/* CAN0 message control register 14  					*/

#define		CAN_C0MDB0115  		*(volatile __far WORD*)(CAN0BASE+0x01F0)				/* CAN0 message data byte 01 register 15				*/
#define		CAN_C0MDB015  		*(volatile __far BYTE*)(CAN0BASE+0x01F0)				/* CAN0 message data byte 0 register  15				*/
#define		CAN_C0MDB115  		*(volatile __far BYTE*)(CAN0BASE+0x01F1)				/* CAN0 message data byte 1 register  15				*/
#define		CAN_C0MDB2315  		*(volatile __far WORD*)(CAN0BASE+0x01F2)				/* CAN0 message data byte 23 register 15				*/
#define		CAN_C0MDB215  		*(volatile __far BYTE*)(CAN0BASE+0x01F2)				/* CAN0 message data byte 2 register  15				*/
#define		CAN_C0MDB315  		*(volatile __far BYTE*)(CAN0BASE+0x01F3)				/* CAN0 message data byte 3 register  15				*/
#define		CAN_C0MDB4515  		*(volatile __far WORD*)(CAN0BASE+0x01F4)				/* CAN0 message data byte 45 register 15				*/
#define		CAN_C0MDB415  		*(volatile __far BYTE*)(CAN0BASE+0x01F4)				/* CAN0 message data byte 4 register  15				*/
#define		CAN_C0MDB515  		*(volatile __far BYTE*)(CAN0BASE+0x01F5)				/* CAN0 message data byte 5 register  15				*/
#define		CAN_C0MDB6715 		*(volatile __far WORD*)(CAN0BASE+0x01F6)				/* CAN0 message data byte 67 register 15				*/
#define		CAN_C0MDB615  		*(volatile __far BYTE*)(CAN0BASE+0x01F6)				/* CAN0 message data byte 6 register  15				*/
#define		CAN_C0MDB715  		*(volatile __far BYTE*)(CAN0BASE+0x01F7)				/* CAN0 message data byte 7 register  15				*/
#define		CAN_C0MDLC15  		*(volatile __far BYTE*)(CAN0BASE+0x01F8)				/* CAN0 message data length register 15  				*/
#define		CAN_C0MCONF15 		*(volatile __far BYTE*)(CAN0BASE+0x01F9)				/* CAN0 message Configuration register 15  				*/
#define		CAN_C0MIDL15  		*(volatile __far WORD*)(CAN0BASE+0x01FA)				/* CAN0 message ID register 15L  						*/
#define		CAN_C0MIDH15  		*(volatile __far WORD*)(CAN0BASE+0x01FC)				/* CAN0 message ID register 15H  						*/
#define		CAN_C0MCTRL15 		*(volatile __far WORD*)(CAN0BASE+0x01FE)				/* CAN0 message control register 15  					*/


/***************************************************************/
/****************************************************************************/
/*                 RAM��؍\��(Global�ر ENTRY�O�ɂ͎g�p���܂���)            */
/****************************************************************************/
/***************************************************************/
/*   memory map                                                */
/*                                                             */
/*   FE700--+-------------------+                              */
/*          |                   |                              */
/*          |    W�EC�EP        | 5k byte                      */
/*          |                   |                              */
/*          |                   |                              */
/*   FFAFF--+-------------------+                              */
/*   FFB00--+-------------------+                              */
/*          |    buffer         | 256 byte                     */
/*   FFBFF--+-------------------+                              */
/*   FFC00--+-------------------+                              */
/*          |    IBL,WCP WORK   | 256 byte                     */
/*   FFCFF--+-------------------+                              */
/*   FFD00--+-------------------+                              */
/*          |    WCP��۰��ٕϐ� | 32 byte                      */
/*   FFD1F--+-------------------+                              */
/*   FFD20--+-------------------+                              */
/*          |    stack          | 256 byte                     */
/*   FFE1F--+-------------------+                              */
/*   FFE20--+-------------------+                              */
/*          |                   | 96 byte                      */
/*   FFEDF--+-------------------+                              */
/*                                                             */
/***************************************************************/
#define		IBL_RAMTOP			0xFE700										/* RAM�擪���ڽ */
#define		IBL_DATARAMTOP		0xFF700										/* �ް��̈�擪���ڽ */
#define 	BUFADDR				0xFF700										/* �ޯ̧�̈�擪���ڽ */
#define		IBL_RAMWORK			(IBL_DATARAMTOP + 0x100)					/* ܰ��̈� */
#define		mcST()				((__far tMod_State*)(IBL_RAMWORK))				/* ܰ��̈�ł͍\���̂̂ݎg�p���܂� */
/****************************************************************************/
/*                          FCx39S2�ŗLڼ޽���`                            */
/****************************************************************************/
#define		KILL_R				*(__far BYTE *)(KILL_ADDR)					/* KILLڼ޽� */

#define		IOS_PORT			*(volatile __far BYTE *)(IOS_P_PORT)				/* I/O���޽�߰� �߰�ڼ޽� */
#define		IOS_PORTDR			*(volatile __far BYTE *)(IOS_PD_PORT)				/* I/O���޽�߰� �߰�Ӱ��ڼ޽ � */

/****************************************************************************/
/*                                CLOCK                                     */
/****************************************************************************/
#define 	CLK_INT 			((CLK_EXT * CLK_MUL) / CLK_DIV)				/* CPU/���Ӹۯ� Mzh * 10 �l */
#define		CLK_MHZ_ROUNDUP		((CLK_INT + 9) / 10)						/* MHz�P�ʂ�CPU/���Ӹۯ� �����_�ȉ��؂�グ */


/****************************************************************************/
/*                                I/O���޽                                  */
/****************************************************************************/
#define		IOS_TB_USEC			50											/* I/O���޽ tb = 500u���� ����10�l��ݒ�*/
#define		IOS_TT0_DATA		0x0AFF										/* �S���ٶ��Ē�~ */
#define		IOS_TS0_DATA		0x0001										/* ����0���ĊJ�n */
#define		IOS_TPS0_DATA		0x0000										/* ��ϱڲ�Ư�0�̶��ĸۯ��ݒ� */
#define		IOS_TMR00_DATA		0x0000										/* ��ϱڲ�Ư�0����0�̓���ݒ� */
#define		IOS_TOE0_DATA		0x0000										/* ��Ϗo�͐ݒ� */
#define		IOS_TOE1_DATA		0x0000										/* ��Ϗo�͐ݒ� */
#define		IOS_TDR00_DATA		(IOS_TB_USEC * CLK_INT) 					/* ��϶����l */
#define		IOS_SP_DIV			IOS_PERIOD									/* I/O�o�� �����l*/

/****************************************************************************/
/*                                ����WDT�ر����                            */
/****************************************************************************/
#define		IOS_WDT_SP_DIV		(WDT_PERIOD * 2)							/* ����WDT�ر ������ */

/****************************************************************************/
/*                                CAN                                       */
/****************************************************************************/
#define		CALC_CB0			((CAN_C0BRP_DATA + 1) * (((CAN_C0BTR_DATA >> 8) & 0x07) + (CAN_C0BTR_DATA & 0x0F) + 3))	/* CAN�ۯ������l�A�ޯ����ݸށACAN�ްڰĂ��CAN�ۯ����g�����v�Z */
#define		CALC_CB1 			((CALC_CB0 * CAN_BAUD) / 100)														/* CAN�ۯ������l�A�ޯ����ݸށACAN�ްڰĂ��CAN�ۯ����g�����v�Z */

#if CALC_CB1 != CLK_INT
//���̍s�Ŵװ�ƂȂ����ꍇ�ްڰĂƸۯ��̊֌W�ɴװ������܂��B�ԈႢ���Ȃ����m���߂Ă��������B
//���A�덷�ȂǂŐ��������Ƃ��������Ă���ꍇ���q�l�̐ӔC�̂��Ƃł��̕��͂���Ăɂ��ĉ������B
#endif 

/****************************************************************************/
/*								SecondaryID�萔			*/
/****************************************************************************/
#define		ID_NUM				0											/* SecondaryID�� */
#define		ID_SIZE				32											/* SecondaryID�̈滲�� */

#endif /* _Y_IBL_H */


