/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFTSTD                                                                   */
/* Copyright        : Nippon Seiki Co.,Ltd                                                      */
/*----------------------------------------------------------------------------------------------*/
/* Author           : PF1                                                                       */
/* Description      : Sample                                                                    */
/************************************************************************************************/

#ifndef SSFTXXX_CAN_CTRL_000_H
#define SSFTXXX_CAN_CTRL_000_H

/*****************************************************************************/
/* Include files                                                             */
/*****************************************************************************/
#include "SSFTSTD_Macro.h"
#include "SSFTxxx_Can_DrvIF_Cfg_000.h"

/*****************************************************************************/
/* Global pre-processor symbols/macros ('define')                            */
/*****************************************************************************/

/*****************************************************************************/
/* Global type definitions ('typedef')                                       */
/*****************************************************************************/

/*****************************************************************************/
/* Global variable declarations ('extern', definition in C source)           */
/*****************************************************************************/

/*****************************************************************************/
/* Global constant declarations ('extern', definition in C source)           */
/*****************************************************************************/

/*****************************************************************************/
/* Global function prototypes ('extern', definition in C source)             */
/*****************************************************************************/
extern void CanCtrl_Init(const E_INIT_TYPE req);
extern void CanCtrl_PreProcess(void);
extern void CanCtrl_PostProcess(void);

#if (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_RL78)
extern void CanCtrl_EnableInterruptService(void);
extern void CanCtrl_DisableInterruptService(void);
extern void CanCtrl_EnableClock(void);
extern void CanCtrl_DisableClock(void);
#endif
#endif /* End Of ( #ifndef SSFTXXX_CAN_CTRL_000_H ) */
/*****************************************************************************/
/* EOF                                                                       */
/*****************************************************************************/
