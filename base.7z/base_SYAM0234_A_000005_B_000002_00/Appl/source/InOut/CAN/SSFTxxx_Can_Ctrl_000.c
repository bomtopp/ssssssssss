/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFTSTD                                                                   */
/* Copyright        : Nippon Seiki Co.,Ltd                                                      */
/*----------------------------------------------------------------------------------------------*/
/* Author           : PF1                                                                       */
/* Description      : Sample                                                                    */
/************************************************************************************************/




/*****************************************************************************/
/* Include files                                                             */
/*****************************************************************************/
#include "SSFTSTD_Can_DrvIF_000.h"
#include "SSFTSTD_Can_IL_000.h"
#include "SSFTxxx_Can_IL_Appl_000.h"
#include "SSFTxxx_Can_TP_000.h" /* Sample */
#include "SSFTxxx_Can_IL_IF_000.h"
#include "SYAM0234_CanCtrl_IF_000.h"
#include "SYAM0234_SysIn_IF_101.h"

#if (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_S6J3370)
	#include "s6j3360io.h"
	#include "SSFTSTD_S6J3370Port_Drv_001.h"
	#define CAN_USE_JM_EVA (1U) /* 1U: use S6J3360 Series 144pin Evaluation board */
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_FR81)
	#include "mb91570.h"
	#include "SSFTSTD_FR81_Port_Drv.h"
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_RL78)
	#include "SSFTSTD_RL78IoReg_CpuType_001.h"
	#include "SYAM0220_RL78Port_Drv_001.h"
#else
	/* Do nothing */
#endif

#define SSFTXXX_CAN_CTRL_000_INTERNAL
#include "SSFTxxx_Can_Ctrl_000.h" /* Sample */

#include "SSFTSTD_MacroFunc.h"

/*****************************************************************************/
/* Local pre-processor symbols/macros ('define')                             */
/*****************************************************************************/
#define CANCTRL_STATE_OFF          (0x00U)
#define CANCTRL_STATE_WAIT_FOR_OFF (0x01U)
#define CANCTRL_STATE_WAIT_FOR_ON  (0x02U)
#define CANCTRL_STATE_ON           (0x03U)


/*****************************************************************************/
/* Global variable definitions (declared in header file with 'extern')       */
/*****************************************************************************/

/*****************************************************************************/
/* Global constant definitions (declared in header file with 'extern')       */
/*****************************************************************************/

/*****************************************************************************/
/* Local type definitions ('typedef')                                        */
/*****************************************************************************/
typedef struct
{
	UI_8 Status;
	UI_8 BusOff;
	UI_8 BusOffCnt;
} T_CanCtrl_Info;

/*****************************************************************************/
/* Local variable definitions ('static')                                     */
/*****************************************************************************/
/* RAM������section 2�̊J�n */
#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA RAM2SEC
#else
 #define START_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

static T_CanCtrl_Info CanCtrl_Info;

#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA @@DATA
#else
 #define STOP_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

/*****************************************************************************/
/* Local function prototypes ('static')                                      */
/*****************************************************************************/

static void can_start(void);
static void can_stop(void);
static void can_ctrl_state(void);
static void can_ctrl_busoff_handling(UI_8 can_drv_status);
static void can_ctrl_disable_tx_msg(void);
static void can_ctrl_enable_tx_msg(void);

#ifdef CAN_USE_JM_EVA
#if CAN_USE_JM_EVA == 1U
static void can_init_transceiver(void);
static void can_init_csio(void);
static void can_transceiver_wait(UI_8 c);
static void can_transceiver_set_mode(UI_8 c, UI_8 m);
static void can_clear_watchdog(void);
#endif /* End Of ( #if CAN_USE_JM_EVA == 1U ) */
#endif /* End Of ( #ifdef CAN_USE_JM_EVA ) */

/*****************************************************************************/
/* Local constant definitions ('static')                                     */
/*****************************************************************************/

/*****************************************************************************/
/* Function implementation - global ('extern') and local ('static')          */
/*****************************************************************************/

/************************************************************************************************/
/* Local Functions                                                                              */
/************************************************************************************************/

/************************************************************************************************/
/* Function name :                                                                              */
/* Parameters    :                                                                              */
/* Return value  :                                                                              */
/* Description   :                                                                              */
/************************************************************************************************/
static void can_start(void)
{
	CanDrvIF_InitController(CANDRVIF_CONTROLLER_FCAN, CANDRVIF_CMD_START);
	CanCtrl_Info.Status = CANCTRL_STATE_WAIT_FOR_ON;
}

static void can_stop(void)
{
	CanDrvIF_InitController(CANDRVIF_CONTROLLER_FCAN, CANDRVIF_CMD_STOP);
	CanCtrl_Info.Status = CANCTRL_STATE_WAIT_FOR_OFF;
}

static void can_ctrl_state(void)
{
	UI_8 can_drv_status;

	can_drv_status = CanDrvIF_GetState(CANDRVIF_CONTROLLER_FCAN);

	if (CanCtrl_Info.Status == CANCTRL_STATE_WAIT_FOR_ON) {
		if (can_drv_status == CANDRVIF_STATE_START) {
			CanCtrl_Info.Status = CANCTRL_STATE_ON;
			CanIL_SetTxMsgActClass(CANIL_MSG_ACT_CLASS_ALL);
			CanIL_SetRxMsgActClass(CANIL_MSG_ACT_CLASS_ALL);
			if (CanCtrl_Info.BusOff != D_FALSE) {
				CanCtrl_Info.BusOff = D_FALSE;
				can_ctrl_enable_tx_msg();
			}
		}
	} else if (CanCtrl_Info.Status == CANCTRL_STATE_WAIT_FOR_OFF) {
		if (can_drv_status == CANDRVIF_STATE_STOP) {
			CanCtrl_Info.Status = CANCTRL_STATE_OFF;
			CanIL_ClrTxMsgActClass(CANIL_MSG_ACT_CLASS_ALL);
			CanIL_ClrRxMsgActClass(CANIL_MSG_ACT_CLASS_ALL);
		}
	} else {
		/*  */
	}

	/**/
	can_ctrl_busoff_handling(can_drv_status);
}

static void can_ctrl_busoff_handling(UI_8 can_drv_status)
{
	if (can_drv_status == CANDRVIF_STATE_BUSOFF) {
		if (CanCtrl_Info.BusOff == D_FALSE) {
			CanCtrl_Info.BusOff = D_TRUE;
			can_ctrl_disable_tx_msg();
		}
		if (CanCtrl_Info.BusOffCnt < 5U) {
			CanCtrl_Info.BusOffCnt++;
		} else {
			can_start();
			CanCtrl_Info.BusOffCnt = 0U;
		}
	} else {
		CanCtrl_Info.BusOffCnt = 0U;
	}
}

static void can_ctrl_disable_tx_msg(void)
{
	UI_16 tx_msg_id;

	for (tx_msg_id = 0U; tx_msg_id < CANILTX_MESSAGE_CNT; tx_msg_id++) {
		CanIL_DisableTxMsg(tx_msg_id);
	}
}

static void can_ctrl_enable_tx_msg(void)
{
	UI_16 tx_msg_id;

	for (tx_msg_id = 0U; tx_msg_id < CANILTX_MESSAGE_CNT; tx_msg_id++) {
		CanIL_EnableTxMsg(tx_msg_id);
	}
}

/************************************************************************************************/
/* Function name :                                                                              */
/* Parameters    :                                                                              */
/* Return value  :                                                                              */
/* Description   :                                                                              */
/************************************************************************************************/
#ifdef CAN_USE_JM_EVA
#if CAN_USE_JM_EVA == 1U
static void can_init_transceiver(void)
{
	/* Initialize CSIO */
	can_init_csio();

	/* Runnning wait */
	GPIO_PODR1_POD9 = D_LOW;
    can_transceiver_wait(0);           /* device channel 0 runnning wait */
	GPIO_PODR1_POD9 = D_HIGH;
 
	GPIO_PODR1_POD10 = D_LOW;
    can_transceiver_wait(1);           /* device channel 1 runnning wait */
	GPIO_PODR1_POD10 = D_HIGH;

	/* Mode change (normal) */
	GPIO_PODR1_POD9 = D_LOW;
    can_transceiver_set_mode(0, 7);     /* device channel 0 mode change (normal) */
	GPIO_PODR1_POD9 = D_HIGH;

	GPIO_PODR1_POD10 = D_LOW;
    can_transceiver_set_mode(1, 7);     /* device channel 1 mode change (normal) */
	GPIO_PODR1_POD10 = D_HIGH;

}

static void can_init_csio(void)
{
	/* MFS6 CSIO settings ------------------------------------------------- */
	// MFS6_SCK_0 P103
	(void)PortDrv_SetFuncBit(PORTDRV_PORT_1, PORTDRV_BIT_3, MULTI_FUNCTION_SCK_INOUT_A);
	// MFS6_SIN_0 P104
	(void)PortDrv_SetFuncBit(PORTDRV_PORT_1, PORTDRV_BIT_4, MULTI_FUNCTION_SERIAL_IN_A);
	// MFS6_SOT_0 P102
	(void)PortDrv_SetFuncBit(PORTDRV_PORT_1, PORTDRV_BIT_2, MULTI_FUNCTION_SERIAL_OUT_A);
	// MFS6_CSX_0 P109
	(void)PortDrv_SetFuncBit(PORTDRV_PORT_1, PORTDRV_BIT_9, PORT_OUT);
	// MFS6_CSX_1 P110
	(void)PortDrv_SetFuncBit(PORTDRV_PORT_1, PORTDRV_BIT_10, PORT_OUT);

	/* MFS - CSIO6 Initialize ------------------------------------------------	*/
	CPG_MFS06_CSIO_SMR_MD = 2;          /* CSIO clock sync mode */
	CPG_MFS06_CSIO_SCR_UPCL = 1;        /* CSIO reset */

	CPG_MFS06_CSIO_SCR_RXE = 0;         /* Disable Rx */
	CPG_MFS06_CSIO_SCR_TXE = 0;         /* Disable Tx */

	CPG_MFS06_CSIO_SCR_MS = 0;          /* Master mode */
	CPG_MFS06_CSIO_SCR_SPI = 0;         /* normal SIO (SMR.SCINV) */
	CPG_MFS06_CSIO_SCR_RIE = 0;         /* Disable Rx interrupt */
	CPG_MFS06_CSIO_SCR_TIE = 0;         /* Disable Tx interrupt */
	CPG_MFS06_CSIO_SCR_TBIE = 0;

	CPG_MFS06_CSIO_SMR_SCINV = 1;       /* SCK level = Low */
	                                    /*   mark level   : Low              */
	                                    /*   data output  : rising edge sync */
	                                    /*   data fetch   : falling edge   */
	CPG_MFS06_CSIO_SMR_BDS = 1;         /* MSB��LSB */
	CPG_MFS06_CSIO_SMR_SCKE = 1;        /* SCK output */
	CPG_MFS06_CSIO_SMR_SOE = 1;         /* SOT output */

	CPG_MFS06_CSIO_SSR_REC = 1;         /* error flag clear */

	CPG_MFS06_CSIO_ESCR_L2_0 = 3;       /* data length�F16bit (L3:L2_0=1011) */
	CPG_MFS06_CSIO_ESCR_L3 = 1;

	CPG_MFS06_CSIO_SACSR_TMRE = 0;      /* serial timer OFF */

	CPG_MFS06_CSIO_SCSCR_SCAM = 0;
	CPG_MFS06_CSIO_SCSCR_CDIV = 4;      /* CS timing clock = 60/16 = 3.75MHz */
	CPG_MFS06_CSIO_SCSCR_CSLVL = 1;     /* CS level = High(1) */
	CPG_MFS06_CSIO_SCSCR_CSEN0 = 1;     /* Enable CS0/1 */
	CPG_MFS06_CSIO_SCSCR_CSEN1 = 1;
	CPG_MFS06_CSIO_SCSCR_CSEN2 = 1;
	CPG_MFS06_CSIO_SCSCR_CSEN3 = 1;
	CPG_MFS06_CSIO_SCSCR_CSOE = 1;      /* CS output enable */

	CPG_MFS06_CSIO_SCSTR1_CSSU = 9;     /* CS setup time */
	CPG_MFS06_CSIO_SCSTR0_CSHD = 27;    /* CS hold time */
	CPG_MFS06_CSIO_SCSTR23_CSDS = 18;   /* CS timing */

	CPG_MFS06_CSIO_BGR = 120 - 1;       /* bit clock=60MHz/120=500kHz�Acycle=2us LCP0A:60MHz) */

	CPG_MFS06_CSIO_SCR_UPCL = 1;        /* CSIO reset */
}

static void can_transceiver_wait(UI_8 c)
{
	/* channel check */
	if (c == 0 || c == 1 || c == 2 || c == 3)
	{
		/* CS select */
		CPG_MFS06_CSIO_SCSCR_SST = (UI_16)c;
		CPG_MFS06_CSIO_SCSCR_SED = (UI_16)c;

		/* Enable Tx/Rx */
		CPG_MFS06_CSIO_SCR_RXE = 1;
		CPG_MFS06_CSIO_SCR_TXE = 1;

		do {
			/* Tx data number */
			if (c == 0)
			{
				CPG_MFS06_CSIO_TBYTE0 = 1;
			}
			else if (c == 1)
			{
				CPG_MFS06_CSIO_TBYTE1 = 1;
			}
			else if (c == 2)
			{
				CPG_MFS06_CSIO_TBYTE2 = 1;
			}
			else
			{
				CPG_MFS06_CSIO_TBYTE3 = 1;
			}
			/* Tx read message (ReadOnly) */
			CPG_MFS06_CSIO_TDR = (0x7Eul << 9) /* identifier */
								| (1ul << 8)   /* R/O = 1 (read only) */
								| 0ul;         /* option(write disable) */

			/* wait Tx data comp */
			while (CPG_MFS06_CSIO_SSR_TBI == 0)
			{
				can_clear_watchdog();
			}

		/* check ID */
		} while ((CPG_MFS06_CSIO_RDR & 0xfful) != 0x74u);

		/* disable Tx/Rx */
		CPG_MFS06_CSIO_SCR_RXE = 0;
		CPG_MFS06_CSIO_SCR_TXE = 0;
	}

}

static void can_transceiver_set_mode(UI_8 c, UI_8 m)
{
	/* channel check */
	if (c == 0 || c == 1 || c == 2 || c == 3)
	{
		/* CS select */
		CPG_MFS06_CSIO_SCSCR_SST = (UI_16)c;
		CPG_MFS06_CSIO_SCSCR_SED = (UI_16)c;

		if (c == 0)
		{
			CPG_MFS06_CSIO_TBYTE0 = 1;
		}
		else if (c == 1)
		{
			CPG_MFS06_CSIO_TBYTE1 = 1;
		}
		else if (c == 2)
		{
			CPG_MFS06_CSIO_TBYTE2 = 1;
		}
		else
		{
			CPG_MFS06_CSIO_TBYTE3 = 1;
		}

		/* Enable Tx/Rx */
		CPG_MFS06_CSIO_SCR_RXE = 1;
		CPG_MFS06_CSIO_SCR_TXE = 1;

		/* change device mode (to normal) */
		CPG_MFS06_CSIO_TDR = (0x01u << 9) /* mode control */
							| (0u << 8)   /* R/O = 0 (read and write)*/
							| (UI_16)m;   /* mode */

		/* wait Tx data comp */
		while (CPG_MFS06_CSIO_SSR_TBI == 0)
		{
			can_clear_watchdog();
		}

		/* disable Tx/Rx */
		CPG_MFS06_CSIO_SCR_RXE = 0;
		CPG_MFS06_CSIO_SCR_TXE = 0;
	}
}

static void can_clear_watchdog(void)
{
	// Satisfy compiler regarding "order of volatile accesses" warning in if-statement
	UI_32 u32CurrentLowerLimit = HWDG_RUNLLC; 

	// Clear hardware watchdog if lower limit of window has been exceeded
	if (HWDG_CNT > u32CurrentLowerLimit)
	{
		D_DI();
		HWDG_TRG0 = HWDG_TRG0CFG;
		HWDG_TRG1 = HWDG_TRG1CFG;
		D_EI();
	}
}

#endif /* End Of ( #if CAN_USE_JM_EVA == 1U ) */
#endif /* End Of ( #ifdef CAN_USE_JM_EVA ) */



/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Function name :                                                                              */
/* Parameters    :                                                                              */
/* Return value  :                                                                              */
/* Description   :                                                                              */
/************************************************************************************************/
void CanCtrl_Init(const E_INIT_TYPE req)
{
	switch (req) {
	case E_INIT_RESET:
	case E_INIT_WAKEUP:
		/* CAN Driver Interface */
		CanDrvIF_Init();

		/* Set start request */
		can_start();

		/* CAN Interaction Layer */
		CanIL_Init();
		CanILAppl_Init();

		/* CAN Transport Protocol */
		CanTP_Init();

#ifdef CAN_USE_JM_EVA
#if CAN_USE_JM_EVA == 1U
		/* For Jupiter/Minerva Eva */
		can_init_transceiver();
#endif /* End Of ( #if CAN_USE_JM_EVA == 1U ) */
#endif /* End Of ( #ifdef CAN_USE_JM_EVA ) */

		break;
	case E_INIT_IGN_ON:
		/* IGN OFF���Ƀ��W�X�^�X�g�b�v���Ȃ����߁A�������ΏەύX */
		can_ctrl_enable_tx_msg();

		/* Set start request */
		can_start();

		break;
	case E_INIT_RET_NORMAL_VOL:
	case E_INIT_INTERVAL_WAKEUP:
	default:
		break;
	}
}


/************************************************************************************************/
/* Function name :                                                                              */
/* Parameters    :                                                                              */
/* Return value  :                                                                              */
/* Description   :                                                                              */
/************************************************************************************************/
void CanCtrl_PreProcess(void)
{
	UI_8 ign_state;													/* IGN��� */
	ign_state = SysIn_GetSwState(SYSTEMINPUT_SW_ID_IGN);
	
	/* CAN Driver Interface */
	CanDrvIF_Main();

	/* CAN state handling */
	can_ctrl_state();

	if ( ign_state == D_ON ){
		/* CAN Interaction Layer */
		CanIL_TxStateMain();
		CanIL_RxMain();
		
		CanCtr_Msg_Update();
		
		/* CAN Transport Protocol */
		CanTP_Main();
	} else {
		/* �S���M�L�����Z�� */
		can_ctrl_disable_tx_msg();
		
		/* ��M�f�[�^�j��/�������A�^�C���A�E�g�G���[������ */
		CanIL_RxMain_IgnOff();

		/* ���M�f�[�^������ */
		CanIL_TxMain_IgnOff();
		
		/* ��M��~ */
		can_stop();
	}
	

}

/************************************************************************************************/
/* Function name :                                                                              */
/* Parameters    :                                                                              */
/* Return value  :                                                                              */
/* Description   :                                                                              */
/************************************************************************************************/
void CanCtrl_PostProcess(void)
{
	/* ���M�f�[�^�X�V */
	CanCtr_SendData();
	
	/* CAN Interaction Layer */
	CanIL_TxMain();

	/* CAN Driver Interface */
	CanDrvIF_ActivateTx();
}

#if (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_RL78)
/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanCtrl_EnableInterruptService(void)
{
	C0ERRIF = 0;
	C0RECIF = 0;
	C0TRXIF = 0;
	C0ERRMK = 0;
	C0RECMK = 0;
	C0TRXMK = 0;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanCtrl_DisableInterruptService(void)
{
	C0ERRMK = 1;
	C0RECMK = 1;
	C0TRXMK = 1;
	C0ERRIF = 0;
	C0RECIF = 0;
	C0TRXIF = 0;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanCtrl_EnableClock(void)
{
	PCKSEL = 0x18;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanCtrl_DisableClock(void)
{
	PCKSEL = 0x00;
}
#endif



/*****************************************************************************/
/* EOF                                                                       */
/*****************************************************************************/
