/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFTSTD                                                                   */
/* Copyright        : Nippon Seiki Co., Ltd.                                                    */
/*----------------------------------------------------------------------------------------------*/
/* Date             : 2016/09/02                                                                */
/* Author           : PF1                                                                       */
/*----------------------------------------------------------------------------------------------*/
/* Ver              : 020000                                                                    */
/************************************************************************************************/


/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#define SSFTSTD_CAN_IL_000_INTERNAL
#include <string.h> /* for memcpy() */
#include "SSFTSTD_Can_IL_000.h"
#include "SSFTxxx_Can_DrvIF_Cfg_000.h"
#include "SSFTSTD_Macro.h"
#include "SYAM090_timer.h"
#include "SSFTSTD_System.h"
#include "SYAM0234_CanCtrl_Msg_000.h"
#include "SYAM0234_CanCtrl_IF_000.h"
#include "SYAM0220_CanCtrl_Task_000.h"
#include "SYAM0234_SysIn_IF_101.h"
#include "SYAM0220_Sp_IF_102.h"
#include "SYAM0220_ServiceProtocol.h"
#include "SYAM0234_Can_lowbatt_TASK_000.h"
#include "SYAM0234_ProdTest_Main_102.h"

/************************************************************************************************/
/* Local Macros                                                                                 */
/************************************************************************************************/
#define CANILTX_EVENT_STATE_NONE ((UI_8)0x00U)
#define CANILTX_EVENT_STATE_CHNG ((UI_8)0x01U)
#define CANILTX_EVENT_STATE_EXT  ((UI_8)0x02U)

/* Indexes for controlling the tx types (external event, signal change event, cyclic) */
/* Some indexes are reserved for event types */
/* These indexes are also used for priority check. */
/* Index zero means the highest priority and cyclic type has the lowest one. */
#define CANILTX_TYPE_CYCLIC (CANILTX_EVENT_TYPE_CNT)
#define CANILTX_TYPE_CNT    (CANILTX_TYPE_CYCLIC + 1U)



/************************************************************************************************/
/* Local Data Types                                                                             */
/************************************************************************************************/
/* A type for controlling message active class information. */
typedef struct
{
	UI_8 TxMsgActClassReq;
	UI_8 TxMsgActClass;
	UI_8 RxMsgActClassReq;
	UI_8 RxMsgActClass;
} T_CanIL_Ctrl;

/* The following type is used to control specific transmission including */
/* cyclic event, signal change event and external trigger event.         */
typedef struct
{
	UI_8 Activated;
	UI_8 SendCnt;
	UI_16 CycleCnt;
} T_CanIL_TxTypeCtrl;

/* The following type is used to control transmission status. */
typedef struct
{
	UI_8 TxStatus;
	UI_8 TxEventReq;
	UI_16 TxDelayCnt;
	UI_16 TxCycleCnt;
	UI_16 TxTimeoutCnt;
	UI_8 CurTxType;
	T_CanIL_TxTypeCtrl TxTypeCtrl[CANILTX_TYPE_CNT];
} T_CanIL_TxCtrl;

/* The following type consists of several bit flags for transmission side. */
typedef struct
{
	UI_16 TxStartFlg[CANILTX_BIT_FLG_INDEX_CNT];
	UI_16 TxDisableFlg[CANILTX_BIT_FLG_INDEX_CNT];
	UI_16 TxPendingFlg[CANILTX_BIT_FLG_INDEX_CNT];
} T_CanIL_TxBitFlg;

/* The following type is used to control reception status. */
typedef struct
{
	UI_8 RxStatus;
	UI_16 RxTimeoutCnt;
} T_CanIL_RxCtrl;

/* The following type consists of several bit flags for reception side. */
typedef struct
{
	UI_16 RxStartFlg[CANILRX_BIT_FLG_INDEX_CNT];
	UI_16 RxDisableFlg[CANILRX_BIT_FLG_INDEX_CNT];
} T_CanIL_RxBitFlg;

/************************************************************************************************/
/* Local Data                                                                                   */
/************************************************************************************************/
/* RAM������section 2�̊J�n */
#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA RAM2SEC
#else
 #define START_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

static T_CanIL_Ctrl CanIL_Ctrl;

static T_CanIL_TxCtrl CanIL_TxCtrl[CANILTX_MESSAGE_CNT + 1U];
static T_CanIL_TxBitFlg CanIL_TxBitFlg;
static T_CanDrvIF_Msg CanIL_TxMsg[CANILTX_MESSAGE_CNT + 1U];

static T_CanIL_RxCtrl CanIL_RxCtrl[CANILRX_MESSAGE_CNT + 1U];
static T_CanIL_RxBitFlg CanIL_RxBitFlg;
static T_CanDrvIF_Msg CanIL_RxMsg[CANILRX_MESSAGE_CNT + 1U];

static UI_8		ErrDetectTime;								

static UI_16	CanIL_RxData_RX_209_OdoPls;
/* static UI_16	CanIL_RxData_RX_20A_OdoPls; */

#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA @@DATA
#else
 #define STOP_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

/* RAM������section 3�̊J�n */
#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA RAM3SEC
#else
 #define START_SEC_RAM3SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

static UI_8		SendWaitFlg;

#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA @@DATA
#else
 #define STOP_SEC_RAM3SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

/************************************************************************************************/
/* Local Function Declarations                                                                  */
/************************************************************************************************/
static void il_init_memory(void);
static void il_tx_init_ctrl_info(UI_16 tx_msg_id);
static void il_tx_chk_act_class(void);
static void il_tx_start_msg(UI_16 tx_msg_id);
static void il_tx_stop_msg(UI_16 tx_msg_id);
static void il_tx_disable_msg(UI_16 tx_msg_id);
static void il_tx_enable_msg(UI_16 tx_msg_id);
static void il_tx_activate_msg(UI_16 tx_msg_id);
static void il_tx_chk_timer(UI_16 tx_msg_id, UI_8 tx_confirmed);
static void il_tx_update_event_state(UI_16 tx_msg_id);
static void il_tx_set_event_state(UI_16 tx_msg_id, UI_8 tx_type);
static void il_tx_update_cyclic_state(UI_16 tx_msg_id);
static void il_tx_type_handling(UI_16 tx_msg_id);
static void il_tx_set_pending_req(UI_16 tx_msg_id);
static void il_tx_send_msg(UI_16 tx_msg_id);

static void il_rx_init_ctrl_info(UI_16 rx_msg_id);
static void il_rx_chk_act_class(void);
static void il_rx_handling(UI_16 rx_msg_id, UI_8 new_msg_flg, T_CanDrvIF_Msg *rx_msg_ptr);
static void il_rx_supervise_timeout(UI_16 rx_msg_id, UI_8 valid_msg_flg);
static void s_fcan_rx_check_timer(UI_16 rx_msg_id, UI_8 valid_msg_flg);
static void il_rx_start_msg(UI_16 rx_msg_id);
static void il_rx_stop_msg(UI_16 rx_msg_id);
static void il_rx_disable_msg(UI_16 rx_msg_id);
static void il_rx_enable_msg(UI_16 rx_msg_id);

static void il_set_flg(UI_16 msg_id, UI_16 flags[]);
static void il_clr_flg(UI_16 msg_id, UI_16 flags[]);
static UI_8 il_chk_flg(UI_16 msg_id, const UI_16 flags[]);
static UI_32 il_get_signal_val(const T_CanIL_SignalMap *signal_map_ptr, const UI_8 data_ptr[]);
static UI_8 il_set_signal_val(const T_CanIL_SignalMap *signal_map_ptr, UI_32 signal_val, UI_8 data_ptr[]);

/************************************************************************************************/
/* Local Constants                                                                              */
/************************************************************************************************/
static const UI_32 C_CanIL_GetBitMask[] =
{
	0x00000000U, 
	0x00000001U, 0x00000003U, 0x00000007U, 0x0000000FU, 0x0000001FU, 0x0000003FU, 0x0000007FU, 0x000000FFU, /* 1-8 */
	0x000001FFU, 0x000003FFU, 0x000007FFU, 0x00000FFFU, 0x00001FFFU, 0x00003FFFU, 0x00007FFFU, 0x0000FFFFU, /* 9-16 */
	0x0001FFFFU, 0x0003FFFFU, 0x0007FFFFU, 0x000FFFFFU, 0x001FFFFFU, 0x003FFFFFU, 0x007FFFFFU, 0x00FFFFFFU, /* 17-24 */
	0x01FFFFFFU, 0x03FFFFFFU, 0x07FFFFFFU, 0x0FFFFFFFU, 0x1FFFFFFFU, 0x3FFFFFFFU, 0x7FFFFFFFU, 0xFFFFFFFFU, /* 25-32 */
};


static const UI_8 C_CanIL_GetBottomBitMask[] =
{
	0xFFU, 0xFEU, 0xFCU, 0xF8U, 0xF0U, 0xE0U, 0xC0U, 0x80U,
};

static const UI_8 C_CanIL_GetTopBitMask[] =
{
	0x01U, 0x03U, 0x07U, 0x0FU, 0x1FU, 0x3FU, 0x7FU, 0xFFU,
};

/************************************************************************************************/
/* Local Functions                                                                              */
/************************************************************************************************/
/************************************************************************************************/
/* Function name    : il_init_memory                                                            */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function initializes all of the internal memory.                     */
/*                                                                                              */
/************************************************************************************************/
static void il_init_memory(void)
{
	UI_16 msg_id;
	UI_16 flg_index;

	CanIL_Ctrl.TxMsgActClassReq = CANIL_MSG_ACT_CLASS_NONE;
	CanIL_Ctrl.TxMsgActClass = CanIL_Ctrl.TxMsgActClassReq;
	CanIL_Ctrl.RxMsgActClassReq = CANIL_MSG_ACT_CLASS_NONE;
	CanIL_Ctrl.RxMsgActClass = CanIL_Ctrl.RxMsgActClassReq;

	for (msg_id = 0U; msg_id < CANILTX_MESSAGE_CNT; msg_id++) {
		il_tx_init_ctrl_info(msg_id);
	}

	for (flg_index = 0U; flg_index < CANILTX_BIT_FLG_INDEX_CNT; flg_index++) {
		CanIL_TxBitFlg.TxStartFlg[flg_index] = 0U;
		CanIL_TxBitFlg.TxDisableFlg[flg_index] = 0U;
		CanIL_TxBitFlg.TxPendingFlg[flg_index] = 0U;
	}

	for (msg_id = 0U; msg_id < CANILRX_MESSAGE_CNT; msg_id++) {
		il_rx_init_ctrl_info(msg_id);
	}

	for (flg_index = 0U; flg_index < CANILRX_BIT_FLG_INDEX_CNT; flg_index++) {
		CanIL_RxBitFlg.RxStartFlg[flg_index] = 0U;
		CanIL_RxBitFlg.RxDisableFlg[flg_index] = 0U;
	}
	
	CanCtr_Msg_Init();
}

/************************************************************************************************/
/* Function name    : il_tx_init_ctrl_info                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function initializes internal data related to TxMsg.                 */
/*                    This function calls the following function                                */
/*                    to get default FrameFormat and Id.                                        */
/*                     - CanDrvIF_GetTxFrameFormat()                                            */
/*                     - CanDrvIF_GetTxId()                                                     */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_init_ctrl_info(UI_16 tx_msg_id)
{
	UI_8 tx_type;

	CanIL_TxCtrl[tx_msg_id].TxStatus = CANILTX_STATE_NONE;
	CanIL_TxCtrl[tx_msg_id].TxEventReq = CANILTX_EVENT_STATE_NONE;
	CanIL_TxCtrl[tx_msg_id].TxDelayCnt = CANIL_STOP_UPDATE_CNT;
	CanIL_TxCtrl[tx_msg_id].TxCycleCnt = CANIL_STOP_UPDATE_CNT;
	CanIL_TxCtrl[tx_msg_id].TxTimeoutCnt = CANIL_STOP_UPDATE_CNT;
	CanIL_TxCtrl[tx_msg_id].CurTxType = CANILTX_TYPE_CNT;
	for (tx_type = 0U; tx_type < CANILTX_TYPE_CNT; tx_type++) {
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].Activated = D_FALSE;
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].SendCnt = 0U;
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt = CANIL_STOP_UPDATE_CNT;
	}

	CanIL_TxMsg[tx_msg_id].FrameFormat = CanDrvIF_GetTxFrameFormat(C_CanIL_TxMsgCfg[tx_msg_id].TxHandle);
	CanIL_TxMsg[tx_msg_id].Id = CanDrvIF_GetTxId(C_CanIL_TxMsgCfg[tx_msg_id].TxHandle);
	CanIL_TxMsg[tx_msg_id].DataLen = C_CanIL_TxMsgCfg[tx_msg_id].DataLen;
	CanIL_TxMsg[tx_msg_id].DataPtr = C_CanIL_TxMsgCfg[tx_msg_id].DataPtr;
	(void)memcpy(CanIL_TxMsg[tx_msg_id].DataPtr, C_CanIL_TxMsgCfg[tx_msg_id].InitialDataPtr, (T_CANIL_SIZE_T)C_CanIL_TxMsgCfg[tx_msg_id].DataLen);
	
}

/************************************************************************************************/
/* Function name    : il_tx_chk_act_class                                                       */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called                                                   */
/*                    when a user calls CanIL_SetTxMsgActClass() or CanIL_ClrTxMsgActClass()    */
/*                    in order to activate or deactivate transmission handling.                 */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_chk_act_class(void)
{
	UI_16 tx_msg_id;
	UI_8 cur_bit_status;
	UI_8 req_bit_status;

	if (CanIL_Ctrl.TxMsgActClassReq != CanIL_Ctrl.TxMsgActClass) {
		for (tx_msg_id = 0U; tx_msg_id < CANILTX_MESSAGE_CNT; tx_msg_id++) {
			cur_bit_status = (UI_8)(C_CanIL_TxMsgCfg[tx_msg_id].TxMsgActClass & CanIL_Ctrl.TxMsgActClass);
			req_bit_status = (UI_8)(C_CanIL_TxMsgCfg[tx_msg_id].TxMsgActClass & CanIL_Ctrl.TxMsgActClassReq);

			if (cur_bit_status != 0U) {
				if (req_bit_status == 0U) {
					il_tx_stop_msg(tx_msg_id);
				}
			} else {
				if (req_bit_status != 0U) {
					il_tx_start_msg(tx_msg_id);
				}
			}
		}
		CanIL_Ctrl.TxMsgActClass = CanIL_Ctrl.TxMsgActClassReq;
	}
}

/************************************************************************************************/
/* Function name    : il_tx_start_msg                                                           */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called when a user calls CanIL_SetTxMsgActClass()        */
/*                    in order to activate transmission handling.                               */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_start_msg(UI_16 tx_msg_id)
{
	/* Set the start flag */
	il_set_flg(tx_msg_id, CanIL_TxBitFlg.TxStartFlg);

	/* Activate transmission */
	il_tx_activate_msg(tx_msg_id);

#if CANILTX_INIT_STATUS_WITH_START == 1
	/* Set the state to none. Especially, clear the first tx confirmed flag. */
	CanIL_TxCtrl[tx_msg_id].TxStatus = CANILTX_STATE_NONE;
#endif /* End of #if CANILTX_INIT_STATUS_WITH_START == 1 */

#if CANILTX_INIT_MSG_DATA_WITH_START == 1
	/* Initialize the tx message data */
	CanIL_TxMsg[tx_msg_id].DataPtr = C_CanIL_TxMsgCfg[tx_msg_id].DataPtr;
	(void)memcpy(CanIL_TxMsg[tx_msg_id].DataPtr, C_CanIL_TxMsgCfg[tx_msg_id].InitialDataPtr, (T_CANIL_SIZE_T)C_CanIL_TxMsgCfg[tx_msg_id].DataLen);
#endif /* End of #if CANILTX_INIT_MSG_DATA_WITH_START == 1 */

}

/************************************************************************************************/
/* Function name    : il_tx_stop_msg                                                            */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called when a user calls CanIL_ClrTxMsgActClass()        */
/*                    in order to deactivate transmission handling.                             */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_stop_msg(UI_16 tx_msg_id)
{
	/* Clear the start flag */
	il_clr_flg(tx_msg_id, CanIL_TxBitFlg.TxStartFlg);

	/* Clear the tx request */
	il_clr_flg(tx_msg_id, CanIL_TxBitFlg.TxPendingFlg);
	CanDrvIF_ClrTxReq(C_CanIL_TxMsgCfg[tx_msg_id].TxHandle);

}

/************************************************************************************************/
/* Function name    : il_tx_disable_msg                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called when a user calls CanIL_DisableTxMsg()            */
/*                    in order to disable transmission handling.                                */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_disable_msg(UI_16 tx_msg_id)
{
	/* Set the disable flag */
	il_set_flg(tx_msg_id, CanIL_TxBitFlg.TxDisableFlg);

	/* Clear the tx request */
	il_clr_flg(tx_msg_id, CanIL_TxBitFlg.TxPendingFlg);
	CanDrvIF_ClrTxReq(C_CanIL_TxMsgCfg[tx_msg_id].TxHandle);

}

/************************************************************************************************/
/* Function name    : il_tx_enable_msg                                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called when a user calls CanIL_EnableTxMsg()             */
/*                    in order to enable transmission handling.                                 */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_enable_msg(UI_16 tx_msg_id)
{
	/* Clear the disable flag */
	il_clr_flg(tx_msg_id, CanIL_TxBitFlg.TxDisableFlg);

	/* Activate transmission */
	il_tx_activate_msg(tx_msg_id);
}

/************************************************************************************************/
/* Function name    : il_tx_activate_msg                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function initializes TxMsg Handler to start transmission handling.   */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_activate_msg(UI_16 tx_msg_id)
{
	UI_8 tx_type;

	/* Initialize the event transmission information */
	CanIL_TxCtrl[tx_msg_id].TxEventReq = CANILTX_EVENT_STATE_NONE;

	/* Initialize the separation delay (event delay) */
	CanIL_TxCtrl[tx_msg_id].TxDelayCnt = 0U;

	/* Try to start cycle timer */
	if (C_CanIL_TxMsgCfg[tx_msg_id].TxCycle != CANIL_STOP_UPDATE_CNT) {
		/* If this message is need to send cyclically, set the cycle delay count. */
		CanIL_TxCtrl[tx_msg_id].TxCycleCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxCycleDelay + 1U;
	} else {
		/* Only event transmission is supported. */
		CanIL_TxCtrl[tx_msg_id].TxCycleCnt = CANIL_STOP_UPDATE_CNT;
	}

	/* Stop the timer */
	CanIL_TxCtrl[tx_msg_id].TxTimeoutCnt = CANIL_STOP_UPDATE_CNT;

	/* Initialize the tx type control information */
	CanIL_TxCtrl[tx_msg_id].CurTxType = CANILTX_TYPE_CNT;
	for (tx_type = 0U; tx_type < CANILTX_TYPE_CNT; tx_type++) {
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].Activated = D_FALSE;
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].SendCnt = 0U;
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt = CANIL_STOP_UPDATE_CNT;
	}
}

/************************************************************************************************/
/* Function name    : il_tx_chk_timer                                                           */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <tx_confirmed> - Confirmed transmission status                            */
/*                      D_FALSE : Transmission and cancel completion has not been confirmed.    */
/*                      D_TRUE  : Transmission or cancel completion has been confirmed.         */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function updates separation timer and reception timer.               */
/*                    The transmission timeout is detected in this function.                    */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_chk_timer(UI_16 tx_msg_id, UI_8 tx_confirmed)
{
	if (tx_confirmed != D_FALSE) {

		/* Confirmed. - Stop the timeout counter. */
		CanIL_TxCtrl[tx_msg_id].TxTimeoutCnt = CANIL_STOP_UPDATE_CNT;

#if CANILTX_CLR_ERR_TIMEOUT_FLG_WITH_COMP == 1
		/* Clear the error flag */
		CanIL_TxCtrl[tx_msg_id].TxStatus &= (UI_8)~CANILTX_STATE_ERR_TIMEOUT;
#endif /* End of (#if CANILTX_CLR_ERR_TIMEOUT_FLG_WITH_COMP == 1) */

#if CANILTX_RELOAD_DELAY_CNT_WITH_COMP == 1
		/* Start the tx delay counter */
		CanIL_TxCtrl[tx_msg_id].TxDelayCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxDelay;
#endif /* End of (#if CANILTX_RELOAD_DELAY_CNT_WITH_COMP == 1) */

	} else {
		/* Not confirmed. - Check for timeout */
		if ((CanIL_TxCtrl[tx_msg_id].TxTimeoutCnt != CANIL_STOP_UPDATE_CNT) && (CanIL_TxCtrl[tx_msg_id].TxTimeoutCnt != 0U)) {
			CanIL_TxCtrl[tx_msg_id].TxTimeoutCnt--;
		}
		/* If the timer expired, set the flag and restart timeout counter. */
		if (CanIL_TxCtrl[tx_msg_id].TxTimeoutCnt == 0U) {

			CanIL_TxCtrl[tx_msg_id].TxStatus |= CANILTX_STATE_ERR_TIMEOUT;
			CanIL_TxCtrl[tx_msg_id].TxTimeoutCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxTimeout;

		}
	}
	/* Decrement counter for the separation time. */
	if ((CanIL_TxCtrl[tx_msg_id].TxDelayCnt != CANIL_STOP_UPDATE_CNT) && (CanIL_TxCtrl[tx_msg_id].TxDelayCnt != 0U)) {
		CanIL_TxCtrl[tx_msg_id].TxDelayCnt--;
	}

}

/************************************************************************************************/
/* Function name    : il_tx_update_event_state                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function checks if the signal change and/or external trigger         */
/*                    event request is set.                                                     */
/*                    If the TxMsg Handler is configured to accept these events,                */
/*                    this function forwards these requests to the transmission event handler.  */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_update_event_state(UI_16 tx_msg_id)
{
	UI_8 tx_event_req;

	/* Get and Clear the event request flags. */
	tx_event_req = CanIL_TxCtrl[tx_msg_id].TxEventReq;
	CanIL_TxCtrl[tx_msg_id].TxEventReq = CANILTX_EVENT_REQ_NONE;

	/* Check if the event request is set*/
	if (tx_event_req != CANILTX_EVENT_REQ_NONE) {
		if (((tx_event_req & CANILTX_EVENT_REQ_EXT) != 0U) && (C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[CANILTX_EVENT_TYPE_EXT].Cnt != 0U)) {
			/* Accept the external event request only if the number of transmission configured is greater than zero. */
			il_tx_set_event_state(tx_msg_id, CANILTX_EVENT_TYPE_EXT);
		}
		if (((tx_event_req & CANILTX_EVENT_REQ_CHNG) != 0U) && (C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[CANILTX_EVENT_TYPE_CHNG].Cnt != 0U)) {
			/* Accept the signal change event request only if the number of transmission configured is greater than zero. */
			il_tx_set_event_state(tx_msg_id, CANILTX_EVENT_TYPE_CHNG);
		}
	}
}

/************************************************************************************************/
/* Function name    : il_tx_set_event_state                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <tx_type> - Event transmission type                                       */
/*                     - CANILTX_EVENT_TYPE_EXT : External trigger event                        */
/*                     - CANILTX_EVENT_TYPE_CHNG : Signal change event                          */
/*                                                                                              */
/*                     The following value is not passed to this function.                      */
/*                     - CANILTX_EVENT_TYPE_CNT(=CANILTX_TYPE_CYCLIC) : Cyclic event            */
/*                     - CANILTX_TYPE_CNT : Invalid value                                       */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function receives the event request.                                 */
/*                    If the event specified with <tx_type> is not activated,                   */
/*                    the event transmission is started immediately.                            */
/*                                                                                              */
/*                    If the event is already running,                                          */
/*                    this function checks if new event can be accepted.                        */
/*                                                                                              */
/*                    If new event can be accepted,                                             */
/*                    transmission cycle and count are updated in accordance with               */
/*                    the user configuration.                                                   */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_set_event_state(UI_16 tx_msg_id, UI_8 tx_type)
{
	if (CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].Activated == D_FALSE) {
		/* This event is not activated. */
		/* Set the parameters to start immediately transmission of the event message. */
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].Activated = D_TRUE;
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].SendCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[tx_type].Cnt;
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt = 0U;
	} else {
		/* This event is already running. */
		/* Check if the same event shall be accepted during the event sending. */
		if ((C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[tx_type].CtrlType & CANILTX_ACCEPT_NEW_EVENT) != 0U) {
			/* Check if the message should be transmitted immediately or keep the current transmission cycle. */
			if ((C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[tx_type].CtrlType & CANILTX_RESTART_EVENT_CYCLE) != 0U) {
				CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt = 0U;
			}
			/* Check if the number of transmission shall be reset or just added. */
			if ((C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[tx_type].CtrlType & CANILTX_RESET_EVENT_CNT) != 0U) {
				CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].SendCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[tx_type].Cnt;
			} else {
				CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].SendCnt += C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[tx_type].Cnt;
			}
		}
	}
}

/************************************************************************************************/
/* Function name    : il_tx_update_cyclic_state                                                 */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function updates cycle timer                                         */
/*                    and activate the cyclic transmission event.                               */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_update_cyclic_state(UI_16 tx_msg_id)
{
#if (CANILTX_RESET_CYCLE_AFTER_EVENT == 1)
	/* If the cyclic timer need to reset after event transmission completed. */
	/* Reload the cycle time if the current tx type has higher priority than the cycle tramsmission's. */
	if (CanIL_TxCtrl[tx_msg_id].CurTxType < CANILTX_TYPE_CYCLIC) {
		if (CanIL_TxCtrl[tx_msg_id].TxCycleCnt != CANIL_STOP_UPDATE_CNT) {
			CanIL_TxCtrl[tx_msg_id].TxCycleCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxCycle;
		}
	}
#endif /* End of (#if (CANILTX_RESET_CYCLE_AFTER_EVENT == 1)) */

	/* Update the cyclic timer */
	if ((CanIL_TxCtrl[tx_msg_id].TxCycleCnt != CANIL_STOP_UPDATE_CNT) && (CanIL_TxCtrl[tx_msg_id].TxCycleCnt != 0U)) {
		CanIL_TxCtrl[tx_msg_id].TxCycleCnt--;
	}
	if (CanIL_TxCtrl[tx_msg_id].TxCycleCnt == 0U) {
		/* Tx timer expired. */
		/* Reload the cycle counter */
		CanIL_TxCtrl[tx_msg_id].TxCycleCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxCycle;

		/* Activate the cyclic type */
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[CANILTX_TYPE_CYCLIC].Activated = D_TRUE;
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[CANILTX_TYPE_CYCLIC].SendCnt = 1U;
		CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[CANILTX_TYPE_CYCLIC].CycleCnt = 0U;
	}
}

/************************************************************************************************/
/* Function name    : il_tx_type_handling                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function checks activated events                                     */
/*                    and decides which event transmission should be done at this time.         */
/*                                                                                              */
/*                    The priority of each event is described below                             */
/*                     Cycle event < Signal change event < External trigger event               */
/*                                                                                              */
/*                    If the cycle event is interrupted by the other events,                    */
/*                    the current cycle event is cleared.                                       */
/*                                                                                              */
/*                    If the signal change event is interrupted by the external trigger event,  */
/*                    a user can decide whether the current signal change event                 */
/*                    shall be cleared or not.                                                  */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_type_handling(UI_16 tx_msg_id)
{
	UI_8 tx_type;
	UI_8 high_priority_tx_type;

	/* Set the lowest priority */
	high_priority_tx_type = CANILTX_TYPE_CNT;
	/* Find the activated tx type with the highest priority. */
	for (tx_type = 0U; tx_type < CANILTX_TYPE_CNT; tx_type++) {
		if (CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].Activated != D_FALSE) {
			/* This type is activated. Check if this type has the highest priority at this time. */
			if (tx_type < high_priority_tx_type) {
				/* As this type has higher priority, update the current type.  */
				high_priority_tx_type = tx_type;
			} else {
				/* This type has lower priority */
				if (tx_type == CANILTX_TYPE_CYCLIC) {
					/* If this type is cyclic type, deactivate this one. */
					CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].Activated = D_FALSE;
				} else {
					/* If this type is event type, deactivate the event if needed. */
					if ((C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[tx_type].CtrlType & CANILTX_CANCEL_EVENT_REQ) != 0U) {
						CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].Activated = D_FALSE;
					}
				}
			}
		}
	}

	/* Update the current type */
	CanIL_TxCtrl[tx_msg_id].CurTxType = high_priority_tx_type;
}

/************************************************************************************************/
/* Function name    : il_tx_set_pending_req                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function controls transmission timing of the running event.          */
/*                    In this function, event cycle and count are also updated                  */
/*                    and the corresponding TxPendingFlg is set at the appropriate time.        */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_set_pending_req(UI_16 tx_msg_id)
{
	UI_8 tx_type;

	tx_type = CanIL_TxCtrl[tx_msg_id].CurTxType;
	if (tx_type < CANILTX_TYPE_CNT) {

		if ((CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt != CANIL_STOP_UPDATE_CNT) && (CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt != 0U)) {
			CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt--;
		}
		if (CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt == 0U) {
			il_set_flg(tx_msg_id, CanIL_TxBitFlg.TxPendingFlg);
			/* The following 'if condition' must be ture. */
			if (CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].SendCnt != 0U) {
				CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].SendCnt--;
				/* Only event type is allowed to do multiple sending. */
				if ((CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].SendCnt != 0U) && (tx_type < CANILTX_EVENT_TYPE_CNT)) {
					CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxEventCfg[tx_type].Cycle;
				} else {
					CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].Activated = D_FALSE;
					CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].SendCnt = 0U;
					CanIL_TxCtrl[tx_msg_id].TxTypeCtrl[tx_type].CycleCnt = CANIL_STOP_UPDATE_CNT;
				}
			}
		}
	}
}

/************************************************************************************************/
/* Function name    : il_tx_send_msg                                                            */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : First of all, this function checks                                        */
/*                    the TxPendingFlg and the separation time.                                 */
/*                    If the TxPendingFlg is set and the separation time is expired,            */
/*                    the transmission request can be issued to CAN Driver Interface.           */
/*                                                                                              */
/*                    This function calls CanDrvIF_SetTxDynamicReq() or CanDrvIF_SetTxReq()     */
/*                    in accordance with the user configuration.                                */
/*                    If the request is accepted, the corresponding TxPendingFlg is cleared     */
/*                    then transmission timeout timer is started here.                          */
/*                                                                                              */
/************************************************************************************************/
static void il_tx_send_msg(UI_16 tx_msg_id)
{
	UI_8 tx_status;
	E_BOOLEAN			enable_flg;								/* ���M������(���޽���ĺ�)	*/

	enable_flg = ServiceProtocol_IF_GetTxEnableState();			/* ���޽���ĺ� ���M����Ԏ擾	*/

	/* If the separation time has been expired AND the pending request has been set, request to send message. */
	if ((CanIL_TxCtrl[tx_msg_id].TxDelayCnt == 0U) && (enable_flg == E_TRUE)) {
		if (il_chk_flg(tx_msg_id, (const UI_16 *)CanIL_TxBitFlg.TxPendingFlg) != D_FALSE) {
			/* If necessary, inform the CAN IL Appl layer that the message is going to send. */
#if (CANILTX_USE_ILAPPL_TXPRESEND == 1)
			CanILAppl_TxPreSend(tx_msg_id, &CanIL_TxMsg[tx_msg_id]);
#endif /* End of #if (CANILTX_USE_ILAPPL_TXPRESEND == 1) */
			if (C_CanIL_TxMsgCfg[tx_msg_id].TxDynamic != D_FALSE) {
				/* The CAN format, id and data length may need to change from the default value. */
				tx_status = CanDrvIF_SetTxDynamicReq(C_CanIL_TxMsgCfg[tx_msg_id].TxHandle,
												CanIL_TxMsg[tx_msg_id].FrameFormat,
												CanIL_TxMsg[tx_msg_id].Id,
												CanIL_TxMsg[tx_msg_id].DataLen,
												(const UI_8 *)CanIL_TxMsg[tx_msg_id].DataPtr);
			} else {
				/* We can use the default setting for CAN format, id and data length */
				tx_status = CanDrvIF_SetTxReq(C_CanIL_TxMsgCfg[tx_msg_id].TxHandle,
												(const UI_8 *)CanIL_TxMsg[tx_msg_id].DataPtr);
			}

			if (tx_status == CANDRVIF_OK) {
				/* The request has been accepted by the CAN Driver Interface. */
				/* Clear the pending flag. */
				il_clr_flg(tx_msg_id, CanIL_TxBitFlg.TxPendingFlg);
#if CANILTX_RELOAD_DELAY_CNT_WITH_COMP == 1
				/* Counting of the separation time shall be started after tx confirmation. */
				/* Stop the tx separation timer. */
				CanIL_TxCtrl[tx_msg_id].TxDelayCnt = CANIL_STOP_UPDATE_CNT;
#else /* Else of (#if CANILTX_RELOAD_DELAY_CNT_WITH_COMP == 1) */
				/* Start the tx separation timer here. */
				CanIL_TxCtrl[tx_msg_id].TxDelayCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxDelay;
#endif /* End of (#if CANILTX_RELOAD_DELAY_CNT_WITH_COMP == 1) */
				/* Start Timeout supervision for this message */
				CanIL_TxCtrl[tx_msg_id].TxTimeoutCnt = C_CanIL_TxMsgCfg[tx_msg_id].TxTimeout;
			}
		}
	}
}

/************************************************************************************************/
/* Function name    : il_rx_init_ctrl_info                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function initializes internal data related to RxMsg.                 */
/*                    This function calls the following function                                */
/*                    to get default FrameFormat and Id.                                        */
/*                     - CanDrvIF_GetRxFrameFormat()                                            */
/*                     - CanDrvIF_GetRxId()                                                     */
/*                                                                                              */
/************************************************************************************************/
static void il_rx_init_ctrl_info(UI_16 rx_msg_id)
{
	UI_16 rx_handle;

	rx_handle = C_CanIL_RxMsgCfg[rx_msg_id].RxHandle;

	CanIL_RxCtrl[rx_msg_id].RxStatus = CANILRX_STATE_NONE;
	CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt = CANIL_STOP_UPDATE_CNT;
	CanIL_RxMsg[rx_msg_id].FrameFormat = CanDrvIF_GetRxFrameFormat(rx_handle);
	CanIL_RxMsg[rx_msg_id].Id = CanDrvIF_GetRxId(rx_handle);
	CanIL_RxMsg[rx_msg_id].DataLen = C_CanIL_RxMsgCfg[rx_msg_id].DataLen;
	CanIL_RxMsg[rx_msg_id].DataPtr = C_CanIL_RxMsgCfg[rx_msg_id].DataPtr;
	(void)memcpy(CanIL_RxMsg[rx_msg_id].DataPtr, C_CanIL_RxMsgCfg[rx_msg_id].InitialDataPtr, (T_CANIL_SIZE_T)C_CanIL_RxMsgCfg[rx_msg_id].DataLen);

}

/************************************************************************************************/
/* Function name    : il_rx_chk_act_class                                                       */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called                                                   */
/*                    when a user calls CanIL_SetRxMsgActClass() or CanIL_ClrRxMsgActClass()    */
/*                    in order to activate or deactivate reception handling.                    */
/*                                                                                              */
/************************************************************************************************/
static void il_rx_chk_act_class(void)
{
	UI_16 rx_msg_id;
	UI_8 cur_bit_status;
	UI_8 req_bit_status;

	if (CanIL_Ctrl.RxMsgActClassReq != CanIL_Ctrl.RxMsgActClass) {
		for (rx_msg_id = 0U; rx_msg_id < CANILRX_MESSAGE_CNT; rx_msg_id++) {
			cur_bit_status = (UI_8)(C_CanIL_RxMsgCfg[rx_msg_id].RxMsgActClass & CanIL_Ctrl.RxMsgActClass);
			req_bit_status = (UI_8)(C_CanIL_RxMsgCfg[rx_msg_id].RxMsgActClass & CanIL_Ctrl.RxMsgActClassReq);

			if (cur_bit_status != 0U) {
				if (req_bit_status == 0U) {
					il_rx_stop_msg(rx_msg_id);
				}
			} else {
				if (req_bit_status != 0U) {
					il_rx_start_msg(rx_msg_id);
				}
			}
		}
		CanIL_Ctrl.RxMsgActClass = CanIL_Ctrl.RxMsgActClassReq;
	}
}

/************************************************************************************************/
/* Function name    : il_rx_handling                                                            */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <new_msg_flg> - Indicates whether new message has been received.          */
/*                     - D_FALSE : A new message has not been received                          */
/*                     - D_TRUE  : A new message has been received                              */
/*                                                                                              */
/*                    <rx_msg_ptr> - Pointer to the received message information.               */
/*                                   This is only valid when <new_msg_flg> is D_TRUE.           */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function checks new message is received and updates timeout timer.   */
/*                    Internal message buffer is also updated in this function.                 */
/*                                                                                              */
/************************************************************************************************/
static void il_rx_handling(UI_16 rx_msg_id, UI_8 new_msg_flg, T_CanDrvIF_Msg *rx_msg_ptr)
{
	UI_8 valid_msg_flg;
	UI_8				timeout2_old = D_OFF;					/* ��ѱ�đO��l                 */
	T_Rx_stat			*rx_stat_p = N_NULL;					/* ��M�ð���Q�Ɨp�߲��         */
	const T_Canctrl_to_tx_stop_ecu_data   *tx_ecu_data;			/* �ʐM����p�f�[�^				*/
	UI_8				tx_ecu_timeout2;						/* �ʐM����p�f�[�^��ѱ��2���	*/
	E_BOOLEAN			enable_flg;								/* ��M������(���޽���ĺ�) 	*/

	tx_ecu_data = CanCtrl_IF_GetTXstopECUData();				/* �ʐM����p�f�[�^�擾			*/
	tx_ecu_timeout2 = CanCtrl_IF_GetTimeout2(TIMEOUT2_CAN_ABNORMAL);	/* CAN��M�ُ�L���擾	*/
	enable_flg = ServiceProtocol_IF_GetRxEnableState();			/* ���޽���ĺ� ��M����Ԏ擾	*/

	valid_msg_flg = D_FALSE;

	if (new_msg_flg != D_FALSE) {
		/* New message has been received. */
#if (CANILRX_USE_ILAPPL_RXPRECOPY == 1)
		if (CanILAppl_RxPreCopy(rx_msg_id, rx_msg_ptr) != D_FALSE)
#endif /* End of #if (CANILRX_USE_ILAPPL_RXPRECOPY == 1) */
		{
			/* Try to copy the received message. */
			if ((C_CanIL_RxMsgCfg[rx_msg_id].MinDataLen <= rx_msg_ptr->DataLen) && (rx_msg_ptr->DataLen <= C_CanIL_RxMsgCfg[rx_msg_id].DataLen)) {
				/* Store the new message */
				CanIL_RxMsg[rx_msg_id].FrameFormat = rx_msg_ptr->FrameFormat;
				CanIL_RxMsg[rx_msg_id].Id = rx_msg_ptr->Id;
				CanIL_RxMsg[rx_msg_id].DataLen = rx_msg_ptr->DataLen;
				(void)memcpy(CanIL_RxMsg[rx_msg_id].DataPtr, rx_msg_ptr->DataPtr, (T_CANIL_SIZE_T)rx_msg_ptr->DataLen);

#if CANILRX_CLR_ERR_DLC_FLG_WITH_RCV == 1
				/* Clear the error flag */
				CanIL_RxCtrl[rx_msg_id].RxStatus &= (UI_8)~CANILRX_STATE_ERR_DLC;
#endif /* End of (#if CANILRX_CLR_ERR_DLC_FLG_WITH_RCV == 1) */
				if (enable_flg != E_TRUE) {								/* ��M�֎~(���޽���ĺ�) */
					if (rx_msg_id == CAN_RX_7DF) {						/* ID 7DFh�̂ݎ�M�\ */
						/* Set the rx indication flag */
						CanIL_RxCtrl[rx_msg_id].RxStatus |= (CANILRX_STATE_FIRST_RCV | CANILRX_STATE_RCV);
						valid_msg_flg = D_TRUE;
					}
				} else {
					/* Set the rx indication flag */
					CanIL_RxCtrl[rx_msg_id].RxStatus |= (CANILRX_STATE_FIRST_RCV | CANILRX_STATE_RCV);
					valid_msg_flg = D_TRUE;
				}
			} else {
				/* The received message cannot be stored in the IL message buffer. */
				CanIL_RxCtrl[rx_msg_id].RxStatus |= CANILRX_STATE_ERR_DLC;
			}
		}
	}

	il_rx_supervise_timeout(rx_msg_id, valid_msg_flg);

	rx_stat_p = CanCtrl_Stat_GetRxBuff(rx_msg_id);
	timeout2_old =  rx_stat_p->Timeout2;
	s_fcan_rx_check_timer(rx_msg_id, valid_msg_flg);
	
	/* �d���ቺ */
	if ((Batt_stable_can() == 0U) && (rx_stat_p != N_NULL)) {
		if ((rx_stat_p->Timeout2 == D_ON) && (timeout2_old == D_OFF)) {
			rx_stat_p->Timeout2 = D_OFF;
			CanCtrl_Task_ForceClearTimer6(rx_msg_id);
		} else if (rx_stat_p->Timeout2 == D_OFF) {
			CanCtrl_Task_ForceClearTimer6(rx_msg_id);
		} else {
														/*  �����Ȃ�                    */
		}
	}
	
	/* ECU���M��~�׸ގ�M */
	if ((tx_ecu_data->TX_stop_ECU_flg == 1U)
	&& (tx_ecu_timeout2 == 0U)
	&& (rx_stat_p != N_NULL)) {
		if ((rx_msg_id == CANDRVIFRX_HND_209 ) ||
			(rx_msg_id == CANDRVIFRX_HND_20A )) {
			if ((rx_stat_p->Timeout2 == D_ON) && (timeout2_old == D_OFF)) {
				rx_stat_p->Timeout2 = D_OFF;
				CanCtrl_Task_ForceClearTimer6(rx_msg_id);
			} else if (rx_stat_p->Timeout2 == D_OFF) {
				CanCtrl_Task_ForceClearTimer6(rx_msg_id);
			} else {
															/*  �����Ȃ�                    */
			}
		}
	}
}

/************************************************************************************************/
/* Function name    : il_rx_supervise_timeout                                                   */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <valid_msg_flg> - Indicates whether new VALID message has been received.  */
/*                     - D_FALSE : A new VALID message has not been received                    */
/*                     - D_TRUE  : A new VALID message has been received                        */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function supervises reception timeout.                               */
/*                                                                                              */
/************************************************************************************************/
static void il_rx_supervise_timeout(UI_16 rx_msg_id, UI_8 valid_msg_flg)
{
	/* Supervise timeout */
	if (valid_msg_flg != D_FALSE) {
		/* New valid message has been received. */

#if CANILRX_CLR_ERR_TIMEOUT_FLG_WITH_RCV == 1
		/* Clear the error flag */
		CanIL_RxCtrl[rx_msg_id].RxStatus &= (UI_8)~CANILRX_STATE_ERR_TIMEOUT;
#endif /* End of (#if CANILRX_CLR_ERR_TIMEOUT_FLG_WITH_RCV == 1) */

		/* Restart timeout counter, if the timeout observation is already started. */
		if (CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt != CANIL_STOP_UPDATE_CNT) {
			CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt = C_CanIL_RxMsgCfg[rx_msg_id].RxTimeout;
		}
	} else {
		/* New valid message has not been received. */
		/* Decrement timeout counter, if the timeout observation is already started. */
		if ((CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt != CANIL_STOP_UPDATE_CNT) && (CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt != 0U)) {
			CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt--;
		}
		/* If the timer expired, set the flag and restart timeout counter. */
		if (CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt == 0U) {

			CanIL_RxCtrl[rx_msg_id].RxStatus |= CANILRX_STATE_ERR_TIMEOUT;
			CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt = C_CanIL_RxMsgCfg[rx_msg_id].RxTimeout;

		}
	}
}

/************************************************************************************************/
/* Function name    : il_rx_start_msg                                                           */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called when a user calls CanIL_SetRxMsgActClass()        */
/*                    in order to activate reception handling.                                  */
/*                                                                                              */
/************************************************************************************************/
static void il_rx_start_msg(UI_16 rx_msg_id)
{
	/* Set the start flag */
	il_set_flg(rx_msg_id, CanIL_RxBitFlg.RxStartFlg);

	/* Start the timeout supervision */
	CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt = C_CanIL_RxMsgCfg[rx_msg_id].RxTimeout;

#if CANILRX_INIT_STATUS_WITH_START == 1
	/* Set the state to none. Especially, clear the first received flag. */
	CanIL_RxCtrl[rx_msg_id].RxStatus = CANILRX_STATE_NONE;
#endif /* End of #if CANILRX_INIT_STATUS_WITH_START == 1 */

#if CANILRX_INIT_MSG_DATA_WITH_START == 1
	/* Initialize the rx message data */
	CanIL_RxMsg[rx_msg_id].DataPtr = C_CanIL_RxMsgCfg[rx_msg_id].DataPtr;
	(void)memcpy(CanIL_RxMsg[rx_msg_id].DataPtr, C_CanIL_RxMsgCfg[rx_msg_id].InitialDataPtr, (T_CANIL_SIZE_T)C_CanIL_RxMsgCfg[rx_msg_id].DataLen);
#endif /* End of #if CANILRX_INIT_MSG_DATA_WITH_START == 1 */
}

/************************************************************************************************/
/* Function name    : il_rx_stop_msg                                                            */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called when a user calls CanIL_ClrRxMsgActClass()        */
/*                    in order to deactivate reception handling.                                */
/*                                                                                              */
/************************************************************************************************/
static void il_rx_stop_msg(UI_16 rx_msg_id)
{
	/* Clear the start flag */
	il_clr_flg(rx_msg_id, CanIL_RxBitFlg.RxStartFlg);

}

/************************************************************************************************/
/* Function name    : il_rx_disable_msg                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called when a user calls CanIL_DisableRxMsg()            */
/*                    in order to disable reception handling.                                   */
/*                                                                                              */
/************************************************************************************************/
static void il_rx_disable_msg(UI_16 rx_msg_id)
{
	/* Set the disable flag */
	il_set_flg(rx_msg_id, CanIL_RxBitFlg.RxDisableFlg);
}

/************************************************************************************************/
/* Function name    : il_rx_enable_msg                                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function is called when a user calls CanIL_EnableRxMsg()             */
/*                    in order to enable reception handling.                                    */
/*                                                                                              */
/************************************************************************************************/
static void il_rx_enable_msg(UI_16 rx_msg_id)
{
	/* Clear the disable flag */
	il_clr_flg(rx_msg_id, CanIL_RxBitFlg.RxDisableFlg);

	/* Start the timeout supervision */
	CanIL_RxCtrl[rx_msg_id].RxTimeoutCnt = C_CanIL_RxMsgCfg[rx_msg_id].RxTimeout;

}

/************************************************************************************************/
/* Function name    : il_set_flg                                                                */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <msg_id> - TxMsgId or RxMsgId                                             */
/*                                                                                              */
/*                    [in-out]                                                                  */
/*                    <flags> - Pointer to a bit flag array in RAM.                             */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function sets the bit corresponded to the MsgId                      */
/*                    in the bit flag array.                                                    */
/*                                                                                              */
/************************************************************************************************/
static void il_set_flg(UI_16 msg_id, UI_16 flags[])
{
	UI_16 index;
	UI_16 mask;

	index = (UI_16)(msg_id >> 4U);
	mask = (UI_16)1U << (msg_id & 0x000FU);

	flags[index] |= mask;

}

/************************************************************************************************/
/* Function name    : il_clr_flg                                                                */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <msg_id> - TxMsgId or RxMsgId                                             */
/*                                                                                              */
/*                    [in-out]                                                                  */
/*                    <flags> - Pointer to a bit flag array in RAM.                             */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears the bit corresponded to the MsgId                    */
/*                    in the bit flag array.                                                    */
/*                                                                                              */
/************************************************************************************************/
static void il_clr_flg(UI_16 msg_id, UI_16 flags[])
{
	UI_16 index;
	UI_16 mask;

	index = (UI_16)(msg_id >> 4U);
	mask = (UI_16)1U << (msg_id & 0x000FU);

	flags[index] &= (UI_16)~mask;
}

/************************************************************************************************/
/* Function name    : il_chk_flg                                                                */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <msg_id> - TxMsgId or RxMsgId                                             */
/*                                                                                              */
/*                    <flags> - Pointer to a bit flag array.                                    */
/*                                                                                              */
/* Return value     : - D_FALSE : The corresponding bit is 0                                    */
/*                    - D_TRUE  : The corresponding bit is 1                                    */
/*                                                                                              */
/* Description      : This function checks if the bit corresponded to the MsgId                 */
/*                    in the bit flag array is set.                                             */
/*                    If the bit is set, this function returns D_TRUE, otherwise D_FALSE.       */
/*                                                                                              */
/************************************************************************************************/
static UI_8 il_chk_flg(UI_16 msg_id, const UI_16 flags[])
{
	UI_8 ret_val;
	UI_16 index;
	UI_16 mask;

	ret_val = D_FALSE;

	index = (UI_16)(msg_id >> 4U);
	mask = (UI_16)1U << (msg_id & 0x000FU);

	if ((flags[index] & mask) != 0U) {
		ret_val = D_TRUE;
	}

	return ret_val;
}

/************************************************************************************************/
/* Function name    : il_get_signal_val                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <signal_map_ptr> - Pointer to a structure                                 */
/*                                       with signal assignment information.                    */
/*                                                                                              */
/*                    <data_ptr> - Pointer to a data from which the signal value is extracted.  */
/*                                                                                              */
/* Return value     : Signal value  (32-bit data)                                               */
/*                                                                                              */
/*                                                                                              */
/* Description      : This function extracts the signal value from the data                     */
/*                    passed as <data_ptr> and returns 32-bit data.                             */
/*                    Unused bits shall be filled with 0.                                       */
/*                                                                                              */
/************************************************************************************************/
static UI_32 il_get_signal_val(const T_CanIL_SignalMap *signal_map_ptr, const UI_8 data_ptr[])
{
	UI_32 signal_val;
	UI_32 bit_mask;
	UI_8 work_byte_index;
	UI_8 work_val;
	SI_8 byte_index;
	SI_8 add_index;
	UI_8 shift_val;

	signal_val = 0U;

	bit_mask = C_CanIL_GetBitMask[signal_map_ptr->BitCnt];
	shift_val = signal_map_ptr->StartBitIndex;
	if (signal_map_ptr->EndianType != 0U) {
		/* big */
		work_byte_index = signal_map_ptr->StartByteIndex - (signal_map_ptr->UsedByteCnt - 1U);
		byte_index = (SI_8)work_byte_index;
		add_index = 1;
	} else {
		/* little */
		work_byte_index = signal_map_ptr->StartByteIndex + (signal_map_ptr->UsedByteCnt - 1U);
		byte_index = (SI_8)work_byte_index;
		add_index = -1;
	}
	
	switch (signal_map_ptr->UsedByteCnt) {
	case 1U:
		signal_val = data_ptr[byte_index];
		signal_val >>= shift_val;
		signal_val &= bit_mask;
		break;
	case 2U:
		signal_val = data_ptr[byte_index];
		signal_val <<= 8U;

		byte_index += add_index;
		signal_val |= data_ptr[byte_index];
		signal_val >>= shift_val;
		signal_val &= bit_mask;

		break;
	case 3U:
		signal_val = data_ptr[byte_index];
		signal_val <<= 8U;

		byte_index += add_index;
		signal_val |= data_ptr[byte_index];
		signal_val <<= 8U;

		byte_index += add_index;
		signal_val |= data_ptr[byte_index];
		signal_val >>= shift_val;
		signal_val &= bit_mask;

		break;
	case 4U:
		signal_val = data_ptr[byte_index];
		signal_val <<= 8U;

		byte_index += add_index;
		signal_val |= data_ptr[byte_index];
		signal_val <<= 8U;

		byte_index += add_index;
		signal_val |= data_ptr[byte_index];
		signal_val <<= 8U;

		byte_index += add_index;
		signal_val |= data_ptr[byte_index];
		signal_val >>= shift_val;
		signal_val &= bit_mask;
		break;
	case 5U:
		signal_val = data_ptr[byte_index];
		signal_val <<= 8U;

		byte_index += add_index;
		signal_val |= data_ptr[byte_index];
		signal_val <<= 8U;

		byte_index += add_index;
		signal_val |= data_ptr[byte_index];
		signal_val <<= 8U;

		byte_index += add_index;
		signal_val |= data_ptr[byte_index];
		signal_val <<= (8U - shift_val);

		byte_index += add_index;
		work_val = (data_ptr[byte_index] >> shift_val);
		signal_val |= work_val;
		signal_val &= bit_mask;
		break;
	default:
		/* avoid MISRA warning */
		break;
	}

	return signal_val;
	
}


/************************************************************************************************/
/* Function name    : il_set_signal_val                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <signal_map_ptr> - Pointer to a structure                                 */
/*                                       with signal assignment information.                    */
/*                                                                                              */
/*                    <signal_val> - Signal value to be stored to the data                      */
/*                                   specified with <data_ptr>.                                 */
/*                                                                                              */
/*                    [in-out]                                                                  */
/*                    <data_ptr> - Pointer to a data to be updated.                             */
/*                                                                                              */
/* Return value     : Indicates if the signal change is detected.                               */
/*                     - D_FALSE : Signal change is not detected.                               */
/*                                 The value of the current signal                              */
/*                                 and requested siganal are identical.                         */
/*                                                                                              */
/*                     - D_TRUE  : Signal change is detected.                                   */
/*                                 The value of the current signal                              */
/*                                 and requested siganal are not identical.                     */
/*                                                                                              */
/* Description      : This function updates signal value of the message data                    */
/*                    specified with <data_ptr>.                                                */
/*                    During updating, if signal change is detected,                            */
/*                    this function returns D_TRUE in order for the caller                      */
/*                    to handle signal change event.                                            */
/*                    Unused bits shall not be checked in order to detect signal change.        */
/*                                                                                              */
/************************************************************************************************/
static UI_8 il_set_signal_val(const T_CanIL_SignalMap *signal_map_ptr, UI_32 signal_val, UI_8 data_ptr[])
{
	UI_8 top_bit_mask;
	UI_8 bottom_bit_mask;
	SI_8 byte_index;
	SI_8 add_index;
	UI_8 shift_val;
	UI_8 set_signal_val;
	UI_32 work_signal_val;
	UI_8 signal_change;

	work_signal_val = signal_val;

	shift_val = signal_map_ptr->StartBitIndex;
	byte_index = (SI_8)signal_map_ptr->StartByteIndex;
	top_bit_mask = C_CanIL_GetTopBitMask[signal_map_ptr->StopBitIndex];
	bottom_bit_mask = C_CanIL_GetBottomBitMask[shift_val];

	if (signal_map_ptr->EndianType != 0U) {
		/* big */
		add_index = -1;
	} else {
		/* little */
		add_index = 1;
	}

	signal_change = D_FALSE;

	switch (signal_map_ptr->UsedByteCnt) {
	case 1U:
		set_signal_val = (((UI_8)(work_signal_val << shift_val) & (top_bit_mask & bottom_bit_mask)) | (data_ptr[byte_index] & (UI_8)~(top_bit_mask & bottom_bit_mask)));
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}
		break;
	case 2U:
		set_signal_val = (((UI_8)(work_signal_val << shift_val) & bottom_bit_mask) | (data_ptr[byte_index] & (UI_8)~bottom_bit_mask));
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= (8U - shift_val);
		byte_index += add_index;

		set_signal_val = ((UI_8)(work_signal_val & top_bit_mask) | (data_ptr[byte_index] & (UI_8)~top_bit_mask));
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		break;
	case 3U:
		set_signal_val = (((UI_8)(work_signal_val << shift_val) & bottom_bit_mask) | (data_ptr[byte_index] & (UI_8)~bottom_bit_mask));
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= (8U - shift_val);
		byte_index += add_index;

		set_signal_val = (UI_8)work_signal_val;
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= 8U;
		byte_index += add_index;

		set_signal_val = ((UI_8)(work_signal_val & top_bit_mask) | (data_ptr[byte_index] & (UI_8)~top_bit_mask));
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		break;
	case 4U:
		set_signal_val = (((UI_8)(work_signal_val << shift_val) & bottom_bit_mask) | (data_ptr[byte_index] & (UI_8)~bottom_bit_mask));
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= (8U - shift_val);
		byte_index += add_index;

		set_signal_val = (UI_8)work_signal_val;
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= 8U;
		byte_index += add_index;

		set_signal_val = (UI_8)work_signal_val;
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= 8U;
		byte_index += add_index;

		set_signal_val = ((UI_8)(work_signal_val & top_bit_mask) | (data_ptr[byte_index] & (UI_8)~top_bit_mask));
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		break;
	case 5U:
		set_signal_val = (((UI_8)(work_signal_val << shift_val) & bottom_bit_mask) | (data_ptr[byte_index] & (UI_8)~bottom_bit_mask));
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= (8U - shift_val);
		byte_index += add_index;

		set_signal_val = (UI_8)work_signal_val;
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= 8U;
		byte_index += add_index;

		set_signal_val = (UI_8)work_signal_val;
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= 8U;
		byte_index += add_index;

		set_signal_val = (UI_8)work_signal_val;
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		work_signal_val >>= 8U;
		byte_index += add_index;

		set_signal_val = ((UI_8)(work_signal_val & top_bit_mask) | (data_ptr[byte_index] & (UI_8)~top_bit_mask));
		if (data_ptr[byte_index] != set_signal_val) {
			signal_change = D_TRUE;
			data_ptr[byte_index] = set_signal_val;
		}

		break;
	default:
		/* avoid MISRA warning */
		break;
	}

	return signal_change;
}

/************************************************************************************************/
/*!																								*/
/* @brief           ��M�Ď��������																*/
/*																								*/
/*                  ��M�Ď���ς̍X�V���s��														*/
/*																								*/
/* @param [in]       id ү���������																*/
/* @n                   �ް��P��: N/A															*/
/* @n                   ����\: N/A																*/
/* @n                   �ް��͈�: N/A															*/
/*																								*/
/* @return          void																		*/
/* @n                   �ް��P��: N/A															*/
/* @n                   ����\: N/A																*/
/* @n                   �ް��͈�: N/A															*/
/*																								*/
/* @author          ��Đ݌v1 �ێR																*/
/* @date            2010/09/01																	*/
/*																								*/
/* @attention       ���ɂȂ�																	*/
/*																								*/
/* @warning         ���ɂȂ�																	*/
/*																								*/
/* @note            ���ɂȂ�																	*/
/*----------------------------------------------------------------------------------------------*/
/* @author          NSCS																		*/
/* @date            2013/02/21																	*/
/* @note            																			*/
/************************************************************************************************/
static void s_fcan_rx_check_timer(UI_16 rx_msg_id, UI_8 valid_msg_flg)
{
	T_Rx_stat			*rx_stat_p;								/* ��M�ð���Q�Ɨp�߲�� */
	E_BOOLEAN			elap5;									/* ��ѱ��1���� */
	E_BOOLEAN			elap6;									/* ��ѱ��2���� */
	E_BOOLEAN			enable_flg;								/* ��M������(���޽���ĺ�) */
/*	E_BOOLEAN			rx_enable = E_TRUE; */					/* ��M������ */
	/*------------------------------------------------------------------------------------------*/
	/* ��M�Ď���ύX�V����                                                                      */
	/*------------------------------------------------------------------------------------------*/
	rx_stat_p = CanCtrl_Stat_GetRxBuff(rx_msg_id);				/* ��M�ð��ð����߲���擾 */
	enable_flg = ServiceProtocol_IF_GetRxEnableState();			/* ���޽���ĺ� ��M����Ԏ擾 */

	if (enable_flg != E_TRUE) {									/* ��M�֎~(���޽���ĺ�) */
		Can_timeout_timer_init();								/* ��ѱ�Ķ����̏����� */
/*		rx_enable = E_FALSE; */									/* ��M�֎~�ɐݒ� */

/*		if ( (rx_msg_id == CAN_RX_7DF) ) { */					/* ID 7DFh�̂ݎ�M�\ */
/*			rx_enable = E_TRUE; */								/* ��M���ɐݒ� */
/*		} */
	}
/*	if (rx_enable != E_FALSE) { */
		if (valid_msg_flg == D_TRUE) {
			/*----------------------------------------------------------------------------------*/
			/* �����M����                                                                     */
			/*----------------------------------------------------------------------------------*/
			rx_stat_p->RxFirst = 1U;								/* �����MON */
			rx_stat_p->Rx = D_ON;									/* �����MON */
		} else {
			/*----------------------------------------------------------------------------------*/
			/* �����M�Ȃ�                                                                     */
			/*----------------------------------------------------------------------------------*/
			rx_stat_p->Rx = D_OFF;									/* �����MOFF */
		}
		rx_stat_p->Timeout1 = D_OFF;									/* ��ѱ��1�ر */
		rx_stat_p->Timeout2 = D_OFF;									/* ��ѱ��2�ر */
		if ((CAN_ERROR_DETECT_TIME < ErrDetectTime) && (SendWaitFlg == 1U) ) {				/* CAN��ѱ�Ĵװ���o�J�n���Ԍo�� */
			if (rx_stat_p->Rx != D_OFF) {								/* �����M����̏ꍇ */
				elap5 = CanCtrl_Task_ClearTimer5(rx_msg_id);				/* ��ѱ��1���A�m�F */
				if (elap5 == E_FALSE) {								/* ��ѱ�Ĵװ1���� */
					rx_stat_p->Timeout1 = D_ON;						/* ��ѱ��1�p�� */
				}
				elap6 = CanCtrl_Task_ClearTimer6(rx_msg_id);		/* ��ѱ��2���A�m�F */
				if (elap6 == E_FALSE) {								/* ��ѱ�Ĵװ2���� */
					rx_stat_p->Timeout2 = D_ON;						/* ��ѱ��2�p�� */
				}
			} else {
				elap5 = CanCtrl_Task_GetElap5(rx_msg_id);			/* ��ѱ��1���o�m�F */
				if (elap5 == E_TRUE) {								/* ��ѱ��1���o */
					rx_stat_p->Timeout1 = D_ON;						/* ��ѱ��1���o */
				}
				elap6 = CanCtrl_Task_GetElap6(rx_msg_id);			/* ��ѱ��2���o�m�F */
				if (elap6 == E_TRUE) {								/* ��ѱ��2���o */
					rx_stat_p->Timeout2 = D_ON;						/* ��ѱ��2���o */
				}
			}
		}
/*	} */
}

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
/************************************************************************************************/
/* Function name    : CanIL_Init                                                                */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function initializes all of the internal memory.                     */
/*                    A user has to call this function before the other APIs                    */
/*                    of CAN IL are used.                                                       */
/*                                                                                              */
/************************************************************************************************/
void CanIL_Init(void)
{
	il_init_memory();
}

/************************************************************************************************/
/* Function name    : CanIL_TxStateMain                                                         */
/*                                                                                              */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function receives the current transmission status                    */
/*                    from CAN Driver Interface then updates the internal status.               */
/*                                                                                              */
/*                    Additionally, transmission timeout and separation time are updated        */
/*                    and monitored in this function.                                           */
/*                                                                                              */
/*                    If CANILTX_RELOAD_DELAY_CNT_WITH_COMP is 1,                               */
/*                    the separation timer is started when transmission                         */
/*                    or cancel completion is confirmed.                                        */
/*                    If unintentional initialization, bus-off recovery for example,            */
/*                    is executend in CAN Driver Interface,                                     */
/*                    TxMsg Handler has to be desabled once in order to initialize              */
/*                    the separetion timer.                                                     */
/*                                                                                              */
/*                    If CANILTX_RELOAD_DELAY_CNT_WITH_COMP is not 1,                           */
/*                    the separation timer is started when a transmission request               */
/*                    is issued to CAN Driver Interface.                                        */
/*                                                                                              */
/*                    If transmission completion is confirmed, the following bits               */
/*                    in TxStatus are set.                                                      */
/*                     - CANILTX_STATE_FIRST_COMP                                               */
/*                     - CANILTX_STATE_COMP                                                     */
/*                                                                                              */
/*                    If cancel completion is confirmed, the following bit in TxStatus is set.  */
/*                     - CANILTX_STATE_CANCELLED                                                */
/*                                                                                              */
/*                    If transmission timeout is confirmed, the following bit                   */
/*                    in TxStatus is set.                                                       */
/*                     - CANILTX_STATE_ERR_TIMEOUT                                              */
/*                                                                                              */
/*                    These bits can be read and clear via                                      */
/*                    CanIL_GetTxState() and CanIL_ClrTxState().                                */
/*                                                                                              */
/*                    A user also can configure the timing when these bits shall be cleared.    */
/*                                                                                              */
/*                    If CANILTX_CLR_COMP_FLG_EVERY_CYCLE is 1,                                 */
/*                    CANILTX_STATE_COMP and CANILTX_STATE_CANCELLED in TxStatus are cleared    */
/*                    when CanIL_TxStateMain() is called.                                       */
/*                                                                                              */
/*                    If CANILTX_CLR_COMP_FLG_WITH_SET is 1,                                    */
/*                    CANILTX_STATE_COMP and CANILTX_STATE_CANCELLED in TxStatus are cleared    */
/*                    when one of the following function is called.                             */
/*                     - CanIL_SetTxEventReq()                                                  */
/*                     - CanIL_SetTxByteSignal()                                                */
/*                     - CanIL_SetTxWordSignal()                                                */
/*                     - CanIL_SetTxDwordSignal()                                               */
/*                                                                                              */
/*                    If CANILTX_CLR_ERR_TIMEOUT_FLG_WITH_COMP in TxStatus is 1,                */
/*                    CANILTX_STATE_ERR_TIMEOUT is cleared                                      */
/*                    when transmission or cancel completion is confirmed                       */
/*                    in CanIL_TxStateMain().                                                   */
/*                                                                                              */
/*                    This function is expected to be called every 10 msec (in timer task).     */
/*                                                                                              */
/************************************************************************************************/
void CanIL_TxStateMain(void)
{
	UI_16 tx_msg_id;
	UI_8 tx_confirmed;

	for (tx_msg_id = 0U; tx_msg_id < CANILTX_MESSAGE_CNT; tx_msg_id++) {

#if CANILTX_CLR_COMP_FLG_EVERY_CYCLE == 1
		/* Clear the tx confirmation flag and the tx cancel notification flag every cycle */
		CanIL_TxCtrl[tx_msg_id].TxStatus &= (UI_8)~(CANILTX_STATE_COMP | CANILTX_STATE_CANCELLED);
#endif /* End of (#if CANILTX_CLR_COMP_FLG_EVERY_CYCLE == 1) */

		/* Initializes the confirmed flag */
		tx_confirmed = D_FALSE;

		/* Check if the current transmission processing has ended (completed or cancelled). */
		if (CanDrvIF_ChkTxConfirmation(C_CanIL_TxMsgCfg[tx_msg_id].TxHandle) != D_FALSE) {
			/* The requested message has been transmitted correctly. Set the tx confirmation flag */
			CanIL_TxCtrl[tx_msg_id].TxStatus |= (CANILTX_STATE_FIRST_COMP | CANILTX_STATE_COMP);
			tx_confirmed = D_TRUE;
		}
		if (CanDrvIF_ChkTxCancelNotification(C_CanIL_TxMsgCfg[tx_msg_id].TxHandle) != D_FALSE) {
			/* The requested message has been cancelled. Set the tx cancel notification flag */
			CanIL_TxCtrl[tx_msg_id].TxStatus |= CANILTX_STATE_CANCELLED;
			tx_confirmed = D_TRUE;
		}

		if (il_chk_flg(tx_msg_id, (const UI_16 *)CanIL_TxBitFlg.TxStartFlg) != D_FALSE) {
			if (il_chk_flg(tx_msg_id, (const UI_16 *)CanIL_TxBitFlg.TxDisableFlg) == D_FALSE) {
				il_tx_chk_timer(tx_msg_id, tx_confirmed);
			}
		}
	}
}

/************************************************************************************************/
/* Function name    : CanIL_TxMain                                                              */
/*                                                                                              */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function controls transmission timing of cyclic, signal change       */
/*                    and external trigger event and issues the transmission request            */
/*                    to CAN Driver Interface actually.                                         */
/*                                                                                              */
/*                    If the cycle event is interrupted by the other event,                     */
/*                    cyclic period is controlled in accordance with the user configuration.    */
/*                    If CANILTX_RESET_CYCLE_AFTER_EVENT is 1,                                  */
/*                    the cycle timer is reset after event transmission is completed.           */
/*                                                                                              */
/*                    If CANILTX_USE_ILAPPL_TXPRESEND is 1,                                     */
/*                    CanILAppl_TxPreSend() is called                                           */
/*                    in order for a user to be able to modify the message contents             */
/*                    before the transmission request is issued to CAN Driver Interface.        */
/*                                                                                              */
/*                    This function is expected to be called every 10 msec (in timer task).     */
/*                                                                                              */
/************************************************************************************************/
void CanIL_TxMain(void)
{
	UI_16 tx_msg_id;
	E_BOOLEAN elap3;										/* ��ѱ�Ĕ��� */

	for (tx_msg_id = 0U; tx_msg_id < CANILTX_MESSAGE_CNT; tx_msg_id++) {
		if ((Get_ns_normal() == D_OFF ) || ( tx_msg_id == CANILTX_MSG_TX_610 )){
			if (il_chk_flg(tx_msg_id, (const UI_16 *)CanIL_TxBitFlg.TxStartFlg) != D_FALSE) {
				if (il_chk_flg(tx_msg_id, (const UI_16 *)CanIL_TxBitFlg.TxDisableFlg) == D_FALSE) {
					elap3 = CanCtrl_Task_GetElap3();
					if (elap3 != E_FALSE) {
						il_tx_update_event_state(tx_msg_id);
						il_tx_update_cyclic_state(tx_msg_id);
						il_tx_type_handling(tx_msg_id);
						il_tx_set_pending_req(tx_msg_id);
						il_tx_send_msg(tx_msg_id);
					}
				}
			}
		} else {
			/* �������Ȃ� */
		}
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetTxMsgActClass                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <act_class> - ActiveClass                                                 */
/*                     A user can set from CANIL_MSG_ACT_CLASS_USER0                            */
/*                     to CANIL_MSG_ACT_CLASS_USER7.                                            */
/*                     Multiple bit,                                                            */
/*                     (CANIL_MSG_ACT_CLASS_USER0 | CANIL_MSG_ACT_CLASS_USER3) for example,     */
/*                     can be set.                                                              */
/*                     If CANIL_MSG_ACT_CLASS_ALL is set, all TxMsg Handler are activated.      */
/*                                                                                              */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function activates TxMsg Handler with the ActiveClass                */
/*                    specified with <act_class>.                                               */
/*                    Each TxMsg Handler is categorized based on an ActiveClass                 */
/*                    and a user can specify multiple ActiveClass to this function.             */
/*                                                                                              */
/*                    When a TxMsg Handler is activated,                                        */
/*                    the corresponding TxStartFlg is set                                       */
/*                    then the internal transmission state is initialized.                      */
/*                    A user can get the current TxStartFlg state via CanIL_GetTxStartFlg().    */
/*                                                                                              */
/*                    Additionally, TxStatus and Tx data can be initialized                     */
/*                    in accordance with the user configuration                                 */
/*                    when a TxMsg Handler is activated.                                        */
/*                                                                                              */
/*                    If CANILTX_INIT_STATUS_WITH_START is 1,                                   */
/*                    TxStatus is cleared to CANILTX_STATE_NONE.                                */
/*                                                                                              */
/*                    If CANILTX_INIT_MSG_DATA_WITH_START is 1,                                 */
/*                    Tx data is filled with the initial value.                                 */
/*                                                                                              */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetTxMsgActClass(const UI_8 act_class)
{
	CanIL_Ctrl.TxMsgActClassReq |= act_class;
	il_tx_chk_act_class();
}

/************************************************************************************************/
/* Function name    : CanIL_ClrTxMsgActClass                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <act_class> - ActiveClass                                                 */
/*                     A user can set from CANIL_MSG_ACT_CLASS_USER0                            */
/*                     to CANIL_MSG_ACT_CLASS_USER7.                                            */
/*                     Multiple bit,                                                            */
/*                     (CANIL_MSG_ACT_CLASS_USER0 | CANIL_MSG_ACT_CLASS_USER3) for example,     */
/*                     can be set.                                                              */
/*                     If CANIL_MSG_ACT_CLASS_ALL is set, all TxMsg Handler are deactivated.    */
/*                                                                                              */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function deactivates TxMsg Handler with the ActiveClass              */
/*                    specified with <act_class>.                                               */
/*                    Each TxMsg Handler is categorized based on an ActiveClass                 */
/*                    and a user can specify multiple ActiveClass to this function.             */
/*                                                                                              */
/*                    When a TxMsg Handler is deactivated, the corresponding TxStartFlg         */
/*                    and TxPendingFlg are cleared.                                             */
/*                    Then, CanDrvIF_ClrTxReq() is called to remove the transmission request    */
/*                    from CAN Driver Interface.                                                */
/*                    A user can get the current TxStartFlg state via CanIL_GetTxStartFlg().    */
/*                                                                                              */
/************************************************************************************************/
void CanIL_ClrTxMsgActClass(const UI_8 act_class)
{
	CanIL_Ctrl.TxMsgActClassReq &= (UI_8)~act_class;
	il_tx_chk_act_class();
}

/************************************************************************************************/
/* Function name    : CanIL_DisableTxMsg                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function disables TxMsg Handler specified with <tx_msg_id>.          */
/*                                                                                              */
/*                    When a TxMsg Handler is got disabled,                                     */
/*                    the corresponding TxDisableFlg is set and TxPendingFlg is cleared.        */
/*                    Then, CanDrvIF_ClrTxReq() is called to remove the transmission request    */
/*                    from CAN Driver Interface.                                                */
/*                    A user can get the current TxDisableFlg state                             */
/*                    via CanIL_GetTxDisableFlg().                                              */
/*                                                                                              */
/************************************************************************************************/
void CanIL_DisableTxMsg(const UI_16 tx_msg_id)
{
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		if (il_chk_flg(tx_msg_id, (const UI_16 *)CanIL_TxBitFlg.TxDisableFlg) == D_FALSE) {
			il_tx_disable_msg(tx_msg_id);
		}
	}
}

/************************************************************************************************/
/* Function name    : CanIL_EnableTxMsg                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function enables TxMsg Handler specified with <tx_msg_id>.           */
/*                                                                                              */
/*                    When a TxMsg Handler is got enabled,                                      */
/*                    the corresponding TxDisableFlg is cleared                                 */
/*                    then the internal transmission state is initialized.                      */
/*                    A user can get the current TxDisableFlg state                             */
/*                    via CanIL_GetTxDisableFlg().                                              */
/*                                                                                              */
/************************************************************************************************/
void CanIL_EnableTxMsg(const UI_16 tx_msg_id)
{
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		if (il_chk_flg(tx_msg_id, (const UI_16 *)CanIL_TxBitFlg.TxDisableFlg) != D_FALSE) {
			il_tx_enable_msg(tx_msg_id);
		}
	}
}

/************************************************************************************************/
/* Function name    : CanIL_GetTxStartFlg                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : - D_FALSE : The TxMsg Handler is deactivated.                             */
/*                    - D_TRUE  : The TxMsg Handler is activated.                               */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the TxStartFlg flag state.                          */
/*                    When CanIL_Init() is called, TxStartFlg is cleared                        */
/*                    i.e. TxMsg Handler is deactivated.                                        */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetTxStartFlg(const UI_16 tx_msg_id)
{
	UI_8 flg;

	flg = D_FALSE;
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		flg = il_chk_flg(tx_msg_id, (const UI_16 *)CanIL_TxBitFlg.TxStartFlg);
	}

	return flg;
}

/************************************************************************************************/
/* Function name    : CanIL_GetTxDisableFlg                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : - D_FALSE : The TxMsg Handler is enabled.                                 */
/*                    - D_TRUE  : The TxMsg Handler is disabled.                                */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the TxDisableFlg flag state.                        */
/*                    When CanIL_Init() is called, TxDisableFlg is cleared                      */
/*                    i.e. TxMsg Handler is enabled.                                            */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetTxDisableFlg(const UI_16 tx_msg_id)
{
	UI_8 flg;

	flg = D_FALSE;
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		flg = il_chk_flg(tx_msg_id, (const UI_16 *)CanIL_TxBitFlg.TxDisableFlg);
	}

	return flg;
}

/************************************************************************************************/
/* Function name    : CanIL_SetTxEventReq                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function accepts a transmission request with                         */
/*                    the external trigger event.                                               */
/*                                                                                              */
/*                    If CANILTX_CLR_COMP_FLG_WITH_SET is 1,                                    */
/*                    CANILTX_STATE_COMP and CANILTX_STATE_CANCELLED in TxStatus are cleared    */
/*                    when this function is called.                                             */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_SetEventReq_{message_name}()                                   */
/*                       A user can set the trigger only.                                       */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetTxEventReq(const UI_16 tx_msg_id)
{
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		CanIL_TxCtrl[tx_msg_id].TxEventReq |= CANILTX_EVENT_REQ_EXT;
#if CANILTX_CLR_COMP_FLG_WITH_SET == 1
		/* Clear the tx confirmation flag and the tx cancel notification flag when tx request is set. */
		CanIL_TxCtrl[tx_msg_id].TxStatus &= (UI_8)~(CANILTX_STATE_COMP | CANILTX_STATE_CANCELLED);
#endif /* End of (#if CANILTX_CLR_COMP_FLG_WITH_SET == 1) */
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetTxFrameFormat                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <frame_format> - CAN frame format to be transmitted.                      */
/*                     CANIL_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)               */
/*                     CANIL_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)               */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function sets the CAN frame format to be transmitted.                */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_SetFrameFormat_{message_name}(frame_format)                    */
/*                       A user can configure whether this macro is generated.                  */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetTxFrameFormat(const UI_16 tx_msg_id, const UI_8 frame_format)
{
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		if (frame_format < CANIL_FRAME_FORMAT_CNT) {
			CanIL_TxMsg[tx_msg_id].FrameFormat = frame_format;
		}
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetTxId                                                             */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <id> - CAN identifier to be transmitted.                                  */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function sets the CAN identifier to be transmitted.                  */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_SetId_{message_name}(id)                                       */
/*                       A user can configure whether this macro is generated.                  */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetTxId(const UI_16 tx_msg_id, const UI_32 id)
{
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		CanIL_TxMsg[tx_msg_id].Id = id;
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetTxDataLen                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <data_len> - Data length to be transmitted in byte                        */
/*                     0-64                                                                     */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function sets the Data length to be transmitted.                     */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_SetDataLen_{message_name}(data_len)                            */
/*                       A user can configure whether this macro is generated.                  */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetTxDataLen(const UI_16 tx_msg_id, const UI_8 data_len)
{
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		if (data_len <= C_CanIL_TxMsgCfg[tx_msg_id].DataLen) {
			CanIL_TxMsg[tx_msg_id].DataLen = data_len;
		}
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetTxByteSignal                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_byte_signal_id> - TxByteSignal Index                                  */
/*                     The valid TxByteSignal Index is defined as below.                        */
/*                      - CANILTX_BSIG_{signal_name}                                            */
/*                                                                                              */
/*                    <tx_byte_signal_val> - TxByteSignal value to be transmitted.              */
/*                     Signal value within a range 1 bit to 8 bits.                             */
/*                                                                                              */
/*                    <tx_event_req> - Event type                                               */
/*                     CANILTX_EVENT_REQ_NONE : No event                                        */
/*                      This function only updates signal value.                                */
/*                                                                                              */
/*                     CANILTX_EVENT_REQ_CHNG : Signal change event                             */
/*                      This function updates signal value and checks                           */
/*                      if the requested value is identical to the last requested value.        */
/*                      If signal value is changed and ChkSignalChng is configured as D_TRUE,   */
/*                      Signal change event is set.                                             */
/*                                                                                              */
/*                     CANILTX_EVENT_REQ_EXT  : External trigger event                          */
/*                      This function updates signal value and sets External trigger event.     */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function updates TxByteSignal value and sets the event request.      */
/*                                                                                              */
/*                    If CANILTX_CLR_COMP_FLG_WITH_SET is 1,                                    */
/*                    CANILTX_STATE_COMP and CANILTX_STATE_CANCELLED in TxStatus are cleared    */
/*                    when this function is called.                                             */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_Set_{signal_name}(val)                                         */
/*                        calls this function with CANILTX_EVENT_REQ_CHNG.                      */
/*                                                                                              */
/*                     - CanILTx_Send_{signal_name}(val)                                        */
/*                        calls this function with CANILTX_EVENT_REQ_EXT.                       */
/*                                                                                              */
/*                     - CanILTx_Update_{signal_name}(val)                                      */
/*                        calls this function with CANILTX_EVENT_REQ_NONE.                      */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetTxByteSignal(const UI_16 tx_byte_signal_id, const UI_8 tx_byte_signal_val, const UI_8 tx_event_req)
{
	UI_8 signal_change;
	UI_8 tx_event_valid_req;

	if (tx_byte_signal_id < CANILTX_BYTE_SIGNAL_CNT) {
		signal_change = il_set_signal_val(&C_CanIL_TxByteSignalCfg[tx_byte_signal_id].TxSignalMap, (UI_32)tx_byte_signal_val, CanIL_TxMsg[C_CanIL_TxByteSignalCfg[tx_byte_signal_id].TxMsgId].DataPtr);
		tx_event_valid_req = tx_event_req;
		if ((C_CanIL_TxByteSignalCfg[tx_byte_signal_id].ChkSignalChng == D_FALSE) || (signal_change == D_FALSE)) {
			tx_event_valid_req &= (UI_8)~CANILTX_EVENT_REQ_CHNG;
		}
		CanIL_TxCtrl[C_CanIL_TxByteSignalCfg[tx_byte_signal_id].TxMsgId].TxEventReq |= tx_event_valid_req;

#if CANILTX_CLR_COMP_FLG_WITH_SET == 1
		/* Clear the tx confirmation flag and the tx cancel notification flag when tx request is set. */
		CanIL_TxCtrl[C_CanIL_TxByteSignalCfg[tx_byte_signal_id].TxMsgId].TxStatus &= (UI_8)~(CANILTX_STATE_COMP | CANILTX_STATE_CANCELLED);
#endif /* End of (#if CANILTX_CLR_COMP_FLG_WITH_SET == 1) */
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetTxWordSignal                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_word_signal_id> - TxWordSignal Index                                  */
/*                     The valid TxWordSignal Index is defined as below.                        */
/*                      - CANILTX_WSIG_{signal_name}                                            */
/*                                                                                              */
/*                    <tx_word_signal_val> - TxWordSignal value to be transmitted.              */
/*                     Signal value within a range 9 bits to 16 bits.                           */
/*                                                                                              */
/*                    <tx_event_req> - Event type                                               */
/*                     CANILTX_EVENT_REQ_NONE : No event                                        */
/*                      This function only updates signal value.                                */
/*                                                                                              */
/*                     CANILTX_EVENT_REQ_CHNG : Signal change event                             */
/*                      This function updates signal value and checks                           */
/*                      if the requested value is identical to the last requested value.        */
/*                      If signal value is changed and ChkSignalChng is configured as D_TRUE,   */
/*                      Signal change event is set.                                             */
/*                                                                                              */
/*                     CANILTX_EVENT_REQ_EXT  : External trigger event                          */
/*                      This function updates signal value and sets External trigger event.     */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function updates TxWordSignal value and sets the event request.      */
/*                                                                                              */
/*                    If CANILTX_CLR_COMP_FLG_WITH_SET is 1,                                    */
/*                    CANILTX_STATE_COMP and CANILTX_STATE_CANCELLED in TxStatus are cleared    */
/*                    when this function is called.                                             */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_Set_{signal_name}(val)                                         */
/*                        calls this function with CANILTX_EVENT_REQ_CHNG.                      */
/*                                                                                              */
/*                     - CanILTx_Send_{signal_name}(val)                                        */
/*                        calls this function with CANILTX_EVENT_REQ_EXT.                       */
/*                                                                                              */
/*                     - CanILTx_Update_{signal_name}(val)                                      */
/*                        calls this function with CANILTX_EVENT_REQ_NONE.                      */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetTxWordSignal(const UI_16 tx_word_signal_id, const UI_16 tx_word_signal_val, const UI_8 tx_event_req)
{
	UI_8 signal_change;
	UI_8 tx_event_valid_req;

	if (tx_word_signal_id < CANILTX_WORD_SIGNAL_CNT) {
		signal_change = il_set_signal_val(&C_CanIL_TxWordSignalCfg[tx_word_signal_id].TxSignalMap, (UI_32)tx_word_signal_val, CanIL_TxMsg[C_CanIL_TxWordSignalCfg[tx_word_signal_id].TxMsgId].DataPtr);
		tx_event_valid_req = tx_event_req;
		if ((C_CanIL_TxWordSignalCfg[tx_word_signal_id].ChkSignalChng == D_FALSE) || (signal_change == D_FALSE)) {
			tx_event_valid_req &= (UI_8)~CANILTX_EVENT_REQ_CHNG;
		}
		CanIL_TxCtrl[C_CanIL_TxWordSignalCfg[tx_word_signal_id].TxMsgId].TxEventReq |= tx_event_valid_req;

#if CANILTX_CLR_COMP_FLG_WITH_SET == 1
		/* Clear the tx confirmation flag and the tx cancel notification flag when tx request is set. */
		CanIL_TxCtrl[C_CanIL_TxWordSignalCfg[tx_word_signal_id].TxMsgId].TxStatus &= (UI_8)~(CANILTX_STATE_COMP | CANILTX_STATE_CANCELLED);
#endif /* End of (#if CANILTX_CLR_COMP_FLG_WITH_SET == 1) */
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetTxDwordSignal                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_dword_signal_id> - TxDwordSignal Index                                */
/*                     The valid TxDwordSignal Index is defined as below.                       */
/*                      - CANILTX_DWSIG_{signal_name}                                           */
/*                                                                                              */
/*                    <tx_dword_signal_val> - TxDwordSignal value to be transmitted.            */
/*                     Signal value within a range 17 bits to 32 bits.                          */
/*                                                                                              */
/*                    <tx_event_req> - Event type                                               */
/*                     CANILTX_EVENT_REQ_NONE : No event                                        */
/*                      This function only updates signal value.                                */
/*                                                                                              */
/*                     CANILTX_EVENT_REQ_CHNG : Signal change event                             */
/*                      This function updates signal value and checks                           */
/*                      if the requested value is identical to the last requested value.        */
/*                      If signal value is changed and ChkSignalChng is configured as D_TRUE,   */
/*                      Signal change event is set.                                             */
/*                                                                                              */
/*                     CANILTX_EVENT_REQ_EXT  : External trigger event                          */
/*                      This function updates signal value and sets External trigger event.     */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function updates TxDwordSignal value and sets the event request.     */
/*                                                                                              */
/*                    If CANILTX_CLR_COMP_FLG_WITH_SET is 1,                                    */
/*                    CANILTX_STATE_COMP and CANILTX_STATE_CANCELLED in TxStatus are cleared    */
/*                    when this function is called.                                             */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_Set_{signal_name}(val)                                         */
/*                        calls this function with CANILTX_EVENT_REQ_CHNG.                      */
/*                                                                                              */
/*                     - CanILTx_Send_{signal_name}(val)                                        */
/*                        calls this function with CANILTX_EVENT_REQ_EXT.                       */
/*                                                                                              */
/*                     - CanILTx_Update_{signal_name}(val)                                      */
/*                        calls this function with CANILTX_EVENT_REQ_NONE.                      */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetTxDwordSignal(const UI_16 tx_dword_signal_id, const UI_32 tx_dword_signal_val, const UI_8 tx_event_req)
{
	UI_8 signal_change;
	UI_8 tx_event_valid_req;

	if (tx_dword_signal_id < CANILTX_DWORD_SIGNAL_CNT) {
		signal_change = il_set_signal_val(&C_CanIL_TxDwordSignalCfg[tx_dword_signal_id].TxSignalMap, (UI_32)tx_dword_signal_val, CanIL_TxMsg[C_CanIL_TxDwordSignalCfg[tx_dword_signal_id].TxMsgId].DataPtr);
		tx_event_valid_req = tx_event_req;
		if ((C_CanIL_TxDwordSignalCfg[tx_dword_signal_id].ChkSignalChng == D_FALSE) || (signal_change == D_FALSE)) {
			tx_event_valid_req &= (UI_8)~CANILTX_EVENT_REQ_CHNG;
		}
		CanIL_TxCtrl[C_CanIL_TxDwordSignalCfg[tx_dword_signal_id].TxMsgId].TxEventReq |= tx_event_valid_req;

#if CANILTX_CLR_COMP_FLG_WITH_SET == 1
		/* Clear the tx confirmation flag and the tx cancel notification flag when tx request is set. */
		CanIL_TxCtrl[C_CanIL_TxDwordSignalCfg[tx_dword_signal_id].TxMsgId].TxStatus &= (UI_8)~(CANILTX_STATE_COMP | CANILTX_STATE_CANCELLED);
#endif /* End of (#if CANILTX_CLR_COMP_FLG_WITH_SET == 1) */
	}
}

/************************************************************************************************/
/* Function name    : CanIL_GetTxState                                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <tx_state_mask> - The bits in TxStatus to be evaluated.                   */
/*                                      A user can sets multiple bits to this parameter.        */
/*                      - CANILTX_STATE_FIRST_COMP                                              */
/*                         Transmission completion has been confirmed.                          */
/*                                                                                              */
/*                      - CANILTX_STATE_COMP                                                    */
/*                         Transmission completion has been confirmed.                          */
/*                                                                                              */
/*                      - CANILTX_STATE_ERR_TIMEOUT                                             */
/*                         Transmission timeout has been detected.                              */
/*                                                                                              */
/*                      - CANILTX_STATE_CANCELLED                                               */
/*                         Transmission cancel completion has been confirmed.                   */
/*                                                                                              */
/*                                                                                              */
/* Return value     : - D_FALSE : One or more bits                                              */
/*                                specified with <tx_state_mask> are 0 in TxStatus.             */
/*                    - D_TRUE  : All of the bits                                               */
/*                                specified with <tx_state_mask> are 1 in TxStatus.             */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the current TxStatus bit state.                     */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_GetState_{message_name}(state_mask)                            */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetTxState(const UI_16 tx_msg_id, const UI_8 tx_state_mask)
{
	UI_8 flg;

	flg = D_FALSE;
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		if ((CanIL_TxCtrl[tx_msg_id].TxStatus & tx_state_mask) == tx_state_mask) {
			flg = D_TRUE;
		}
	}
	return flg;
}

/************************************************************************************************/
/* Function name    : CanIL_ClrTxState                                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <tx_state_mask> - The bits in TxStatus to be cleared.                     */
/*                                      A user can sets multiple bits to this parameter.        */
/*                      - CANILTX_STATE_FIRST_COMP                                              */
/*                         Transmission completion has been confirmed.                          */
/*                                                                                              */
/*                      - CANILTX_STATE_COMP                                                    */
/*                         Transmission completion has been confirmed.                          */
/*                                                                                              */
/*                      - CANILTX_STATE_ERR_TIMEOUT                                             */
/*                         Transmission timeout has been detected.                              */
/*                                                                                              */
/*                      - CANILTX_STATE_CANCELLED                                               */
/*                         Transmission cancel completion has been confirmed.                   */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears the current TxStatus bit state                       */
/*                    specified with <tx_state_mask>.                                           */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_ClrState_{message_name}(state_mask)                            */
/*                                                                                              */
/************************************************************************************************/
void CanIL_ClrTxState(const UI_16 tx_msg_id, const UI_8 tx_state_mask)
{
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		CanIL_TxCtrl[tx_msg_id].TxStatus &= (UI_8)~tx_state_mask;
	}
}

/************************************************************************************************/
/* Function name    : CanIL_GetTxFrameFormat                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : The last requested CAN frame format                                       */
/*                    - CANIL_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)              */
/*                    - CANIL_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)              */
/*                    If parameter is invalid, CANIL_FRAME_FORMAT_INVALID is returned.          */
/*                                                                                              */
/* Description      : This function returns the last requested CAN frame format.                */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_GetFrameFormat_{message_name}()                                */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetTxFrameFormat(const UI_16 tx_msg_id)
{
	UI_8 frame_format;

	frame_format = CANIL_FRAME_FORMAT_INVALID;
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		frame_format = CanIL_TxMsg[tx_msg_id].FrameFormat;
	}

	return frame_format;
}

/************************************************************************************************/
/* Function name    : CanIL_GetTxId                                                             */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : The last requested CAN identifier                                         */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                    If parameter is invalid, CANIL_ID_INVALID is returned.                    */
/*                                                                                              */
/* Description      : This function returns the last requested CAN identifier.                  */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_GetId_{message_name}()                                         */
/*                                                                                              */
/************************************************************************************************/
UI_32 CanIL_GetTxId(const UI_16 tx_msg_id)
{
	UI_32 id;

	id = CANIL_ID_INVALID;
	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		id = CanIL_TxMsg[tx_msg_id].Id;
	}

	return id;
}

/************************************************************************************************/
/* Function name    : CanIL_GetTxDataLen                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : The last requested Data length in byte                                    */
/*                     0-64                                                                     */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns the last requested Data length.                     */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_GetDataLen_{message_name}()                                    */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetTxDataLen(const UI_16 tx_msg_id)
{
	UI_8 data_len;

	data_len = 0U;

	if (tx_msg_id < CANILTX_MESSAGE_CNT) {
		data_len = CanIL_TxMsg[tx_msg_id].DataLen;
	}

	return data_len;
}

/************************************************************************************************/
/* Function name    : CanIL_GetTxByteSignal                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_byte_signal_id> - TxByteSignal Index                                  */
/*                     The valid TxByteSignal Index is defined as below.                        */
/*                      - CANILTX_BSIG_{signal_name}                                            */
/*                                                                                              */
/* Return value     : The last requested TxByteSignal value                                     */
/*                     Signal value within a range 1 bit to 8 bits.                             */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns the last requested TxByteSignal value.              */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_Get_{signal_name}()                                            */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetTxByteSignal(const UI_16 tx_byte_signal_id)
{
	UI_8 tx_byte_signal_val;

	tx_byte_signal_val = 0U;
	if (tx_byte_signal_id < CANILTX_BYTE_SIGNAL_CNT) {
		tx_byte_signal_val = (UI_8)il_get_signal_val(&C_CanIL_TxByteSignalCfg[tx_byte_signal_id].TxSignalMap, (const UI_8 *)CanIL_TxMsg[C_CanIL_TxByteSignalCfg[tx_byte_signal_id].TxMsgId].DataPtr);
	}

	return tx_byte_signal_val;
}

/************************************************************************************************/
/* Function name    : CanIL_GetTxWordSignal                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_word_signal_id> - TxWordSignal Index                                  */
/*                     The valid TxWordSignal Index is defined as below.                        */
/*                      - CANILTX_WSIG_{signal_name}                                            */
/*                                                                                              */
/* Return value     : The last requested TxWordSignal value                                     */
/*                     Signal value within a range 9 bits to 16 bits.                           */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns the last requested TxWordSignal value.              */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_Get_{signal_name}()                                            */
/*                                                                                              */
/************************************************************************************************/
UI_16 CanIL_GetTxWordSignal(const UI_16 tx_word_signal_id)
{
	UI_16 tx_word_signal_val;

	tx_word_signal_val = 0U;
	if (tx_word_signal_id < CANILTX_WORD_SIGNAL_CNT) {
		tx_word_signal_val = (UI_16)il_get_signal_val(&C_CanIL_TxWordSignalCfg[tx_word_signal_id].TxSignalMap, (const UI_8 *)CanIL_TxMsg[C_CanIL_TxWordSignalCfg[tx_word_signal_id].TxMsgId].DataPtr);
	}

	return tx_word_signal_val;
}

/************************************************************************************************/
/* Function name    : CanIL_GetTxDwordSignal                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_dword_signal_id> - TxDwordSignal Index                                */
/*                     The valid TxDwordSignal Index is defined as below.                       */
/*                      - CANILTX_DWSIG_{signal_name}                                           */
/*                                                                                              */
/* Return value     : The last requested TxDwordSignal value                                    */
/*                     Signal value within a range 17 bits to 32 bits.                          */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns the last requested TxDwordSignal value.             */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILTx_Get_{signal_name}()                                            */
/*                                                                                              */
/************************************************************************************************/
UI_32 CanIL_GetTxDwordSignal(const UI_16 tx_dword_signal_id)
{
	UI_32 tx_dword_signal_val;

	tx_dword_signal_val = 0U;
	if (tx_dword_signal_id < CANILTX_DWORD_SIGNAL_CNT) {
		tx_dword_signal_val = (UI_32)il_get_signal_val(&C_CanIL_TxDwordSignalCfg[tx_dword_signal_id].TxSignalMap, (const UI_8 *)CanIL_TxMsg[C_CanIL_TxDwordSignalCfg[tx_dword_signal_id].TxMsgId].DataPtr);
	}

	return tx_dword_signal_val;
}

/************************************************************************************************/
/* Function name    : CanIL_RxMain                                                              */
/*                                                                                              */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function checks if the new message is received                       */
/*                    and detects data length error and reception timeout error.                */
/*                                                                                              */
/*                    The received message information can be get                               */
/*                    via the following functions.                                              */
/*                     - CanIL_GetRxFrameFormat()                                               */
/*                     - CanIL_GetRxId()                                                        */
/*                     - CanIL_GetRxDataLen()                                                   */
/*                     - CanIL_GetRxByteSignal()                                                */
/*                     - CanIL_GetRxWordSignal()                                                */
/*                     - CanIL_GetRxDwordSignal()                                               */
/*                                                                                              */
/*                    If a valid message is received,                                           */
/*                    the message is stored to the internal buffer                              */
/*                    and the following bits in RxStatus are set.                               */
/*                     - CANILRX_STATE_FIRST_RCV                                                */
/*                     - CANILRX_STATE_RCV                                                      */
/*                                                                                              */
/*                    If the data length of the received message is out of range,               */
/*                    the follwoing bit in RxStatus is set.                                     */
/*                     - CANILRX_STATE_ERR_DLC                                                  */
/*                                                                                              */
/*                    If the reception timeout is detected,                                     */
/*                    the following bit in RxStatus is set.                                     */
/*                     - CANILRX_STATE_ERR_TIMEOUT                                              */
/*                                                                                              */
/*                    These bits can be read and clear via                                      */
/*                    CanIL_GetRxState() and CanIL_ClrRxState().                                */
/*                                                                                              */
/*                    A user also can configure the timing when these bits shall be cleared.    */
/*                                                                                              */
/*                    If CANILRX_CLR_RCV_FLG_EVERY_CYCLE is 1,                                  */
/*                    CANILRX_STATE_RCV in RxStatus is cleared when CanIL_RxMain() is called.   */
/*                                                                                              */
/*                    If CANILRX_CLR_ERR_DLC_FLG_WITH_RCV is 1,                                 */
/*                    CANILRX_STATE_ERR_DLC in RxStatus is cleared                              */
/*                    when a valid message is received.                                         */
/*                                                                                              */
/*                    If CANILRX_CLR_ERR_TIMEOUT_FLG_WITH_RCV is 1,                             */
/*                    CANILRX_STATE_ERR_TIMEOUT in RxStatus is cleared                          */
/*                    when a valid message is received.                                         */
/*                                                                                              */
/*                                                                                              */
/*                    If CANILRX_USE_ILAPPL_RXPRECOPY is 1,                                     */
/*                    CanILAppl_RxPreCopy() is called in order for a user to be able to         */
/*                    analyze the received message and discard it before storing the message.   */
/*                                                                                              */
/*                                                                                              */
/*                    This function is expected to be called every 10 msec (in timer task).     */
/*                                                                                              */
/************************************************************************************************/
void CanIL_RxMain(void)
{
	UI_16 rx_msg_id;
	UI_8 new_msg_flg;
	UI_8 work_rx_data[64U];
	T_CanDrvIF_Msg work_rx_msg;
	E_BOOLEAN			enable_flg;							/* �ʐM�ُ팟�o������(���޽���ĺ�) */

	enable_flg = ServiceProtocol_IF_GetDtcEnableState();	/* ���޽���ĺ� �ʐM�ُ팟�o�ێ擾 */
	if (enable_flg == E_TRUE) {								/* �ʐM�ُ팟�o���� */
		if (CanCtrl_Task_GetEnableSend() == E_TRUE) {		/* CAN���M����� */
			SendWaitFlg = 1U;								/* ���M�J�n�t���O�̃Z�b�g */
		}
		if (SendWaitFlg == 1U) {							/* ���M�J�n */
			if (ErrDetectTime <= CAN_ERROR_DETECT_TIME) {	/* CAN��ѱ�Ĵװ���o�J�n���� */
				ErrDetectTime++;							/* CAN��ѱ�Ĵװ���o�J�n���ԍX�V */
			}
		}
	} else {
		Can_timeout_timer_init();							/* ��ѱ�Ķ����̏����� */
	}


	work_rx_msg.DataPtr = work_rx_data;

	for (rx_msg_id = 0U; rx_msg_id < CANILRX_MESSAGE_CNT; rx_msg_id++) {

#if CANILRX_CLR_RCV_FLG_EVERY_CYCLE == 1
		/* Clear the received flag */
		CanIL_RxCtrl[rx_msg_id].RxStatus &= (UI_8)~CANILRX_STATE_RCV;
#endif /* End of (#if CANILRX_CLR_RCV_FLG_EVERY_CYCLE == 1) */

		/* Get rx indication flag and received message from the driver interface */
		new_msg_flg = CanDrvIF_GetRxMsg(C_CanIL_RxMsgCfg[rx_msg_id].RxHandle, &work_rx_msg);

		if (il_chk_flg(rx_msg_id, (const UI_16 *)CanIL_RxBitFlg.RxStartFlg) != D_FALSE) {
			if (il_chk_flg(rx_msg_id, (const UI_16 *)CanIL_RxBitFlg.RxDisableFlg) == D_FALSE) {
				il_rx_handling(rx_msg_id, new_msg_flg, &work_rx_msg);
			}
		}
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetRxMsgActClass                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <act_class> - ActiveClass                                                 */
/*                     A user can set from CANIL_MSG_ACT_CLASS_USER0                            */
/*                     to CANIL_MSG_ACT_CLASS_USER7.                                            */
/*                     Multiple bit,                                                            */
/*                     (CANIL_MSG_ACT_CLASS_USER0 | CANIL_MSG_ACT_CLASS_USER3) for example,     */
/*                     can be set.                                                              */
/*                     If CANIL_MSG_ACT_CLASS_ALL is set, all RxMsg Handler are activated.      */
/*                                                                                              */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function activates RxMsg Handler with the ActiveClass                */
/*                    specified with <act_class>.                                               */
/*                    Each RxMsg Handler is categorized based on an ActiveClass                 */
/*                    and a user can specify multiple ActiveClass to this function.             */
/*                                                                                              */
/*                    When a RxMsg Handler is activated,                                        */
/*                    the corresponding RxStartFlg is set                                       */
/*                    then the reception timeout timer is started.                              */
/*                    A user can get the current RxStartFlg state via CanIL_GetRxStartFlg().    */
/*                                                                                              */
/*                    Additionally, RxStatus and Rx data can be initialized                     */
/*                    in accordance with the user configuration                                 */
/*                    when a RxMsg Handler is activated.                                        */
/*                                                                                              */
/*                    If CANILRX_INIT_STATUS_WITH_START is 1,                                   */
/*                    RxStatus is cleared to CANILRX_STATE_NONE.                                */
/*                                                                                              */
/*                    If CANILRX_INIT_MSG_DATA_WITH_START is 1,                                 */
/*                    Rx data is filled with the initial value.                                 */
/*                                                                                              */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetRxMsgActClass(const UI_8 act_class)
{
	CanIL_Ctrl.RxMsgActClassReq |= act_class;
	il_rx_chk_act_class();
}

/************************************************************************************************/
/* Function name    : CanIL_ClrRxMsgActClass                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <act_class> - ActiveClass                                                 */
/*                     A user can set from CANIL_MSG_ACT_CLASS_USER0                            */
/*                     to CANIL_MSG_ACT_CLASS_USER7.                                            */
/*                     Multiple bit,                                                            */
/*                     (CANIL_MSG_ACT_CLASS_USER0 | CANIL_MSG_ACT_CLASS_USER3) for example,     */
/*                     can be set.                                                              */
/*                     If CANIL_MSG_ACT_CLASS_ALL is set, all RxMsg Handler are deactivated.    */
/*                                                                                              */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function deactivates RxMsg Handler with the ActiveClass              */
/*                    specified with <act_class>.                                               */
/*                    Each RxMsg Handler is categorized based on an ActiveClass                 */
/*                    and a user can specify multiple ActiveClass to this function.             */
/*                                                                                              */
/*                    When a RxMsg Handler is deactivated, the corresponding RxStartFlg         */
/*                    is cleared.                                                               */
/*                    A user can get the current RxStartFlg state via CanIL_GetRxStartFlg().    */
/*                                                                                              */
/************************************************************************************************/
void CanIL_ClrRxMsgActClass(const UI_8 act_class)
{
	CanIL_Ctrl.RxMsgActClassReq &= (UI_8)~act_class;
	il_rx_chk_act_class();
}

/************************************************************************************************/
/* Function name    : CanIL_DisableRxMsg                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function disables RxMsg Handler specified with <rx_msg_id>.          */
/*                                                                                              */
/*                    When a RxMsg Handler is got disabled,                                     */
/*                    the corresponding RxDisableFlg is set.                                    */
/*                    A user can get the current RxDisableFlg state                             */
/*                    via CanIL_GetRxDisableFlg().                                              */
/*                                                                                              */
/************************************************************************************************/
void CanIL_DisableRxMsg(const UI_16 rx_msg_id)
{
	if (rx_msg_id < CANILRX_MESSAGE_CNT) {
		if (il_chk_flg(rx_msg_id, (const UI_16 *)CanIL_RxBitFlg.RxDisableFlg) == D_FALSE) {
			il_rx_disable_msg(rx_msg_id);
		}
	}
}

/************************************************************************************************/
/* Function name    : CanIL_EnableRxMsg                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function enables RxMsg Handler specified with <rx_msg_id>.           */
/*                                                                                              */
/*                    When a RxMsg Handler is got enabled,                                      */
/*                    the corresponding RxDisableFlg is cleared                                 */
/*                    then the reception timeout timer is started.                              */
/*                    A user can get the current RxDisableFlg state                             */
/*                    via CanIL_GetRxDisableFlg().                                              */
/*                                                                                              */
/************************************************************************************************/
void CanIL_EnableRxMsg(const UI_16 rx_msg_id)
{
	if (rx_msg_id < CANILRX_MESSAGE_CNT) {
		if (il_chk_flg(rx_msg_id, (const UI_16 *)CanIL_RxBitFlg.RxDisableFlg) != D_FALSE) {
			il_rx_enable_msg(rx_msg_id);
		}
	}
}

/************************************************************************************************/
/* Function name    : CanIL_GetRxStartFlg                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : - D_FALSE : The RxMsg Handler is deactivated.                             */
/*                    - D_TRUE  : The RxMsg Handler is activated.                               */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the RxStartFlg flag state.                          */
/*                    When CanIL_Init() is called, RxStartFlg is cleared                        */
/*                    i.e. RxMsg Handler is deactivated.                                        */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetRxStartFlg(const UI_16 rx_msg_id)
{
	UI_8 flg;

	flg = D_FALSE;
	if (rx_msg_id < CANILRX_MESSAGE_CNT) {
		flg = il_chk_flg(rx_msg_id, (const UI_16 *)CanIL_RxBitFlg.RxStartFlg);
	}

	return flg;
}

/************************************************************************************************/
/* Function name    : CanIL_GetRxDisableFlg                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : - D_FALSE : The RxMsg Handler is enabled.                                 */
/*                    - D_TRUE  : The RxMsg Handler is disabled.                                */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the RxDisableFlg flag state.                        */
/*                    When CanIL_Init() is called, RxDisableFlg is cleared                      */
/*                    i.e. RxMsg Handler is enabled.                                            */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetRxDisableFlg(const UI_16 rx_msg_id)
{
	UI_8 flg;

	flg = D_FALSE;
	if (rx_msg_id < CANILRX_MESSAGE_CNT) {
		flg = il_chk_flg(rx_msg_id, (const UI_16 *)CanIL_RxBitFlg.RxDisableFlg);
	}

	return flg;
}

/************************************************************************************************/
/* Function name    : CanIL_SetRxByteSignal                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_byte_signal_id> - RxByteSignal Index                                  */
/*                     The valid RxByteSignal Index is defined as below.                        */
/*                      - CANILRX_BSIG_{signal_name}                                            */
/*                                                                                              */
/*                    <rx_byte_signal_val> - RxByteSignal value to be manipulated.              */
/*                     Signal value within a range 1 bit to 8 bits.                             */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function manipulates RxByteSignal value.                             */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_Set_{signal_name}(val)                                         */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetRxByteSignal(const UI_16 rx_byte_signal_id, const UI_8 rx_byte_signal_val)
{
	if (rx_byte_signal_id < CANILRX_BYTE_SIGNAL_CNT) {
		(void)il_set_signal_val(&C_CanIL_RxByteSignalCfg[rx_byte_signal_id].RxSignalMap, (UI_32)rx_byte_signal_val, CanIL_RxMsg[C_CanIL_RxByteSignalCfg[rx_byte_signal_id].RxMsgId].DataPtr);
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetRxWordSignal                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_word_signal_id> - RxWordSignal Index                                  */
/*                     The valid RxWordSignal Index is defined as below.                        */
/*                      - CANILRX_WSIG_{signal_name}                                            */
/*                                                                                              */
/*                    <rx_word_signal_val> - RxWordSignal value to be manipulated.              */
/*                     Signal value within a range 9 bits to 16 bits.                           */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function manipulates RxWordSignal value.                             */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_Set_{signal_name}(val)                                         */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetRxWordSignal(const UI_16 rx_word_signal_id, const UI_16 rx_word_signal_val)
{
	if (rx_word_signal_id < CANILRX_WORD_SIGNAL_CNT) {
		(void)il_set_signal_val(&C_CanIL_RxWordSignalCfg[rx_word_signal_id].RxSignalMap, (UI_32)rx_word_signal_val, CanIL_RxMsg[C_CanIL_RxWordSignalCfg[rx_word_signal_id].RxMsgId].DataPtr);
	}
}

/************************************************************************************************/
/* Function name    : CanIL_SetRxDwordSignal                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_dword_signal_id> - RxDwordSignal Index                                */
/*                     The valid RxDwordSignal Index is defined as below.                       */
/*                      - CANILRX_DWSIG_{signal_name}                                           */
/*                                                                                              */
/*                    <rx_dword_signal_val> - RxDwordSignal value to be manipulated.            */
/*                     Signal value within a range 17 bits to 32 bits.                          */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function manipulates RxDwordSignal value.                            */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_Set_{signal_name}(val)                                         */
/*                                                                                              */
/************************************************************************************************/
void CanIL_SetRxDwordSignal(const UI_16 rx_dword_signal_id, const UI_32 rx_dword_signal_val)
{
	if (rx_dword_signal_id < CANILRX_DWORD_SIGNAL_CNT) {
		(void)il_set_signal_val(&C_CanIL_RxDwordSignalCfg[rx_dword_signal_id].RxSignalMap, (UI_32)rx_dword_signal_val, CanIL_RxMsg[C_CanIL_RxDwordSignalCfg[rx_dword_signal_id].RxMsgId].DataPtr);
	}
}

/************************************************************************************************/
/* Function name    : CanIL_GetRxState                                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <rx_state_mask> - The bits in RxStatus to be evaluated.                   */
/*                                      A user can sets multiple bits to this parameter.        */
/*                      - CANILRX_STATE_FIRST_RCV                                               */
/*                         A message has been received.                                         */
/*                                                                                              */
/*                      - CANILRX_STATE_RCV                                                     */
/*                         A message has been received.                                         */
/*                                                                                              */
/*                      - CANILRX_STATE_ERR_DLC                                                 */
/*                         The data length error has been detected.                             */
/*                                                                                              */
/*                      - CANILRX_STATE_ERR_TIMEOUT                                             */
/*                         The reception timeout error has been detected.                       */
/*                                                                                              */
/*                                                                                              */
/* Return value     : - D_FALSE : One or more bits                                              */
/*                                specified with <rx_state_mask> are 0 in RxStatus.             */
/*                    - D_TRUE  : All of the bits                                               */
/*                                specified with <rx_state_mask> are 1 in RxStatus.             */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the current RxStatus bit state.                     */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_GetState_{message_name}(state_mask)                            */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetRxState(const UI_16 rx_msg_id, const UI_8 rx_state_mask)
{
	UI_8 flg;

	flg = D_FALSE;
	if (rx_msg_id < CANILRX_MESSAGE_CNT) {
		if ((CanIL_RxCtrl[rx_msg_id].RxStatus & rx_state_mask) == rx_state_mask) {
			flg = D_TRUE;
		}
	}
	return flg;
}

/************************************************************************************************/
/* Function name    : CanIL_ClrRxState                                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <rx_state_mask> - The bits in RxStatus to be cleared.                     */
/*                                      A user can sets multiple bits to this parameter.        */
/*                      - CANILRX_STATE_FIRST_RCV                                               */
/*                         A message has been received.                                         */
/*                                                                                              */
/*                      - CANILRX_STATE_RCV                                                     */
/*                         A message has been received.                                         */
/*                                                                                              */
/*                      - CANILRX_STATE_ERR_DLC                                                 */
/*                         The data length error has been detected.                             */
/*                                                                                              */
/*                      - CANILRX_STATE_ERR_TIMEOUT                                             */
/*                         The reception timeout error has been detected.                       */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears the current RxStatus bit state                       */
/*                    specified with <rx_state_mask>.                                           */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_ClrState_{message_name}(state_mask)                            */
/*                                                                                              */
/************************************************************************************************/
void CanIL_ClrRxState(const UI_16 rx_msg_id, const UI_8 rx_state_mask)
{
	if (rx_msg_id < CANILRX_MESSAGE_CNT) {
		CanIL_RxCtrl[rx_msg_id].RxStatus &= (UI_8)~rx_state_mask;
	}
}

/************************************************************************************************/
/* Function name    : CanIL_GetRxFrameFormat                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : CAN frame format of the received message                                  */
/*                    - CANIL_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)              */
/*                    - CANIL_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)              */
/*                    If parameter is invalid, CANIL_FRAME_FORMAT_INVALID is returned.          */
/*                                                                                              */
/* Description      : This function returns CAN frame format of the received message.           */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_GetFrameFormat_{message_name}()                                */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetRxFrameFormat(const UI_16 rx_msg_id)
{
	UI_8 frame_format;

	frame_format = CANIL_FRAME_FORMAT_INVALID;
	if (rx_msg_id < CANILRX_MESSAGE_CNT) {
		frame_format = CanIL_RxMsg[rx_msg_id].FrameFormat;
	}

	return frame_format;
}

/************************************************************************************************/
/* Function name    : CanIL_GetRxId                                                             */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : CAN identifier of the received message                                    */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                    If parameter is invalid, CANIL_ID_INVALID is returned.                    */
/*                                                                                              */
/* Description      : This function returns CAN identifier of the received message.             */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_GetId_{message_name}()                                         */
/*                                                                                              */
/************************************************************************************************/
UI_32 CanIL_GetRxId(const UI_16 rx_msg_id)
{
	UI_32 id;

	id = CANIL_ID_INVALID;

	if (rx_msg_id < CANILRX_MESSAGE_CNT) {
		id = CanIL_RxMsg[rx_msg_id].Id;
	}

	return id;
}

/************************************************************************************************/
/* Function name    : CanIL_GetRxDataLen                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : Data length of the received message in byte                               */
/*                     0-64                                                                     */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns Data length of the received message.                */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_GetDataLen_{message_name}()                                    */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetRxDataLen(const UI_16 rx_msg_id)
{
	UI_8 data_len;

	data_len = 0U;

	if (rx_msg_id < CANILRX_MESSAGE_CNT) {
		data_len = CanIL_RxMsg[rx_msg_id].DataLen;
	}

	return data_len;
}

/************************************************************************************************/
/* Function name    : CanIL_GetRxByteSignal                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_byte_signal_id> - RxByteSignal Index                                  */
/*                     The valid RxByteSignal Index is defined as below.                        */
/*                      - CANILRX_BSIG_{signal_name}                                            */
/*                                                                                              */
/* Return value     : The last received RxByteSignal value                                      */
/*                     Signal value within a range 1 bit to 8 bits.                             */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns the last received RxByteSignal value.               */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_Get_{signal_name}()                                            */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanIL_GetRxByteSignal(const UI_16 rx_byte_signal_id)
{
	UI_8 rx_byte_signal_val;

	rx_byte_signal_val = 0U;
	if (rx_byte_signal_id < CANILRX_BYTE_SIGNAL_CNT) {
		rx_byte_signal_val = (UI_8)il_get_signal_val(&C_CanIL_RxByteSignalCfg[rx_byte_signal_id].RxSignalMap, (const UI_8 *)CanIL_RxMsg[C_CanIL_RxByteSignalCfg[rx_byte_signal_id].RxMsgId].DataPtr);
	}

	return rx_byte_signal_val;
}

/************************************************************************************************/
/* Function name    : CanIL_GetRxWordSignal                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_word_signal_id> - RxWordSignal Index                                  */
/*                     The valid RxWordSignal Index is defined as below.                        */
/*                      - CANILRX_WSIG_{signal_name}                                            */
/*                                                                                              */
/* Return value     : The last received RxWordSignal value                                      */
/*                     Signal value within a range 9 bits to 16 bits.                           */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns the last received RxWordSignal value.               */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_Get_{signal_name}()                                            */
/*                                                                                              */
/************************************************************************************************/
UI_16 CanIL_GetRxWordSignal(const UI_16 rx_word_signal_id)
{
	UI_16 rx_word_signal_val;

	rx_word_signal_val = 0U;
	if (rx_word_signal_id < CANILRX_WORD_SIGNAL_CNT) {
		rx_word_signal_val = (UI_16)il_get_signal_val(&C_CanIL_RxWordSignalCfg[rx_word_signal_id].RxSignalMap, (const UI_8 *)CanIL_RxMsg[C_CanIL_RxWordSignalCfg[rx_word_signal_id].RxMsgId].DataPtr);
	}

	return rx_word_signal_val;
}

/************************************************************************************************/
/* Function name    : CanIL_GetRxDwordSignal                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_dword_signal_id> - RxDwordSignal Index                                */
/*                     The valid RxDwordSignal Index is defined as below.                       */
/*                      - CANILRX_DWSIG_{signal_name}                                           */
/*                                                                                              */
/* Return value     : The last received RxDwordSignal value                                     */
/*                     Signal value within a range 17 bits to 32 bits.                          */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns the last received RxDwordSignal value.              */
/*                                                                                              */
/*                    A user needs to call this function through the access interface macro.    */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILRx_Get_{signal_name}()                                            */
/*                                                                                              */
/************************************************************************************************/
UI_32 CanIL_GetRxDwordSignal(const UI_16 rx_dword_signal_id)
{
	UI_32 rx_dword_signal_val;

	rx_dword_signal_val = 0U;
	if (rx_dword_signal_id < CANILRX_DWORD_SIGNAL_CNT) {
		rx_dword_signal_val = (UI_32)il_get_signal_val(&C_CanIL_RxDwordSignalCfg[rx_dword_signal_id].RxSignalMap, (const UI_8 *)CanIL_RxMsg[C_CanIL_RxDwordSignalCfg[rx_dword_signal_id].RxMsgId].DataPtr);
	}

	return rx_dword_signal_val;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanILRx_RxIndication_209(const UI_16 rx_handle, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[])
{
	UI_8		ign;												/* IGN��� */
	E_BOOLEAN enable_flg;
	
	if (rx_handle == C_CanIL_RxMsgCfg[CANILRX_MSG_RX_209].RxHandle) {
		ign = SysIn_GetSwState(SYSTEMINPUT_SW_ID_IGN);
		if ( ign == D_ON ){
			enable_flg = ServiceProtocol_IF_GetRxEnableState();	/* ���޽���ĺ� ��M����Ԏ擾 */
			if (((C_CanIL_RxMsgCfg[CANILRX_MSG_RX_209].MinDataLen <= data_length) && (data_length <= C_CanIL_RxMsgCfg[CANILRX_MSG_RX_209].DataLen)) && 
				(enable_flg == E_TRUE)) {
				CanIL_RxData_RX_209_OdoPls += (UI_16)(data_ptr[2]);
				Sp_CanPulseStore((UI_16)data_ptr[2]);
			}
		}
	}
}

#if 0
/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanILRx_RxIndication_20A(const UI_16 rx_handle, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[])
{
	UI_8		ign;												/* IGN��� */
	E_BOOLEAN enable_flg;
	
	if (rx_handle == C_CanIL_RxMsgCfg[CANILRX_MSG_RX_20A].RxHandle) {
		ign = SysIn_GetSwState(SYSTEMINPUT_SW_ID_IGN);
		if ( ign == D_ON ){
			enable_flg = ServiceProtocol_IF_GetRxEnableState();	/* ���޽���ĺ� ��M����Ԏ擾 */
			if (((C_CanIL_RxMsgCfg[CANILRX_MSG_RX_20A].MinDataLen <= data_length) && (data_length <= C_CanIL_RxMsgCfg[CANILRX_MSG_RX_20A].DataLen)) && 
				(enable_flg == E_TRUE)) {
				CanIL_RxData_RX_20A_OdoPls += (UI_16)(data_ptr[4]);
				Sp_CanPulseStore((UI_16)data_ptr[4]);
			}
		}
	}
}
#endif
/************************************************************************************************/
/* Function name    : CanIL_RxMain_IgnOff                                                       */
/* Description      : IGN OFF����M�f�[�^����������                                             */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanIL_RxMain_IgnOff(void)
{
		UI_16 msg_id;
	UI_8 work_rx_data[64U];
	T_CanDrvIF_Msg work_rx_msg;
	T_Rx_stat			*rx_stat_p;

	work_rx_msg.DataPtr = work_rx_data;															

	for (msg_id = 0U; msg_id < CANILRX_MESSAGE_CNT; msg_id++) {									
		(void)CanDrvIF_GetRxMsg(C_CanIL_RxMsgCfg[msg_id].RxHandle, &work_rx_msg);				

		il_rx_init_ctrl_info(msg_id);															

		rx_stat_p = CanCtrl_Stat_GetRxBuff(msg_id);				/* ��M�ð��ð����߲���擾 */	
		rx_stat_p->RxFirst = D_OFF;								/* �����MOFF */				
		rx_stat_p->Rx = D_OFF;									/* �����MOFF */				
		rx_stat_p->Timeout1 = D_OFF;								/* ��ѱ��1�ر */				
		rx_stat_p->Timeout2 = D_OFF;								/* ��ѱ��2�ر */				
	}																							
	CanCtr_Msg_Init();											/* ��M�f�[�^������ */			
	Can_timeout_timer_init();									/* ��ѱ�Ķ����̏����� */		
	CanCtrl_Task_ClearTimer3();									/* ���M��ѱ�Ķ����̏����� */	

/*	if (SendWaitFlg == 1U) { */									/* ���M�J�n */					
/*		if (ErrDetectTime <= CAN_ERROR_DETECT_TIME) { */		/* CAN��ѱ�Ĵװ���o�J�n���� */	
/*			ErrDetectTime++; */									/* CAN��ѱ�Ĵװ���o�J�n���ԍX�V */
/*		} */
/*	} */
}

/************************************************************************************************/
/* Function name    : CanIL_TxMain_IgnOff                                                       */
/* Description      : IGN OFF�����M�f�[�^����������                                             */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanIL_TxMain_IgnOff(void)
{
	UI_16 msg_id;
		
	for (msg_id = 0U; msg_id < CANILTX_MESSAGE_CNT; msg_id++) {
			il_tx_init_ctrl_info(msg_id);
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_16 CanIL_GetRxOdoPls(void)
{
	return CanIL_RxData_RX_209_OdoPls;
}

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/
