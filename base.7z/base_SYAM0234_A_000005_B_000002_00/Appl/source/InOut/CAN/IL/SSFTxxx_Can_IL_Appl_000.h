/************************************************************************************************/
/* Customer         : -                                                                         */
/* Model(Theme No.) : SSFTxxx                                                                   */
/* Copyright        : Nippon Seiki Co., Ltd.                                                    */
/*----------------------------------------------------------------------------------------------*/
/* Date             : 2016/09/02                                                                */
/* Author           : PF1                                                                       */
/*----------------------------------------------------------------------------------------------*/
/* Ver              : 020000                                                                    */
/************************************************************************************************/


#ifndef SSFTXXX_CAN_IL_APPL_000_H
#define SSFTXXX_CAN_IL_APPL_000_H

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Can_IL_000.h"

/************************************************************************************************/
/* Global Macros                                                                                */
/************************************************************************************************/

/************************************************************************************************/
/* Global Data Types                                                                            */
/************************************************************************************************/

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/

/************************************************************************************************/
/* Global Data                                                                                  */
/************************************************************************************************/

/************************************************************************************************/
/* Global Constants                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
extern void CanILAppl_Init(void);
extern void CanILAppl_TxMain(void);
extern void CanILAppl_RxMain(void);

#if (CANILTX_USE_ILAPPL_TXPRESEND == 1)
extern void CanILAppl_TxPreSend(const UI_16 tx_msg_id, T_CanDrvIF_Msg *tx_msg_ptr);
#endif /* End of (#if (CANILTX_USE_ILAPPL_TXPRESEND == 1)) */

#if (CANILRX_USE_ILAPPL_RXPRECOPY == 1)
extern UI_8 CanILAppl_RxPreCopy(const UI_16 rx_msg_id, T_CanDrvIF_Msg *rx_msg_ptr);
#endif /* End of (#if (CANILRX_USE_ILAPPL_RXPRECOPY == 1)) */

#if (CANILRX_USE_ILAPPL_MSGIF == 1)
extern UI_8 CanILAppl_GetRxFrameFormat(const UI_16 rx_msg_id);
extern UI_32 CanILAppl_GetRxId(const UI_16 rx_msg_id);
extern UI_8 CanILAppl_GetRxDataLen(const UI_16 rx_msg_id);
extern UI_8 CanILAppl_GetRxState(const UI_16 rx_msg_id, const UI_8 rx_state_mask);
extern void CanILAppl_ClrRxState(const UI_16 rx_msg_id, const UI_8 rx_state_mask);
#endif /* End of (#if (CANILRX_USE_ILAPPL_MSGIF == 1)) */

#if (CANILRX_USE_ILAPPL_SIGIF == 1)
extern UI_8 CanILAppl_GetRxByteSignal(const UI_16 rx_byte_signal_id);
extern UI_16 CanILAppl_GetRxWordSignal(const UI_16 rx_word_signal_id);
extern UI_32 CanILAppl_GetRxDwordSignal(const UI_16 rx_dword_signal_id);
extern void CanILAppl_SetRxByteSignal(const UI_16 rx_byte_signal_id, const UI_8 rx_byte_signal_val);
extern void CanILAppl_SetRxWordSignal(const UI_16 rx_word_signal_id, const UI_16 rx_word_signal_val);
extern void CanILAppl_SetRxDwordSignal(const UI_16 rx_dword_signal_id, const UI_32 rx_dword_signal_val);
#endif /* End of (#if (CANILRX_USE_ILAPPL_SIGIF == 1)) */

#endif /* SSFTXXX_CAN_IL_APPL_000_H */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/

