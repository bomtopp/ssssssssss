/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFTSTD                                                                   */
/* Copyright        : Nippon Seiki Co., Ltd.                                                    */
/*----------------------------------------------------------------------------------------------*/
/* Date             : 2016/09/02                                                                */
/* Author           : PF1                                                                       */
/*----------------------------------------------------------------------------------------------*/
/* Ver              : 020000                                                                    */
/************************************************************************************************/


#ifndef SSFTSTD_CAN_IL_000_H
#define SSFTSTD_CAN_IL_000_H

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"
#include "SSFTxxx_Can_IL_Cfg_000.h"

/************************************************************************************************/
/* Global Macros                                                                                */
/************************************************************************************************/
#define CANILTX_EVENT_REQ_NONE ((UI_8)0x00U) /* 0000 0000b */
#define CANILTX_EVENT_REQ_CHNG ((UI_8)0x01U) /* 0000 0001b */
#define CANILTX_EVENT_REQ_EXT  ((UI_8)0x02U) /* 0000 0010b */

/************************************************************************************************/
/* Global Data Types                                                                            */
/************************************************************************************************/

/************************************************************************************************/
/* Global Data                                                                                  */
/************************************************************************************************/

/************************************************************************************************/
/* Global Constants                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
extern void CanIL_Init(void);

/* Tx */
extern void CanIL_TxStateMain(void);
extern void CanIL_TxMain(void);

extern void CanIL_SetTxMsgActClass(const UI_8 act_class);
extern void CanIL_ClrTxMsgActClass(const UI_8 act_class);
extern void CanIL_DisableTxMsg(const UI_16 tx_msg_id);
extern void CanIL_EnableTxMsg(const UI_16 tx_msg_id);

extern UI_8 CanIL_GetTxStartFlg(const UI_16 tx_msg_id);
extern UI_8 CanIL_GetTxDisableFlg(const UI_16 tx_msg_id);

extern void CanIL_SetTxEventReq(const UI_16 tx_msg_id);
extern void CanIL_SetTxFrameFormat(const UI_16 tx_msg_id, const UI_8 frame_format);
extern void CanIL_SetTxId(const UI_16 tx_msg_id, const UI_32 id);
extern void CanIL_SetTxDataLen(const UI_16 tx_msg_id, const UI_8 data_len);
extern void CanIL_SetTxByteSignal(const UI_16 tx_byte_signal_id, const UI_8 tx_byte_signal_val, const UI_8 tx_event_req);
extern void CanIL_SetTxWordSignal(const UI_16 tx_word_signal_id, const UI_16 tx_word_signal_val, const UI_8 tx_event_req);
extern void CanIL_SetTxDwordSignal(const UI_16 tx_dword_signal_id, const UI_32 tx_dword_signal_val, const UI_8 tx_event_req);

extern UI_8 CanIL_GetTxState(const UI_16 tx_msg_id, const UI_8 tx_state_mask);
extern void CanIL_ClrTxState(const UI_16 tx_msg_id, const UI_8 tx_state_mask);

extern UI_8 CanIL_GetTxFrameFormat(const UI_16 tx_msg_id);
extern UI_32 CanIL_GetTxId(const UI_16 tx_msg_id);
extern UI_8 CanIL_GetTxDataLen(const UI_16 tx_msg_id);
extern UI_8 CanIL_GetTxByteSignal(const UI_16 tx_byte_signal_id);
extern UI_16 CanIL_GetTxWordSignal(const UI_16 tx_word_signal_id);
extern UI_32 CanIL_GetTxDwordSignal(const UI_16 tx_dword_signal_id);

extern void CanIL_TxMain_IgnOff(void);

/* Rx */
extern void CanIL_RxMain(void);

extern void CanIL_SetRxMsgActClass(const UI_8 act_class);
extern void CanIL_ClrRxMsgActClass(const UI_8 act_class);
extern void CanIL_DisableRxMsg(const UI_16 rx_msg_id);
extern void CanIL_EnableRxMsg(const UI_16 rx_msg_id);

extern UI_8 CanIL_GetRxStartFlg(const UI_16 rx_msg_id);
extern UI_8 CanIL_GetRxDisableFlg(const UI_16 rx_msg_id);

extern void CanIL_SetRxByteSignal(const UI_16 rx_byte_signal_id, const UI_8 rx_byte_signal_val);
extern void CanIL_SetRxWordSignal(const UI_16 rx_word_signal_id, const UI_16 rx_word_signal_val);
extern void CanIL_SetRxDwordSignal(const UI_16 rx_dword_signal_id, const UI_32 rx_dword_signal_val);

extern UI_8 CanIL_GetRxState(const UI_16 rx_msg_id, const UI_8 rx_state_mask);
extern void CanIL_ClrRxState(const UI_16 rx_msg_id, const UI_8 rx_state_mask);

extern UI_8 CanIL_GetRxFrameFormat(const UI_16 rx_msg_id);
extern UI_32 CanIL_GetRxId(const UI_16 rx_msg_id);
extern UI_8 CanIL_GetRxDataLen(const UI_16 rx_msg_id);
extern UI_8 CanIL_GetRxByteSignal(const UI_16 rx_byte_signal_id);
extern UI_16 CanIL_GetRxWordSignal(const UI_16 rx_word_signal_id);
extern UI_32 CanIL_GetRxDwordSignal(const UI_16 rx_dword_signal_id);

extern void CanILRx_RxIndication_209(const UI_16 rx_handle, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[]);
/* extern void CanILRx_RxIndication_20A(const UI_16 rx_handle, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[]); */
extern UI_16 CanIL_GetRxOdoPls(void);
extern void CanIL_RxMain_IgnOff(void);

#endif /* SSFTSTD_CAN_IL_000_H */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/

