/************************************************************************************************/
/* Customer         : -                                                                         */
/* Model(Theme No.) : SSFTxxx                                                                   */
/* Copyright        : Nippon Seiki Co., Ltd.                                                    */
/*----------------------------------------------------------------------------------------------*/
/* Date             : 2016/09/02                                                                */
/* Author           : PF1                                                                       */
/*----------------------------------------------------------------------------------------------*/
/* Ver              : 020000                                                                    */
/************************************************************************************************/



/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#define SSFTXXX_CAN_IL_APPL_000_INTERNAL
#include "SSFTxxx_Can_IL_Appl_000.h"

/************************************************************************************************/
/* Local Macros                                                                                 */
/************************************************************************************************/

/************************************************************************************************/
/* Local Data Types                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Local Data                                                                                   */
/************************************************************************************************/

/************************************************************************************************/
/* Local Function Declarations                                                                  */
/************************************************************************************************/

/************************************************************************************************/
/* Local Constants                                                                              */
/************************************************************************************************/

/************************************************************************************************/
/* Local Functions                                                                              */
/************************************************************************************************/


/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
/************************************************************************************************/
/* Function name    : CanILAppl_Init                                                            */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's initialization function.                              */
/*                                                                                              */
/************************************************************************************************/
void CanILAppl_Init(void)
{

}

/************************************************************************************************/
/* Function name    : CanILAppl_TxMain                                                          */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's transmission related function.                        */
/*                                                                                              */
/************************************************************************************************/
void CanILAppl_TxMain(void)
{
	
}

/************************************************************************************************/
/* Function name    : CanILAppl_RxMain                                                          */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's reception related function.                           */
/*                                                                                              */
/************************************************************************************************/
void CanILAppl_RxMain(void)
{
	
}

#if (CANILTX_USE_ILAPPL_TXPRESEND == 1)
/************************************************************************************************/
/* Function name    : CanILAppl_TxPreSend                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_msg_id> - TxMsgId                                                     */
/*                     Valid TxMsgId is defined in the configuration header file as below.      */
/*                      - CANILTX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    [in-out]                                                                  */
/*                    <tx_msg_ptr> - Pointer to the messege information to be transmitted.      */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : If CANILTX_USE_ILAPPL_TXPRESEND is 1,                                     */
/*                    this skeleton function is called before CAN Interaction Layer             */
/*                    issues a transmission request to CAN Driver Interface.                    */
/*                    This function allows a user                                               */
/*                    to modify the message contents to be transmitted.                         */
/*                                                                                              */
/************************************************************************************************/
void CanILAppl_TxPreSend(const UI_16 tx_msg_id, T_CanDrvIF_Msg *tx_msg_ptr)
{
	
}

#endif /* End of (#if (CANILTX_USE_ILAPPL_TXPRESEND == 1)) */

#if (CANILRX_USE_ILAPPL_RXPRECOPY == 1)
/************************************************************************************************/
/* Function name    : CanILAppl_RxPreCopy                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    [in-out]                                                                  */
/*                    <rx_msg_ptr> - Pointer to the received message information.               */
/*                                                                                              */
/* Return value     :A user can decide whether the message shall be discarded.                  */
/*                    - D_FALSE : CAN Interaction Layer discards the message.                   */
/*                    - D_TRUE  : CAN Interaction Layer checks message validity.                */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : If CANILRX_USE_ILAPPL_RXPRECOPY is 1,                                     */
/*                    this skeleton function is called before CAN Interaction Layer             */
/*                    checks length error and updates internal buffer.                          */
/*                    This function allows a user                                               */
/*                    to analyze the message contents and discards the message.                 */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanILAppl_RxPreCopy(const UI_16 rx_msg_id, T_CanDrvIF_Msg *rx_msg_ptr)
{
	return D_TRUE;
}

#endif /* End of (#if (CANILRX_USE_ILAPPL_RXPRECOPY == 1)) */

#if (CANILRX_USE_ILAPPL_MSGIF == 1)
/************************************************************************************************/
/* Function name    : CanILAppl_GetRxFrameFormat                                                */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : User-Dependent                                                            */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_GetFrameFormat_{message_name}()                            */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanILAppl_GetRxFrameFormat(const UI_16 rx_msg_id)
{
	return CANIL_FRAME_FORMAT_CNT;
}

/************************************************************************************************/
/* Function name    : CanILAppl_GetRxId                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : User-Dependent                                                            */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_GetId_{message_name}()                                     */
/*                                                                                              */
/************************************************************************************************/
UI_32 CanILAppl_GetRxId(const UI_16 rx_msg_id)
{
	return CANIL_ID_INVALID;
}

/************************************************************************************************/
/* Function name    : CanILAppl_GetRxDataLen                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/* Return value     : User-Dependent                                                            */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_GetDataLen_{message_name}()                                */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanILAppl_GetRxDataLen(const UI_16 rx_msg_id)
{
	return 0U;
}

/************************************************************************************************/
/* Function name    : CanILAppl_GetRxState                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <rx_state_mask> - User-Dependent                                          */
/*                                                                                              */
/* Return value     : User-Dependent                                                            */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_GetState_{message_name}(state_mask)                        */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanILAppl_GetRxState(const UI_16 rx_msg_id, const UI_8 rx_state_mask)
{
	return D_FALSE;
}

/************************************************************************************************/
/* Function name    : CanILAppl_ClrRxState                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_msg_id> - RxMsgId                                                     */
/*                     Valid RxMsgId is defined in the configuration header file as below.      */
/*                      - CANILRX_MSG_{message_name}                                            */
/*                                                                                              */
/*                    <rx_state_mask> - User-Dependent                                          */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_ClrState_{message_name}(state_mask)                        */
/*                                                                                              */
/************************************************************************************************/
void CanILAppl_ClrRxState(const UI_16 rx_msg_id, const UI_8 rx_state_mask)
{
	
}

#endif /* End of (#if (CANILRX_USE_ILAPPL_MSGIF == 1)) */

#if (CANILRX_USE_ILAPPL_SIGIF == 1)
/************************************************************************************************/
/* Function name    : CanILAppl_GetRxByteSignal                                                 */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_byte_signal_id> - RxByteSignal Index                                  */
/*                     The valid RxByteSignal Index is defined as below.                        */
/*                      - CANILRX_BSIG_{signal_name}                                            */
/*                                                                                              */
/* Return value     : User-Dependent                                                            */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_Get_{signal_name}()                                        */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanILAppl_GetRxByteSignal(const UI_16 rx_byte_signal_id)
{
	return 0U;
}

/************************************************************************************************/
/* Function name    : CanILAppl_GetRxWordSignal                                                 */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_word_signal_id> - RxWordSignal Index                                  */
/*                     The valid RxWordSignal Index is defined as below.                        */
/*                      - CANILRX_WSIG_{signal_name}                                            */
/*                                                                                              */
/* Return value     : User-Dependent                                                            */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_Get_{signal_name}()                                        */
/*                                                                                              */
/************************************************************************************************/
UI_16 CanILAppl_GetRxWordSignal(const UI_16 rx_word_signal_id)
{
	return 0U;
}

/************************************************************************************************/
/* Function name    : CanILAppl_GetRxDwordSignal                                                */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_dword_signal_id> - RxDwordSignal Index                                */
/*                     The valid RxDwordSignal Index is defined as below.                       */
/*                      - CANILRX_DWSIG_{signal_name}                                           */
/*                                                                                              */
/* Return value     : User-Dependent                                                            */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_Get_{signal_name}()                                        */
/*                                                                                              */
/************************************************************************************************/
UI_32 CanILAppl_GetRxDwordSignal(const UI_16 rx_dword_signal_id)
{
	return 0U;
}

/************************************************************************************************/
/* Function name    : CanILAppl_SetRxByteSignal                                                 */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_byte_signal_id> - RxByteSignal Index                                  */
/*                     The valid RxByteSignal Index is defined as below.                        */
/*                      - CANILRX_BSIG_{signal_name}                                            */
/*                                                                                              */
/*                    <rx_byte_signal_val> - User-Dependent                                     */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_Set_{signal_name}()                                        */
/*                                                                                              */
/************************************************************************************************/
void CanILAppl_SetRxByteSignal(const UI_16 rx_byte_signal_id, const UI_8 rx_byte_signal_val)
{

}

/************************************************************************************************/
/* Function name    : CanILAppl_SetRxWordSignal                                                 */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_word_signal_id> - RxWordSignal Index                                  */
/*                     The valid RxWordSignal Index is defined as below.                        */
/*                      - CANILRX_WSIG_{signal_name}                                            */
/*                                                                                              */
/*                    <rx_word_signal_val> - User-Dependent                                     */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_Set_{signal_name}()                                        */
/*                                                                                              */
/************************************************************************************************/
void CanILAppl_SetRxWordSignal(const UI_16 rx_word_signal_id, const UI_16 rx_word_signal_val)
{

}

/************************************************************************************************/
/* Function name    : CanILAppl_SetRxDwordSignal                                                */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_dword_signal_id> - RxDwordSignal Index                                */
/*                     The valid RxDwordSignal Index is defined as below.                       */
/*                      - CANILRX_DWSIG_{signal_name}                                           */
/*                                                                                              */
/*                    <rx_dword_signal_val> - User-Dependent                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : User-Dependent                                                            */
/*                                                                                              */
/* Note             : This skeleton function can be used                                        */
/*                    to implement user's API.                                                  */
/*                                                                                              */
/*                    This function can be called through the access interface macro.           */
/*                    [ACCESS INTERFACE MACRO]                                                  */
/*                     - CanILApplRx_Set_{signal_name}()                                        */
/*                                                                                              */
/************************************************************************************************/
void CanILAppl_SetRxDwordSignal(const UI_16 rx_dword_signal_id, const UI_32 rx_dword_signal_val)
{

}

#endif /* End of (#if (CANILRX_USE_ILAPPL_SIGIF == 1)) */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/
