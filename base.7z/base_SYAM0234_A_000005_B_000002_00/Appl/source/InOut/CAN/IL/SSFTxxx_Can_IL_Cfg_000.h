/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFT                                                                      */
/*----------------------------------------------------------------------------------------------*/
/* CPU              : -                                                                         */
/* Date             : 12 Mar. 2019                                                              */
/*----------------------------------------------------------------------------------------------*/
/* Programmed by    : PF1                                                                       */
/* Copyrights       : Nippon Seiki Co., Ltd.                                                    */
/*----------------------------------------------------------------------------------------------*/
/* Powered by       : CAN Configuration File Generator (0.8.0.0)                                */
/************************************************************************************************/


#ifndef SFFTXXX_CAN_IL_CFG_000_H
#define SFFTXXX_CAN_IL_CFG_000_H

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Can_DrvIF_000.h"

/************************************************************************************************/
/* Global Macros                                                                                */
/************************************************************************************************/
#define CANILTX_MAIN_CYCLE (10U) /* 10 msec */
#define CANILRX_MAIN_CYCLE (10U) /* 10 msec */

/* Definitions of invalid value */
#define CANIL_FRAME_FORMAT_INVALID ((UI_8)CANDRVIF_FRAME_FORMAT_INVALID)
#define CANIL_ID_INVALID           ((UI_32)CANDRVIF_ID_INVALID)

/* Definitions of CAN Frame Format */
#define CANIL_CAN_STANDARD_FRAME ((UI_8)CANDRVIF_CAN_STANDARD_FRAME)
#define CANIL_CAN_EXTENDED_FRAME ((UI_8)CANDRVIF_CAN_EXTENDED_FRAME)
#define CANIL_FRAME_FORMAT_CNT   ((UI_8)CANDRVIF_FRAME_FORMAT_CNT)

/* IL Tx Configurations */
#define CANILTX_INIT_STATUS_WITH_START        (1)
#define CANILTX_INIT_MSG_DATA_WITH_START      (1)
#define CANILTX_RESET_CYCLE_AFTER_EVENT       (1)
#define CANILTX_RELOAD_DELAY_CNT_WITH_COMP    (1)
#define CANILTX_CLR_COMP_FLG_EVERY_CYCLE      (1)
#define CANILTX_CLR_COMP_FLG_WITH_SET         (1)
#define CANILTX_CLR_ERR_TIMEOUT_FLG_WITH_COMP (1)
#define CANILTX_USE_ILAPPL_TXPRESEND          (1)

/* IL Rx Configurations */
#define CANILRX_INIT_STATUS_WITH_START        (1)
#define CANILRX_INIT_MSG_DATA_WITH_START      (1)
#define CANILRX_CLR_RCV_FLG_EVERY_CYCLE       (1)
#define CANILRX_CLR_ERR_DLC_FLG_WITH_RCV      (1)
#define CANILRX_CLR_ERR_TIMEOUT_FLG_WITH_RCV  (1)
#define CANILRX_USE_ILAPPL_RXPRECOPY          (1)
#define CANILRX_USE_ILAPPL_MSGIF              (1)
#define CANILRX_USE_ILAPPL_SIGIF              (1)

/* IL message active class */
#define CANIL_MSG_ACT_CLASS_NONE  ((UI_8)0x00U) /* 0000 0000b */
#define CANIL_MSG_ACT_CLASS_ALL   ((UI_8)0xFFU) /* 1111 1111b */
#define CANIL_MSG_ACT_CLASS_USER0 ((UI_8)0x01U) /* 0000 0001b */
#define CANIL_MSG_ACT_CLASS_USER1 ((UI_8)0x02U) /* 0000 0010b */
#define CANIL_MSG_ACT_CLASS_USER2 ((UI_8)0x04U) /* 0000 0100b */
#define CANIL_MSG_ACT_CLASS_USER3 ((UI_8)0x08U) /* 0000 1000b */
#define CANIL_MSG_ACT_CLASS_USER4 ((UI_8)0x10U) /* 0001 0000b */
#define CANIL_MSG_ACT_CLASS_USER5 ((UI_8)0x20U) /* 0010 0000b */
#define CANIL_MSG_ACT_CLASS_USER6 ((UI_8)0x40U) /* 0100 0000b */
#define CANIL_MSG_ACT_CLASS_USER7 ((UI_8)0x80U) /* 1000 0000b */

/* Rx Status definitions - These parameters are used for CanILRx_GetState_{MNAME}(state_mask)/CanILRx_ClrState_{MNAME}(state_mask) */
#define CANILRX_STATE_NONE        ((UI_8)0x00U) /* 0000 0000b */
#define CANILRX_STATE_ALL         ((UI_8)0xFFU) /* 1111 1111b */
#define CANILRX_STATE_FIRST_RCV   ((UI_8)0x01U) /* 0000 0001b */
#define CANILRX_STATE_RCV         ((UI_8)0x02U) /* 0000 0010b */
#define CANILRX_STATE_ERR_DLC     ((UI_8)0x04U) /* 0000 0100b */
#define CANILRX_STATE_ERR_SUM     ((UI_8)0x08U) /* 0000 1000b */
#define CANILRX_STATE_ERR_ALV     ((UI_8)0x10U) /* 0001 0000b */
#define CANILRX_STATE_ERR_TIMEOUT ((UI_8)0x20U) /* 0010 0000b */
#define CANILRX_STATE_USER_01     ((UI_8)0x40U) /* 0100 0000b */
#define CANILRX_STATE_USER_02     ((UI_8)0x80U) /* 1000 0000b */

/* Tx Status definitions - These parameters are used for CanILTx_GetState_{MNAME}(state_mask)/CanILTx_ClrState_{MNAME}(state_mask) */
#define CANILTX_STATE_NONE        ((UI_8)0x00U) /* 0000 0000b */
#define CANILTX_STATE_ALL         ((UI_8)0xFFU) /* 1111 1111b */
#define CANILTX_STATE_FIRST_COMP  ((UI_8)0x01U) /* 0000 0001b */
#define CANILTX_STATE_COMP        ((UI_8)0x02U) /* 0000 0010b */
#define CANILTX_STATE_ERR_TIMEOUT ((UI_8)0x04U) /* 0000 0100b */
#define CANILTX_STATE_CANCELLED   ((UI_8)0x08U) /* 0000 1000b */
#define CANILTX_STATE_USER_01     ((UI_8)0x10U) /* 0001 0000b */
#define CANILTX_STATE_USER_02     ((UI_8)0x20U) /* 0010 0000b */
#define CANILTX_STATE_USER_03     ((UI_8)0x40U) /* 0100 0000b */
#define CANILTX_STATE_USER_04     ((UI_8)0x80U) /* 1000 0000b */

/* Definitions of transmission message/signal identifiers for CAN Interaction Layer. */
/* Tx Message ID */
#define CANILTX_MSG_TX_22E (0U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000022E, DataLen: 2 */
#define CANILTX_MSG_TX_22D (1U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000022D, DataLen: 4 */
#define CANILTX_MSG_TX_240 (2U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000240, DataLen: 1 */
#define CANILTX_MSG_TX_610 (3U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000610, DataLen: 8 */
#define CANILTX_MSG_TX_5A1 (4U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x000005A1, DataLen: 3 */
#define CANILTX_MESSAGE_CNT (5U)

/* Tx Byte Signal ID */
#define CANILTX_BSIG_ID22E_GRIP_WARMER_TEMP			( 0U) /* TxMsgId: CANILTX_MSG_TX_22E, start bit:  4, bit count: 4 */
#define CANILTX_BSIG_ID22E_BUTTON_STATUS			( 1U) /* TxMsgId: CANILTX_MSG_TX_22E, start bit:  0, bit count: 4 */
#define CANILTX_BSIG_ID22E_SELECT_UNIT				( 2U) /* TxMsgId: CANILTX_MSG_TX_22E, start bit:  8, bit count: 8 */
#define CANILTX_BSIG_ID22D_IT_LOG_START				( 3U) /* TxMsgId: CANILTX_MSG_TX_22D, start bit:  7, bit count: 1 */
#define CANILTX_BSIG_ID22D_SELECT_UNIT_ECU_FLAG		( 4U) /* TxMsgId: CANILTX_MSG_TX_22D, start bit:  6, bit count: 1 */
#define CANILTX_BSIG_ID22D_SELECT_UNIT_ME_FLAG		( 5U) /* TxMsgId: CANILTX_MSG_TX_22D, start bit:  5, bit count: 1 */
#define CANILTX_BSIG_ID22D_BUTTON_STATUS			( 6U) /* TxMsgId: CANILTX_MSG_TX_22D, start bit:  0, bit count: 4 */
#define CANILTX_BSIG_ID240_PM_BUTTON_STATUS			( 7U) /* TxMsgId: CANILTX_MSG_TX_240, start bit:  5, bit count: 3 */
#define CANILTX_BSIG_ID240_SUS_MODE_SELECT			( 8U) /* TxMsgId: CANILTX_MSG_TX_240, start bit:  0, bit count: 5 */
#define CANILTX_BSIG_LINE_TEST_DATA0				( 9U) /* TxMsgId: CANILTX_MSG_TX_610, start bit:  0, bit count: 8 */
#define CANILTX_BSIG_LINE_TEST_DATA1				(10U) /* TxMsgId: CANILTX_MSG_TX_610, start bit:  8, bit count: 8 */
#define CANILTX_BSIG_LINE_TEST_DATA2				(11U) /* TxMsgId: CANILTX_MSG_TX_610, start bit: 16, bit count: 8 */
#define CANILTX_BSIG_LINE_TEST_DATA3				(12U) /* TxMsgId: CANILTX_MSG_TX_610, start bit: 24, bit count: 8 */
#define CANILTX_BSIG_LINE_TEST_DATA4				(13U) /* TxMsgId: CANILTX_MSG_TX_610, start bit: 32, bit count: 8 */
#define CANILTX_BSIG_LINE_TEST_DATA5				(14U) /* TxMsgId: CANILTX_MSG_TX_610, start bit: 40, bit count: 8 */
#define CANILTX_BSIG_LINE_TEST_DATA6				(15U) /* TxMsgId: CANILTX_MSG_TX_610, start bit: 48, bit count: 8 */
#define CANILTX_BSIG_LINE_TEST_DATA7				(16U) /* TxMsgId: CANILTX_MSG_TX_610, start bit: 56, bit count: 8 */
#define CANILTX_BSIG_ID5A1_FUNCTION_SW_1			(17U) /* TxMsgId: CANILTX_MSG_TX_5A1, start bit:  7, bit count: 1 */
#define CANILTX_BSIG_ID5A1_FUNCTION_SW_2			(18U) /* TxMsgId: CANILTX_MSG_TX_5A1, start bit:  6, bit count: 1 */
#define CANILTX_BSIG_ID5A1_FUNCTION_SW_3			(19U) /* TxMsgId: CANILTX_MSG_TX_5A1, start bit:  5, bit count: 1 */
#define CANILTX_BSIG_ID5A1_FUNCTION_SW_4			(20U) /* TxMsgId: CANILTX_MSG_TX_5A1, start bit:  4, bit count: 1 */
#define CANILTX_BSIG_ID5A1_FUNCTION_SW_5			(21U) /* TxMsgId: CANILTX_MSG_TX_5A1, start bit:  3, bit count: 1 */
#define CANILTX_BSIG_ID5A1_FUNCTION_SW_6			(22U) /* TxMsgId: CANILTX_MSG_TX_5A1, start bit:  2, bit count: 1 */
#define CANILTX_BSIG_ID5A1_SCREEN_LAYER				(23U) /* TxMsgId: CANILTX_MSG_TX_5A1, start bit: 16, bit count: 1 */
#define CANILTX_BYTE_SIGNAL_CNT (24U)

/* Tx Word Signal ID */
#define CANILTX_WORD_SIGNAL_CNT (0U)

/* Tx Dword Signal ID */
#define CANILTX_DSIG_ID22D_TOTAL_MILEAGE			(0U) /* TxMsgId: CANILTX_MSG_TX_22D, start bit:  24, bit count: 24 */
#define CANILTX_DWORD_SIGNAL_CNT (1U)

/* Tx Message Data Length */
#define CANILTX_DATA_LEN_TX_22E (2U)
#define CANILTX_DATA_LEN_TX_22D (4U)
#define CANILTX_DATA_LEN_TX_240 (1U)
#define CANILTX_DATA_LEN_TX_610 (8U)
#define CANILTX_DATA_LEN_TX_5A1 (3U)

/* Definitions of reception message/signal identifiers for CAN Interaction Layer. */
/* Rx Message ID */
#define CANILRX_MSG_RX_401 ( 0U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000401, DataLen: 8 */
#define CANILRX_MSG_RX_23A ( 1U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000023A, DataLen: 8 */
#define CANILRX_MSG_RX_23E ( 2U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000023E, DataLen: 8 */
#define CANILRX_MSG_RX_209 ( 3U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000209, DataLen: 8 */
#define CANILRX_MSG_RX_215 ( 4U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000215, DataLen: 8 */
#define CANILRX_MSG_RX_22A ( 5U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000022A, DataLen: 8 */
#define CANILRX_MSG_RX_20A ( 6U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000020A, DataLen: 8 */
#define CANILRX_MSG_RX_216 ( 7U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000216, DataLen: 8 */
#define CANILRX_MSG_RX_245 ( 8U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000245, DataLen: 8 */
#define CANILRX_MSG_RX_600 ( 9U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000600, DataLen: 8 */
#define CANILRX_MSG_RX_7DF (10U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x000007DF, DataLen: 8 */
#define CANILRX_MESSAGE_CNT (11U)

/* Rx Byte Signal ID */
#define CANILRX_BSIG_ID401_TX_STOP_ECU				( 0U) /* RxMsgId: CANILRX_MSG_RX_401, start bit:  7, bit count: 1 */
#define CANILRX_BSIG_ID23A_FI_MODE					( 1U) /* RxMsgId: CANILRX_MSG_RX_23A, start bit:  4, bit count: 4 */
#define CANILRX_BSIG_ID23A_FI_WARNING_LAMP_BLINK	( 2U) /* RxMsgId: CANILRX_MSG_RX_23A, start bit:  3, bit count: 1 */
#define CANILRX_BSIG_ID23A_FI_WARNING_LAMP			( 3U) /* RxMsgId: CANILRX_MSG_RX_23A, start bit:  2, bit count: 1 */
#define CANILRX_BSIG_ID23A_DIAG_CYL_N				( 4U) /* RxMsgId: CANILRX_MSG_RX_23A, start bit:  8, bit count: 8 */
#define CANILRX_BSIG_ID23A_CO_DIAG_DATA				( 5U) /* RxMsgId: CANILRX_MSG_RX_23A, start bit: 16, bit count: 8 */
#define CANILRX_BSIG_ID23E_WATER_TEMP				( 6U) /* RxMsgId: CANILRX_MSG_RX_23E, start bit:  0, bit count: 8 */
#define CANILRX_BSIG_ID23E_INTAKE_AIR_TEMP			( 7U) /* RxMsgId: CANILRX_MSG_RX_23E, start bit:  8, bit count: 8 */
#define CANILRX_BSIG_ID209_VH_SPEED_PULSE			( 8U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 16, bit count: 8 */
#define CANILRX_BSIG_ID209_GEAR_POSITION_5			( 9U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 29, bit count: 3 */
#define CANILRX_BSIG_ID209_TC_MODE					(10U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 25, bit count: 4 */
#define CANILRX_BSIG_ID209_START_SW_STATUS			(11U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 24, bit count: 1 */
#define CANILRX_BSIG_ID209_EG_MODE					(12U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 38, bit count: 2 */
#define CANILRX_BSIG_ID209_E_LAMP					(13U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 37, bit count: 1 */
#define CANILRX_BSIG_ID209_TC_INDICATOR				(14U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 35, bit count: 2 */
#define CANILRX_BSIG_ID209_GEAR_POSITION_4			(15U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 32, bit count: 3 */
#define CANILRX_BSIG_ID209_CATION_LAMP				(16U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 44, bit count: 2 */
#define CANILRX_BSIG_ID215_NEUTRAL_FLAG				(17U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 39, bit count: 1 */
#define CANILRX_BSIG_ID215_MODE_FLAG1				(18U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 38, bit count: 1 */
#define CANILRX_BSIG_ID215_MODE_FLAG2				(19U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 37, bit count: 1 */
#define CANILRX_BSIG_ID215_MODE_FLAG3				(20U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 36, bit count: 1 */
#define CANILRX_BSIG_ID215_LAUNCH_MODE				(21U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 34, bit count: 2 */
#define CANILRX_BSIG_ID215_WHEELIE_MODE				(22U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 32, bit count: 2 */
#define CANILRX_BSIG_ID215_SPEEDSHIFT_MODE			(23U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 45, bit count: 3 */
#define CANILRX_BSIG_ID215_SCS_MODE					(24U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 40, bit count: 3 */
#define CANILRX_BSIG_ID215_YSC_FAIL_FLAG			(25U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 55, bit count: 1 */
#define CANILRX_BSIG_ID215_LAUNCH_INDICATOR			(26U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 53, bit count: 2 */
#define CANILRX_BSIG_ID215_TC_MODE					(27U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 49, bit count: 4 */
#define CANILRX_BSIG_ID215_EG_MODE					(28U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 62, bit count: 2 */
#define CANILRX_BSIG_ID22A_CC_SELF_DIAG				(29U) /* RxMsgId: CANILRX_MSG_RX_22A, start bit:  0, bit count: 8 */
#define CANILRX_BSIG_ID22A_CC_MAIN_IND_STATUS		(30U) /* RxMsgId: CANILRX_MSG_RX_22A, start bit: 14, bit count: 2 */
#define CANILRX_BSIG_ID22A_CC_SET_IND_STATUS		(31U) /* RxMsgId: CANILRX_MSG_RX_22A, start bit: 12, bit count: 2 */
#define CANILRX_BSIG_ID22A_MCU_WARNING_LAMP			(32U) /* RxMsgId: CANILRX_MSG_RX_22A, start bit:  8, bit count: 1 */
#define CANILRX_BSIG_ID20A_VH_SPEED_PULSE			(33U) /* RxMsgId: CANILRX_MSG_RX_20A, start bit: 32, bit count: 8 */
#define CANILRX_BSIG_ID20A_START_SW_STATUS			(34U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 63, bit count: 1 */
#define CANILRX_BSIG_ID20A_EG_MODE					(35U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 62, bit count: 2 */
#define CANILRX_BSIG_ID20A_E_LAMP					(36U) /* RxMsgId: CANILRX_MSG_RX_209, start bit: 59, bit count: 1 */
#define CANILRX_BSIG_ID216_TC_MODE					(37U) /* RxMsgId: CANILRX_MSG_RX_216, start bit: 52, bit count: 4 */
#define CANILRX_BSIG_ID216_TC_INDICATOR				(38U) /* RxMsgId: CANILRX_MSG_RX_216, start bit: 50, bit count: 1 */
#define CANILRX_BSIG_ID245_GEAR_POSITION_3			(39U) /* RxMsgId: CANILRX_MSG_RX_245, start bit:  5, bit count: 3 */
#define CANILRX_BSIG_ID245_GRIP_WARMER_STATUS		(40U) /* RxMsgId: CANILRX_MSG_RX_245, start bit:  4, bit count: 1 */
#define CANILRX_BSIG_LINE_TEST_DATA0				(41U) /* RxMsgId: CANILRX_MSG_RX_600, start bit:  0, bit count: 8 */
#define CANILRX_BSIG_LINE_TEST_DATA1				(42U) /* RxMsgId: CANILRX_MSG_RX_600, start bit:  8, bit count: 8 */
#define CANILRX_BSIG_LINE_TEST_DATA2				(43U) /* RxMsgId: CANILRX_MSG_RX_600, start bit: 16, bit count: 8 */
#define CANILRX_BSIG_LINE_TEST_DATA3				(44U) /* RxMsgId: CANILRX_MSG_RX_600, start bit: 24, bit count: 8 */
#define CANILRX_BSIG_LINE_TEST_DATA4				(45U) /* RxMsgId: CANILRX_MSG_RX_600, start bit: 32, bit count: 8 */
#define CANILRX_BSIG_LINE_TEST_DATA5				(46U) /* RxMsgId: CANILRX_MSG_RX_600, start bit: 40, bit count: 8 */
#define CANILRX_BSIG_LINE_TEST_DATA6				(47U) /* RxMsgId: CANILRX_MSG_RX_600, start bit: 48, bit count: 8 */
#define CANILRX_BSIG_LINE_TEST_DATA7				(48U) /* RxMsgId: CANILRX_MSG_RX_600, start bit: 56, bit count: 8 */
#define CANILRX_BSIG_ID7DF_DATA0					(49U) /* RxMsgId: CANILRX_MSG_RX_7DF, start bit:  0, bit count: 8 */
#define CANILRX_BSIG_ID7DF_DATA1					(50U) /* RxMsgId: CANILRX_MSG_RX_7DF, start bit:  8, bit count: 8 */
#define CANILRX_BSIG_ID7DF_DATA2					(51U) /* RxMsgId: CANILRX_MSG_RX_7DF, start bit: 16, bit count: 8 */
#define CANILRX_BSIG_ID7DF_DATA3					(52U) /* RxMsgId: CANILRX_MSG_RX_7DF, start bit: 24, bit count: 8 */
#define CANILRX_BSIG_ID7DF_DATA4					(53U) /* RxMsgId: CANILRX_MSG_RX_7DF, start bit: 32, bit count: 8 */
#define CANILRX_BSIG_ID7DF_DATA5					(54U) /* RxMsgId: CANILRX_MSG_RX_7DF, start bit: 40, bit count: 8 */
#define CANILRX_BSIG_ID7DF_DATA6					(55U) /* RxMsgId: CANILRX_MSG_RX_7DF, start bit: 48, bit count: 8 */
#define CANILRX_BSIG_ID7DF_DATA7					(56U) /* RxMsgId: CANILRX_MSG_RX_7DF, start bit: 56, bit count: 8 */
#define CANILRX_BYTE_SIGNAL_CNT (57U)																					

/* Rx Word Signal ID */
#define CANILRX_WSIG_ID23E_INJECTION				( 0U) /* RxMsgId: CANILRX_MSG_RX_23E, start bit: 24, bit count: 16 */
#define CANILRX_WSIG_ID209_EG_SPEED					( 1U) /* RxMsgId: CANILRX_MSG_RX_209, start bit:  8, bit count: 16 */
#define CANILRX_WSIG_ID215_TPS_ANGLE2				( 2U) /* RxMsgId: CANILRX_MSG_RX_215, start bit:  8, bit count: 16 */
#define CANILRX_WSIG_ID215_APS_ANGLE2				( 3U) /* RxMsgId: CANILRX_MSG_RX_215, start bit: 24, bit count: 16 */
#define CANILRX_WSIG_ID20A_EG_SPEED					( 4U) /* RxMsgId: CANILRX_MSG_RX_20A, start bit: 24, bit count: 16 */
#define CANILRX_WSIG_ID216_APS_ANGLE				( 5U) /* RxMsgId: CANILRX_MSG_RX_216, start bit: 24, bit count: 16 */
#define CANILRX_WORD_SIGNAL_CNT 					( 6U)

/* Rx Dword Signal ID */
#define CANILRX_DWORD_SIGNAL_CNT (0U)

/* Rx Message Data Length */
#define CANILRX_DATA_LEN_RX_401 (8U)
#define CANILRX_DATA_LEN_RX_23A (8U)
#define CANILRX_DATA_LEN_RX_23E (8U)
#define CANILRX_DATA_LEN_RX_209 (8U)
#define CANILRX_DATA_LEN_RX_215 (8U)
#define CANILRX_DATA_LEN_RX_22A (8U)
#define CANILRX_DATA_LEN_RX_20A (8U)
#define CANILRX_DATA_LEN_RX_216 (8U)
#define CANILRX_DATA_LEN_RX_245 (8U)
#define CANILRX_DATA_LEN_RX_600 (8U)
#define CANILRX_DATA_LEN_RX_7DF (8U)

/* Rx Message Min Data Length */
#define CANILRX_MIN_DATA_LEN_RX_401 (1U)
#define CANILRX_MIN_DATA_LEN_RX_23A (3U)
#define CANILRX_MIN_DATA_LEN_RX_23E (4U)
#define CANILRX_MIN_DATA_LEN_RX_209 (6U)
#define CANILRX_MIN_DATA_LEN_RX_215 (8U)
#define CANILRX_MIN_DATA_LEN_RX_22A (2U)
#define CANILRX_MIN_DATA_LEN_RX_20A (8U)
#define CANILRX_MIN_DATA_LEN_RX_216 (7U)
#define CANILRX_MIN_DATA_LEN_RX_245 (1U)
#define CANILRX_MIN_DATA_LEN_RX_600 (8U)
#define CANILRX_MIN_DATA_LEN_RX_7DF (8U)

/************************************************************************************************/
/* Global Data Types                                                                            */
/************************************************************************************************/

/************************************************************************************************/
/* Global Data                                                                                  */
/************************************************************************************************/

/************************************************************************************************/
/* Global Constants                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Callback Functions                                                                            */
/************************************************************************************************/

/************************************************************************************************/
/*                                                                                              */
/* The section below is related to the CAN IL modules.                                          */
/*                                                                                              */
/************************************************************************************************/
#ifdef SSFTSTD_CAN_IL_000_INTERNAL
/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#if ((CANILTX_USE_ILAPPL_TXPRESEND == 1) || (CANILRX_USE_ILAPPL_RXPRECOPY == 1))
#include "SSFTxxx_Can_IL_Appl_000.h"
#endif

/************************************************************************************************/
/* Local Macros                                                                                 */
/************************************************************************************************/
/* Index count for bit flag arrays */
#define CANILTX_BIT_FLG_INDEX_CNT (((UI_16)CANILTX_MESSAGE_CNT / 16U) + 1U)
#define CANILRX_BIT_FLG_INDEX_CNT (((UI_16)CANILRX_MESSAGE_CNT / 16U) + 1U)

/* Timer related definitions */
#define CANILTX_GET_CNT(time) (UI_16)(((time) + (CANILTX_MAIN_CYCLE - 1U)) / CANILTX_MAIN_CYCLE) 
#define CANILRX_GET_CNT(time) (UI_16)(((time) + (CANILRX_MAIN_CYCLE - 1U)) / CANILRX_MAIN_CYCLE) 
#define CANIL_STOP_UPDATE_CNT ((UI_16)0xFFFFU)

/* Internal definitions for event configurations */
#define CANILTX_EVENT_TYPE_EXT  (0x00U)
#define CANILTX_EVENT_TYPE_CHNG (0x01U)
#define CANILTX_EVENT_TYPE_CNT  (0x02U)

/* Internal definitions for controlling transmission behavior. */
#define CANILTX_ACCEPT_NEW_EVENT    (0x01U) /* 0000 0001b */
#define CANILTX_RESTART_EVENT_CYCLE (0x02U) /* 0000 0010b */
#define CANILTX_RESET_EVENT_CNT     (0x04U) /* 0000 0100b */
#define CANILTX_CANCEL_EVENT_REQ    (0x08U) /* 0000 1000b */
#define CANILTX_IGNORE_NEW_EVENT    (0x00U) /* bit CANILTX_ACCEPT_NEW_EVENT is 0 */
#define CANILTX_KEEP_EVENT_CYCLE    (0x00U) /* bit CANILTX_RESTART_EVENT_CYCLE is 0 */
#define CANILTX_ADD_EVENT_CNT       (0x00U) /* bit CANILTX_RESET_EVENT_CNT is 0 */
#define CANILTX_KEEP_EVENT_REQ      (0x00U) /* bit CANILTX_CANCEL_EVENT_REQ is 0 */


/************************************************************************************************/
/* Local Data Types                                                                             */
/************************************************************************************************/
typedef struct
{
	UI_8 BitCnt;
	UI_8 StartBitIndex;
	UI_8 StopBitIndex;
	UI_8 StartByteIndex;
	UI_8 UsedByteCnt;
	UI_8 EndianType;
} T_CanIL_SignalMap;

typedef struct
{
    UI_8 Cnt;
    UI_16 Cycle;
    UI_8 CtrlType;
} T_CanIL_TxEventCfg;

typedef struct
{
	UI_16 TxHandle;
	UI_8 TxMsgActClass;
	UI_8 DataLen;
	UI_8 *DataPtr;
	const UI_8 *InitialDataPtr;
	UI_8 TxDynamic;
	UI_16 TxDelay;
	UI_16 TxTimeout;
	UI_16 TxCycle;
	UI_16 TxCycleDelay;
    const T_CanIL_TxEventCfg TxEventCfg[CANILTX_EVENT_TYPE_CNT];
} T_CanIL_TxMsgCfg;

typedef struct
{
	UI_16 TxMsgId;
	const T_CanIL_SignalMap TxSignalMap;
	UI_8 ChkSignalChng;
} T_CanIL_TxSignalCfg;

typedef struct
{
	UI_16 RxHandle;
	UI_8 RxMsgActClass;
	UI_8 DataLen;
	UI_8 *DataPtr;
	const UI_8 *InitialDataPtr;
	UI_8 MinDataLen;
	UI_16 RxTimeout;
} T_CanIL_RxMsgCfg;

typedef struct
{
	UI_16 RxMsgId;
	const T_CanIL_SignalMap RxSignalMap;
} T_CanIL_RxSignalCfg;


typedef T_CANDRVIF_SIZE_T T_CANIL_SIZE_T;

/************************************************************************************************/
/* Local Data                                                                                   */
/************************************************************************************************/
/* �q�`�l�Q�F�X�^���o�C�������ɏ����������q�`�l */			
#if defined(__RL78_CA78K0R__)									
#pragma section @@DATA RAM2SEC									
#else															
#define START_SEC_RAM2SEC			/* ����݊J�n */				
#include "SSFTSTD_MemoryMap.h"		/* ϯ��̧�ق�include */		
#endif															

/* Tx Message Data */
static UI_8 CanIL_TxData_TX_22E[CANILTX_DATA_LEN_TX_22E];
static UI_8 CanIL_TxData_TX_22D[CANILTX_DATA_LEN_TX_22D];
static UI_8 CanIL_TxData_TX_240[CANILTX_DATA_LEN_TX_240];
static UI_8 CanIL_TxData_TX_610[CANILTX_DATA_LEN_TX_610];
static UI_8 CanIL_TxData_TX_5A1[CANILTX_DATA_LEN_TX_5A1];

/* Rx Message Data */
static UI_8 CanIL_RxData_RX_401[CANILRX_DATA_LEN_RX_401];
static UI_8 CanIL_RxData_RX_23A[CANILRX_DATA_LEN_RX_23A];
static UI_8 CanIL_RxData_RX_23E[CANILRX_DATA_LEN_RX_23E];
static UI_8 CanIL_RxData_RX_209[CANILRX_DATA_LEN_RX_209];
static UI_8 CanIL_RxData_RX_215[CANILRX_DATA_LEN_RX_215];
static UI_8 CanIL_RxData_RX_22A[CANILRX_DATA_LEN_RX_22A];
static UI_8 CanIL_RxData_RX_20A[CANILRX_DATA_LEN_RX_20A];
static UI_8 CanIL_RxData_RX_216[CANILRX_DATA_LEN_RX_216];
static UI_8 CanIL_RxData_RX_245[CANILRX_DATA_LEN_RX_245];
static UI_8 CanIL_RxData_RX_600[CANILRX_DATA_LEN_RX_600];
static UI_8 CanIL_RxData_RX_7DF[CANILRX_DATA_LEN_RX_7DF];

#if defined(__RL78_CA78K0R__)									
#pragma section @@DATA @@DATA									
#else															
#define STOP_SEC_RAM2SEC		/* ����ݏI�� */					
#include "SSFTSTD_MemoryMap.h"		/* ϯ��̧�ق�include */		
#endif															


/************************************************************************************************/
/* Local Constants                                                                              */
/************************************************************************************************/
/* Tx Message Initial Data */
static const UI_8 C_CanIL_TxInitialData_TX_22E[CANILTX_DATA_LEN_TX_22E] = { 0x00U, 0x00U  };
static const UI_8 C_CanIL_TxInitialData_TX_22D[CANILTX_DATA_LEN_TX_22D] = { 0x00U, 0x00U, 0x00U, 0x00U  };
static const UI_8 C_CanIL_TxInitialData_TX_240[CANILTX_DATA_LEN_TX_240] = { 0x00U  };
static const UI_8 C_CanIL_TxInitialData_TX_610[CANILTX_DATA_LEN_TX_610] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_TxInitialData_TX_5A1[CANILTX_DATA_LEN_TX_5A1] = { 0x00U, 0x00U, 0x00U};

/* Rx Message Initial Data */
static const UI_8 C_CanIL_RxInitialData_RX_401[CANILRX_DATA_LEN_RX_401] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_23A[CANILRX_DATA_LEN_RX_23A] = { 0x00U, 0x00U, 0xFFU, 0xFFU, 0x00U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_23E[CANILRX_DATA_LEN_RX_23E] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_209[CANILRX_DATA_LEN_RX_209] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x07U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_215[CANILRX_DATA_LEN_RX_215] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x01U, 0x21U, 0x02U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_22A[CANILRX_DATA_LEN_RX_22A] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_20A[CANILRX_DATA_LEN_RX_20A] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_216[CANILRX_DATA_LEN_RX_216] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_245[CANILRX_DATA_LEN_RX_245] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_600[CANILRX_DATA_LEN_RX_600] = { 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U };
static const UI_8 C_CanIL_RxInitialData_RX_7DF[CANILRX_DATA_LEN_RX_7DF] = { 0xE0U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U };

/* TxMsgCfg */
static const T_CanIL_TxMsgCfg C_CanIL_TxMsgCfg[CANILTX_MESSAGE_CNT + 1U] =
{
	/* CANILTX_MSG_TX_22E */
	{
		/* TxHandle */
		CANDRVIFTX_HND_22E,
		/* TxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILTX_DATA_LEN_TX_22E,
		/* DataPtr */
		CanIL_TxData_TX_22E,
		/* InitialDataPtr */
		C_CanIL_TxInitialData_TX_22E,
		/* TxDynamic */
		D_FALSE,
		/* TxDelay */
		CANILTX_GET_CNT(0U),
		/* TxTimeout */
		CANILTX_GET_CNT(200U),
		/* TxCycle */
		CANILTX_GET_CNT(100U),
		/* TxCycleDelay */
		CANILTX_GET_CNT(0U),
		/* TxEventCfg */
		{
			/* CANILTX_EVENT_TYPE_EXT : Disabled */
			{
				/* Cnt */
				0U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ  
				),
			},
			/* CANILTX_EVENT_TYPE_CHNG : Disabled */
			{
				/* Cnt */
				0U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ  
				),
			}
		},
	},
	/* CANILTX_MSG_TX_22D */
	{
		/* TxHandle */
		CANDRVIFTX_HND_22D,
		/* TxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILTX_DATA_LEN_TX_22D,
		/* DataPtr */
		CanIL_TxData_TX_22D,
		/* InitialDataPtr */
		C_CanIL_TxInitialData_TX_22D,
		/* TxDynamic */
		D_FALSE,
		/* TxDelay */
		CANILTX_GET_CNT(0U),
		/* TxTimeout */
		CANILTX_GET_CNT(200U),
		/* TxCycle */
		CANILTX_GET_CNT(100U),
		/* TxCycleDelay */
		CANILTX_GET_CNT(0U),
		/* TxEventCfg */
		{
			/* CANILTX_EVENT_TYPE_EXT : Disabled */
			{
				/* Cnt */
				0U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ  
				),
			},
			/* CANILTX_EVENT_TYPE_CHNG : Disabled */
			{
				/* Cnt */
				0U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ  
				),
			}
		},
	},
	/* CANILTX_MSG_TX_240 */
	{
		/* TxHandle */
		CANDRVIFTX_HND_240,
		/* TxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILTX_DATA_LEN_TX_240,
		/* DataPtr */
		CanIL_TxData_TX_240,
		/* InitialDataPtr */
		C_CanIL_TxInitialData_TX_240,
		/* TxDynamic */
		D_FALSE,
		/* TxDelay */
		CANILTX_GET_CNT(0U),
		/* TxTimeout */
		CANILTX_GET_CNT(200U),
		/* TxCycle */
		CANILTX_GET_CNT(10U),
		/* TxCycleDelay */
		CANILTX_GET_CNT(0U),
		/* TxEventCfg */
		{
			/* CANILTX_EVENT_TYPE_EXT : Disabled */
			{
				/* Cnt */
				0U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ  
				),
			},
			/* CANILTX_EVENT_TYPE_CHNG : Disabled */
			{
				/* Cnt */
				0U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ  
				),
			}
		},
	},
	/* CANILTX_MSG_TX_610 */
	{
		/* TxHandle */
		CANDRVIFTX_HND_610,
		/* TxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILTX_DATA_LEN_TX_610,
		/* DataPtr */
		CanIL_TxData_TX_610,
		/* InitialDataPtr */
		C_CanIL_TxInitialData_TX_610,
		/* TxDynamic */
		D_FALSE,
		/* TxDelay */
		CANILTX_GET_CNT(0U),
		/* TxTimeout */
		CANILTX_GET_CNT(200U),
		/* TxCycle */
		CANIL_STOP_UPDATE_CNT,
		/* TxCycleDelay */
		CANILTX_GET_CNT(0U),
		/* TxEventCfg */
		{
			/* CANILTX_EVENT_TYPE_EXT : Enabled */
			{
				/* Cnt */
				1U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ   /* ('CANILTX_KEEP_EVENT_REQ' is fixed because an External Event does not have this flag.) */
				),
			},
			/* CANILTX_EVENT_TYPE_CHNG : Disabled */
			{
				/* Cnt */
				0U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ  
				),
			}
		},
	},
	/* CANILTX_MSG_TX_5A1 */
	{
		/* TxHandle */
		CANDRVIFTX_HND_5A1,
		/* TxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILTX_DATA_LEN_TX_5A1,
		/* DataPtr */
		CanIL_TxData_TX_5A1,
		/* InitialDataPtr */
		C_CanIL_TxInitialData_TX_5A1,
		/* TxDynamic */
		D_FALSE,
		/* TxDelay */
		CANILTX_GET_CNT(0U),
		/* TxTimeout */
		CANILTX_GET_CNT(200U),
		/* TxCycle */
		CANILTX_GET_CNT(10U),
		/* TxCycleDelay */
		CANILTX_GET_CNT(0U),
		/* TxEventCfg */
		{
			/* CANILTX_EVENT_TYPE_EXT : Disabled */
			{
				/* Cnt */
				0U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ  
				),
			},
			/* CANILTX_EVENT_TYPE_CHNG : Disabled */
			{
				/* Cnt */
				0U,
				/* Cycle */
				CANILTX_GET_CNT(0U),
				/* CtrlType */
				(
					CANILTX_IGNORE_NEW_EVENT |
					CANILTX_KEEP_EVENT_CYCLE |
					CANILTX_ADD_EVENT_CNT    |
					CANILTX_KEEP_EVENT_REQ  
				),
			}
		},
	},

	/* dummy */ {0}
};

/* TxSignalCfg - Byte */
static const T_CanIL_TxSignalCfg C_CanIL_TxByteSignalCfg[CANILTX_BYTE_SIGNAL_CNT + 1U] =
/* TxMsgId, TxSignalMap(BitCnt, StartBitIndex, StopBitIndex, StartByteIndex, UsedByteCnt, EndianType(0: little/ 1: big)), SignalChangeEvent */
{
	/* CANILTX_BSIG_ID22E_GRIP_WARMER_TEMP			*/ { CANILTX_MSG_TX_22E, { 4U, 4U, 7U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID22E_BUTTON_STATUS				*/ { CANILTX_MSG_TX_22E, { 4U, 0U, 3U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID22E_SELECT_UNIT				*/ { CANILTX_MSG_TX_22E, { 8U, 0U, 7U, 1U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID22D_IT_LOG_START				*/ { CANILTX_MSG_TX_22D, { 1U, 7U, 7U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID22D_SELECT_UNIT_ECU_FLAG		*/ { CANILTX_MSG_TX_22D, { 1U, 6U, 6U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID22D_SELECT_UNIT_ME_FLAG		*/ { CANILTX_MSG_TX_22D, { 1U, 5U, 5U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID22D_BUTTON_STATUS				*/ { CANILTX_MSG_TX_22D, { 4U, 0U, 3U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID240_PM_BUTTON_STATUS			*/ { CANILTX_MSG_TX_240, { 3U, 5U, 7U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID240_SUS_MODE_SELECT			*/ { CANILTX_MSG_TX_240, { 5U, 0U, 4U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_LINE_TEST_DATA0					*/ { CANILTX_MSG_TX_610, { 8U, 0U, 7U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_LINE_TEST_DATA1					*/ { CANILTX_MSG_TX_610, { 8U, 0U, 7U, 1U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_LINE_TEST_DATA2					*/ { CANILTX_MSG_TX_610, { 8U, 0U, 7U, 2U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_LINE_TEST_DATA3					*/ { CANILTX_MSG_TX_610, { 8U, 0U, 7U, 3U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_LINE_TEST_DATA4					*/ { CANILTX_MSG_TX_610, { 8U, 0U, 7U, 4U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_LINE_TEST_DATA5					*/ { CANILTX_MSG_TX_610, { 8U, 0U, 7U, 5U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_LINE_TEST_DATA6					*/ { CANILTX_MSG_TX_610, { 8U, 0U, 7U, 6U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_LINE_TEST_DATA7					*/ { CANILTX_MSG_TX_610, { 8U, 0U, 7U, 7U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID5A1_FUNCTION_SW_1				*/ { CANILTX_MSG_TX_5A1, { 1U, 7U, 7U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID5A1_FUNCTION_SW_2				*/ { CANILTX_MSG_TX_5A1, { 1U, 6U, 6U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID5A1_FUNCTION_SW_3				*/ { CANILTX_MSG_TX_5A1, { 1U, 5U, 5U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID5A1_FUNCTION_SW_4				*/ { CANILTX_MSG_TX_5A1, { 1U, 4U, 4U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID5A1_FUNCTION_SW_5				*/ { CANILTX_MSG_TX_5A1, { 1U, 3U, 3U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID5A1_FUNCTION_SW_6				*/ { CANILTX_MSG_TX_5A1, { 1U, 2U, 2U, 0U, 1U, 1U }, D_TRUE },
	/* CANILTX_BSIG_ID5A1_SCREEN_LAYER				*/ { CANILTX_MSG_TX_5A1, { 1U, 0U, 0U, 2U, 1U, 1U }, D_TRUE },

	/* dummy */ {0}
};

/* TxSignalCfg - Word */
static const T_CanIL_TxSignalCfg C_CanIL_TxWordSignalCfg[CANILTX_WORD_SIGNAL_CNT + 1U] =
/* TxMsgId, TxSignalMap(BitCnt, StartBitIndex, StopBitIndex, StartByteIndex, UsedByteCnt, EndianType(0: little/ 1: big)), SignalChangeEvent */
{

	/* dummy */ {0}
};

/* TxSignalCfg - Dword */
static const T_CanIL_TxSignalCfg C_CanIL_TxDwordSignalCfg[CANILTX_DWORD_SIGNAL_CNT + 1U] =
/* TxMsgId, TxSignalMap(BitCnt, StartBitIndex, StopBitIndex, StartByteIndex, UsedByteCnt, EndianType(0: little/ 1: big)), SignalChangeEvent */
{
	/* CANILTX_DSIG_TOTAL_MILEAGE                 */ { CANILTX_MSG_TX_22D, {24U, 0U, 7U, 3U, 3U, 1U },  },

	/* dummy */ {0}
};

/* RxMsgCfg */
static const T_CanIL_RxMsgCfg C_CanIL_RxMsgCfg[CANILRX_MESSAGE_CNT + 1U] =
{
	/* CANILRX_MSG_RX_401 */
	{
		/* RxHandle */
		CANDRVIFRX_HND_401,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_401,
		/* DataPtr */
		CanIL_RxData_RX_401,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_401,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_401,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_23A */
	{
		/* RxHandle */
		CANDRVIFRX_HND_23A,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_23A,
		/* DataPtr */
		CanIL_RxData_RX_23A,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_23A,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_23A,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_23E */
	{
		/* RxHandle */
		CANDRVIFRX_HND_23E,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_23E,
		/* DataPtr */
		CanIL_RxData_RX_23E,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_23E,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_23E,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_209 */
	{
		/* RxHandle */
		CANDRVIFRX_HND_209,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_209,
		/* DataPtr */
		CanIL_RxData_RX_209,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_209,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_209,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_215 */
	{
		/* RxHandle */
		CANDRVIFRX_HND_215,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_215,
		/* DataPtr */
		CanIL_RxData_RX_215,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_215,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_215,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_22A */
	{
		/* RxHandle */
		CANDRVIFRX_HND_22A,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_22A,
		/* DataPtr */
		CanIL_RxData_RX_22A,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_22A,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_22A,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_20A */
	{
		/* RxHandle */
		CANDRVIFRX_HND_20A,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_20A,
		/* DataPtr */
		CanIL_RxData_RX_20A,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_20A,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_20A,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_216 */
	{
		/* RxHandle */
		CANDRVIFRX_HND_216,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_216,
		/* DataPtr */
		CanIL_RxData_RX_216,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_216,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_216,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_245 */
	{
		/* RxHandle */
		CANDRVIFRX_HND_245,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_245,
		/* DataPtr */
		CanIL_RxData_RX_245,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_245,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_245,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_600 */
	{
		/* RxHandle */
		CANDRVIFRX_HND_600,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_600,
		/* DataPtr */
		CanIL_RxData_RX_600,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_600,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_600,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* CANILRX_MSG_RX_7DF */
	{
		/* RxHandle */
		CANDRVIFRX_HND_7DF,
		/* RxMsgActClass */
		CANIL_MSG_ACT_CLASS_USER0,
		/* DataLen */
		CANILRX_DATA_LEN_RX_7DF,
		/* DataPtr */
		CanIL_RxData_RX_7DF,
		/* InitialDataPtr */
		C_CanIL_RxInitialData_RX_7DF,
		/* MinDataLen */
		CANILRX_MIN_DATA_LEN_RX_7DF,
		/* RxTimeout */
		CANIL_STOP_UPDATE_CNT,
	},
	/* dummy */ {0}
};

/* RxSignalCfg - Byte */
static const T_CanIL_RxSignalCfg C_CanIL_RxByteSignalCfg[CANILRX_BYTE_SIGNAL_CNT + 1U] =
/* RxMsgId, RxSignalMap(BitCnt, StartBitIndex, StopBitIndex, StartByteIndex, UsedByteCnt, EndianType(0: little/ 1: big)) */
{
	/* CANILRX_BSIG_ID401_TX_STOP_ECU				*/ { CANILRX_MSG_RX_401, { 1U, 7U, 7U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_ID23A_FI_MODE					*/ { CANILRX_MSG_RX_23A, { 4U, 3U, 7U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_ID23A_FI_WARNING_LAMP_BLINK		*/ { CANILRX_MSG_RX_23A, { 1U, 3U, 3U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_ID23A_FI_WARNING_LAMP			*/ { CANILRX_MSG_RX_23A, { 1U, 2U, 2U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_ID23A_DIAG_CYL_N				*/ { CANILRX_MSG_RX_23A, { 8U, 0U, 7U, 1U, 1U, 1U } },
	/* CANILRX_BSIG_ID23A_CO_DIAG_DATA				*/ { CANILRX_MSG_RX_23A, { 8U, 0U, 7U, 2U, 1U, 1U } },
	/* CANILRX_BSIG_ID23E_WATER_TEMP				*/ { CANILRX_MSG_RX_23E, { 8U, 0U, 7U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_ID23E_INTAKE_AIR_TEMP			*/ { CANILRX_MSG_RX_23E, { 8U, 0U, 7U, 1U, 1U, 1U } },
	/* CANILRX_BSIG_ID209_VH_SPEED_PULSE			*/ { CANILRX_MSG_RX_209, { 8U, 0U, 7U, 2U, 1U, 1U } },
	/* CANILRX_BSIG_ID209_GEAR_POSITION_5			*/ { CANILRX_MSG_RX_209, { 3U, 5U, 7U, 3U, 1U, 1U } },
	/* CANILRX_BSIG_ID209_TC_MODE					*/ { CANILRX_MSG_RX_209, { 4U, 1U, 4U, 3U, 1U, 1U } },
	/* CANILRX_BSIG_ID209_START_SW_STATUS			*/ { CANILRX_MSG_RX_209, { 1U, 0U, 0U, 3U, 1U, 1U } },
	/* CANILRX_BSIG_ID209_EG_MODE					*/ { CANILRX_MSG_RX_209, { 2U, 6U, 7U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID209_E_LAMP					*/ { CANILRX_MSG_RX_209, { 1U, 5U, 5U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID209_TC_INDICATOR				*/ { CANILRX_MSG_RX_209, { 2U, 3U, 4U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID209_GEAR_POSITION_4			*/ { CANILRX_MSG_RX_209, { 3U, 0U, 2U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID209_CATION_LAMP				*/ { CANILRX_MSG_RX_209, { 2U, 4U, 5U, 5U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_NEUTRAL_FLAG				*/ { CANILRX_MSG_RX_215, { 1U, 7U, 7U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_MODE_FLAG1				*/ { CANILRX_MSG_RX_215, { 1U, 6U, 6U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_MODE_FLAG2				*/ { CANILRX_MSG_RX_215, { 1U, 5U, 5U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_MODE_FLAG3				*/ { CANILRX_MSG_RX_215, { 1U, 4U, 4U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_LAUNCH_MODE				*/ { CANILRX_MSG_RX_215, { 2U, 2U, 3U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_WHEELIE_MODE				*/ { CANILRX_MSG_RX_215, { 2U, 0U, 1U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_SPEEDSHIFT_MODE			*/ { CANILRX_MSG_RX_215, { 3U, 5U, 7U, 5U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_SCS_MODE					*/ { CANILRX_MSG_RX_215, { 3U, 0U, 2U, 5U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_YSC_FAIL_FLAG				*/ { CANILRX_MSG_RX_215, { 1U, 7U, 7U, 6U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_LAUNCH_INDICATOR			*/ { CANILRX_MSG_RX_215, { 2U, 5U, 6U, 6U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_TC_MODE					*/ { CANILRX_MSG_RX_215, { 4U, 1U, 4U, 6U, 1U, 1U } },
	/* CANILRX_BSIG_ID215_EG_MODE					*/ { CANILRX_MSG_RX_215, { 2U, 6U, 7U, 7U, 1U, 1U } },
	/* CANILRX_BSIG_ID22A_CC_SELF_DIAG				*/ { CANILRX_MSG_RX_22A, { 8U, 0U, 7U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_ID22A_CC_MAIN_IND_STATUS		*/ { CANILRX_MSG_RX_22A, { 2U, 6U, 7U, 1U, 1U, 1U } },
	/* CANILRX_BSIG_ID22A_CC_SET_IND_STATUS			*/ { CANILRX_MSG_RX_22A, { 2U, 5U, 5U, 1U, 1U, 1U } },
	/* CANILRX_BSIG_ID22A_MCU_WARNING_LAMP			*/ { CANILRX_MSG_RX_22A, { 1U, 0U, 0U, 1U, 1U, 1U } },
	/* CANILRX_BSIG_ID20A_VH_SPEED_PULSE			*/ { CANILRX_MSG_RX_20A, { 8U, 0U, 7U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID20A_START_SW_STATUS			*/ { CANILRX_MSG_RX_209, { 1U, 7U, 7U, 7U, 1U, 1U } },
	/* CANILRX_BSIG_ID20A_EG_MODE					*/ { CANILRX_MSG_RX_209, { 2U, 5U, 6U, 7U, 1U, 1U } },
	/* CANILRX_BSIG_ID20A_E_LAMP					*/ { CANILRX_MSG_RX_209, { 1U, 3U, 3U, 7U, 1U, 1U } },
	/* CANILRX_BSIG_ID216_TC_MODE					*/ { CANILRX_MSG_RX_216, { 4U, 4U, 7U, 6U, 1U, 1U } },
	/* CANILRX_BSIG_ID216_TC_INDICATOR				*/ { CANILRX_MSG_RX_216, { 2U, 2U, 3U, 6U, 1U, 1U } },
	/* CANILRX_BSIG_ID245_GEAR_POSITION_3			*/ { CANILRX_MSG_RX_245, { 3U, 5U, 7U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_ID245_GRIP_WARMER_STATUS		*/ { CANILRX_MSG_RX_245, { 1U, 4U, 4U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_LINE_TEST_DATA0					*/ { CANILRX_MSG_RX_600, { 8U, 0U, 7U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_LINE_TEST_DATA1					*/ { CANILRX_MSG_RX_600, { 8U, 0U, 7U, 1U, 1U, 1U } },
	/* CANILRX_BSIG_LINE_TEST_DATA2					*/ { CANILRX_MSG_RX_600, { 8U, 0U, 7U, 2U, 1U, 1U } },
	/* CANILRX_BSIG_LINE_TEST_DATA3					*/ { CANILRX_MSG_RX_600, { 8U, 0U, 7U, 3U, 1U, 1U } },
	/* CANILRX_BSIG_LINE_TEST_DATA4					*/ { CANILRX_MSG_RX_600, { 8U, 0U, 7U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_LINE_TEST_DATA5					*/ { CANILRX_MSG_RX_600, { 8U, 0U, 7U, 5U, 1U, 1U } },
	/* CANILRX_BSIG_LINE_TEST_DATA6					*/ { CANILRX_MSG_RX_600, { 8U, 0U, 7U, 6U, 1U, 1U } },
	/* CANILRX_BSIG_LINE_TEST_DATA7					*/ { CANILRX_MSG_RX_600, { 8U, 0U, 7U, 7U, 1U, 1U } },
	/* CANILRX_BSIG_ID7DF_DATA0						*/ { CANILRX_MSG_RX_7DF, { 8U, 0U, 7U, 0U, 1U, 1U } },
	/* CANILRX_BSIG_ID7DF_DATA1						*/ { CANILRX_MSG_RX_7DF, { 8U, 0U, 7U, 1U, 1U, 1U } },
	/* CANILRX_BSIG_ID7DF_DATA2						*/ { CANILRX_MSG_RX_7DF, { 8U, 0U, 7U, 2U, 1U, 1U } },
	/* CANILRX_BSIG_ID7DF_DATA3						*/ { CANILRX_MSG_RX_7DF, { 8U, 0U, 7U, 3U, 1U, 1U } },
	/* CANILRX_BSIG_ID7DF_DATA4						*/ { CANILRX_MSG_RX_7DF, { 8U, 0U, 7U, 4U, 1U, 1U } },
	/* CANILRX_BSIG_ID7DF_DATA5						*/ { CANILRX_MSG_RX_7DF, { 8U, 0U, 7U, 5U, 1U, 1U } },
	/* CANILRX_BSIG_ID7DF_DATA6						*/ { CANILRX_MSG_RX_7DF, { 8U, 0U, 7U, 6U, 1U, 1U } },
	/* CANILRX_BSIG_ID7DF_DATA7						*/ { CANILRX_MSG_RX_7DF, { 8U, 0U, 7U, 7U, 1U, 1U } },

	/* dummy */ {0}
};

/* RxSignalCfg - Word */
static const T_CanIL_RxSignalCfg C_CanIL_RxWordSignalCfg[CANILRX_WORD_SIGNAL_CNT + 1U] =
/* RxMsgId, RxSignalMap(BitCnt, StartBitIndex, StopBitIndex, StartByteIndex, UsedByteCnt, EndianType(0: little/ 1: big)) */
{
	/* CANILRX_WSIG_ID23E_INJECTION					*/ { CANILRX_MSG_RX_23E, { 16U, 0U, 7U, 3U, 2U, 1U } },
	/* CANILRX_WSIG_ID209_EG_SPEED					*/ { CANILRX_MSG_RX_209, { 16U, 0U, 7U, 1U, 2U, 1U } },
	/* CANILRX_WSIG_ID215_TPS_ANGLE2				*/ { CANILRX_MSG_RX_215, { 16U, 0U, 7U, 1U, 2U, 1U } },
	/* CANILRX_WSIG_ID215_APS_ANGLE2				*/ { CANILRX_MSG_RX_215, { 16U, 0U, 7U, 3U, 2U, 1U } },
	/* CANILRX_WSIG_ID20A_EG_SPEED					*/ { CANILRX_MSG_RX_20A, { 16U, 0U, 7U, 3U, 2U, 1U } },
	/* CANILRX_WSIG_ID216_APS_ANGLE					*/ { CANILRX_MSG_RX_216, { 16U, 0U, 7U, 3U, 2U, 1U } },

	/* dummy */ {0}
};

/* RxSignalCfg - Dword */
static const T_CanIL_RxSignalCfg C_CanIL_RxDwordSignalCfg[CANILRX_DWORD_SIGNAL_CNT + 1U] =
/* RxMsgId, RxSignalMap(BitCnt, StartBitIndex, StopBitIndex, StartByteIndex, UsedByteCnt, EndianType(0: little/ 1: big)) */
{

	/* dummy */ {0}
};

#endif /* SSFTSTD_CAN_IL_000_INTERNAL */

#endif /* SFFTXXX_CAN_IL_CFG_000_H */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/

