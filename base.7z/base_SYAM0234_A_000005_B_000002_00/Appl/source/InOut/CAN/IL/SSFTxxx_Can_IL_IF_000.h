/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFT                                                                      */
/*----------------------------------------------------------------------------------------------*/
/* CPU              : -                                                                         */
/* Date             : 26 Feb. 2019                                                              */
/*----------------------------------------------------------------------------------------------*/
/* Programmed by    : PF1                                                                       */
/* Copyrights       : Nippon Seiki Co., Ltd.                                                    */
/*----------------------------------------------------------------------------------------------*/
/* Powered by       : CAN Configuration File Generator (0.8.0.0)                                */
/************************************************************************************************/


#ifndef SSFTXXX_CAN_IL_IF_000_H
#define SSFTXXX_CAN_IL_IF_000_H

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Can_IL_000.h"
#include "SSFTxxx_Can_IL_Appl_000.h"


/*
------------------------------------------------------------------------------------------------------------------------------------------------------
FCAN
------------------------------------------------------------------------------------------------------------------------------------------------------

[TX]
TX_22E (CAN_Standard: 0x0000022E)
------------------------------------------------------------------------------------------------------------------------
	ID22E_GRIP_WARMER_TEMP			: Startbit  4 | Length [Bit]  4 | Big Endian
	ID22E_BUTTON_STATUS				: Startbit  0 | Length [Bit]  4 | Big Endian
	ID22E_SELECT_UNIT				: Startbit  8 | Length [Bit]  8 | Big Endian

TX_22D (CAN_Standard: 0x0000022D)
------------------------------------------------------------------------------------------------------------------------
	ID22D_IT_LOG_START				: Startbit  7 | Length [Bit]  1 | Big Endian
	ID22D_SELECT_UNIT_ECU_FLAG		: Startbit  6 | Length [Bit]  1 | Big Endian
	ID22D_SELECT_UNIT_ME_FLAG		: Startbit  5 | Length [Bit]  1 | Big Endian
	ID22D_BUTTON_STATUS				: Startbit  0 | Length [Bit]  4 | Big Endian
	ID22D_TOTAL_MILEAGE				: Startbit 24 | Length [Bit] 24 | Big Endian

TX_240 (CAN_Standard: 0x00000240)
------------------------------------------------------------------------------------------------------------------------
	ID240_PM_BUTTON_STATUS			: Startbit  5 | Length [Bit]  3 | Big Endian
	ID240_SUS_MODE_SELECT			: Startbit  0 | Length [Bit]  5 | Big Endian

TX_5A1 (CAN_Standard: 0x000005A1)
------------------------------------------------------------------------------------------------------------------------
	ID5A1_FUNCTION_SW_1				: Startbit  7 | Length [Bit]  1 | Big Endian
	ID5A1_FUNCTION_SW_2				: Startbit  6 | Length [Bit]  1 | Big Endian
	ID5A1_FUNCTION_SW_3				: Startbit  5 | Length [Bit]  1 | Big Endian
	ID5A1_FUNCTION_SW_4				: Startbit  4 | Length [Bit]  1 | Big Endian
	ID5A1_FUNCTION_SW_5				: Startbit  3 | Length [Bit]  1 | Big Endian
	ID5A1_FUNCTION_SW_6				: Startbit  2 | Length [Bit]  1 | Big Endian
	ID5A1_SCREEN_LAYER				: Startbit 16 | Length [Bit]  1 | Big Endian


[RX]
RX_401 (CAN_Standard: 0x00000401)
------------------------------------------------------------------------------------------------------------------------
	ID401_TX_STOP_ECU : Startbit 7 | Length [Bit] 1 | Big Endian

RX_23A (CAN_Standard: 0x0000023A)
------------------------------------------------------------------------------------------------------------------------
	ID23A_FI_MODE					: Startbit  4 | Length [Bit]  4 | Big Endian
	ID23A_FI_WARNING_LAMP_BLINK		: Startbit  3 | Length [Bit]  1 | Big Endian
	ID23A_FI_WARNING_LAMP			: Startbit  2 | Length [Bit]  1 | Big Endian
	ID23A_DIAG_CYL_N				: Startbit  8 | Length [Bit]  8 | Big Endian
	ID23A_CO_DIAG_DATA				: Startbit 16 | Length [Bit]  8 | Big Endian

RX_23E (CAN_Standard: 0x0000023E)
------------------------------------------------------------------------------------------------------------------------
	ID23E_WATER_TEMP				: Startbit  0 | Length [Bit]  8 | Big Endian
	ID23E_INTAKE_AIR_TEMP			: Startbit  8 | Length [Bit]  8 | Big Endian
	ID23E_INJECTION					: Startbit 24 | Length [Bit] 16 | Big Endian

RX_209 (CAN_Standard: 0x00000209)
------------------------------------------------------------------------------------------------------------------------
	ID209_EG_SPEED					: Startbit  8 | Length [Bit] 16 | Big Endian
	ID209_VH_SPEED_PULSE			: Startbit 16 | Length [Bit]  8 | Big Endian
	ID209_GEAR_POSITION_5			: Startbit 29 | Length [Bit]  3 | Big Endian
	ID209_TC_MODE					: Startbit 25 | Length [Bit]  4 | Big Endian
	ID209_START_SW_STATUS			: Startbit 24 | Length [Bit]  1 | Big Endian
	ID209_EG_MODE					: Startbit 38 | Length [Bit]  2 | Big Endian
	ID209_E_LAMP					: Startbit 37 | Length [Bit]  1 | Big Endian
	ID209_TC_INDICATOR				: Startbit 35 | Length [Bit]  2 | Big Endian
	ID209_GEAR_POSITION_4			: Startbit 32 | Length [Bit]  3 | Big Endian
	ID209_CATION_LAMP				: Startbit 44 | Length [Bit]  2 | Big Endian

RX_215 (CAN_Standard: 0x00000215)
------------------------------------------------------------------------------------------------------------------------
	ID215_TPS_ANGLE2				: Startbit  8 | Length [Bit] 16 | Big Endian
	ID215_APS_ANGLE2				: Startbit 24 | Length [Bit] 16 | Big Endian
	ID215_NEUTRAL_FLAG				: Startbit 39 | Length [Bit]  1 | Big Endian
	ID215_MODE_FLAG1				: Startbit 38 | Length [Bit]  1 | Big Endian
	ID215_MODE_FLAG2				: Startbit 37 | Length [Bit]  1 | Big Endian
	ID215_MODE_FLAG3				: Startbit 36 | Length [Bit]  1 | Big Endian
	ID215_LAUNCH_MODE				: Startbit 34 | Length [Bit]  2 | Big Endian
	ID215_WHEELIE_MODE				: Startbit 32 | Length [Bit]  2 | Big Endian
	ID215_SPEEDSHIFT_MODE			: Startbit 45 | Length [Bit]  3 | Big Endian
	ID215_SCS_MODE					: Startbit 40 | Length [Bit]  3 | Big Endian
	ID215_YSC_FAIL_FLAG				: Startbit 55 | Length [Bit]  1 | Big Endian
	ID215_LAUNCH_INDICATOR			: Startbit 53 | Length [Bit]  2 | Big Endian
	ID215_TC_MODE					: Startbit 49 | Length [Bit]  4 | Big Endian
	ID215_EG_MODE					: Startbit 62 | Length [Bit]  2 | Big Endian

RX_22A (CAN_Standard: 0x0000022A)
------------------------------------------------------------------------------------------------------------------------
	ID22A_CC_SELF_DIAG				: Startbit  0 | Length [Bit]  8 | Big Endian
	ID22A_CC_MAIN_IND_STATUS		: Startbit 14 | Length [Bit]  2 | Big Endian
	ID22A_CC_SET_IND_STATUS			: Startbit 12 | Length [Bit]  2 | Big Endian
	ID22A_MCU_WARNING_LAMP			: Startbit  8 | Length [Bit]  1 | Big Endian

RX_20A (CAN_Standard: 0x0000020A)
------------------------------------------------------------------------------------------------------------------------
	ID20A_EG_SPEED					: Startbit 24 | Length [Bit] 16 | Big Endian
	ID20A_VH_SPEED_PULSE			: Startbit 32 | Length [Bit]  8 | Big Endian
	ID20A_START_SW_STATUS			: Startbit 63 | Length [Bit]  1 | Big Endian
	ID20A_EG_MODE					: Startbit 62 | Length [Bit]  2 | Big Endian
	ID20A_E_LAMP					: Startbit 59 | Length [Bit]  1 | Big Endian

RX_216 (CAN_Standard: 0x00000216)
------------------------------------------------------------------------------------------------------------------------
	ID216_APS_ANGLE					: Startbit 24 | Length [Bit] 16 | Big Endian
	ID216_TC_MODE					: Startbit 52 | Length [Bit]  4 | Big Endian
	ID216_TC_INDICATOR				: Startbit 50 | Length [Bit]  1 | Big Endian

RX_216 (CAN_Standard: 0x00000216)
------------------------------------------------------------------------------------------------------------------------
	ID245_GEAR_POSITION_3			: Startbit  5 | Length [Bit]  3 | Big Endian
	ID245_GRIP_WARMER_STATUS		: Startbit  4 | Length [Bit]  1 | Big Endian

RX_600 (CAN_Standard: 0x00000600)
------------------------------------------------------------------------------------------------------------------------
	LINE_TEST_DATA0					: Startbit  0 | Length [Bit] 8 | Big Endian
	LINE_TEST_DATA1					: Startbit  8 | Length [Bit] 8 | Big Endian
	LINE_TEST_DATA2					: Startbit 16 | Length [Bit] 8 | Big Endian
	LINE_TEST_DATA3					: Startbit 24 | Length [Bit] 8 | Big Endian
	LINE_TEST_DATA4					: Startbit 32 | Length [Bit] 8 | Big Endian
	LINE_TEST_DATA5					: Startbit 40 | Length [Bit] 8 | Big Endian
	LINE_TEST_DATA6					: Startbit 48 | Length [Bit] 8 | Big Endian
	LINE_TEST_DATA7					: Startbit 56 | Length [Bit] 8 | Big Endian

RX_7DF (CAN_Standard: 0x000007DF)
------------------------------------------------------------------------------------------------------------------------
	ID7DF_DATA0						: Startbit  0 | Length [Bit] 8 | Big Endian
	ID7DF_DATA1						: Startbit  8 | Length [Bit] 8 | Big Endian
	ID7DF_DATA2						: Startbit 16 | Length [Bit] 8 | Big Endian
	ID7DF_DATA3						: Startbit 24 | Length [Bit] 8 | Big Endian
	ID7DF_DATA4						: Startbit 32 | Length [Bit] 8 | Big Endian
	ID7DF_DATA5						: Startbit 40 | Length [Bit] 8 | Big Endian
	ID7DF_DATA6						: Startbit 48 | Length [Bit] 8 | Big Endian
	ID7DF_DATA7						: Startbit 56 | Length [Bit] 8 | Big Endian

*/

/************************************************************************************************/
/* Global Macros                                                                                */
/************************************************************************************************/
/************************************************************************************************/
/* CANDRVIF_CONTROLLER_FCAN                                                                     */
/************************************************************************************************/

/*------------------------------------------------------------*/
/* CanILTx : TX_22E                                           */
/*------------------------------------------------------------*/
/* Access to TxMsg Information --- */
#define CanILTx_GetFrameFormat_TX_22E()     CanIL_GetTxFrameFormat(CANILTX_MSG_TX_22E)
#define CanILTx_GetId_TX_22E()              CanIL_GetTxId(CANILTX_MSG_TX_22E)
#define CanILTx_GetDataLen_TX_22E()         CanIL_GetTxDataLen(CANILTX_MSG_TX_22E)
#define CanILTx_GetState_TX_22E(state_mask) CanIL_GetTxState(CANILTX_MSG_TX_22E, (state_mask))
#define CanILTx_ClrState_TX_22E(state_mask) CanIL_ClrTxState(CANILTX_MSG_TX_22E, (state_mask))
#define CanILTx_SetEventReq_TX_22E()        CanIL_SetTxEventReq(CANILTX_MSG_TX_22E)
/* --- Access to TxMsg Information */
/* Access to TxMsg Information (Dynamic) --- */
/* --- Access to TxMsg Information (Dynamic) */
/* Access to TxSignal Information --- */
#define CanILTx_Get_ID22E_GRIP_WARMER_TEMP()       	CanIL_GetTxByteSignal(CANILTX_BSIG_ID22E_GRIP_WARMER_TEMP)
#define CanILTx_Set_ID22E_GRIP_WARMER_TEMP(val)    	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22E_GRIP_WARMER_TEMP, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID22E_GRIP_WARMER_TEMP(val)   	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22E_GRIP_WARMER_TEMP, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID22E_GRIP_WARMER_TEMP(val) 	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22E_GRIP_WARMER_TEMP, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID22E_BUTTON_STATUS()       	CanIL_GetTxByteSignal(CANILTX_BSIG_ID22E_BUTTON_STATUS)
#define CanILTx_Set_ID22E_BUTTON_STATUS(val)    	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22E_BUTTON_STATUS, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID22E_BUTTON_STATUS(val)   	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22E_BUTTON_STATUS, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID22E_BUTTON_STATUS(val) 	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22E_BUTTON_STATUS, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID22E_SELECT_UNIT()       		CanIL_GetTxByteSignal(CANILTX_BSIG_ID22E_SELECT_UNIT)
#define CanILTx_Set_ID22E_SELECT_UNIT(val)    		CanIL_SetTxByteSignal(CANILTX_BSIG_ID22E_SELECT_UNIT, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID22E_SELECT_UNIT(val)   		CanIL_SetTxByteSignal(CANILTX_BSIG_ID22E_SELECT_UNIT, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID22E_SELECT_UNIT(val) 		CanIL_SetTxByteSignal(CANILTX_BSIG_ID22E_SELECT_UNIT, (val), CANILTX_EVENT_REQ_NONE)
/* --- Access to TxSignal Information */
/*------------------------------------------------------------*/
/* CanILTx : TX_22D                                           */
/*------------------------------------------------------------*/
/* Access to TxMsg Information --- */
#define CanILTx_GetFrameFormat_TX_22D()     CanIL_GetTxFrameFormat(CANILTX_MSG_TX_22D)
#define CanILTx_GetId_TX_22D()              CanIL_GetTxId(CANILTX_MSG_TX_22D)
#define CanILTx_GetDataLen_TX_22D()         CanIL_GetTxDataLen(CANILTX_MSG_TX_22D)
#define CanILTx_GetState_TX_22D(state_mask) CanIL_GetTxState(CANILTX_MSG_TX_22D, (state_mask))
#define CanILTx_ClrState_TX_22D(state_mask) CanIL_ClrTxState(CANILTX_MSG_TX_22D, (state_mask))
#define CanILTx_SetEventReq_TX_22D()        CanIL_SetTxEventReq(CANILTX_MSG_TX_22D)
/* --- Access to TxMsg Information */
/* Access to TxMsg Information (Dynamic) --- */
/* --- Access to TxMsg Information (Dynamic) */
/* Access to TxSignal Information --- */
#define CanILTx_Get_ID22D_IT_LOG_START()       			CanIL_GetTxByteSignal(CANILTX_BSIG_ID22D_IT_LOG_START)
#define CanILTx_Set_ID22D_IT_LOG_START(val)    			CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_IT_LOG_START, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID22D_IT_LOG_START(val)   			CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_IT_LOG_START, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID22D_IT_LOG_START(val) 			CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_IT_LOG_START, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID22D_SELECT_UNIT_ECU_FLAG()       	CanIL_GetTxByteSignal(CANILTX_BSIG_ID22D_SELECT_UNIT_ECU_FLAG)
#define CanILTx_Set_ID22D_SELECT_UNIT_ECU_FLAG(val)    	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_SELECT_UNIT_ECU_FLAG, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID22D_SELECT_UNIT_ECU_FLAG(val)   	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_SELECT_UNIT_ECU_FLAG, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID22D_SELECT_UNIT_ECU_FLAG(val) 	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_SELECT_UNIT_ECU_FLAG, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID22D_SELECT_UNIT_ME_FLAG()       	CanIL_GetTxByteSignal(CANILTX_BSIG_ID22D_SELECT_UNIT_ME_FLAG)
#define CanILTx_Set_ID22D_SELECT_UNIT_ME_FLAG(val)    	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_SELECT_UNIT_ME_FLAG, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID22D_SELECT_UNIT_ME_FLAG(val)   	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_SELECT_UNIT_ME_FLAG, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID22D_SELECT_UNIT_ME_FLAG(val) 	CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_SELECT_UNIT_ME_FLAG, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID22D_BUTTON_STATUS()       		CanIL_GetTxByteSignal(CANILTX_BSIG_ID22D_BUTTON_STATUS)
#define CanILTx_Set_ID22D_BUTTON_STATUS(val)    		CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_BUTTON_STATUS, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID22D_BUTTON_STATUS(val)   		CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_BUTTON_STATUS, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID22D_BUTTON_STATUS(val) 		CanIL_SetTxByteSignal(CANILTX_BSIG_ID22D_BUTTON_STATUS, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID22D_TOTAL_MILEAGE()       		CanIL_GetTxDwordSignal(CANILTX_DSIG_ID22D_TOTAL_MILEAGE)
#define CanILTx_Set_ID22D_TOTAL_MILEAGE(val)    		CanIL_SetTxDwordSignal(CANILTX_DSIG_ID22D_TOTAL_MILEAGE, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID22D_TOTAL_MILEAGE(val)   		CanIL_SetTxDwordSignal(CANILTX_DSIG_ID22D_TOTAL_MILEAGE, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID22D_TOTAL_MILEAGE(val) 		CanIL_SetTxDwordSignal(CANILTX_DSIG_ID22D_TOTAL_MILEAGE, (val), CANILTX_EVENT_REQ_NONE)
/* --- Access to TxSignal Information */
/*------------------------------------------------------------*/
/* CanILTx : TX_240                                           */
/*------------------------------------------------------------*/
/* Access to TxMsg Information --- */
#define CanILTx_GetFrameFormat_TX_240()     CanIL_GetTxFrameFormat(CANILTX_MSG_TX_240)
#define CanILTx_GetId_TX_240()              CanIL_GetTxId(CANILTX_MSG_TX_240)
#define CanILTx_GetDataLen_TX_240()         CanIL_GetTxDataLen(CANILTX_MSG_TX_240)
#define CanILTx_GetState_TX_240(state_mask) CanIL_GetTxState(CANILTX_MSG_TX_240, (state_mask))
#define CanILTx_ClrState_TX_240(state_mask) CanIL_ClrTxState(CANILTX_MSG_TX_240, (state_mask))
#define CanILTx_SetEventReq_TX_240()        CanIL_SetTxEventReq(CANILTX_MSG_TX_240)
/* --- Access to TxMsg Information */
/* Access to TxMsg Information (Dynamic) --- */
/* --- Access to TxMsg Information (Dynamic) */
/* Access to TxSignal Information --- */
#define CanILTx_Get_ID240_PM_BUTTON_STATUS()       	CanIL_GetTxByteSignal(CANILTX_BSIG_ID240_PM_BUTTON_STATUS)
#define CanILTx_Set_ID240_PM_BUTTON_STATUS(val)    	CanIL_SetTxByteSignal(CANILTX_BSIG_ID240_PM_BUTTON_STATUS, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID240_PM_BUTTON_STATUS(val)   	CanIL_SetTxByteSignal(CANILTX_BSIG_ID240_PM_BUTTON_STATUS, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID240_PM_BUTTON_STATUS(val) 	CanIL_SetTxByteSignal(CANILTX_BSIG_ID240_PM_BUTTON_STATUS, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID240_SUS_MODE_SELECT()       	CanIL_GetTxByteSignal(CANILTX_BSIG_ID240_SUS_MODE_SELECT)
#define CanILTx_Set_ID240_SUS_MODE_SELECT(val)    	CanIL_SetTxByteSignal(CANILTX_BSIG_ID240_SUS_MODE_SELECT, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID240_SUS_MODE_SELECT(val)   	CanIL_SetTxByteSignal(CANILTX_BSIG_ID240_SUS_MODE_SELECT, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID240_SUS_MODE_SELECT(val) 	CanIL_SetTxByteSignal(CANILTX_BSIG_ID240_SUS_MODE_SELECT, (val), CANILTX_EVENT_REQ_NONE)
/* --- Access to TxSignal Information */
/*------------------------------------------------------------*/
/* CanILTx : TX_610                                           */
/*------------------------------------------------------------*/
/* Access to TxMsg Information --- */
#define CanILTx_GetFrameFormat_TX_610()     CanIL_GetTxFrameFormat(CANILTX_MSG_TX_610)
#define CanILTx_GetId_TX_610()              CanIL_GetTxId(CANILTX_MSG_TX_610)
#define CanILTx_GetDataLen_TX_610()         CanIL_GetTxDataLen(CANILTX_MSG_TX_610)
#define CanILTx_GetState_TX_610(state_mask) CanIL_GetTxState(CANILTX_MSG_TX_610, (state_mask))
#define CanILTx_ClrState_TX_610(state_mask) CanIL_ClrTxState(CANILTX_MSG_TX_610, (state_mask))
#define CanILTx_SetEventReq_TX_610()        CanIL_SetTxEventReq(CANILTX_MSG_TX_610)
/* --- Access to TxMsg Information */
/* Access to TxMsg Information (Dynamic) --- */
/* --- Access to TxMsg Information (Dynamic) */
/* Access to TxSignal Information --- */
#define CanILTx_Get_LINE_TEST_DATA0()       CanIL_GetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA0)
#define CanILTx_Set_LINE_TEST_DATA0(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA0, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_LINE_TEST_DATA0(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA0, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_LINE_TEST_DATA0(val) CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA0, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_LINE_TEST_DATA1()       CanIL_GetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA1)
#define CanILTx_Set_LINE_TEST_DATA1(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA1, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_LINE_TEST_DATA1(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA1, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_LINE_TEST_DATA1(val) CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA1, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_LINE_TEST_DATA2()       CanIL_GetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA2)
#define CanILTx_Set_LINE_TEST_DATA2(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA2, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_LINE_TEST_DATA2(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA2, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_LINE_TEST_DATA2(val) CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA2, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_LINE_TEST_DATA3()       CanIL_GetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA3)
#define CanILTx_Set_LINE_TEST_DATA3(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA3, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_LINE_TEST_DATA3(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA3, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_LINE_TEST_DATA3(val) CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA3, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_LINE_TEST_DATA4()       CanIL_GetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA4)
#define CanILTx_Set_LINE_TEST_DATA4(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA4, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_LINE_TEST_DATA4(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA4, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_LINE_TEST_DATA4(val) CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA4, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_LINE_TEST_DATA5()       CanIL_GetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA5)
#define CanILTx_Set_LINE_TEST_DATA5(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA5, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_LINE_TEST_DATA5(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA5, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_LINE_TEST_DATA5(val) CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA5, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_LINE_TEST_DATA6()       CanIL_GetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA6)
#define CanILTx_Set_LINE_TEST_DATA6(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA6, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_LINE_TEST_DATA6(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA6, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_LINE_TEST_DATA6(val) CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA6, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_LINE_TEST_DATA7()       CanIL_GetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA7)
#define CanILTx_Set_LINE_TEST_DATA7(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA7, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_LINE_TEST_DATA7(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA7, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_LINE_TEST_DATA7(val) CanIL_SetTxByteSignal(CANILTX_BSIG_LINE_TEST_DATA7, (val), CANILTX_EVENT_REQ_NONE)
/* --- Access to TxSignal Information */
/*------------------------------------------------------------*/
/* CanILTx : TX_5A1                                           */
/*------------------------------------------------------------*/
/* Access to TxMsg Information --- */
#define CanILTx_GetFrameFormat_TX_5A1()     CanIL_GetTxFrameFormat(CANILTX_MSG_TX_5A1)
#define CanILTx_GetId_TX_5A1()              CanIL_GetTxId(CANILTX_MSG_TX_5A1)
#define CanILTx_GetDataLen_TX_5A1()         CanIL_GetTxDataLen(CANILTX_MSG_TX_5A1)
#define CanILTx_GetState_TX_5A1(state_mask) CanIL_GetTxState(CANILTX_MSG_TX_5A1, (state_mask))
#define CanILTx_ClrState_TX_5A1(state_mask) CanIL_ClrTxState(CANILTX_MSG_TX_5A1, (state_mask))
#define CanILTx_SetEventReq_TX_5A1()        CanIL_SetTxEventReq(CANILTX_MSG_TX_5A1)
/* --- Access to TxMsg Information */
/* Access to TxMsg Information (Dynamic) --- */
/* --- Access to TxMsg Information (Dynamic) */
/* Access to TxSignal Information --- */
#define CanILTx_Get_ID5A1_FUNCTION_SW_1()       CanIL_GetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_1)
#define CanILTx_Set_ID5A1_FUNCTION_SW_1(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_1, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID5A1_FUNCTION_SW_1(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_1, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID5A1_FUNCTION_SW_1(val) CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_1, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID5A1_FUNCTION_SW_2()       CanIL_GetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_2)
#define CanILTx_Set_ID5A1_FUNCTION_SW_2(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_2, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID5A1_FUNCTION_SW_2(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_2, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID5A1_FUNCTION_SW_2(val) CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_2, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID5A1_FUNCTION_SW_3()       CanIL_GetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_3)
#define CanILTx_Set_ID5A1_FUNCTION_SW_3(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_3, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID5A1_FUNCTION_SW_3(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_3, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID5A1_FUNCTION_SW_3(val) CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_3, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID5A1_FUNCTION_SW_4()       CanIL_GetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_4)
#define CanILTx_Set_ID5A1_FUNCTION_SW_4(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_4, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID5A1_FUNCTION_SW_4(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_4, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID5A1_FUNCTION_SW_4(val) CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_4, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID5A1_FUNCTION_SW_5()       CanIL_GetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_5)
#define CanILTx_Set_ID5A1_FUNCTION_SW_5(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_5, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID5A1_FUNCTION_SW_5(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_5, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID5A1_FUNCTION_SW_5(val) CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_5, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID5A1_FUNCTION_SW_6()       CanIL_GetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_6)
#define CanILTx_Set_ID5A1_FUNCTION_SW_6(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_6, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID5A1_FUNCTION_SW_6(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_6, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID5A1_FUNCTION_SW_6(val) CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_FUNCTION_SW_6, (val), CANILTX_EVENT_REQ_NONE)

#define CanILTx_Get_ID5A1_SCREEN_LAYER()       CanIL_GetTxByteSignal(CANILTX_BSIG_ID5A1_SCREEN_LAYER)
#define CanILTx_Set_ID5A1_SCREEN_LAYER(val)    CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_SCREEN_LAYER, (val), CANILTX_EVENT_REQ_CHNG)
#define CanILTx_Send_ID5A1_SCREEN_LAYER(val)   CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_SCREEN_LAYER, (val), CANILTX_EVENT_REQ_EXT)
#define CanILTx_Update_ID5A1_SCREEN_LAYER(val) CanIL_SetTxByteSignal(CANILTX_BSIG_ID5A1_SCREEN_LAYER, (val), CANILTX_EVENT_REQ_NONE)
/* --- Access to TxSignal Information */


/*------------------------------------------------------------*/
/* CanILRx : RX_401                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_401()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_401)
#define CanILRx_GetId_RX_401()              CanIL_GetRxId(CANILRX_MSG_RX_401)
#define CanILRx_GetDataLen_RX_401()         CanIL_GetRxDataLen(CANILRX_MSG_RX_401)
#define CanILRx_GetState_RX_401(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_401, (state_mask))
#define CanILRx_ClrState_RX_401(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_401, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID401_TX_STOP_ECU()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID401_TX_STOP_ECU)
#define CanILRx_Set_ID401_TX_STOP_ECU(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID401_TX_STOP_ECU, (val))
/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_401                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */

/*------------------------------------------------------------*/
/* CanILRx : RX_23A                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_23A()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_23A)
#define CanILRx_GetId_RX_23A()              CanIL_GetRxId(CANILRX_MSG_RX_23A)
#define CanILRx_GetDataLen_RX_23A()         CanIL_GetRxDataLen(CANILRX_MSG_RX_23A)
#define CanILRx_GetState_RX_23A(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_23A, (state_mask))
#define CanILRx_ClrState_RX_23A(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_23A, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID23A_FI_MODE()    					CanIL_GetRxByteSignal(CANILRX_BSIG_ID23A_FI_MODE)
#define CanILRx_Set_ID23A_FI_MODE(val) 					CanIL_SetRxByteSignal(CANILRX_BSIG_ID23A_FI_MODE, (val))

#define CanILRx_Get_ID23A_FI_WARNING_LAMP_BLINK()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID23A_FI_WARNING_LAMP_BLINK)
#define CanILRx_Set_ID23A_FI_WARNING_LAMP_BLINK(val) 	CanIL_SetRxByteSignal(CANILRX_BSIG_ID23A_FI_WARNING_LAMP_BLINK, (val))

#define CanILRx_Get_ID23A_FI_WARNING_LAMP()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID23A_FI_WARNING_LAMP)
#define CanILRx_Set_ID23A_FI_WARNING_LAMP(val) 			CanIL_SetRxByteSignal(CANILRX_BSIG_ID23A_FI_WARNING_LAMP, (val))

#define CanILRx_Get_ID23A_DIAG_CYL_N()    				CanIL_GetRxByteSignal(CANILRX_BSIG_ID23A_DIAG_CYL_N)
#define CanILRx_Set_ID23A_DIAG_CYL_N(val) 				CanIL_SetRxByteSignal(CANILRX_BSIG_ID23A_DIAG_CYL_N, (val))

#define CanILRx_Get_ID23A_CO_DIAG_DATA()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID23A_CO_DIAG_DATA)
#define CanILRx_Set_ID23A_CO_DIAG_DATA(val) 			CanIL_SetRxByteSignal(CANILRX_BSIG_ID23A_CO_DIAG_DATA, (val))
/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_23A                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */


/*------------------------------------------------------------*/
/* CanILRx : RX_23E                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_23E()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_23E)
#define CanILRx_GetId_RX_23E()              CanIL_GetRxId(CANILRX_MSG_RX_23E)
#define CanILRx_GetDataLen_RX_23E()         CanIL_GetRxDataLen(CANILRX_MSG_RX_23E)
#define CanILRx_GetState_RX_23E(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_23E, (state_mask))
#define CanILRx_ClrState_RX_23E(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_23E, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID23E_WATER_TEMP()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID23E_WATER_TEMP)
#define CanILRx_Set_ID23E_WATER_TEMP(val) 		CanIL_SetRxByteSignal(CANILRX_BSIG_ID23E_WATER_TEMP, (val))

#define CanILRx_Get_ID23E_INTAKE_AIR_TEMP()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID23E_INTAKE_AIR_TEMP)
#define CanILRx_Set_ID23E_INTAKE_AIR_TEMP(val) 	CanIL_SetRxByteSignal(CANILRX_BSIG_ID23E_INTAKE_AIR_TEMP, (val))

#define CanILRx_Get_ID23E_INJECTION()    		CanIL_GetRxWordSignal(CANILRX_WSIG_ID23E_INJECTION)
#define CanILRx_Set_ID23E_INJECTION(val) 		CanIL_SetRxWordSignal(CANILRX_WSIG_ID23E_INJECTION, (val))
/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_23E                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */


/*------------------------------------------------------------*/
/* CanILRx : RX_209                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_209()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_209)
#define CanILRx_GetId_RX_209()              CanIL_GetRxId(CANILRX_MSG_RX_209)
#define CanILRx_GetDataLen_RX_209()         CanIL_GetRxDataLen(CANILRX_MSG_RX_209)
#define CanILRx_GetState_RX_209(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_209, (state_mask))
#define CanILRx_ClrState_RX_209(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_209, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID209_EG_SPEED()    		CanIL_GetRxByteSignal(CANILRX_WSIG_ID209_EG_SPEED)
#define CanILRx_Set_ID209_EG_SPEED(val) 		CanIL_SetRxByteSignal(CANILRX_WSIG_ID209_EG_SPEED, (val))

#define CanILRx_Get_ID209_VH_SPEED_PULSE()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID209_VH_SPEED_PULSE)
#define CanILRx_Set_ID209_VH_SPEED_PULSE(val) 	CanIL_SetRxByteSignal(CANILRX_BSIG_ID209_VH_SPEED_PULSE, (val))

#define CanILRx_Get_ID209_GEAR_POSITION_5()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID209_GEAR_POSITION_5)
#define CanILRx_Set_ID209_GEAR_POSITION_5(val) 	CanIL_SetRxByteSignal(CANILRX_BSIG_ID209_GEAR_POSITION_5, (val))

#define CanILRx_Get_ID209_TC_MODE()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID209_TC_MODE)
#define CanILRx_Set_ID209_TC_MODE(val) 			CanIL_SetRxByteSignal(CANILRX_BSIG_ID209_TC_MODE, (val))

#define CanILRx_Get_ID209_START_SW_STATUS()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID209_START_SW_STATUS)
#define CanILRx_Set_ID209_START_SW_STATUS(val) 	CanIL_SetRxByteSignal(CANILRX_BSIG_ID209_START_SW_STATUS, (val))

#define CanILRx_Get_ID209_EG_MODE()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID209_EG_MODE)
#define CanILRx_Set_ID209_EG_MODE(val) 			CanIL_SetRxByteSignal(CANILRX_BSIG_ID209_EG_MODE, (val))

#define CanILRx_Get_ID209_E_LAMP()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID209_E_LAMP)
#define CanILRx_Set_ID209_E_LAMP(val) 			CanIL_SetRxByteSignal(CANILRX_BSIG_ID209_E_LAMP, (val))

#define CanILRx_Get_ID209_TC_INDICATOR()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID209_TC_INDICATOR)
#define CanILRx_Set_ID209_TC_INDICATOR(val) 	CanIL_SetRxByteSignal(CANILRX_BSIG_ID209_TC_INDICATOR, (val))

#define CanILRx_Get_ID209_GEAR_POSITION_4()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID209_GEAR_POSITION_4)
#define CanILRx_Set_ID209_GEAR_POSITION_4(val) 	CanIL_SetRxByteSignal(CANILRX_BSIG_ID209_GEAR_POSITION_4, (val))

#define CanILRx_Get_ID209_CATION_LAMP()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID209_CATION_LAMP)
#define CanILRx_Set_ID209_CATION_LAMP(val) 		CanIL_SetRxByteSignal(CANILRX_BSIG_ID209_CATION_LAMP, (val))


/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_209                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */


/*------------------------------------------------------------*/
/* CanILRx : RX_215                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_215()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_215)
#define CanILRx_GetId_RX_215()              CanIL_GetRxId(CANILRX_MSG_RX_215)
#define CanILRx_GetDataLen_RX_215()         CanIL_GetRxDataLen(CANILRX_MSG_RX_215)
#define CanILRx_GetState_RX_215(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_215, (state_mask))
#define CanILRx_ClrState_RX_215(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_215, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID215_TPS_ANGLE2()    		CanIL_GetRxByteSignal(CANILRX_WSIG_ID215_TPS_ANGLE2)
#define CanILRx_Set_ID215_TPS_ANGLE2(val) 		CanIL_SetRxByteSignal(CANILRX_WSIG_ID215_TPS_ANGLE2, (val))

#define CanILRx_Get_ID215_APS_ANGLE2()    		CanIL_GetRxByteSignal(CANILRX_WSIG_ID215_APS_ANGLE2)
#define CanILRx_Set_ID215_APS_ANGLE2(val) 		CanIL_SetRxByteSignal(CANILRX_WSIG_ID215_APS_ANGLE2, (val))

#define CanILRx_Get_ID215_NEUTRAL_FLAG()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_NEUTRAL_FLAG)
#define CanILRx_Set_ID215_NEUTRAL_FLAG()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_NEUTRAL_FLAG)

#define CanILRx_Get_ID215_MODE_FLAG1()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_MODE_FLAG1)
#define CanILRx_Set_ID215_MODE_FLAG1()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_MODE_FLAG1)

#define CanILRx_Get_ID215_MODE_FLAG2()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_MODE_FLAG2)
#define CanILRx_Set_ID215_MODE_FLAG2()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_MODE_FLAG2)

#define CanILRx_Get_ID215_MODE_FLAG3()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_MODE_FLAG3)
#define CanILRx_Set_ID215_MODE_FLAG3()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_MODE_FLAG3)

#define CanILRx_Get_ID215_LAUNCH_MODE()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_LAUNCH_MODE)
#define CanILRx_Set_ID215_LAUNCH_MODE()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_LAUNCH_MODE)

#define CanILRx_Get_ID215_WHEELIE_MODE()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_WHEELIE_MODE)
#define CanILRx_Set_ID215_WHEELIE_MODE()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_WHEELIE_MODE)

#define CanILRx_Get_ID215_SPEEDSHIFT_MODE()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_SPEEDSHIFT_MODE)
#define CanILRx_Set_ID215_SPEEDSHIFT_MODE()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_SPEEDSHIFT_MODE)

#define CanILRx_Get_ID215_SCS_MODE()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_SCS_MODE)
#define CanILRx_Set_ID215_SCS_MODE()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_SCS_MODE)

#define CanILRx_Get_ID215_YSC_FAIL_FLAG()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_YSC_FAIL_FLAG)
#define CanILRx_Set_ID215_YSC_FAIL_FLAG()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_YSC_FAIL_FLAG)

#define CanILRx_Get_ID215_LAUNCH_INDICATOR()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_LAUNCH_INDICATOR)
#define CanILRx_Set_ID215_LAUNCH_INDICATOR()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_LAUNCH_INDICATOR)

#define CanILRx_Get_ID215_TC_MODE()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_TC_MODE)
#define CanILRx_Set_ID215_TC_MODE()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_TC_MODE)

#define CanILRx_Get_ID215_EG_MODE()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_EG_MODE)
#define CanILRx_Set_ID215_EG_MODE()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID215_EG_MODE)
/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_215                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */


/*------------------------------------------------------------*/
/* CanILRx : RX_22A                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_22A()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_22A)
#define CanILRx_GetId_RX_22A()              CanIL_GetRxId(CANILRX_MSG_RX_22A)
#define CanILRx_GetDataLen_RX_22A()         CanIL_GetRxDataLen(CANILRX_MSG_RX_22A)
#define CanILRx_GetState_RX_22A(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_22A, (state_mask))
#define CanILRx_ClrState_RX_22A(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_22A, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID22A_CC_SELF_DIAG()    		CanIL_GetRxByteSignal(CANILRX_BSIG_ID22A_CC_SELF_DIAG)
#define CanILRx_Set_ID22A_CC_SELF_DIAG()    		CanIL_SetRxByteSignal(CANILRX_BSIG_ID22A_CC_SELF_DIAG, (val))

#define CanILRx_Get_ID22A_CC_MAIN_IND_STATUS()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID22A_CC_MAIN_IND_STATUS)
#define CanILRx_Set_ID22A_CC_MAIN_IND_STATUS()    	CanIL_SetRxByteSignal(CANILRX_BSIG_ID22A_CC_MAIN_IND_STATUS, (val))

#define CanILRx_Get_ID22A_CC_SET_IND_STATUS()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID22A_CC_SET_IND_STATUS)
#define CanILRx_Set_ID22A_CC_SET_IND_STATUS()    	CanIL_SetRxByteSignal(CANILRX_BSIG_ID22A_CC_SET_IND_STATUS, (val))

#define CanILRx_Get_ID22A_MCU_WARNING_LAMP()    	CanIL_GetRxByteSignal(CANILRX_BSIG_ID22A_MCU_WARNING_LAMP)
#define CanILRx_Set_ID22A_MCU_WARNING_LAMP()    	CanIL_SetRxByteSignal(CANILRX_BSIG_ID22A_MCU_WARNING_LAMP, (val))
/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_22A                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */


/*------------------------------------------------------------*/
/* CanILRx : RX_20A                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_20A()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_20A)
#define CanILRx_GetId_RX_20A()              CanIL_GetRxId(CANILRX_MSG_RX_20A)
#define CanILRx_GetDataLen_RX_20A()         CanIL_GetRxDataLen(CANILRX_MSG_RX_20A)
#define CanILRx_GetState_RX_20A(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_20A, (state_mask))
#define CanILRx_ClrState_RX_20A(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_20A, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID20A_EG_SPEED()    		CanIL_GetRxWordSignal(CANILRX_WSIG_ID20A_EG_SPEED)
#define CanILRx_Set_ID20A_EG_SPEED(val) 		CanIL_SetRxWordSignal(CANILRX_WSIG_ID20A_EG_SPEED, (val))

#define CanILRx_Get_ID20A_VH_SPEED_PULSE()		CanIL_GetRxByteSignal(CANILRX_BSIG_ID20A_VH_SPEED_PULSE)
#define CanILRx_Set_ID20A_VH_SPEED_PULSE()		CanIL_GetRxByteSignal(CANILRX_BSIG_ID20A_VH_SPEED_PULSE)

#define CanILRx_Get_ID20A_START_SW_STATUS()		CanIL_GetRxByteSignal(CANILRX_BSIG_ID20A_START_SW_STATUS)
#define CanILRx_Set_ID20A_START_SW_STATUS()		CanIL_GetRxByteSignal(CANILRX_BSIG_ID20A_START_SW_STATUS)

#define CanILRx_Get_ID20A_EG_MODE()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID20A_EG_MODE)
#define CanILRx_Set_ID20A_EG_MODE()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID20A_EG_MODE)

#define CanILRx_Get_ID20A_E_LAMP()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID20A_E_LAMP)
#define CanILRx_Set_ID20A_E_LAMP()    			CanIL_GetRxByteSignal(CANILRX_BSIG_ID20A_E_LAMP)
/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_20A                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */


/*------------------------------------------------------------*/
/* CanILRx : RX_216                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_216()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_216)
#define CanILRx_GetId_RX_216()              CanIL_GetRxId(CANILRX_MSG_RX_216)
#define CanILRx_GetDataLen_RX_216()         CanIL_GetRxDataLen(CANILRX_MSG_RX_216)
#define CanILRx_GetState_RX_216(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_216, (state_mask))
#define CanILRx_ClrState_RX_216(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_216, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID216_TC_MODE()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID216_TC_MODE)
#define CanILRx_Set_ID216_TC_MODE(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID216_TC_MODE, (val))

#define CanILRx_Get_ID216_TC_INDICATOR()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID216_TC_INDICATOR)
#define CanILRx_Set_ID216_TC_INDICATOR(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID216_TC_INDICATOR, (val))

#define CanILRx_Get_ID216_APS_ANGLE()    CanIL_GetRxByteSignal(CANILRX_WSIG_ID216_APS_ANGLE)
#define CanILRx_Set_ID216_APS_ANGLE(val) CanIL_SetRxByteSignal(CANILRX_WSIG_ID216_APS_ANGLE, (val))

/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_216                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */

/*------------------------------------------------------------*/
/* CanILRx : RX_245                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_245()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_245)
#define CanILRx_GetId_RX_245()              CanIL_GetRxId(CANILRX_MSG_RX_245)
#define CanILRx_GetDataLen_RX_245()         CanIL_GetRxDataLen(CANILRX_MSG_RX_245)
#define CanILRx_GetState_RX_245(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_245, (state_mask))
#define CanILRx_ClrState_RX_245(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_245, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID245_GEAR_POSITION_3()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID245_GEAR_POSITION_3)
#define CanILRx_Set_ID245_GEAR_POSITION_3(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID245_GEAR_POSITION_3, (val))

#define CanILRx_Get_ID245_GRIP_WARMER_STATUS()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID245_GRIP_WARMER_STATUS)
#define CanILRx_Set_ID245_GRIP_WARMER_STATUS(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID245_GRIP_WARMER_STATUS, (val))
/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_245                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */

/*------------------------------------------------------------*/
/* CanILRx : RX_600                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_600()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_600)
#define CanILRx_GetId_RX_600()              CanIL_GetRxId(CANILRX_MSG_RX_600)
#define CanILRx_GetDataLen_RX_600()         CanIL_GetRxDataLen(CANILRX_MSG_RX_600)
#define CanILRx_GetState_RX_600(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_600, (state_mask))
#define CanILRx_ClrState_RX_600(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_600, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_LINE_TEST_DATA0()    CanIL_GetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA0)
#define CanILRx_Set_LINE_TEST_DATA0(val) CanIL_SetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA0, (val))

#define CanILRx_Get_LINE_TEST_DATA1()    CanIL_GetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA1)
#define CanILRx_Set_LINE_TEST_DATA1(val) CanIL_SetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA1, (val))

#define CanILRx_Get_LINE_TEST_DATA2()    CanIL_GetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA2)
#define CanILRx_Set_LINE_TEST_DATA2(val) CanIL_SetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA2, (val))

#define CanILRx_Get_LINE_TEST_DATA3()    CanIL_GetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA3)
#define CanILRx_Set_LINE_TEST_DATA3(val) CanIL_SetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA3, (val))

#define CanILRx_Get_LINE_TEST_DATA4()    CanIL_GetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA4)
#define CanILRx_Set_LINE_TEST_DATA4(val) CanIL_SetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA4, (val))

#define CanILRx_Get_LINE_TEST_DATA5()    CanIL_GetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA5)
#define CanILRx_Set_LINE_TEST_DATA5(val) CanIL_SetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA5, (val))

#define CanILRx_Get_LINE_TEST_DATA6()    CanIL_GetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA6)
#define CanILRx_Set_LINE_TEST_DATA6(val) CanIL_SetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA6, (val))

#define CanILRx_Get_LINE_TEST_DATA7()    CanIL_GetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA7)
#define CanILRx_Set_LINE_TEST_DATA7(val) CanIL_SetRxByteSignal(CANILRX_BSIG_LINE_TEST_DATA7, (val))
/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_600                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */


/*------------------------------------------------------------*/
/* CanILRx : RX_7DF                                           */
/*------------------------------------------------------------*/
/* Access to RxMsg Information --- */
#define CanILRx_GetFrameFormat_RX_7DF()     CanIL_GetRxFrameFormat(CANILRX_MSG_RX_7DF)
#define CanILRx_GetId_RX_7DF()              CanIL_GetRxId(CANILRX_MSG_RX_7DF)
#define CanILRx_GetDataLen_RX_7DF()         CanIL_GetRxDataLen(CANILRX_MSG_RX_7DF)
#define CanILRx_GetState_RX_7DF(state_mask) CanIL_GetRxState(CANILRX_MSG_RX_7DF, (state_mask))
#define CanILRx_ClrState_RX_7DF(state_mask) CanIL_ClrRxState(CANILRX_MSG_RX_7DF, (state_mask))
/* --- Access to RxMsg Information */
/* Access to RxSignal Information --- */
#define CanILRx_Get_ID7DF_DATA0()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID7DF_DATA0)
#define CanILRx_Set_ID7DF_DATA0(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID7DF_DATA0, (val))

#define CanILRx_Get_ID7DF_DATA1()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID7DF_DATA1)
#define CanILRx_Set_ID7DF_DATA1(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID7DF_DATA1, (val))

#define CanILRx_Get_ID7DF_DATA2()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID7DF_DATA2)
#define CanILRx_Set_ID7DF_DATA2(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID7DF_DATA2, (val))

#define CanILRx_Get_ID7DF_DATA3()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID7DF_DATA3)
#define CanILRx_Set_ID7DF_DATA3(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID7DF_DATA3, (val))

#define CanILRx_Get_ID7DF_DATA4()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID7DF_DATA4)
#define CanILRx_Set_ID7DF_DATA4(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID7DF_DATA4, (val))

#define CanILRx_Get_ID7DF_DATA5()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID7DF_DATA5)
#define CanILRx_Set_ID7DF_DATA5(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID7DF_DATA5, (val))

#define CanILRx_Get_ID7DF_DATA6()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID7DF_DATA6)
#define CanILRx_Set_ID7DF_DATA6(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID7DF_DATA6, (val))

#define CanILRx_Get_ID7DF_DATA7()    CanIL_GetRxByteSignal(CANILRX_BSIG_ID7DF_DATA7)
#define CanILRx_Set_ID7DF_DATA7(val) CanIL_SetRxByteSignal(CANILRX_BSIG_ID7DF_DATA7, (val))
/* --- Access to RxSignal Information */

/*------------------------------------------------------------*/
/* CanApplILRx (Optional) : RX_7DF                            */
/*------------------------------------------------------------*/
/* Access to RxMsg Information (Optional) --- */
/* --- Access to RxMsg Information (Optional) */
/* Access to RxSignal Information (Optional) --- */
/* --- Access to RxSignal Information (Optional) */

#endif /* SSFTXXX_CAN_IL_IF_000_H */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/



