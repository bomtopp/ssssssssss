/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFTSTD                                                                   */
/* Copyright        : Nippon Seiki Co.,Ltd                                                      */
/*----------------------------------------------------------------------------------------------*/
/* Author           : PF1                                                                       */
/* Description      : Sample                                                                    */
/************************************************************************************************/



/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Can_DrvIF_000.h"

#define SOPVSTD_CAN_TP_000_INTERNAL
#include "SSFTxxx_Can_TP_000.h"


/************************************************************************************************/
/* Local Macros                                                                                 */
/************************************************************************************************/
/*  */
#define CANTP_FORMAT_OFFSET (0U) /* Only normal addressing shall be used. (RS-DS01-7) */

/* to be used for filling unused bytes */
#define CANTP_PADDING_BYTE (0x00U) /* All unused bytes shall be set to zero. (RS-IL/IC01-20) */

/*  */
#define CANTP_RECEIVE_BLOCKED_CNT (10000U / CANTP_MAIN_CYCLE) /* 10000 msec */

/* Definitions for rx connection channels */
#define CANTP_RX_CHANNEL_CNT (1U)
#define CANTP_RX_CHANNEL_INVALID (0xFFU)


#define CANTP_POS_N_PCITYPE (0U + CANTP_FORMAT_OFFSET) /* N_PCItype is located in the Byte1 in the CAN frame data field */

/* N_PCItype */
#define CANTP_N_PCITYPE_MASK (0xF0U) /* 1111 0000b */
#define CANTP_N_PCITYPE_SF (0x00U) /* 0000 0000b */ /* SingleFrame */
#define CANTP_N_PCITYPE_FF (0x10U) /* 0001 0000b */ /* FirstFrame */
#define CANTP_N_PCITYPE_CF (0x20U) /* 0010 0000b */ /* ConsecutiveFrame */
#define CANTP_N_PCITYPE_FC (0x30U) /* 0011 0000b */ /* FlowControl */

/* N_PCItype = SingleFrame */
#define CANTP_POS_N_PCITYPE_AND_SF_DL (0U + CANTP_FORMAT_OFFSET)
#define CANTP_POS_SF_N_DATA (1U + CANTP_FORMAT_OFFSET)
#define CANTP_SF_DL_MASK (0x0FU)
#define CANTP_SF_DL (7U - CANTP_FORMAT_OFFSET)

/* N_PCItype = FirstFrame */
#define CANTP_POS_N_PCITYPE_AND_FF_DL_HIGH (0U + CANTP_FORMAT_OFFSET)
#define CANTP_POS_FF_DL_LOW (1U + CANTP_FORMAT_OFFSET)
#define CANTP_POS_FF_N_DATA (2U + CANTP_FORMAT_OFFSET)
#define CANTP_FF_DL_HIGH_MASK (0x0F00U)
#define CANTP_FF_DL_LOW_MASK (0x00FFU)
#define CANTP_FF_DL (8U - CANTP_FORMAT_OFFSET)
#define CANTP_FF_N_DATA_LEN (6U - CANTP_FORMAT_OFFSET)


/* N_PCItype = ConsecutiveFrame */
#define CANTP_POS_N_PCITYPE_AND_SN (0U + CANTP_FORMAT_OFFSET)
#define CANTP_POS_CF_N_DATA (1U + CANTP_FORMAT_OFFSET)
#define CANTP_SN_MASK (0x0FU)
#define CANTP_CF_N_DATA_LEN (7U - CANTP_FORMAT_OFFSET)


/* N_PCItype = FlowControl */
#define CANTP_POS_N_PCITYPE_AND_FS (0U + CANTP_FORMAT_OFFSET)
#define CANTP_POS_BS (1U + CANTP_FORMAT_OFFSET)
#define CANTP_POS_STMIN (2U + CANTP_FORMAT_OFFSET)
#define CANTP_FS_MASK (0x0FU)

/* FlowStatus (FS) parameter definition*/
#define CANTP_FS_CTS (0U) /* ContinueToSend */
#define CANTP_FS_WT (1U) /* Wait */
#define CANTP_FS_OVFLW (2U) /* Overflow */


/* Network layer timing parameters (RS-DS01-5) */
#define CANTP_N_AS_TIME (25U) /* N_As: 25 ms */
#define CANTP_N_AR_TIME (25U) /* N_Ar: 25 ms */
#define CANTP_N_BS_TIME (75U) /* N_Bs: 75 ms */
#define CANTP_N_BR_TIME (25U) /* N_Br: (N_Br + N_Ar) < 25 ms */
#define CANTP_N_CS_TIME (50U) /* N_Cs: (N_Cs + N_As) < 50 ms */
#define CANTP_N_CR_TIME (150U) /* N_Cr: 150 ms */

#define CANTP_N_AS ((UI_16)((CANTP_N_AS_TIME + (CANTP_MAIN_CYCLE - 1U)) / CANTP_MAIN_CYCLE))
#define CANTP_N_AR ((UI_16)((CANTP_N_AR_TIME + (CANTP_MAIN_CYCLE - 1U)) / CANTP_MAIN_CYCLE))
#define CANTP_N_BS ((UI_16)((CANTP_N_BS_TIME + (CANTP_MAIN_CYCLE - 1U)) / CANTP_MAIN_CYCLE))
#define CANTP_N_BR ((UI_16)((CANTP_N_BR_TIME + (CANTP_MAIN_CYCLE - 1U)) / CANTP_MAIN_CYCLE))
#define CANTP_N_CS ((UI_16)((CANTP_N_CS_TIME + (CANTP_MAIN_CYCLE - 1U)) / CANTP_MAIN_CYCLE))
#define CANTP_N_CR ((UI_16)((CANTP_N_CR_TIME + (CANTP_MAIN_CYCLE - 1U)) / CANTP_MAIN_CYCLE))


/* Rx */
#define CANTP_RX_STATE_IDLE                   (0x00U)
#define CANTP_RX_STATE_FC                     (0x01U)
#define CANTP_RX_STATE_FC_OVFLW               (0x02U)
#define CANTP_RX_STATE_WAIT_FOR_CF            (0x03U)
#define CANTP_RX_STATE_WAIT_FOR_FC_CONF       (0x04U)
#define CANTP_RX_STATE_WAIT_FOR_FC_OVFLW_CONF (0x05U)

/* Tx */
#define CANTP_TX_STATE_IDLE             (0x00U)
#define CANTP_TX_STATE_SF               (0x01U)
#define CANTP_TX_STATE_FF               (0x02U)
#define CANTP_TX_STATE_CF               (0x03U)
#define CANTP_TX_STATE_WAIT_FOR_FC      (0x04U)
#define CANTP_TX_STATE_WAIT_FOR_SF_CONF (0x05U)
#define CANTP_TX_STATE_WAIT_FOR_FF_CONF (0x06U)
#define CANTP_TX_STATE_WAIT_FOR_CF_CONF (0x07U)



/************************************************************************************************/
/* Local Data Types                                                                             */
/************************************************************************************************/
typedef struct
{
	UI_8 ReleaseReq;
	UI_8 LockStatus;
	UI_16 LockCnt;
} T_CanTP_BufCtrl;

typedef struct
{
	UI_8 FirstFrame;
	UI_8 IndicationFlg;
	UI_8 ErrResult;
} T_CanTP_Indication;

typedef struct
{
	UI_8 ConfirmationFlg;
	UI_8 ErrResult;
} T_CanTP_Confirmation;


typedef struct
{
	UI_8 RxStatus;
	UI_16 Timer;
	UI_16 DataIndex;
	UI_16 DataLength;
	UI_8 BS;
	UI_8 BSCnt;
	UI_16 ST;
	UI_8 ExpectedSN;
	UI_8 Channel;
	UI_8 AddrType;
	UI_8 FCTxReq;
} T_CanTP_RxCtrl;

typedef struct
{
	UI_8 TxStatus;
	UI_16 Timer;
	UI_8 *DataPtr;
	UI_16 DataIndex;
	UI_16 DataLength;
	UI_16 ST;
	UI_16 STCnt;
	UI_8 BS;
	UI_8 BSCnt;
	UI_8 SN;
	UI_8 TxReq;
} T_CanTP_TxCtrl;

typedef struct
{
	UI_16 RxHandle;
	UI_8 AddrType;
} T_CanTP_RxChannel;

typedef struct
{
	UI_16 MaxDataLen;
	UI_8 Controller;
	UI_16 TxHandle;
	const T_CanTP_RxChannel RxChannelList[CANTP_RX_CHANNEL_CNT];
} T_CanTP_Cfg;

/************************************************************************************************/
/* Local Data                                                                                   */
/************************************************************************************************/
/* RAM������section 2�̊J�n */
#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA RAM2SEC
#else
 #define START_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

static UI_8 CanTP_EnableFlg[CANTP_HANDLE_CNT];

static T_CanTP_BufCtrl CanTP_BufCtrl[CANTP_HANDLE_CNT];
static T_CanTP_Indication CanTP_Indication[CANTP_HANDLE_CNT];
static T_CanTP_Confirmation CanTP_Confirmation[CANTP_HANDLE_CNT];
static T_CanTP_RxCtrl CanTP_RxCtrl[CANTP_HANDLE_CNT];
static T_CanTP_TxCtrl CanTP_TxCtrl[CANTP_HANDLE_CNT];



/* Sub Data. */
static UI_8 CanTP_SubData[CANTP_HANDLE_CNT][8U];
/* Main Data. */
static UI_8 CanTP_Data_DIAG[CANTP_DATA_LEN_DIAG];
/* Data Length. */
static UI_16 CanTP_DataLen[CANTP_HANDLE_CNT][CANTP_BUF_TYPE_CNT];

#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA @@DATA
#else
 #define STOP_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

/************************************************************************************************/
/* Local Constants                                                                              */
/************************************************************************************************/
static const T_CanTP_Cfg C_CanTP_Cfg[CANTP_HANDLE_CNT] =
{
	/* CANTP_HANDLE_DIAG */
	{
		/* MaxDataLen */
		CANTP_DATA_LEN_DIAG,
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* TxHandle */
		0U,
		/* RxChannelList */
		{
			/* RxHandle, AddrType */
			{0U, 0U},
		},
	},
};

static const T_CanTP_DataBuf C_CanTP_DataBuf[CANTP_HANDLE_CNT][CANTP_BUF_TYPE_CNT] =
{
	/* CANTP_HANDLE_DIAG */
	{
		/* CANTP_BUF_TYPE_MAIN */
		{
			/* DataPtr */
			CanTP_Data_DIAG,
			/* DataLenPtr */
			&CanTP_DataLen[CANTP_HANDLE_DIAG][CANTP_BUF_TYPE_MAIN],
		},
		/* CANTP_BUF_TYPE_SUB */
		{
			/* DataPtr */
			CanTP_SubData[CANTP_HANDLE_DIAG],
			/* DataLenPtr */
			&CanTP_DataLen[CANTP_HANDLE_DIAG][CANTP_BUF_TYPE_SUB],
		},
	},
};

/************************************************************************************************/
/* Local Function Declarations                                                                  */
/************************************************************************************************/
static void tp_init_module(UI_8 tp_handle);
static void tp_init_rx_state(UI_8 tp_handle);
static void tp_init_tx_state(UI_8 tp_handle);

static void tp_receive_msg(UI_8 tp_handle, UI_8 tp_rx_channel, const UI_8 rx_data_ptr[]);
static void tp_receive_single_frame(UI_8 tp_handle, UI_8 tp_rx_channel, const UI_8 rx_data_ptr[]);
static void tp_receive_first_frame(UI_8 tp_handle, UI_8 tp_rx_channel, const UI_8 rx_data_ptr[]);
static void tp_receive_consecutive_frame(UI_8 tp_handle, UI_8 tp_rx_channel, const UI_8 rx_data_ptr[]);
static void tp_receive_flow_control(UI_8 tp_handle, const UI_8 rx_data_ptr[]);

static UI_8 tp_check_single_frame(UI_8 tp_handle, UI_8 tp_rx_channel);
static UI_8 tp_check_first_frame(UI_8 tp_handle, UI_8 tp_rx_channel);
static UI_8 tp_check_consecutive_frame(UI_8 tp_handle, UI_8 tp_rx_channel);

static void tp_ctrl_module(UI_8 tp_handle);
static void tp_receiver_process(UI_8 tp_handle);
static void tp_handle_receiver_state(UI_8 tp_handle);
static void tp_sender_process(UI_8 tp_handle);
static void tp_handle_sender_state(UI_8 tp_handle);

static void tp_tx_confirmation_receiver(UI_8 tp_handle);
static void tp_tx_confirmation_sender(UI_8 tp_handle);

static void tp_terminate_reception(UI_8 tp_handle, UI_8 result);
static void tp_terminate_transmission(UI_8 tp_handle, UI_8 result);

static void tp_set_first_frame_indication(UI_8 tp_handle);

static UI_8 tp_transmit_single_frame(UI_8 tp_handle);
static UI_8 tp_transmit_first_frame(UI_8 tp_handle);
static UI_8 tp_transmit_consecutive_frame(UI_8 tp_handle);
static UI_8 tp_transmit_flow_control(UI_8 tp_handle, UI_8 fs, UI_8 bs, UI_8 stmin);

static UI_8 tp_can_transmit(UI_8 tp_handle, const UI_8 *data_ptr);
static void tp_cancel_transmit(UI_8 tp_handle);

static UI_16 tp_get_separation_time(UI_8 stmin);
static void tp_monitor_reception_block_timer(UI_8 tp_handle);

/************************************************************************************************/
/* Local Functions                                                                              */
/************************************************************************************************/
/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_init_module(UI_8 tp_handle)
{
	/* Initialize reception and transmission state */
	tp_init_rx_state(tp_handle);
	tp_init_tx_state(tp_handle);
	/* Clear Control information */
	CanTP_BufCtrl[tp_handle].ReleaseReq = D_FALSE;
	CanTP_BufCtrl[tp_handle].LockStatus = D_FALSE;
	CanTP_BufCtrl[tp_handle].LockCnt = CANTP_RECEIVE_BLOCKED_CNT;
	/* Clear Indication */
	CanTP_Indication[tp_handle].FirstFrame = D_FALSE;
	CanTP_Indication[tp_handle].IndicationFlg = D_FALSE;
	CanTP_Indication[tp_handle].ErrResult = CANTP_N_RESULT_OK;
	/* Clear Confirmation */
	CanTP_Confirmation[tp_handle].ConfirmationFlg = D_FALSE;
	CanTP_Confirmation[tp_handle].ErrResult = CANTP_N_RESULT_OK;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_init_rx_state(UI_8 tp_handle)
{
	T_CanTP_RxCtrl *rx_ctrl_ptr = &CanTP_RxCtrl[tp_handle];

	rx_ctrl_ptr->RxStatus = CANTP_RX_STATE_IDLE;
	rx_ctrl_ptr->Timer = 0U;
	rx_ctrl_ptr->DataIndex = 0U;
	rx_ctrl_ptr->DataLength = 0U;
	rx_ctrl_ptr->BS = 0U;
	rx_ctrl_ptr->BSCnt = 0U;
	rx_ctrl_ptr->ST = 0U;
	rx_ctrl_ptr->ExpectedSN = 0U;
	rx_ctrl_ptr->Channel = CANTP_RX_CHANNEL_INVALID;
	rx_ctrl_ptr->AddrType = CANTP_ADDR_TYPE_PHYSICAL;
	rx_ctrl_ptr->FCTxReq = D_FALSE;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_init_tx_state(UI_8 tp_handle)
{
	T_CanTP_TxCtrl *tx_ctrl_ptr = &CanTP_TxCtrl[tp_handle];

	tx_ctrl_ptr->TxStatus = CANTP_TX_STATE_IDLE;
	tx_ctrl_ptr->Timer = 0U;
	tx_ctrl_ptr->DataPtr = D_NULL;
	tx_ctrl_ptr->DataIndex = 0U;
	tx_ctrl_ptr->DataLength = 0U;
	tx_ctrl_ptr->ST = 0U;
	tx_ctrl_ptr->STCnt = 0U;
	tx_ctrl_ptr->BS = 0U;
	tx_ctrl_ptr->BSCnt = 0U;
	tx_ctrl_ptr->SN = 0U;
	tx_ctrl_ptr->TxReq = D_FALSE;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_receive_msg(UI_8 tp_handle, UI_8 tp_rx_channel, const UI_8 rx_data_ptr[])
{
	UI_8 n_pcitype;

	n_pcitype = (UI_8)(rx_data_ptr[CANTP_POS_N_PCITYPE] & CANTP_N_PCITYPE_MASK);
	switch (n_pcitype) {
	case CANTP_N_PCITYPE_SF:
		tp_receive_single_frame(tp_handle, tp_rx_channel, rx_data_ptr);
		break;
	case CANTP_N_PCITYPE_FF:
		tp_receive_first_frame(tp_handle, tp_rx_channel, rx_data_ptr);
		break;
	case CANTP_N_PCITYPE_CF:
		tp_receive_consecutive_frame(tp_handle, tp_rx_channel, rx_data_ptr);
		break;
	case CANTP_N_PCITYPE_FC:
		tp_receive_flow_control(tp_handle, rx_data_ptr);
		break;
	default:
		/* As a general rule, arrival of an unexpected N_PDU from any node */
		/* shall be ignored. (ISO 15765-2) */
		break;
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_receive_single_frame(UI_8 tp_handle, UI_8 tp_rx_channel, const UI_8 rx_data_ptr[])
{
	UI_8 expected;
	UI_8 sf_dl;
	UI_8 i;

	/* Check if this SF is expected. */
	expected = tp_check_single_frame(tp_handle, tp_rx_channel);
	if (expected != D_FALSE) {
		/* Check if the buffer has been freed by the upper layer (or due to the timeout). */
		if (CanTP_BufCtrl[tp_handle].LockStatus == D_FALSE) {
			/* Read SF_DL */
			sf_dl = (UI_8)(rx_data_ptr[CANTP_POS_N_PCITYPE_AND_SF_DL] & CANTP_SF_DL_MASK);
			/* If the network layer receives an SF with an SF_DL equal to zero (0), */
			/* then the network layer shall ignore the received SF N_PDU. (ISO 15765-2) */
			if ((1U <= sf_dl) && (sf_dl <= CANTP_SF_DL)) {
				/* Copy the SF N_DATA */
				for (i = 0U; i < sf_dl; i++) {
					C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_MAIN].DataPtr[i] = rx_data_ptr[i + CANTP_POS_SF_N_DATA];
				}
				/* Completed the reception */
				/* Set the rx indication flag and received data length */
				/* issue the indication */
				*C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_MAIN].DataLenPtr = (UI_16)sf_dl;
				CanTP_RxCtrl[tp_handle].AddrType = C_CanTP_Cfg[tp_handle].RxChannelList[tp_rx_channel].AddrType;
				tp_terminate_reception(tp_handle, CANTP_N_RESULT_OK);

				/* Block the next reception until releasing from the upper layer. */
				CanTP_BufCtrl[tp_handle].LockStatus = D_TRUE;
			}
		}
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_receive_first_frame(UI_8 tp_handle, UI_8 tp_rx_channel, const UI_8 rx_data_ptr[])
{
	UI_8 expected;
	UI_16 ff_dl;
	UI_8 i;

	/* Check if this FF is expected. */
	expected = tp_check_first_frame(tp_handle, tp_rx_channel);
	if (expected != D_FALSE) {
		/* Check if the buffer has been freed by the upper layer (or due to the timeout). */
		if (CanTP_BufCtrl[tp_handle].LockStatus == D_FALSE) {
			/* Read FF_DL */
			ff_dl = ((UI_16)rx_data_ptr[CANTP_POS_N_PCITYPE_AND_FF_DL_HIGH] << 8U) & CANTP_FF_DL_HIGH_MASK;
			ff_dl |= (UI_16)rx_data_ptr[CANTP_POS_FF_DL_LOW] & CANTP_FF_DL_LOW_MASK;
			/* If the network layer receives an FF with FF_DL that is less than eight (8), */
			/* then the network layer shall ignore the received FF N_PDU and not transmit an FC N_PDU.*/
			if (CANTP_FF_DL <= ff_dl) {
				/* SeparationTime (STmin) shall be less than 25 ms (RS-DS01-4) */
				CanTP_RxCtrl[tp_handle].ST = 0U;
				/* BlockSize (BS) shall be 0 (RS-DS01-4) */
				CanTP_RxCtrl[tp_handle].BS = 0U;
				CanTP_RxCtrl[tp_handle].BSCnt = 0U;
				CanTP_RxCtrl[tp_handle].Timer = CANTP_N_BR;
				CanTP_RxCtrl[tp_handle].Channel = tp_rx_channel;

				/* Check the available receiver buffer size. */
				if (C_CanTP_Cfg[tp_handle].MaxDataLen < ff_dl) {
					/* The FF_DL is greater than the available receiver buffer size. */
					/* Send an FC N_PDU with the parameter FlowStatus=Overflow. */
					CanTP_RxCtrl[tp_handle].RxStatus = CANTP_RX_STATE_FC_OVFLW;
				} else {
					CanTP_RxCtrl[tp_handle].DataIndex = 0U;
					CanTP_RxCtrl[tp_handle].DataLength = ff_dl;
					/* Copy the FF N_DATA */
					for (i = 0; i < CANTP_FF_N_DATA_LEN; i++) {
						C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_MAIN].DataPtr[CanTP_RxCtrl[tp_handle].DataIndex] = rx_data_ptr[i + CANTP_POS_FF_N_DATA];
						CanTP_RxCtrl[tp_handle].DataIndex++;
					}
					/* Issue the N_USData_FF.indication */
					/* The upper layer can use this indication to stop the S3 Timer. */
					tp_set_first_frame_indication(tp_handle);

					CanTP_RxCtrl[tp_handle].RxStatus = CANTP_RX_STATE_FC;
					CanTP_RxCtrl[tp_handle].ExpectedSN = 1U;
				}
				/* Set the request flag in order to send the FC in the cyclic task. */
				CanTP_RxCtrl[tp_handle].FCTxReq = D_TRUE;

				/* In the current design, we do not transmit the FC in the ISR task. */
				/* If required, call tp_handle_receiver_state() here. */
				
			}
		}
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_receive_consecutive_frame(UI_8 tp_handle, UI_8 tp_rx_channel, const UI_8 rx_data_ptr[])
{
	UI_8 expected;
	UI_8 received_sn;
	UI_16 remaining_data_length;
	UI_8 i;

	/* Check if this CF is expected. */
	expected = tp_check_consecutive_frame(tp_handle, tp_rx_channel);
	if (expected != D_FALSE) {
		/* Check if the buffer has been freed by the upper layer (or due to the timeout). */
		if (CanTP_BufCtrl[tp_handle].LockStatus == D_FALSE) {
			/* Read SN */
			received_sn = rx_data_ptr[CANTP_POS_N_PCITYPE_AND_SN] & CANTP_SN_MASK;
			if (received_sn != CanTP_RxCtrl[tp_handle].ExpectedSN) {
				/* If a CF N_PDU message is received with an incorrect sequence number, */
				/* the message reception shall be aborted and */
				/* report it with the parameter N_WRONG_SN to the upper layer. (ISO 15765-2) */
				/* issue the indication */
				tp_terminate_reception(tp_handle, CANTP_N_RESULT_WRONG_SN);
			} else {
				/* correct SN received. */
				/* calculate the remaining data length */
				remaining_data_length = CanTP_RxCtrl[tp_handle].DataLength - CanTP_RxCtrl[tp_handle].DataIndex;
				if (CANTP_CF_N_DATA_LEN < remaining_data_length) {
					/* Copy the all CF N_DATA */
					for (i = 0U; i < CANTP_CF_N_DATA_LEN; i++) {
						C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_MAIN].DataPtr[CanTP_RxCtrl[tp_handle].DataIndex] = rx_data_ptr[i + CANTP_POS_CF_N_DATA];
						CanTP_RxCtrl[tp_handle].DataIndex++;
					}
					/* We will wait for the next CF */
					CanTP_RxCtrl[tp_handle].Timer = CANTP_N_CR;
					CanTP_RxCtrl[tp_handle].RxStatus = CANTP_RX_STATE_WAIT_FOR_CF;
					CanTP_RxCtrl[tp_handle].ExpectedSN = (CanTP_RxCtrl[tp_handle].ExpectedSN + 1) & CANTP_SN_MASK;
				} else {
					/* Copy the remaining CF N_DATA */
					for (i = 0; i < remaining_data_length; i++) {
						C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_MAIN].DataPtr[CanTP_RxCtrl[tp_handle].DataIndex] = rx_data_ptr[i + CANTP_POS_CF_N_DATA];
						CanTP_RxCtrl[tp_handle].DataIndex++;
					}
					/* Completed the segmented reception */
					/* Set the rx indication flag and received data length */
					/* issue the indication */
					*C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_MAIN].DataLenPtr = CanTP_RxCtrl[tp_handle].DataLength;
					CanTP_RxCtrl[tp_handle].AddrType = C_CanTP_Cfg[tp_handle].RxChannelList[tp_rx_channel].AddrType;
					tp_terminate_reception(tp_handle, CANTP_N_RESULT_OK);

					/* Block the next reception until releasing from the upper layer. */
					CanTP_BufCtrl[tp_handle].LockStatus = D_TRUE;
				}
			}
		}
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_receive_flow_control(UI_8 tp_handle, const UI_8 rx_data_ptr[])
{
	UI_8 fs;
	UI_8 bs;
	UI_8 stmin;

	/* Check if this FC is expected */
	/* If awaited, handle the FC N_PDU, otherwise ignore it. (ISO 15765-2) */
	if (CanTP_TxCtrl[tp_handle].TxStatus == CANTP_TX_STATE_WAIT_FOR_FC) {
		fs = rx_data_ptr[CANTP_POS_N_PCITYPE_AND_FS] & CANTP_FS_MASK;
		switch (fs) {
		case CANTP_FS_CTS:
			/* FS.CTS (ContinueToSend) */
			/* Read BS and STmin */
			bs = rx_data_ptr[CANTP_POS_BS];
			stmin = rx_data_ptr[CANTP_POS_STMIN];
			/* Save the received BS */
			CanTP_TxCtrl[tp_handle].BS = bs;
			/* BlockSizeCounter shall be equal to the BlockSize at the moment. */
			CanTP_TxCtrl[tp_handle].BSCnt = bs;
			/* Save the received STmin */
			CanTP_TxCtrl[tp_handle].ST = tp_get_separation_time(stmin);
			/* Let us use value=1 here. It means that we do not use STmin for the first CF transmission. */
			CanTP_TxCtrl[tp_handle].STCnt = 1U;

			CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_CF;
			CanTP_TxCtrl[tp_handle].Timer = CANTP_N_CS;
			CanTP_TxCtrl[tp_handle].TxReq = D_TRUE;

			/* In the current design, we do not transmit the First CF in the ISR task. */
			/* If required, call tp_handle_receiver_state() here. */

			break;
		case CANTP_FS_WT:
			/* FS.WT (Wait) */
			/* Restart the N_Bs timer. */
			CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_WAIT_FOR_FC;
			CanTP_TxCtrl[tp_handle].Timer = CANTP_N_BS;
			break;
		case CANTP_FS_OVFLW:
			/* FS.OVFLW (Overflow) */
			/* Abort the transmission of a segmented message and issue the confirmation */
			/* with the parameter <N_Result>=N_BUFFER_OVFLW. */
			tp_terminate_transmission(tp_handle, CANTP_N_RESULT_BUFFER_OVFLW);
			break;
		default:
			/* (ISO 15765-2 FS error handling) */
			/* If an FC N_PDU message is received with an invalid (reserved) FS parameter value, */
			/* the message transmission shall be aborted and issue the confirmation */
			/* with the parameter <N_Result>=N_INVALID_FS. */
			tp_terminate_transmission(tp_handle, CANTP_N_RESULT_INVALID_FS);
			break;
		}
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_8 tp_check_single_frame(UI_8 tp_handle, UI_8 tp_rx_channel)
{
	UI_8 expected;

	expected = D_FALSE;

	/* The Diagnostic server shall support half-duplex communication. (RS-DS01-6) */
	/* If a segmented transmission is in progress, */
	/* an unexpected arrival of N_PDU shall be ignored. (ISO 15765-2) */
	if (CanTP_TxCtrl[tp_handle].TxStatus == CANTP_TX_STATE_IDLE) {
		/* No segmented transmission is in progress. Let us check if this SF is expected. */
		if (CanTP_RxCtrl[tp_handle].RxStatus != CANTP_RX_STATE_IDLE) {
			/* A segmented reception is in progress. Check if the frame belongs to the current connection */
			/* If the frame is coming from other connection, ignore it. */
			if (CanTP_RxCtrl[tp_handle].Channel == tp_rx_channel) {
				/* Terminate the current reception and handle the SF N_PDU as the start of a new reception */
				/* Issue the N_USData.indication with <N_Result> set to N_UNEXP_PDU. */
				tp_terminate_reception(tp_handle, CANTP_N_RESULT_UNEXP_PDU);
				expected = D_TRUE;
			}
		} else {
			/* Neither a secmented transmission nor segmented reception is in progress. */
			/* Process the SF N_PDU as the start of a new reception. */
			expected = D_TRUE;
		}
	}

	return expected;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_8 tp_check_first_frame(UI_8 tp_handle, UI_8 tp_rx_channel)
{
	UI_8 expected;
	UI_8 address_type;

	expected = D_FALSE;

	/* Get the corresponding addressing type */
	address_type = C_CanTP_Cfg[tp_handle].RxChannelList[tp_rx_channel].AddrType;

	/* The Diagnostic server shall support half-duplex communication. (RS-DS01-6) */
	/* If a segmented transmission is in progress, */
	/* an unexpected arrival of N_PDU shall be ignored. (ISO 15765-2) */
	if (CanTP_TxCtrl[tp_handle].TxStatus == CANTP_TX_STATE_IDLE) {
		/* No segmented transmission is in progress. Check if this FF N_PDU's address type */
		/* Functionally addressed FF N_PDUs shall be ignored. (RS-DS03-3) */
		if (address_type != CANTP_ADDR_TYPE_FUNCTIONAL) {
			/* This is a physically addressed FF N_PDU, Check if this FF is expected. */
			if (CanTP_RxCtrl[tp_handle].RxStatus != CANTP_RX_STATE_IDLE) {
				/* A segmented reception is in progress. Check if the frame belongs to the current connection */
				/* If the frame is coming from other connection, ignore it. */
				if (CanTP_RxCtrl[tp_handle].Channel == tp_rx_channel) {
					/* Terminate the current reception and handle the FF N_PDU as the start of a new reception */
					/* Issue the N_USData.indication with <N_Result> set to N_UNEXP_PDU. */
					tp_terminate_reception(tp_handle, CANTP_N_RESULT_UNEXP_PDU);
					expected = D_TRUE;
				}
			} else {
				/* Neither a secmented transmission nor segmented reception is in progress. */
				/* Process the SF N_PDU as the start of a new reception. */
				expected = D_TRUE;
			}
		}
	}

	return expected;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_8 tp_check_consecutive_frame(UI_8 tp_handle, UI_8 tp_rx_channel)
{
	UI_8 expected;
	UI_8 address_type;

	expected = D_FALSE;

	/* Get the corresponding addressing type */
	address_type = C_CanTP_Cfg[tp_handle].RxChannelList[tp_rx_channel].AddrType;

	/* The Diagnostic server shall support half-duplex communication. (RS-DS01-6) */
	/* If a segmented transmission is in progress, */
	/* an unexpected arrival of N_PDU shall be ignored. (ISO 15765-2) */
	if (CanTP_TxCtrl[tp_handle].TxStatus == CANTP_TX_STATE_IDLE) {
		/* No segmented transmission is in progress. Check if this CF N_PDU's address type */
		/* Functionally addressed CF N_PDUs shall be ignored. (RS-DS03-3) */
		if (address_type != CANTP_ADDR_TYPE_FUNCTIONAL) {
			/* This is a physically addressed CF N_PDU, Check if this CF is expected. */
			if ((CanTP_RxCtrl[tp_handle].RxStatus == CANTP_RX_STATE_WAIT_FOR_CF) && (CanTP_RxCtrl[tp_handle].Channel == tp_rx_channel)) {
				/* We are waiting for the CF and the frame belongs to the current connection. */
				expected = D_TRUE;
			}
		}
	}

	return expected;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_ctrl_module(UI_8 tp_handle)
{
	tp_receiver_process(tp_handle);
	tp_sender_process(tp_handle);
	tp_monitor_reception_block_timer(tp_handle);
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_receiver_process(UI_8 tp_handle)
{
	UI_16 mask_level;

	CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

	if (CanTP_RxCtrl[tp_handle].Timer != 0U) {
		/* A segmented reception is in progress */
		CanTP_RxCtrl[tp_handle].Timer--;
		if (CanTP_RxCtrl[tp_handle].Timer == 0U) {
			/* Timeout */
			switch (CanTP_RxCtrl[tp_handle].RxStatus) {
			case CANTP_RX_STATE_WAIT_FOR_CF:
				/* Abort message reception and issue N_USData.indication */
				/* with <N_Result>=N_TIMEOUT_Cr. */
				tp_terminate_reception(tp_handle, CANTP_N_RESULT_TIMEOUT_CR);
				break;
			case CANTP_RX_STATE_FC:
			case CANTP_RX_STATE_FC_OVFLW:
				/* timeout N_Br*/
				/* Perfomance requirement value N_Br is described as */
				/* (N_Br + N_Ar) < 25 ms. (RS-DS01-5) */
				/* If the network layer cannot start transmission of FC, */
				/* we will handle this situation as N_Ar timeout. */
				tp_terminate_reception(tp_handle, CANTP_N_RESULT_TIMEOUT_A);
				break;
			case CANTP_RX_STATE_WAIT_FOR_FC_CONF:
			case CANTP_RX_STATE_WAIT_FOR_FC_OVFLW_CONF:
				/* FC confirmation timeout (N_Ar) */
				/* Abort message reception and issue N_USData.indication */
				/* with <N_Result>=N_TIMEOUT_A. */
				tp_terminate_reception(tp_handle, CANTP_N_RESULT_TIMEOUT_A);
				break;
			default:
				/* T.B.D. */
				break;
			}
		} else {
			/* Timeout not reached */
			tp_handle_receiver_state(tp_handle);
		}
	}

	CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);

}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_handle_receiver_state(UI_8 tp_handle)
{
	UI_8 transmit_fc;
	UI_8 fs;
	UI_8 bs;
	UI_8 stmin;

	transmit_fc = D_FALSE;
	if (CanTP_RxCtrl[tp_handle].FCTxReq != D_FALSE) {
		switch (CanTP_RxCtrl[tp_handle].RxStatus) {
		case CANTP_RX_STATE_FC:
			fs = CANTP_N_PCITYPE_FC | CANTP_FS_CTS;
			bs = CanTP_RxCtrl[tp_handle].BS;
			stmin = CanTP_RxCtrl[tp_handle].ST;
			transmit_fc = D_TRUE;
			break;
		case CANTP_RX_STATE_FC_OVFLW:
			fs = CANTP_N_PCITYPE_FC | CANTP_FS_OVFLW;
			bs = CanTP_RxCtrl[tp_handle].BS;
			stmin = CanTP_RxCtrl[tp_handle].ST;
			transmit_fc = D_TRUE;
			break;
		default:
			/* Unexpected state. */
			tp_terminate_reception(tp_handle, CANTP_N_RESULT_ERROR);
			break;
		}
	}
	if (transmit_fc != D_FALSE) {
		if (tp_transmit_flow_control(tp_handle, fs, bs, stmin) != D_FALSE) {
			/* The request has been accepted. clear request and update the Timer */
			CanTP_RxCtrl[tp_handle].FCTxReq = D_FALSE;
			if (CANTP_N_AR < CanTP_RxCtrl[tp_handle].Timer) {
				CanTP_RxCtrl[tp_handle].Timer = CANTP_N_AR;
			}
			switch (CanTP_RxCtrl[tp_handle].RxStatus) {
			case CANTP_RX_STATE_FC:
				CanTP_RxCtrl[tp_handle].RxStatus = CANTP_RX_STATE_WAIT_FOR_FC_CONF;
				break;
			case CANTP_RX_STATE_FC_OVFLW:
				CanTP_RxCtrl[tp_handle].RxStatus = CANTP_RX_STATE_WAIT_FOR_FC_OVFLW_CONF;
				break;
			default:
				/* Unexpected state. */
				tp_terminate_reception(tp_handle, CANTP_N_RESULT_ERROR);
				break;
			}
		}
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_sender_process(UI_8 tp_handle)
{
	UI_16 mask_level;

	CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

	if (CanTP_TxCtrl[tp_handle].Timer != 0U) {
		CanTP_TxCtrl[tp_handle].Timer--;
		if (CanTP_TxCtrl[tp_handle].Timer == 0U) {
			/* Timeout */
			switch (CanTP_TxCtrl[tp_handle].TxStatus) {
			case CANTP_TX_STATE_SF:
			case CANTP_TX_STATE_FF:
				/* We have set the timer N_As for SF/FF transmission just in case. */
				/* In this case, we issue the confirmation */
				/* with the parameter <N_Result>=N_TIMEOUT_A. */
				tp_terminate_transmission(tp_handle, CANTP_N_RESULT_TIMEOUT_A);
				break;
			case CANTP_TX_STATE_CF:
				/* timeout N_Cs*/
				/* Perfomance requirement value N_Cs is described as */
				/* (N_Cs + N_As) < 50 ms. (RS-DS01-5) */
				/* If the network layer cannot start transmission of CF, */
				/* we will handle this situation as N_As timeout. */
				tp_terminate_transmission(tp_handle, CANTP_N_RESULT_TIMEOUT_A);
				break;
			case CANTP_TX_STATE_WAIT_FOR_FC:
				/* timeout N_Bs */
				/* FlowControl N_PDU not received on the sender side. */
				/* Abort message transmission and issue N_USData.confirm with */
				/* <N_Result>=N_TIMEOUT_Bs. */
				tp_terminate_transmission(tp_handle, CANTP_N_RESULT_TIMEOUT_BS);
				break;
			case CANTP_TX_STATE_WAIT_FOR_SF_CONF:
			case CANTP_TX_STATE_WAIT_FOR_FF_CONF:
			case CANTP_TX_STATE_WAIT_FOR_CF_CONF:
				/* Timeout N_As */
				/* Any N_PDU not transmitted in time on the sender side. */
				/* Abort message transmission and issue N_USData.confirm with */
				/* <N_Result>=N_TIMEOUT_A. */
				tp_terminate_transmission(tp_handle, CANTP_N_RESULT_TIMEOUT_A);
				break;
			default:
				break;
			}
		} else {
			/* No timeout */
			tp_handle_sender_state(tp_handle);
		}
	}

	CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);

}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_handle_sender_state(UI_8 tp_handle)
{
	if (CanTP_TxCtrl[tp_handle].TxReq != D_FALSE) {
		switch (CanTP_TxCtrl[tp_handle].TxStatus) {
		case CANTP_TX_STATE_SF:
			if (tp_transmit_single_frame(tp_handle) != D_FALSE) {
				/* The request has been accepted. Clear the pending request */
				CanTP_TxCtrl[tp_handle].TxReq = D_FALSE;
				/* There is no requirement regarding the confirmation timeout of */
				/* a single frame transmission... Let us use the same parameter as a first frame transmission. */
				if (CANTP_N_AS < CanTP_TxCtrl[tp_handle].Timer) {
					CanTP_TxCtrl[tp_handle].Timer = CANTP_N_AS;
				}
				CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_WAIT_FOR_SF_CONF;
			}
			break;
		case CANTP_TX_STATE_FF:
			if (tp_transmit_first_frame(tp_handle) != D_FALSE) {
				/* The request has been accepted. Clear the pending request */
				CanTP_TxCtrl[tp_handle].TxReq = D_FALSE;
				if (CANTP_N_AS < CanTP_TxCtrl[tp_handle].Timer) {
					CanTP_TxCtrl[tp_handle].Timer = CANTP_N_AS;
				}
				CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_WAIT_FOR_FF_CONF;
			}
			break;
		case CANTP_TX_STATE_CF:
			if (CanTP_TxCtrl[tp_handle].STCnt != 0U) {
				CanTP_TxCtrl[tp_handle].STCnt--;
			}
			if (CanTP_TxCtrl[tp_handle].STCnt == 0U) {
				if (tp_transmit_consecutive_frame(tp_handle) != D_FALSE) {
					/* The request has been accepted. Clear the pending request */
					CanTP_TxCtrl[tp_handle].TxReq = D_FALSE;
					if (CANTP_N_AS < CanTP_TxCtrl[tp_handle].Timer) {
						CanTP_TxCtrl[tp_handle].Timer = CANTP_N_AS;
					}
					CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_WAIT_FOR_CF_CONF;
				}
			}
			break;
		default:
			break;
		}
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_tx_confirmation_receiver(UI_8 tp_handle)
{
	switch (CanTP_RxCtrl[tp_handle].RxStatus) {
	case CANTP_RX_STATE_WAIT_FOR_FC_CONF:
		CanTP_RxCtrl[tp_handle].Timer = CANTP_N_CR;
		CanTP_RxCtrl[tp_handle].RxStatus = CANTP_RX_STATE_WAIT_FOR_CF;
		break;
	case CANTP_RX_STATE_WAIT_FOR_FC_OVFLW_CONF:
		tp_terminate_reception(tp_handle, CANTP_N_RESULT_ERROR);
		break;
	default:
		break;
	}
	
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_tx_confirmation_sender(UI_8 tp_handle)
{
	switch (CanTP_TxCtrl[tp_handle].TxStatus) {
	case CANTP_TX_STATE_WAIT_FOR_SF_CONF:
		/* The transmission completed */
		/* Issue the confirmation */
		tp_terminate_transmission(tp_handle, CANTP_N_RESULT_OK);
		break;
	case CANTP_TX_STATE_WAIT_FOR_FF_CONF:
		/* The transmission of FirstFrame conpleted. */
		/* We will wait for FlowControl */
		CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_WAIT_FOR_FC;
		CanTP_TxCtrl[tp_handle].Timer = CANTP_N_BS;
		break;
	case CANTP_TX_STATE_WAIT_FOR_CF_CONF:
		/* Check if all segmented messages have been transmitted. */
		if (CanTP_TxCtrl[tp_handle].DataLength == CanTP_TxCtrl[tp_handle].DataIndex) {
			/* The segmented transmission completed. */
			/* Issue the confirmation */
			tp_terminate_transmission(tp_handle, CANTP_N_RESULT_OK);
		} else {
			/* There are some remaining data */
			/* Check the received BS */
			if (CanTP_TxCtrl[tp_handle].BS == 0U) {
				/* The received BS value is zero (0). */
				/* In this case, the sending network layer shall send all remaining */
				/* consecutive frames without any stop for further FC frams from the receiving network layer. */
				/* So, we will prepare the next CF transmission. */
				CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_CF;
				CanTP_TxCtrl[tp_handle].Timer = CANTP_N_CS;
				CanTP_TxCtrl[tp_handle].STCnt = CanTP_TxCtrl[tp_handle].ST;
				CanTP_TxCtrl[tp_handle].TxReq = D_TRUE;

			} else {
				/* The received BS value is not zero (0). */
				if (CanTP_TxCtrl[tp_handle].BSCnt == 0U) {
					/* All remaining blocks have been transmitted. */
					/* We will wait for the next FlowControl */
					CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_WAIT_FOR_FC;
					CanTP_TxCtrl[tp_handle].Timer = CANTP_N_BS;
				} else {
					/* Some blocks are remaining. */
					/* We will prepare the next CF transmission. */
					CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_CF;
					CanTP_TxCtrl[tp_handle].Timer = CANTP_N_CS;
					CanTP_TxCtrl[tp_handle].STCnt = CanTP_TxCtrl[tp_handle].ST;
					CanTP_TxCtrl[tp_handle].TxReq = D_TRUE;
				}
			}
		}
		break;
	default:
		break;
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_terminate_reception(UI_8 tp_handle, UI_8 result)
{
	/* If the receiver is waiting for the confirmation of FlowControl */
	if (CanTP_RxCtrl[tp_handle].RxStatus == CANTP_RX_STATE_WAIT_FOR_FC_CONF) {
		tp_cancel_transmit(tp_handle);
	}

	/* Check if the service execution has completed successfully */
	if (result == CANTP_N_RESULT_OK) {
		CanTP_Indication[tp_handle].IndicationFlg = D_TRUE;
	} else {
		CanTP_Indication[tp_handle].ErrResult = result;
	}

	/* Initialize the all parameters in the CanTP_RxCtrl */
	tp_init_rx_state(tp_handle);
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_terminate_transmission(UI_8 tp_handle, UI_8 result)
{
	tp_cancel_transmit(tp_handle);

	/* Check if the service execution has completed successfully */
	if (result == CANTP_N_RESULT_OK) {
		/* The service execution has completed successfully. */
		if (CanTP_BufCtrl[tp_handle].ReleaseReq != D_FALSE) {
			CanTP_BufCtrl[tp_handle].LockStatus = D_FALSE;
			CanTP_BufCtrl[tp_handle].LockCnt = CANTP_RECEIVE_BLOCKED_CNT;
		}
		CanTP_Confirmation[tp_handle].ConfirmationFlg = D_TRUE;
	} else {
		CanTP_BufCtrl[tp_handle].LockStatus = D_FALSE;
		CanTP_BufCtrl[tp_handle].LockCnt = CANTP_RECEIVE_BLOCKED_CNT;

		CanTP_Confirmation[tp_handle].ErrResult = result;
	}

	/* Initialize the all parameters in the CanTP_TxCtrl */
	tp_init_tx_state(tp_handle);

}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_set_first_frame_indication(UI_8 tp_handle)
{
	CanTP_Indication[tp_handle].FirstFrame = D_TRUE;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_8 tp_transmit_single_frame(UI_8 tp_handle)
{
	UI_8 tx_data_ptr[8];
	UI_8 i;
	UI_8 sf_dl;
	UI_8 accepted;

	accepted = D_FALSE;

	if (CanTP_TxCtrl[tp_handle].DataLength <= CANTP_SF_DL) {

		/* DLC for all diagnostic frames shall be 8. (RS-DS01-9) */
		/* Let us initialize the work buffer by using the padding byte value. */
		for (i = 0U; i < 8U; i++) {
			tx_data_ptr[i] = CANTP_PADDING_BYTE;
		}

		sf_dl = (UI_8)CanTP_TxCtrl[tp_handle].DataLength;
		tx_data_ptr[CANTP_POS_N_PCITYPE_AND_SF_DL] = CANTP_N_PCITYPE_SF | (sf_dl & CANTP_SF_DL_MASK);
		for (i = 0U; i < sf_dl; i++) {
			tx_data_ptr[i + CANTP_POS_SF_N_DATA] = CanTP_TxCtrl[tp_handle].DataPtr[i];
		}
		accepted = tp_can_transmit(tp_handle, (const UI_8*)tx_data_ptr);
	}

	return accepted;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_8 tp_transmit_first_frame(UI_8 tp_handle)
{
	UI_8 tx_data_ptr[8];
	UI_8 i;
	UI_16 ff_dl;
	UI_16 data_index;
	UI_8 accepted;

	accepted = D_FALSE;

	/* DLC for all diagnostic frames shall be 8. (RS-DS01-9) */
	/* Let us initialize the work buffer by using the padding byte value just in case. */
	for (i = 0U; i < 8U; i++) {
		tx_data_ptr[i] = CANTP_PADDING_BYTE;
	}

	/* Let us use the auto variable in order to keep the current DataIndex. */
	/* If the Can Driver did not accept the request, we would be able to use the current value for the retry. */
	data_index = CanTP_TxCtrl[tp_handle].DataIndex;

	ff_dl = CanTP_TxCtrl[tp_handle].DataLength;
	tx_data_ptr[CANTP_POS_N_PCITYPE_AND_FF_DL_HIGH] = CANTP_N_PCITYPE_FF | (UI_8)((ff_dl & CANTP_FF_DL_HIGH_MASK) >> 8U);
	tx_data_ptr[CANTP_POS_FF_DL_LOW] = (UI_8)(ff_dl & CANTP_FF_DL_LOW_MASK);

	for (i = 0U; i < CANTP_FF_N_DATA_LEN; i++) {
		tx_data_ptr[i + CANTP_POS_FF_N_DATA] = CanTP_TxCtrl[tp_handle].DataPtr[data_index];
		data_index++;
	}

	accepted = tp_can_transmit(tp_handle, (const UI_8*)tx_data_ptr);
	if (accepted != D_FALSE) {
		/* The DataIndex can be updated. */
		CanTP_TxCtrl[tp_handle].DataIndex = data_index;
	}

	return accepted;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_8 tp_transmit_consecutive_frame(UI_8 tp_handle)
{
	UI_8 tx_data_ptr[8];
	UI_8 i;
	UI_8 accepted;
	UI_16 data_index;
	UI_16 remaining_data_length;

	accepted = D_FALSE;

	/* DLC for all diagnostic frames shall be 8. (RS-DS01-9) */
	/* Let us initialize the work buffer by using the padding byte value just in case. */
	for (i = 0U; i < 8U; i++) {
		tx_data_ptr[i] = CANTP_PADDING_BYTE;
	}

	/* Let us use the auto variable in order to keep the current DataIndex. */
	/* If the Can Driver did not accept the request, we would be able to use the current value for the retry. */
	data_index = CanTP_TxCtrl[tp_handle].DataIndex;

	/* Set SN */
	tx_data_ptr[CANTP_POS_N_PCITYPE_AND_SN] = CANTP_N_PCITYPE_CF | (CanTP_TxCtrl[tp_handle].SN & CANTP_SN_MASK);

	/* calculate the remaining data length */
	remaining_data_length = CanTP_TxCtrl[tp_handle].DataLength - CanTP_TxCtrl[tp_handle].DataIndex;
	if (CANTP_CF_N_DATA_LEN < remaining_data_length) {
		/* Fill the all CF N_DATA */
		for (i = 0U; i < CANTP_CF_N_DATA_LEN; i++) {
			tx_data_ptr[i + CANTP_POS_CF_N_DATA] = CanTP_TxCtrl[tp_handle].DataPtr[data_index];
			data_index++;
		}
	} else {
		/* Use the remaining data */
		for (i = 0U; i < remaining_data_length; i++) {
			tx_data_ptr[i + CANTP_POS_CF_N_DATA] = CanTP_TxCtrl[tp_handle].DataPtr[data_index];
			data_index++;
		}
	}

	accepted = tp_can_transmit(tp_handle, (const UI_8*)tx_data_ptr);
	if (accepted != D_FALSE) {
		/* The DataIndex, BlockSizeCounter and SN can be updated. */
		CanTP_TxCtrl[tp_handle].DataIndex = data_index;
		CanTP_TxCtrl[tp_handle].SN = (CanTP_TxCtrl[tp_handle].SN + 1U) & CANTP_SN_MASK;
		if (CanTP_TxCtrl[tp_handle].BSCnt != 0U) {
			CanTP_TxCtrl[tp_handle].BSCnt--;
		}
	}

	return accepted;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_8 tp_transmit_flow_control(UI_8 tp_handle, UI_8 fs, UI_8 bs, UI_8 stmin)
{
	UI_8 tx_data_ptr[8];
	UI_8 i;
	UI_8 accepted;

	accepted = D_FALSE;

	/* DLC for all diagnostic frames shall be 8. (RS-DS01-9) */
	/* Let us initialize the work buffer by using the padding byte value. */
	for (i = 0U; i < 8U; i++) {
		tx_data_ptr[i] = CANTP_PADDING_BYTE;
	}

	tx_data_ptr[CANTP_POS_N_PCITYPE_AND_FS] = fs;
	tx_data_ptr[CANTP_POS_BS] = bs;
	tx_data_ptr[CANTP_POS_STMIN] = stmin;

	accepted = tp_can_transmit(tp_handle, (const UI_8*)tx_data_ptr);

	return accepted;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_8 tp_can_transmit(UI_8 tp_handle, const UI_8 *data_ptr)
{
	UI_8 accepted;
	UI_16 tx_handle;

	accepted = D_FALSE;
	tx_handle = C_CanTP_Cfg[tp_handle].TxHandle;
	if (CanDrvIF_SetTxReq(tx_handle, data_ptr) == CANDRVIF_OK) {
		accepted = D_TRUE;
	}
	return accepted;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_cancel_transmit(UI_8 tp_handle)
{
	UI_16 tx_handle;

	tx_handle = C_CanTP_Cfg[tp_handle].TxHandle;

	CanDrvIF_ClrTxReq(tx_handle);
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_16 tp_get_separation_time(UI_8 stmin)
{
	UI_16 task_cycles;
	/* Hex value    Description*/
	/* 00-7F        SeparationTime (STmin) range: 0 ms - 127 ms */
	/*              The units of STmin in the range 00 hex - 7F hex are absolute milliseconds (ms). */
	/* 80-F0        Reserved */
	/* F1-F9        SeparationTime (STmin) range: 100 us - 900 us */
	/*              The units of STmin in the range F1 hex - F9 hex are even 100 microseconds (us), */
	/*              where parameter value F1 hex represents 100 us and parameter value F9 hex represents 900 us. */
	/* FA-FF        Reserved */

	if ((stmin & 0x80U) != 0U) {
		if ((0xF1U <= stmin) && (stmin <= 0xF9U)) {
			/* 100 us - 900 us */
			/* The parameter value is valid but we cannot handle this range due to the tp task cycle. */
			/* We use 1 task cycle in this case. */
			task_cycles = 1U;
		} else {
			/* Reseved ST parameter value. We shall use the longest ST value (127 ms). */
			task_cycles = (UI_16)((127U + (CANTP_MAIN_CYCLE - 1U)) / CANTP_MAIN_CYCLE);

		}
	} else {
		/* 0 ms - 127ms */
		if (stmin == 0U) {
			task_cycles = 1U;
		} else {
			task_cycles = (UI_16)((stmin + (CANTP_MAIN_CYCLE - 1U)) / CANTP_MAIN_CYCLE);
		}
	}
	return task_cycles;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void tp_monitor_reception_block_timer(UI_8 tp_handle)
{
	/* This function is called to prevent the buffer from permanent lock. */
	/* The upper layer shall have responsibility for releasing the buffer. */
	if (CanTP_BufCtrl[tp_handle].LockStatus == D_FALSE) {
		CanTP_BufCtrl[tp_handle].LockCnt = CANTP_RECEIVE_BLOCKED_CNT;
	} else {
		if (0U < CanTP_BufCtrl[tp_handle].LockCnt) {
			CanTP_BufCtrl[tp_handle].LockCnt--;
		}
		if (CanTP_BufCtrl[tp_handle].LockCnt == 0) {
			CanTP_BufCtrl[tp_handle].LockStatus = D_FALSE;
		}
	}
}

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanTP_Init(void)
{
	UI_8 tp_handle;

	for (tp_handle = 0U; tp_handle < CANTP_HANDLE_CNT; tp_handle++) {
		/* Initialize Tp module */
		tp_init_module(tp_handle);
		/* Enable Tp module */
		CanTP_EnableFlg[tp_handle] = D_TRUE;
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanTP_Main(void)
{
	UI_8 tp_handle;

	for (tp_handle = 0U; tp_handle < CANTP_HANDLE_CNT; tp_handle++) {
		if (CanTP_EnableFlg[tp_handle] != D_FALSE) {
			tp_ctrl_module(tp_handle);
		} else {
			tp_init_module(tp_handle);
		}
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanTP_Enable(const UI_8 tp_handle, const UI_8 enable)
{
	if (tp_handle < CANTP_HANDLE_CNT) {
		CanTP_EnableFlg[tp_handle] = enable;
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
const T_CanTP_DataBuf* CanTP_GetDataBuf(const UI_8 tp_handle, const UI_8 buf_type)
{
	const T_CanTP_DataBuf *buf_ptr;

	if ((tp_handle < CANTP_HANDLE_CNT) && (buf_type < CANTP_BUF_TYPE_CNT)) {
		buf_ptr = &C_CanTP_DataBuf[tp_handle][buf_type];
	} else {
		buf_ptr = D_NULL;
	}

	return buf_ptr;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_8 CanTP_SetTxReq(const UI_8 tp_handle, const UI_8 buf_type)
{
	UI_16 mask_level;
	UI_8 accepted;
	UI_16 max_data_length;
	UI_16 data_length;
	UI_8 *data_ptr;
	UI_8 release_req;

	accepted = D_FALSE;

	if ((tp_handle < CANTP_HANDLE_CNT) && (buf_type < CANTP_BUF_TYPE_CNT)) {

		if (buf_type == CANTP_BUF_TYPE_MAIN) {
			max_data_length = C_CanTP_Cfg[tp_handle].MaxDataLen;
			data_length = *C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_MAIN].DataLenPtr;
			data_ptr = C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_MAIN].DataPtr;
			release_req = D_TRUE;
		} else {
			max_data_length = CANTP_SF_DL;
			data_length = *C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_SUB].DataLenPtr;
			data_ptr = C_CanTP_DataBuf[tp_handle][CANTP_BUF_TYPE_SUB].DataPtr;
			release_req = D_FALSE;
		}

		CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

		if (CanTP_TxCtrl[tp_handle].TxStatus == CANTP_TX_STATE_IDLE) {
			/* No transmission is in progress. */
			/* Check the requested data length. */
			/* According to the ISO 15765-2, at least 1 byte data is required. */
			if ((1U <= data_length) && (data_length <= max_data_length)) {
				/* The requested data length is valid, accept the request. */
				accepted = D_TRUE;
				/* Set the unlock request to accept the next reception after the transmission. */
				CanTP_BufCtrl[tp_handle].ReleaseReq = release_req;

				if (data_length <= CANTP_SF_DL) {
					/* We can use the single frame transmission. */
					CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_SF;
				} else {
					/* We have to use the multi frame transmission. */
					CanTP_TxCtrl[tp_handle].TxStatus = CANTP_TX_STATE_FF;
					CanTP_TxCtrl[tp_handle].SN = 1U;
				}
				CanTP_TxCtrl[tp_handle].DataPtr = data_ptr;
				CanTP_TxCtrl[tp_handle].DataIndex = 0U;
				CanTP_TxCtrl[tp_handle].DataLength = data_length;
				/* Let us use N_As for the performance requirement value */
				CanTP_TxCtrl[tp_handle].Timer = CANTP_N_AS;
				CanTP_TxCtrl[tp_handle].TxReq = D_TRUE;

				/* Try to transmit the message */
				tp_handle_sender_state(tp_handle);

			}
		}

		CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);
	}

	return accepted;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanTP_ReleaseBuf(const UI_8 tp_handle)
{
	UI_16 mask_level;

	if (tp_handle < CANTP_HANDLE_CNT) {

		CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

		CanTP_BufCtrl[tp_handle].LockStatus = D_FALSE;
		CanTP_BufCtrl[tp_handle].LockCnt = CANTP_RECEIVE_BLOCKED_CNT;

		CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_8 CanTP_ChkFirstFrame(const UI_8 tp_handle)
{
	UI_16 mask_level;
	UI_8 flg;

	flg = D_FALSE;
	if (tp_handle < CANTP_HANDLE_CNT) {

		CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

		flg = CanTP_Indication[tp_handle].FirstFrame;
		CanTP_Indication[tp_handle].FirstFrame = D_FALSE;

		CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);
	}

	return flg;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_8 CanTP_ChkIndication(const UI_8 tp_handle)
{
	UI_16 mask_level;
	UI_8 flg;

	flg = D_FALSE;
	if (tp_handle < CANTP_HANDLE_CNT) {

		CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

		flg = CanTP_Indication[tp_handle].IndicationFlg;
		CanTP_Indication[tp_handle].IndicationFlg = D_FALSE;

		CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);
	}

	return flg;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_8 CanTP_ChkErrIndication(const UI_8 tp_handle)
{
	UI_16 mask_level;
	UI_8 result;

	result = CANTP_N_RESULT_OK;
	if (tp_handle < CANTP_HANDLE_CNT) {

		CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

		result = CanTP_Indication[tp_handle].ErrResult;
		CanTP_Indication[tp_handle].ErrResult = CANTP_N_RESULT_OK;

		CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);
	}

	return result;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_8 CanTP_GetRequestedAddrType(const UI_8 tp_handle)
{
	UI_16 mask_level;
	UI_8 address_type;

	address_type = CANTP_ADDR_TYPE_PHYSICAL;
	if (tp_handle < CANTP_HANDLE_CNT) {

		CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

		address_type = CanTP_RxCtrl[tp_handle].AddrType;

		CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);
	}

	return address_type;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_8 CanTP_ChkConfirmation(const UI_8 tp_handle)
{
	UI_16 mask_level;
	UI_8 flg;

	flg = D_FALSE;
	if (tp_handle < CANTP_HANDLE_CNT) {

		CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

		flg = CanTP_Confirmation[tp_handle].ConfirmationFlg;
		CanTP_Confirmation[tp_handle].ConfirmationFlg = D_FALSE;

		CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);
	}

	return flg;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_8 CanTP_ChkErrConfirmation(const UI_8 tp_handle)
{
	UI_16 mask_level;
	UI_8 result;

	result = CANTP_N_RESULT_OK;
	if (tp_handle < CANTP_HANDLE_CNT) {

		CanDrvIF_DisableIntr(C_CanTP_Cfg[tp_handle].Controller, &mask_level);

		result = CanTP_Confirmation[tp_handle].ErrResult;
		CanTP_Confirmation[tp_handle].ErrResult = CANTP_N_RESULT_OK;

		CanDrvIF_EnableIntr(C_CanTP_Cfg[tp_handle].Controller, mask_level);
	}

	return result;
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanTP_TxCancelNotification(const UI_16 tx_handle)
{
	/* T.B.D. */
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanTP_TxConfirmation(const UI_16 tx_handle)
{
	UI_8 tp_handle;

	for (tp_handle = 0U; tp_handle < CANTP_HANDLE_CNT; tp_handle++) {
		if (C_CanTP_Cfg[tp_handle].TxHandle == tx_handle) {
			/* Sender related */
			switch (CanTP_TxCtrl[tp_handle].TxStatus) {
			case CANTP_TX_STATE_WAIT_FOR_SF_CONF:
			case CANTP_TX_STATE_WAIT_FOR_FF_CONF:
			case CANTP_TX_STATE_WAIT_FOR_CF_CONF:
				tp_tx_confirmation_sender(tp_handle);
				break;
			default:
				break;
			}
			/* Receiver related */
			switch (CanTP_RxCtrl[tp_handle].RxStatus) {
			case CANTP_RX_STATE_WAIT_FOR_FC_CONF:
			case CANTP_RX_STATE_WAIT_FOR_FC_OVFLW_CONF:
				tp_tx_confirmation_receiver(tp_handle);
				break;
			default:
				break;
			}

			/* terminate the loop */
			break;
		}
	}
}

/************************************************************************************************/
/* Function name    :                                                                           */
/* Description      :                                                                           */
/* Argument         :                                                                           */
/* Return value     :                                                                           */
/* Programmed by    :                                                                           */
/* Date             : YYYY/MM/DD                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanTP_RxIndication(const UI_16 rx_handle, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[])
{
	UI_8 tp_rx_channel;
	UI_8 tp_handle;
	UI_8 valid_msg_received;

	/* DLC for all diagnostic frames shall be 8. (RS-DS01-9) */
	if ((data_length == 8U) && (data_ptr != D_NULL)) {
		valid_msg_received = D_FALSE;
		for (tp_handle = 0U; (valid_msg_received == D_FALSE) && (tp_handle < CANTP_HANDLE_CNT); tp_handle++) {
			if (CanTP_EnableFlg[tp_handle] != D_FALSE) {
				for (tp_rx_channel = 0U; tp_rx_channel < CANTP_RX_CHANNEL_CNT; tp_rx_channel++) {
					if (rx_handle == C_CanTP_Cfg[tp_handle].RxChannelList[tp_rx_channel].RxHandle) {
						tp_receive_msg(tp_handle, tp_rx_channel, data_ptr);
						valid_msg_received = D_TRUE;
						break;
					}
				}
			}
		}
	}
}

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/
