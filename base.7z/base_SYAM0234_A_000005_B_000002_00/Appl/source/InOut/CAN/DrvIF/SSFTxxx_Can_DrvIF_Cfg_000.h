/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFT                                                                      */
/*----------------------------------------------------------------------------------------------*/
/* CPU              : FR81                                                                      */
/* Date             : 26 Feb. 2019                                                              */
/*----------------------------------------------------------------------------------------------*/
/* Programmed by    : PF1                                                                       */
/* Copyrights       : Nippon Seiki Co., Ltd.                                                    */
/*----------------------------------------------------------------------------------------------*/
/* Powered by       : CAN Configuration File Generator (0.8.0.0)                                */
/************************************************************************************************/


#ifndef SSFTXXX_CANDRVIF_CFG_000_H
#define SSFTXXX_CANDRVIF_CFG_000_H

#define CANDRVIF_DRV_INVALID (0U)
#define CANDRVIF_DRV_16FX    (1U)
#define CANDRVIF_DRV_FR81    (2U)
#define CANDRVIF_DRV_RL78    (3U)
#define CANDRVIF_DRV_S6J3370 (4U)
#define CANDRVIF_DRV_TYPE CANDRVIF_DRV_RL78

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"

#if (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_INVALID)
#error "Unkown driver type is defined."
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_16FX)
#include "SSFTSTD_16FXCan_Drv_000.h"
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_FR81)
#include "SSFTSTD_FR81Can_Drv_000.h"
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_RL78)
#include "SSFTSTD_RL78Can_Drv_000.h"
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_S6J3370)
#include "SSFTSTD_S6J3370Can_Drv_001.h"
#else
#error "Unkown driver type is defined."
#endif

/************************************************************************************************/
/* Global Macros                                                                                */
/************************************************************************************************/
#define CANDRVIF_MAIN_CYCLE (10U) /* 10 msec */

/* Definitions to be used for identifying the interrupt signal (reason) in CanDrvIF_IntrMain(). */
#if (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_INVALID)
#error "Unkown driver type is defined."
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_16FX)
#define CANDRVIF_INTR_SIGNAL_CAN ((UI_8)CANDRV_INTR_SIGNAL_CAN)
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_FR81)
#define CANDRVIF_INTR_SIGNAL_CAN ((UI_8)CANDRV_INTR_SIGNAL_CAN)
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_RL78)
#define CANDRVIF_INTR_SIGNAL_CAN ((UI_8)CANDRV_INTR_SIGNAL_CAN)
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_S6J3370)
#define CANDRVIF_INTR_SIGNAL_CAN ((UI_8)CANDRV_INTR_SIGNAL_CAN)
#else
#error "Unkown driver type is defined."
#endif

/* Definitions to be used as an operation command for CanDrvIF_CtrlState(). */
#define CANDRVIF_CMD_STOP           ((UI_8)CANDRV_CMD_STOP)
#define CANDRVIF_CMD_START          ((UI_8)CANDRV_CMD_START)
#define CANDRVIF_CMD_START_WITH_CHK ((UI_8)CANDRV_CMD_START_WITH_CHK)
#define CANDRVIF_CMD_CNT ((UI_8)3U)

/* Definitions of CAN Frame Format */
#define CANDRVIF_CAN_STANDARD_FRAME ((UI_8)CANDRV_CAN_STANDARD_FRAME)
#define CANDRVIF_CAN_EXTENDED_FRAME ((UI_8)CANDRV_CAN_EXTENDED_FRAME)
#define CANDRVIF_FRAME_FORMAT_CNT ((UI_8)2U)


/* Identification numbers of the used Controllers */
#define CANDRVIF_CONTROLLER_FCAN ((UI_8)CANDRV_CONTROLLER_0) /* Controller index: 0 */
#define CANDRVIF_CONTROLLER_CNT ((UI_8)1U)

/* Identification numbers of the TxHandle */
#define CANDRVIFTX_HND_22E (0U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000022E, DataLen: 2 */
#define CANDRVIFTX_HND_22D (1U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000022D, DataLen: 4 */
#define CANDRVIFTX_HND_240 (2U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000240, DataLen: 1 */
#define CANDRVIFTX_HND_610 (3U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000610, DataLen: 8 */
#define CANDRVIFTX_HND_5A1 (4U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x000005A1, DataLen: 3 */
#define CANDRVIFTX_HANDLE_CNT (5U)

/* Identification numbers of the RxHandle */
#define CANDRVIFRX_HND_401 ( 0U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000401, DataLen: 8 */
#define CANDRVIFRX_HND_23A ( 1U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000023A, DataLen: 8 */
#define CANDRVIFRX_HND_23E ( 2U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000023E, DataLen: 8 */
#define CANDRVIFRX_HND_209 ( 3U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000209, DataLen: 8 */
#define CANDRVIFRX_HND_215 ( 4U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000215, DataLen: 8 */
#define CANDRVIFRX_HND_22A ( 5U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000022A, DataLen: 8 */
#define CANDRVIFRX_HND_20A ( 6U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x0000020A, DataLen: 8 */
#define CANDRVIFRX_HND_216 ( 7U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000216, DataLen: 8 */
#define CANDRVIFRX_HND_245 ( 8U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000245, DataLen: 8 */
#define CANDRVIFRX_HND_600 ( 9U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x00000600, DataLen: 8 */
#define CANDRVIFRX_HND_7DF (10U) /* CANDRVIF_CONTROLLER_FCAN, Frame Format: CAN_Standard, ID: 0x000007DF, DataLen: 8 */
#define CANDRVIFRX_HANDLE_CNT (11U)


/************************************************************************************************/
/* Global Data Types                                                                            */
/************************************************************************************************/
#if (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_INVALID)
#error "Unkown driver type is defined."
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_16FX)
typedef UI_16 T_CANDRVIF_SIZE_T;
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_FR81)
typedef UI_32 T_CANDRVIF_SIZE_T;
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_RL78)
typedef UI_16 T_CANDRVIF_SIZE_T;
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_S6J3370)
typedef UI_32 T_CANDRVIF_SIZE_T;
#else
#error "Unkown driver type is defined."
#endif

/************************************************************************************************/
/* Global Data                                                                                  */
/************************************************************************************************/

/************************************************************************************************/
/* Global Constants                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Callback Functions                                                                           */
/************************************************************************************************/

/************************************************************************************************/
/*                                                                                              */
/* The section below is related to the CAN Driver Interface.                                    */
/*                                                                                              */
/************************************************************************************************/
#ifdef SSFTSTD_CAN_DRVIF_000_INTERNAL
/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#if (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_INVALID)
#error "Unkown driver type is defined."
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_16FX)
#include "SSFTSTD_16FXIntr_Drv_001.h"
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_FR81)
#include "SSFTSTD_FR81_Interrupt_Drv.h"
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_RL78)
#include "SSFTSTD_RL78Intr_Drv_001.h"
#elif (CANDRVIF_DRV_TYPE == CANDRVIF_DRV_S6J3370)
#include "SSFTSTD_S6J3370Intr_Drv_001.h"
#else
#error "Unkown driver type is defined."
#endif


#include "SSFTSTD_Can_IL_000.h"

/************************************************************************************************/
/* Local Macros                                                                                 */
/************************************************************************************************/
/* Index count for bit flag arrays */
#define CANDRVIFTX_BIT_FLG_INDEX_CNT (((UI_16)CANDRVIFTX_HANDLE_CNT / 16U) + 1U)
#define CANDRVIFRX_BIT_FLG_INDEX_CNT (((UI_16)CANDRVIFRX_HANDLE_CNT / 16U) + 1U)

/* Interrupt mask level */
#define CANDRVIF0_INTR_MASK_LEVEL ((UI_16)CAN_INTR_LEVEL_PRIORITY_1)

/* Timeout count */
#define CANDRVIF_TIMER_STATE_TIMEOUT ((UI_16)((200U + (CANDRVIF_MAIN_CYCLE - 1U)) / CANDRVIF_MAIN_CYCLE))
#define CANDRVIF_TIMER_TX_TIMEOUT    ((UI_16)((200U + (CANDRVIF_MAIN_CYCLE - 1U)) / CANDRVIF_MAIN_CYCLE))

/* Tx Data Length */
#define CANDRVIFTX_DATA_LEN_22E (2U)
#define CANDRVIFTX_DATA_LEN_22D (4U)
#define CANDRVIFTX_DATA_LEN_240 (1U)
#define CANDRVIFTX_DATA_LEN_610 (8U)
#define CANDRVIFTX_DATA_LEN_5A1 (3U)

/* Rx Data Length */
#define CANDRVIFRX_DATA_LEN_401 (8U)
#define CANDRVIFRX_DATA_LEN_23A (8U)
#define CANDRVIFRX_DATA_LEN_23E (8U)
#define CANDRVIFRX_DATA_LEN_209 (8U)
#define CANDRVIFRX_DATA_LEN_215 (8U)
#define CANDRVIFRX_DATA_LEN_22A (8U)
#define CANDRVIFRX_DATA_LEN_20A (8U)
#define CANDRVIFRX_DATA_LEN_216 (8U)
#define CANDRVIFRX_DATA_LEN_245 (8U)
#define CANDRVIFRX_DATA_LEN_600 (8U)
#define CANDRVIFRX_DATA_LEN_7DF (8U)

/* TxMsgObj Count */
#define CANDRVIF0_TX_MSG_OBJ_CNT (3U)


/************************************************************************************************/
/* Callback Function Types                                                                      */
/************************************************************************************************/
/* ControllerBusOff */
typedef void (*T_CanDrvIF_ControllerBusOffFunc) (const UI_8 controller);
/* TxConfirmation */
typedef void (*T_CanDrvIF_TxConfirmationFunc) (const UI_16 tx_handle);
/* TxCancelNotification */
typedef void (*T_CanDrvIF_TxCancelNotificationFunc) (const UI_16 tx_handle);
/* RxIndication */
typedef void (*T_CanDrvIF_RxIndicationFunc) (const UI_16 rx_handle, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[]);


/************************************************************************************************/
/* Local Data Types                                                                             */
/************************************************************************************************/
typedef struct
{
	UI_8  Controller;
	UI_16 TxMsgObjIndex;
	UI_8  FrameFormat;
	UI_32 Id;
	UI_8  DataLen;
	UI_8 *DataPtr;

	/* callback function */
	T_CanDrvIF_TxConfirmationFunc       TxConfirmationFunc;
	T_CanDrvIF_TxCancelNotificationFunc TxCancelNotificationFunc;

} T_CanDrvIF_TxCfg;

typedef struct
{
	UI_8  Controller;
	UI_8  FrameFormat;
	UI_32 Id;
    UI_8  DataLen;
    UI_8 *DataPtr;

	/* callback function */
	T_CanDrvIF_RxIndicationFunc RxIndicationFunc;

} T_CanDrvIF_RxCfg;

typedef struct
{
	UI_32 IdInfo;
	UI_16 RxHandle;

} T_CanDrvIF_HashTbl;


typedef struct
{
	UI_32 IdInfo;
	UI_32 IdMask;
	UI_16 RxHandle;

} T_CanDrvIF_LinearTbl;

typedef struct
{
	UI_16 IndexTblStdCnt;
	const UI_16 *IndexTblStdPtr;

	UI_16 HashTblStdCnt;
	const T_CanDrvIF_HashTbl *HashTblStdPtr;

	UI_16 LinearTblStdCnt;
	const T_CanDrvIF_LinearTbl *LinearTblStdPtr;

	UI_16 IndexTblExtCnt;
	const UI_16 *IndexTblExtPtr;

	UI_16 HashTblExtCnt;
	const T_CanDrvIF_HashTbl *HashTblExtPtr;

	UI_16 LinearTblExtCnt;
	const T_CanDrvIF_LinearTbl *LinearTblExtPtr;
	
} T_CanDrvIF_RxSearchTbl;

typedef struct
{
	UI_8  TxStatus;
	UI_16 TxHandle;
	UI_16 TxTimeoutCnt;
} T_CanDrvIF_TxMsgObj;

typedef struct
{
	UI_16 IntrMaskLevel;

	const UI_16 *TxBitFlgControllerMaskPtr;
	const UI_16 *RxBitFlgControllerMaskPtr;
	const T_CanDrvIF_RxSearchTbl *RxSearchTblPtr;

	/* TxMsgObj */
	UI_16                TxMsgObjCnt;
	T_CanDrvIF_TxMsgObj *TxMsgObjPtr;
	const UI_16 (*TxBitFlgTxMsgObjMaskPtr)[CANDRVIFTX_BIT_FLG_INDEX_CNT];

	/* callback function */
	T_CanDrvIF_ControllerBusOffFunc ControllerBusOffFunc;
} T_CanDrvIF_Cfg;

/************************************************************************************************/
/* Local Data                                                                                   */
/************************************************************************************************/
/* RAM������section 2�̊J�n */
#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA RAM2SEC
#else
 #define START_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

/* Tx Data */
static UI_8 CanDrvIF_TxData_22E[CANDRVIFTX_DATA_LEN_22E];
static UI_8 CanDrvIF_TxData_22D[CANDRVIFTX_DATA_LEN_22D];
static UI_8 CanDrvIF_TxData_240[CANDRVIFTX_DATA_LEN_240];
static UI_8 CanDrvIF_TxData_610[CANDRVIFTX_DATA_LEN_610];
static UI_8 CanDrvIF_TxData_5A1[CANDRVIFTX_DATA_LEN_5A1];

/* Rx Data */
static UI_8 CanDrvIF_RxData_401[CANDRVIFRX_DATA_LEN_401];
static UI_8 CanDrvIF_RxData_23A[CANDRVIFRX_DATA_LEN_23A];
static UI_8 CanDrvIF_RxData_23E[CANDRVIFRX_DATA_LEN_23E];
static UI_8 CanDrvIF_RxData_209[CANDRVIFRX_DATA_LEN_209];
static UI_8 CanDrvIF_RxData_215[CANDRVIFRX_DATA_LEN_215];
static UI_8 CanDrvIF_RxData_22A[CANDRVIFRX_DATA_LEN_22A];
static UI_8 CanDrvIF_RxData_20A[CANDRVIFRX_DATA_LEN_20A];
static UI_8 CanDrvIF_RxData_216[CANDRVIFRX_DATA_LEN_216];
static UI_8 CanDrvIF_RxData_245[CANDRVIFRX_DATA_LEN_245];
static UI_8 CanDrvIF_RxData_600[CANDRVIFRX_DATA_LEN_600];
static UI_8 CanDrvIF_RxData_7DF[CANDRVIFRX_DATA_LEN_7DF];

/* TxMsgObj */
static T_CanDrvIF_TxMsgObj CanDrvIF0_TxMsgObj[CANDRVIF0_TX_MSG_OBJ_CNT];

#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA @@DATA
#else
 #define STOP_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

/************************************************************************************************/
/* Local Constants                                                                              */
/************************************************************************************************/
/* TxCfg */
static const T_CanDrvIF_TxCfg C_CanDrvIF_TxCfg[CANDRVIFTX_HANDLE_CNT + 1U] =
{
	/* CANDRVIFTX_HND_22E */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* TxMsgObjIndex */
		0U,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x0000022EU,
		/* DataLen */
		CANDRVIFTX_DATA_LEN_22E,
		/* DataPtr */
		CanDrvIF_TxData_22E,
		/* TxConfirmationFunc */
		D_NULL,
		/* TxCancelNotificationFunc */
		D_NULL
	},
	/* CANDRVIFTX_HND_22D */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* TxMsgObjIndex */
		0U,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x0000022DU,
		/* DataLen */
		CANDRVIFTX_DATA_LEN_22D,
		/* DataPtr */
		CanDrvIF_TxData_22D,
		/* TxConfirmationFunc */
		D_NULL,
		/* TxCancelNotificationFunc */
		D_NULL
	},
	/* CANDRVIFTX_HND_240 */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* TxMsgObjIndex */
		0U,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x00000240U,
		/* DataLen */
		CANDRVIFTX_DATA_LEN_240,
		/* DataPtr */
		CanDrvIF_TxData_240,
		/* TxConfirmationFunc */
		D_NULL,
		/* TxCancelNotificationFunc */
		D_NULL
	},
	/* CANDRVIFTX_HND_610 */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* TxMsgObjIndex */
		0U,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x00000610U,
		/* DataLen */
		CANDRVIFTX_DATA_LEN_610,
		/* DataPtr */
		CanDrvIF_TxData_610,
		/* TxConfirmationFunc */
		D_NULL,
		/* TxCancelNotificationFunc */
		D_NULL
	},
	/* CANDRVIFTX_HND_5A1 */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* TxMsgObjIndex */
		0U,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x000005A1U,
		/* DataLen */
		CANDRVIFTX_DATA_LEN_5A1,
		/* DataPtr */
		CanDrvIF_TxData_5A1,
		/* TxConfirmationFunc */
		D_NULL,
		/* TxCancelNotificationFunc */
		D_NULL
	},
	/* dummy */ {0}
};

/* RxCfg */
static const T_CanDrvIF_RxCfg C_CanDrvIF_RxCfg[CANDRVIFRX_HANDLE_CNT + 1U] =
{
	/* CANDRVIFRX_HND_401 */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x00000401U,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_401,
		/* DataPtr */
		CanDrvIF_RxData_401,
		/* RxIndicationFunc */
		D_NULL
	},
	/* CANDRVIFRX_HND_23A */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x0000023AU,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_23A,
		/* DataPtr */
		CanDrvIF_RxData_23A,
		/* RxIndicationFunc */
		D_NULL
	},
	/* CANDRVIFRX_HND_23E */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x0000023EU,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_23E,
		/* DataPtr */
		CanDrvIF_RxData_23E,
		/* RxIndicationFunc */
		D_NULL
	},
	/* CANDRVIFRX_HND_209 */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x00000209U,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_209,
		/* DataPtr */
		CanDrvIF_RxData_209,
		/* RxIndicationFunc */
		&CanILRx_RxIndication_209
	},
	/* CANDRVIFRX_HND_215 */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x00000215U,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_215,
		/* DataPtr */
		CanDrvIF_RxData_215,
		/* RxIndicationFunc */
		D_NULL
	},
	/* CANDRVIFRX_HND_22A */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x0000022AU,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_22A,
		/* DataPtr */
		CanDrvIF_RxData_22A,
		/* RxIndicationFunc */
		D_NULL
	},
	/* CANDRVIFRX_HND_20A */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_STANDARD_FRAME,
		/* Id */
		0x0000020AU,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_20A,
		/* DataPtr */
		CanDrvIF_RxData_20A,
		/* RxIndicationFunc */
		D_NULL
	},
	/* CANDRVIFRX_HND_216 */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_EXTENDED_FRAME,
		/* Id */
		0x00000216U,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_216,
		/* DataPtr */
		CanDrvIF_RxData_216,
		/* RxIndicationFunc */
		D_NULL
	},
	/* CANDRVIFRX_HND_245 */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_EXTENDED_FRAME,
		/* Id */
		0x00000245U,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_245,
		/* DataPtr */
		CanDrvIF_RxData_245,
		/* RxIndicationFunc */
		D_NULL
	},
	/* CANDRVIFRX_HND_600 */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_EXTENDED_FRAME,
		/* Id */
		0x00000600U,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_600,
		/* DataPtr */
		CanDrvIF_RxData_600,
		/* RxIndicationFunc */
		D_NULL
	},
	/* CANDRVIFRX_HND_7DF */
	{
		/* Controller */
		CANDRVIF_CONTROLLER_FCAN,
		/* FrameFormat */
		CANDRVIF_CAN_EXTENDED_FRAME,
		/* Id */
		0x000007DFU,
		/* DataLen */
		CANDRVIFRX_DATA_LEN_7DF,
		/* DataPtr */
		CanDrvIF_RxData_7DF,
		/* RxIndicationFunc */
		D_NULL
	},

	/* dummy */ {0}
};


/**********************************************************************************************************/
/* When CAN Driver Interface module receive a CAN message, whose CAN identifier is <ID>, from CAN Driver, */
/* a valid RxHandle will be searched with the following procedures.                                       */
/*                                                                                                        */
/* Step1. Get <TBL_INDEX> (= C_CanDrvIF{x}_IndexTbl{Xxx}[(<ID> % CANDRVIF{x}_INDEX_TBL_{XXX}_CNT)])       */
/*     - If <TBL_INDEX> == 0xFFFFU ---> End of searching.                                                 */
/*                                      No valid RxHandle was found.                                      */
/*     - If <TBL_INDEX> != 0xFFFFU ---> Go to Step2                                                       */
/*                                                                                                        */
/* Step2. Get <VALID_ID> (= C_CanDrvIF{x}_HashTbl{Xxx}[<TBL_INDEX>].IdInfo & 0x1FFFFFFFU)                 */
/*     - If <VALID_ID> == <ID> ---> Get <RxHandle> (= C_CanDrvIF{x}_HashTbl{Xxx}[<TBL_INDEX>].RxHandle).  */
/*                                  End of searching. A valid RxHandle(= <RxHandle>) was found.           */
/*     - If <VALID_ID> != <ID> ---> Go to Step3                                                           */
/*                                                                                                        */
/* Step3. Get <STOP_MARK> (= C_CanDrvIF{x}_HashTbl{Xxx}[<TBL_INDEX>].IdInfo & 0x80000000U)                */
/*     - If <STOP_MARK> != 0U ---> End of searching.                                                      */
/*                                 No valid RxHandle was found.                                           */
/*     - If <STOP_MARK> == 0U ---> <TBL_INDEX> += 1U, then Go to Step2.                                   */
/*                                                                                                        */
/* {x}: Controller Index [0...(CANDRVIF_CONTROLLER_CNT - 1)]                                              */
/* {Xxx}: Frame Format [Std or Ext]                                                                       */
/* {XXX}: Frame Format [STD or EXT]                                                                       */
/**********************************************************************************************************/
static const UI_16 C_CanDrvIF0_IndexTblStd[] = 
{
	0x0000U,0xFFFFU,0xFFFFU,0xFFFFU,0x0005U,0xFFFFU,0x0008U,0xFFFFU, /*  0 ~  7 */
	0x0004U,0x0007U,0xFFFFU,0x0009U,0xFFFFU,0xFFFFU,0xFFFFU,0x000AU, /*  8 ~ 15 */
	0xFFFFU,0xFFFFU,0xFFFFU,0xFFFFU,0x0001U,0x0003U,0x0006U,0xFFFFU, /* 16 ~ 23 */
	0x0002U,														 /* 24 */
	
	/* dummy */ 0U
};

#define CANDRVIF0_INDEX_TBL_STD_CNT ((UI_16)(sizeof(C_CanDrvIF0_IndexTblStd) / sizeof(C_CanDrvIF0_IndexTblStd[0])) - 1U)

static const T_CanDrvIF_HashTbl C_CanDrvIF0_HashTblStd[] = 
{
	{ 0x80000401U, CANDRVIFRX_HND_401 },
	{ 0x8000023AU, CANDRVIFRX_HND_23A },
	{ 0x8000023EU, CANDRVIFRX_HND_23E },
	{ 0x80000209U, CANDRVIFRX_HND_209 },
	{ 0x80000215U, CANDRVIFRX_HND_215 },
	{ 0x8000022AU, CANDRVIFRX_HND_22A },
	{ 0x8000020AU, CANDRVIFRX_HND_20A },
	{ 0x80000216U, CANDRVIFRX_HND_216 },
	{ 0x80000245U, CANDRVIFRX_HND_245 },
	{ 0x80000600U, CANDRVIFRX_HND_600 },
	{ 0x800007DFU, CANDRVIFRX_HND_7DF },
	
	/* dummy */ {0}
};

#define CANDRVIF0_HASH_TBL_STD_CNT ((UI_16)(sizeof(C_CanDrvIF0_HashTblStd) / sizeof(C_CanDrvIF0_HashTblStd[0])) - 1U)

static const T_CanDrvIF_LinearTbl C_CanDrvIF0_LinearTblStd[] = 
{
	
	/* dummy */ {0}
};

#define CANDRVIF0_LINEAR_TBL_STD_CNT ((UI_16)(sizeof(C_CanDrvIF0_LinearTblStd) / sizeof(C_CanDrvIF0_LinearTblStd[0])) - 1U)

static const UI_16 C_CanDrvIF0_IndexTblExt[] = 
{
	0x0000U,0xFFFFU,0x0001U,0x0002U,0x0003U,0xFFFFU,
	
	/* dummy */ 0U
};

#define CANDRVIF0_INDEX_TBL_EXT_CNT ((UI_16)(sizeof(C_CanDrvIF0_IndexTblExt) / sizeof(C_CanDrvIF0_IndexTblExt[0])) - 1U)

static const T_CanDrvIF_HashTbl C_CanDrvIF0_HashTblExt[] = 
{
	/* dummy */ {0}
};

#define CANDRVIF0_HASH_TBL_EXT_CNT ((UI_16)(sizeof(C_CanDrvIF0_HashTblExt) / sizeof(C_CanDrvIF0_HashTblExt[0])) - 1U)

static const T_CanDrvIF_LinearTbl C_CanDrvIF0_LinearTblExt[] = 
{
	
	/* dummy */ {0}
};

#define CANDRVIF0_LINEAR_TBL_EXT_CNT ((UI_16)(sizeof(C_CanDrvIF0_LinearTblExt) / sizeof(C_CanDrvIF0_LinearTblExt[0])) - 1U)

static const T_CanDrvIF_RxSearchTbl C_CanDrvIF0_RxSearchTbl =
{
	/* IndexTblStdCnt           , IndexTblStdPtr          */
	CANDRVIF0_INDEX_TBL_STD_CNT , C_CanDrvIF0_IndexTblStd ,

	/* HashTblStdCnt            , HashTblStdPtr           */
	CANDRVIF0_HASH_TBL_STD_CNT  , C_CanDrvIF0_HashTblStd  ,

	/* LinearTblStdCnt          , LinearTblStdPtr         */
	CANDRVIF0_LINEAR_TBL_STD_CNT, C_CanDrvIF0_LinearTblStd,

	/* IndexTblExtCnt           , IndexTblExtPtr          */
	CANDRVIF0_INDEX_TBL_EXT_CNT , C_CanDrvIF0_IndexTblExt ,

	/* HashTblExtCnt            , HashTblExtPtr           */
	CANDRVIF0_HASH_TBL_EXT_CNT  , C_CanDrvIF0_HashTblExt  ,

	/* LinearTblExtCnt          , LinearTblExtPtr         */
	CANDRVIF0_LINEAR_TBL_EXT_CNT, C_CanDrvIF0_LinearTblExt
};


/* TxBitFlgControllerMask */
static const UI_16 C_CanDrvIF0_TxBitFlgControllerMask[CANDRVIFTX_BIT_FLG_INDEX_CNT] =
{
	0x007FU
};


/* RxBitFlgControllerMask */
static const UI_16 C_CanDrvIF0_RxBitFlgControllerMask[CANDRVIFRX_BIT_FLG_INDEX_CNT] =
{
	0x07FFU
};


/* TxBitFlgTxMsgObjMask */
static const UI_16 C_CanDrvIF0_TxBitFlgTxMsgObjMask[CANDRVIF0_TX_MSG_OBJ_CNT][CANDRVIFTX_BIT_FLG_INDEX_CNT] =
{
	/* TxMsgObjIndex = 0 */
	{
		0x001FU
	},
	/* TxMsgObjIndex = 1 */
	{
		0x0000U
	},
	/* TxMsgObjIndex = 2 */
	{
		0x0000U
	}
};


/* Cfg */
static const T_CanDrvIF_Cfg C_CanDrvIF_Cfg[CANDRVIF_CONTROLLER_CNT] =
{
	/* CANDRVIF_CONTROLLER_FCAN */
	{
		/* IntrMaskLevel */
		CANDRVIF0_INTR_MASK_LEVEL,
		/* TxBitFlgControllerMaskPtr */
		C_CanDrvIF0_TxBitFlgControllerMask,
		/* RxBitFlgControllerMaskPtr */
		C_CanDrvIF0_RxBitFlgControllerMask,
		/* RxSearchTblPtr */
		&C_CanDrvIF0_RxSearchTbl,
		/* TxMsgObjCnt */
		CANDRVIF0_TX_MSG_OBJ_CNT,
		/* TxMsgObjPtr */
		CanDrvIF0_TxMsgObj,
		/* TxBitFlgTxMsgObjMaskPtr */
		C_CanDrvIF0_TxBitFlgTxMsgObjMask,
		/* ControllerBusOffFunc */
		D_NULL
	}
};


#endif /* SSFTSTD_CAN_DRVIF_000_INTERNAL */

#endif /* SSFTXXX_CANDRVIF_CFG_000_H */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/

