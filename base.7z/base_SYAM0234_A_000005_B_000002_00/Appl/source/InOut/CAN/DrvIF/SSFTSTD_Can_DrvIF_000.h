/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFTSTD                                                                   */
/* Copyright        : Nippon Seiki Co., Ltd.                                                    */
/*----------------------------------------------------------------------------------------------*/
/* Date             : 2016/09/02                                                                */
/* Author           : PF1                                                                       */
/*----------------------------------------------------------------------------------------------*/
/* Ver              : 020000                                                                    */
/************************************************************************************************/


#ifndef SSFTSTD_CAN_DRVIF_000_H
#define SSFTSTD_CAN_DRVIF_000_H

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"

/************************************************************************************************/
/* Global Macros                                                                                */
/************************************************************************************************/

#define CANDRVIF_OK     ((UI_8)0x00U)
#define CANDRVIF_NOT_OK ((UI_8)0x01U)


/* Definitions for checking the return value of CanDrvIF_GetState().*/
#define CANDRVIF_STATE_STOP           ((UI_8)0x00U)
#define CANDRVIF_STATE_START          ((UI_8)0x01U)
#define CANDRVIF_STATE_WAIT_FOR_STOP  ((UI_8)0x02U)
#define CANDRVIF_STATE_WAIT_FOR_START ((UI_8)0x03U)
#define CANDRVIF_STATE_MSG_RAM_ERR    ((UI_8)0x04U)
#define CANDRVIF_STATE_TIMEOUT        ((UI_8)0x05U)
#define CANDRVIF_STATE_BUSOFF         ((UI_8)0x06U)
#define CANDRVIF_STATE_CNT            ((UI_8)7U)

/* Definitions for checking the return value of CanDrvIF_ChkAllTxState() and CanDrvIF_ChkTxState(). */
#define CANDRVIFTX_STATE_IDLE       ((UI_8)0x00U) /* 0000 0000b */
#define CANDRVIFTX_STATE_SENDING    ((UI_8)0x01U) /* 0000 0001b */
#define CANDRVIFTX_STATE_CANCELLING ((UI_8)0x02U) /* 0000 0010b */
#define CANDRVIFTX_STATE_WAITING    ((UI_8)0x04U) /* 0000 0100b */

/* Definitions for checking the return value of CanDrvIF_GetErrState().*/
#define CANDRVIF_ERR_STATE_ACTIVE  ((UI_8)0x00U) /* No error */
#define CANDRVIF_ERR_STATE_WARNING ((UI_8)0x01U) /* Warning */
#define CANDRVIF_ERR_STATE_PASSIVE ((UI_8)0x02U) /* Error Passive */
#define CANDRVIF_ERR_STATE_BUSOFF  ((UI_8)0x03U) /* BusOff */


#define CANDRVIF_CONTROLLER_INVALID   ((UI_8)0xFFU)
#define CANDRVIF_FRAME_FORMAT_INVALID ((UI_8)0xFFU)
#define CANDRVIF_ID_INVALID           ((UI_32)0xFFFFFFFFU)
#define CANDRVIF_HANDLE_INVALID       ((UI_16)0xFFFFU)

/************************************************************************************************/
/* Global Data Types                                                                            */
/************************************************************************************************/
typedef struct
{
	UI_8 FrameFormat;
	UI_32 Id;
	UI_8 DataLen;
	UI_8 *DataPtr;
} T_CanDrvIF_Msg;

/************************************************************************************************/
/* Global Data                                                                                  */
/************************************************************************************************/

/************************************************************************************************/
/* Global Constants                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTxxx_Can_DrvIF_Cfg_000.h"

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
extern void CanDrvIF_Init(void);

extern void CanDrvIF_InitController(const UI_8 controller, const UI_8 cmd);
extern UI_8 CanDrvIF_GetState(const UI_8 controller);

extern UI_8 CanDrvIF_SetTxReq(const UI_16 tx_handle, const UI_8 data_ptr[]);
extern UI_8 CanDrvIF_SetTxDynamicReq(const UI_16 tx_handle, const UI_8 frame_format, const UI_32 id, const UI_8 data_len, const UI_8 data_ptr[]);

extern void CanDrvIF_ClrAllTxReq(const UI_8 controller);
extern void CanDrvIF_ClrTxReq(const UI_16 tx_handle);

extern UI_8 CanDrvIF_ChkAllTxState(const UI_8 controller);
extern UI_8 CanDrvIF_ChkTxState(const UI_16 tx_handle);

extern UI_8 CanDrvIF_GetErrState(const UI_8 controller);
extern UI_16 CanDrvIF_GetTxErrCnt(const UI_8 controller);
extern UI_16 CanDrvIF_GetRxErrCnt(const UI_8 controller);

extern UI_8 CanDrvIF_ChkTxConfirmation(const UI_16 tx_handle);
extern UI_8 CanDrvIF_ChkTxCancelNotification(const UI_16 tx_handle);

extern UI_8 CanDrvIF_GetRxMsg(const UI_16 rx_handle, T_CanDrvIF_Msg *rx_msg_ptr);

extern UI_8 CanDrvIF_GetTxOkFlg(const UI_8 controller);
extern void CanDrvIF_ClrTxOkFlg(const UI_8 controller);

extern UI_8 CanDrvIF_GetRxOkFlg(const UI_8 controller);
extern void CanDrvIF_ClrRxOkFlg(const UI_8 controller);

extern UI_8 CanDrvIF_GetTxTimeoutFlg(const UI_8 controller);
extern void CanDrvIF_ClrTxTimeoutFlg(const UI_8 controller);

extern UI_8 CanDrvIF_GetRxMsgLostFlg(const UI_8 controller);
extern void CanDrvIF_ClrRxMsgLostFlg(const UI_8 controller);

extern void CanDrvIF_DisableIntr(const UI_8 controller, UI_16 *mask_level_ptr);
extern void CanDrvIF_EnableIntr(const UI_8 controller, const UI_16 mask_level);

extern UI_8 CanDrvIF_GetTxController(const UI_16 tx_handle);
extern UI_8 CanDrvIF_GetTxFrameFormat(const UI_16 tx_handle);
extern UI_32 CanDrvIF_GetTxId(const UI_16 tx_handle);
extern UI_8 CanDrvIF_GetTxDataLen(const UI_16 tx_handle);

extern UI_8 CanDrvIF_GetRxController(const UI_16 rx_handle);
extern UI_8 CanDrvIF_GetRxFrameFormat(const UI_16 rx_handle);
extern UI_32 CanDrvIF_GetRxId(const UI_16 rx_handle);
extern UI_8 CanDrvIF_GetRxDataLen(const UI_16 rx_handle);

extern void CanDrvIF_IntrMain(const UI_8 controller, const UI_8 intr_signal);
extern void CanDrvIF_Main(void);
extern void CanDrvIF_ActivateTx(void);

/* The follwoing functions are called by the CAN Driver.  */
extern void CanDrvIF_ControllerBusOff(const UI_8 controller);
extern void CanDrvIF_RxMsgLost(const UI_8 controller);
extern void CanDrvIF_TxConfirmation(const UI_8 controller, const UI_16 tx_msg_obj_index);
extern void CanDrvIF_RxIndication(const UI_8 controller, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[]);
extern void CanDrvIF_MsgRamChkFailed(const UI_8 controller);


#endif /* SSFTSTD_CAN_DRVIF_000_H */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/

