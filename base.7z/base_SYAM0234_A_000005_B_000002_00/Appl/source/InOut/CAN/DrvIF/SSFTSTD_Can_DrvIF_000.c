/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFTSTD                                                                   */
/* Copyright        : Nippon Seiki Co., Ltd.                                                    */
/*----------------------------------------------------------------------------------------------*/
/* Date             : 2016/09/02                                                                */
/* Author           : PF1                                                                       */
/*----------------------------------------------------------------------------------------------*/
/* Ver              : 020100                                                                    */
/************************************************************************************************/


/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#define SSFTSTD_CAN_DRVIF_000_INTERNAL
#include <string.h> /* for memcpy() */
#include "SSFTSTD_Can_DrvIF_000.h"

/************************************************************************************************/
/* Local Macros                                                                                 */
/************************************************************************************************/
/* Index for C_CanDrvIF_StateCtrlFunc */
#define CANDRVIF_CTRL_FUNC_START          (0U)
#define CANDRVIF_CTRL_FUNC_STOP           (1U)
#define CANDRVIF_CTRL_FUNC_WAIT_FOR_START (2U)
#define CANDRVIF_CTRL_FUNC_WAIT_FOR_STOP  (3U)
#define CANDRVIF_CTRL_FUNC_CNT            (4U)

/* The following value indicates that timer counting should be stopped. */
#define CANDRVIF_TIMER_STOP ((UI_16)0xFFFFU)

/************************************************************************************************/
/* Local Data Types                                                                             */
/************************************************************************************************/
/* A type for controlling the main state of CAN Driver Interface. */
typedef struct
{
	UI_8 Status;
	UI_8 ReqCmd;
	UI_8 MsgRamChkFailed;
	UI_8 BusOff;
	UI_8 TxTimeout;
	UI_8 RxMsgLost;
	UI_8 TxOk;
	UI_8 RxOk;
	T_CanDrvIF_TxMsgObj *TxMsgObjPtr;
	UI_16 StateTimeoutCnt;
} T_CanDrvIF_Ctrl;

/* The following type consists of several bit flags for transmission side. */
typedef struct
{
	UI_16 TxPendingFlg[CANDRVIFTX_BIT_FLG_INDEX_CNT];
	UI_16 TxConfirmationFlg[CANDRVIFTX_BIT_FLG_INDEX_CNT];
	UI_16 TxCancelNotificationFlg[CANDRVIFTX_BIT_FLG_INDEX_CNT];
} T_CanDrvIF_TxBitFlg;

/* The following type consists of several bit flags for reception side. */
typedef struct
{
	UI_16 RxIndicationFlg[CANDRVIFRX_BIT_FLG_INDEX_CNT];
} T_CanDrvIF_RxBitFlg;

/* A type for state control function table */
typedef UI_8 (*T_CanDrvIF_StateCtrlFunc) (UI_8 controller, UI_8 cur_status, UI_8 req_cmd);

/************************************************************************************************/
/* Local Data                                                                                   */
/************************************************************************************************/
/* RAM������section 2�̊J�n */
#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA RAM2SEC
#else
 #define START_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

static T_CanDrvIF_Ctrl CanDrvIF_Ctrl[CANDRVIF_CONTROLLER_CNT];
static T_CanDrvIF_TxBitFlg CanDrvIF_TxBitFlg;
static T_CanDrvIF_RxBitFlg CanDrvIF_RxBitFlg;
static T_CanDrvIF_Msg CanDrvIF_TxMsg[CANDRVIFTX_HANDLE_CNT + 1U];
static T_CanDrvIF_Msg CanDrvIF_RxMsg[CANDRVIFRX_HANDLE_CNT + 1U];

#if defined(__RL78_CA78K0R__)
 #pragma section @@DATA @@DATA
#else
 #define STOP_SEC_RAM2SEC
 #include "SSFTSTD_MemoryMap.h"
#endif

/************************************************************************************************/
/* Local Function Declarations                                                                  */
/************************************************************************************************/
static void can_disable_intr(UI_8 controller, UI_16 *mask_level_ptr);
static void can_enable_intr(UI_8 controller, UI_16 mask_level);
static void can_init_memory(void);
static void can_init_ctrl_info(UI_8 controller);
static void can_init_tx_msg_obj_info(UI_8 controller);
static void can_init_tx_bit_flg(UI_8 controller);
static void can_init_rx_bit_flg(UI_8 controller);
static UI_8 can_chk_msg_ram_chk_failed_flg(UI_8 controller);
static void can_clr_msg_ram_chk_failed_flg(UI_8 controller);

static void can_state_handling(UI_8 controller);
static UI_8 can_state_ctrl_start(UI_8 controller, UI_8 cur_status, UI_8 req_cmd);
static UI_8 can_state_ctrl_stop(UI_8 controller, UI_8 cur_status, UI_8 req_cmd);
static UI_8 can_state_ctrl_wait_for_start(UI_8 controller, UI_8 cur_status, UI_8 req_cmd);
static UI_8 can_state_ctrl_wait_for_stop(UI_8 controller, UI_8 cur_status, UI_8 req_cmd);

static void can_tx_chk_tx_timeout(UI_8 controller);
static void can_tx_set_req(UI_16 tx_handle, UI_8 frame_format, UI_32 id, UI_8 data_len, const UI_8 data_ptr[]);
static void can_tx_queue_handling(UI_8 controller, UI_16 tx_msg_obj_index);
static void can_tx_queue_transmit(UI_8 controller, UI_16 tx_msg_obj_index, UI_16 tx_handle);

static UI_16 can_get_top_handle(UI_16 flg_index_cnt, const UI_16 flg[], const UI_16 flg_mask[]);
static void can_set_flg(UI_16 handle, UI_16 flg[]);
static void can_clr_flg(UI_16 handle, UI_16 flg[]);
static UI_8 can_chk_flg(UI_16 handle, const UI_16 flg[]);
static void can_clr_all_flg(UI_16 flg_index_cnt, UI_16 flg[], const UI_16 flg_mask[]);
static UI_8 can_chk_all_flg(UI_16 flg_index_cnt, const UI_16 flg[], const UI_16 flg_mask[]);

static UI_16 can_rx_find_handle(const T_CanDrvIF_RxSearchTbl *tbl_ptr, UI_8 frame_format, UI_32 id);
static UI_16 can_rx_hash_search(UI_32 id, UI_16 index_tbl_size, const UI_16 index_tbl[], const T_CanDrvIF_HashTbl tbl[]);
static UI_16 can_rx_linear_search(UI_32 id, UI_16 tbl_size, const T_CanDrvIF_LinearTbl tbl[]);

/************************************************************************************************/
/* Local Constants                                                                              */
/************************************************************************************************/
static const T_CanDrvIF_StateCtrlFunc C_CanDrvIF_StateCtrlFunc[CANDRVIF_CTRL_FUNC_CNT] =
{
	/* CANDRVIF_CTRL_FUNC_START          */ &can_state_ctrl_start,
	/* CANDRVIF_CTRL_FUNC_STOP           */ &can_state_ctrl_stop,
	/* CANDRVIF_CTRL_FUNC_WAIT_FOR_START */ &can_state_ctrl_wait_for_start,
	/* CANDRVIF_CTRL_FUNC_WAIT_FOR_STOP  */ &can_state_ctrl_wait_for_stop,
};

static const UI_8 C_CanDrvIF_StateCtrlTbl[CANDRVIF_STATE_CNT][CANDRVIF_CMD_CNT + 1U] =
{
	                                    /* CANDRVIF_CMD_STOP                 CANDRVIF_CMD_START                 CANDRVIF_CMD_START_WITH_CHK        CANDRVIF_CMD_CNT*/
	/* CANDRVIF_STATE_STOP */           {  CANDRVIF_CTRL_FUNC_CNT,           CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_CNT            },
	/* CANDRVIF_STATE_START */          {  CANDRVIF_CTRL_FUNC_STOP,          CANDRVIF_CTRL_FUNC_CNT,            CANDRVIF_CTRL_FUNC_CNT,            CANDRVIF_CTRL_FUNC_CNT            },
	/* CANDRVIF_STATE_WAIT_FOR_STOP */  {  CANDRVIF_CTRL_FUNC_WAIT_FOR_STOP, CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_WAIT_FOR_STOP  },
	/* CANDRVIF_STATE_WAIT_FOR_START */ {  CANDRVIF_CTRL_FUNC_STOP,          CANDRVIF_CTRL_FUNC_WAIT_FOR_START, CANDRVIF_CTRL_FUNC_WAIT_FOR_START, CANDRVIF_CTRL_FUNC_WAIT_FOR_START },
	/* CANDRVIF_STATE_MSG_RAM_ERR */    {  CANDRVIF_CTRL_FUNC_STOP,          CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_CNT            },
	/* CANDRVIF_STATE_TIMEOUT */        {  CANDRVIF_CTRL_FUNC_STOP,          CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_CNT            },
	/* CANDRVIF_STATE_BUSOFF */         {  CANDRVIF_CTRL_FUNC_STOP,          CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_START,          CANDRVIF_CTRL_FUNC_CNT            },
};

/************************************************************************************************/
/* Local Functions                                                                              */
/************************************************************************************************/
/************************************************************************************************/
/* Function name    : can_disable_intr                                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    [out]                                                                     */
/*                    <mask_level_ptr> - Pointer to a memory location,                          */
/*                                       where the current interrupt mask level will be stored. */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function shall be called in order to enter a critical section.       */
/*                    First, the current interrupt mask level is read.                          */
/*                    Then, this function changes the interrupt mask level                      */
/*                    using pre configured vale.                                                */
/*                    A user has to set the value of <mask_level_ptr> to can_enable_intr()      */
/*                    to leave a critical section.                                              */
/*                                                                                              */
/************************************************************************************************/
static void can_disable_intr(UI_8 controller, UI_16 *mask_level_ptr)
{
	/* Get the current mask level in advance. */
	(void)IntrDrv_GetMaskLevel(mask_level_ptr);
	/* Mask the CAN interrupts. */
	(void)IntrDrv_SetMaskLevel(C_CanDrvIF_Cfg[controller].IntrMaskLevel);

}

/************************************************************************************************/
/* Function name    : can_enable_intr                                                           */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <mask_level> - Interrupt Mask Level to be set.                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function shall be called in order to leave a critical section.       */
/*                    A user has to set obtained value from                                     */
/*                    can_disable_intr() to <mask_level>.                                       */
/*                                                                                              */
/************************************************************************************************/
static void can_enable_intr(UI_8 controller, UI_16 mask_level)
{
	controller = controller; /* avoid MISRA warning */
	/* The mask level specified with the argument shall be the same value */
	/* which was read in the function can_disable_intr(). */
	(void)IntrDrv_SetMaskLevel(mask_level);
}

/************************************************************************************************/
/* Function name    : can_init_memory                                                           */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function initializes all of the internal memory.                     */
/*                                                                                              */
/************************************************************************************************/
static void can_init_memory(void)
{
	UI_8 controller;
	UI_16 handle;

	for (controller = 0U; controller < CANDRVIF_CONTROLLER_CNT; controller++) {
		/* Initialize control information */
		can_init_ctrl_info(controller);
		/* Clear all tx bit flags */
		can_init_tx_bit_flg(controller);
		/* Clear all rx bit flags */
		can_init_rx_bit_flg(controller);
	}

	/* Initialize the transmission message information */
	for (handle = 0U; handle < CANDRVIFTX_HANDLE_CNT; handle++) {
		CanDrvIF_TxMsg[handle].FrameFormat = C_CanDrvIF_TxCfg[handle].FrameFormat;
		CanDrvIF_TxMsg[handle].Id = C_CanDrvIF_TxCfg[handle].Id;
		CanDrvIF_TxMsg[handle].DataLen = C_CanDrvIF_TxCfg[handle].DataLen;
		/* Each handle has a different data length. */
		/* The pointer to the transmission data is set here. */
		CanDrvIF_TxMsg[handle].DataPtr = C_CanDrvIF_TxCfg[handle].DataPtr;
	}

	/* Initialize the reception message information */
	for (handle = 0U; handle < CANDRVIFRX_HANDLE_CNT; handle++) {
		/* Each handle has a different data length. */
		/* The pointer to the reception data is set here. */
		CanDrvIF_RxMsg[handle].DataPtr = C_CanDrvIF_RxCfg[handle].DataPtr;
	}

}

/************************************************************************************************/
/* Function name    : can_init_ctrl_info                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function initializes main control information of                     */
/*                    CAN controller index specified with <controller>.                         */
/*                                                                                              */
/************************************************************************************************/
static void can_init_ctrl_info(UI_8 controller)
{
	CanDrvIF_Ctrl[controller].Status = CANDRVIF_STATE_STOP;
	CanDrvIF_Ctrl[controller].ReqCmd = CANDRVIF_CMD_CNT;
	CanDrvIF_Ctrl[controller].MsgRamChkFailed = D_FALSE;
	CanDrvIF_Ctrl[controller].BusOff = D_FALSE;
	CanDrvIF_Ctrl[controller].TxTimeout = D_FALSE;
	CanDrvIF_Ctrl[controller].RxMsgLost = D_FALSE;
	CanDrvIF_Ctrl[controller].TxOk = D_FALSE;
	CanDrvIF_Ctrl[controller].RxOk = D_FALSE;

	/* Initialize the current TxMsgObj. */
	can_init_tx_msg_obj_info(controller);

	/* Stop the state timer. */
	CanDrvIF_Ctrl[controller].StateTimeoutCnt = CANDRVIF_TIMER_STOP;
}

/************************************************************************************************/
/* Function name    : can_init_tx_msg_obj_info                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function initializes TxMsgObj information of                         */
/*                    CAN controller index specified with <controller>.                         */
/*                                                                                              */
/************************************************************************************************/
static void can_init_tx_msg_obj_info(UI_8 controller)
{
	UI_16 tx_msg_obj_index;

	CanDrvIF_Ctrl[controller].TxMsgObjPtr = C_CanDrvIF_Cfg[controller].TxMsgObjPtr;

	for (tx_msg_obj_index = 0U; tx_msg_obj_index < C_CanDrvIF_Cfg[controller].TxMsgObjCnt; tx_msg_obj_index++) {
		CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus = CANDRVIFTX_STATE_IDLE;
		CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxHandle = CANDRVIF_HANDLE_INVALID;
		CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt = CANDRVIF_TIMER_STOP;
	}
}

/************************************************************************************************/
/* Function name    : can_init_tx_bit_flg                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears all of the transmission related flags of             */
/*                    CAN controller index specified with <controller>.                         */
/*                                                                                              */
/************************************************************************************************/
static void can_init_tx_bit_flg(UI_8 controller)
{
	UI_16 flg_index_cnt = CANDRVIFTX_BIT_FLG_INDEX_CNT;
	const UI_16 *flg_mask_ptr = C_CanDrvIF_Cfg[controller].TxBitFlgControllerMaskPtr;

	can_clr_all_flg(flg_index_cnt, CanDrvIF_TxBitFlg.TxPendingFlg, flg_mask_ptr);
	can_clr_all_flg(flg_index_cnt, CanDrvIF_TxBitFlg.TxConfirmationFlg, flg_mask_ptr);
	can_clr_all_flg(flg_index_cnt, CanDrvIF_TxBitFlg.TxCancelNotificationFlg, flg_mask_ptr);
}

/************************************************************************************************/
/* Function name    : can_init_rx_bit_flg                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears all of the reception related flags of                */
/*                    CAN controller index specified with <controller>.                         */
/*                                                                                              */
/************************************************************************************************/
static void can_init_rx_bit_flg(UI_8 controller)
{
	UI_16 flg_index_cnt = CANDRVIFRX_BIT_FLG_INDEX_CNT;
	const UI_16 *flg_mask_ptr = C_CanDrvIF_Cfg[controller].RxBitFlgControllerMaskPtr;

	can_clr_all_flg(flg_index_cnt, CanDrvIF_RxBitFlg.RxIndicationFlg, flg_mask_ptr);
}

/************************************************************************************************/
/* Function name    : can_chk_msg_ram_chk_failed_flg                                            */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : - D_FALSE : A problem has not been detected in the message objects.       */
/*                    - D_TRUE  : A problem has been detected in the message objects.           */
/*                                                                                              */
/* Description      : This function returns the current MsgRamChkFailed flag state.             */
/*                    MsgRamChkFailed has to be read two times in can_state_ctrl_start().       */
/*                    If MsgRamChkFailed is read directlly in can_state_ctrl_start(),           */
/*                    unexpected optiomization may occur.                                       */
/*                    This function is prepared to avoid the optimization.                      */
/*                                                                                              */
/************************************************************************************************/
static UI_8 can_chk_msg_ram_chk_failed_flg(UI_8 controller)
{
	return CanDrvIF_Ctrl[controller].MsgRamChkFailed;
}

/************************************************************************************************/
/* Function name    : can_clr_msg_ram_chk_failed_flg                                            */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears the current MsgRamChkFailed flag.                    */
/*                                                                                              */
/************************************************************************************************/
static void can_clr_msg_ram_chk_failed_flg(UI_8 controller)
{
	CanDrvIF_Ctrl[controller].MsgRamChkFailed = D_FALSE;
}

/************************************************************************************************/
/* Function name    : can_state_handling                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function handles the operation state transition.                     */
/*                    A user can set start or stop trigger via CanDrvIF_InitController().       */
/*                    This function also checks if the bus off error has been detected.         */
/*                    If the bus off is detected, the state is set to CANDRVIF_STATE_BUSOFF.    */
/*                                                                                              */
/*                    Additionally this function updates state change timeout timer.            */
/*                    The sub functions check if the timer is expired                           */
/*                    and set the timeout flag there.                                           */
/*                                                                                              */
/*                    This function is expected to be called every 10 msec.                     */
/*                                                                                              */
/************************************************************************************************/
static void can_state_handling(UI_8 controller)
{
	UI_8 cur_status;
	UI_8 new_status;
	UI_8 req_cmd;
	UI_8 func_index;
	UI_16 mask_level;

	/* Get and clear the state control request. */
	req_cmd = CanDrvIF_Ctrl[controller].ReqCmd;
	CanDrvIF_Ctrl[controller].ReqCmd = CANDRVIF_CMD_CNT;

	/* If the buf off occur, change the current state to BUSOFF. */
	can_disable_intr(controller, &mask_level); /* DI */
	if (CanDrvIF_Ctrl[controller].BusOff != D_FALSE) {
		CanDrvIF_Ctrl[controller].BusOff = D_FALSE;
		CanDrvIF_Ctrl[controller].Status = CANDRVIF_STATE_BUSOFF;
	}
	can_enable_intr(controller, mask_level); /* EI */

	/* Check if the request command is valid for the current state. */
	cur_status = CanDrvIF_Ctrl[controller].Status;
	func_index = C_CanDrvIF_StateCtrlTbl[cur_status][req_cmd];
	if (func_index < CANDRVIF_CTRL_FUNC_CNT) {
		new_status = C_CanDrvIF_StateCtrlFunc[func_index](controller, cur_status, req_cmd);
	} else {
		new_status = cur_status;
	}

	/* Update the current state. */
	CanDrvIF_Ctrl[controller].Status = new_status;

	/* Update state timer */
	if ((CanDrvIF_Ctrl[controller].StateTimeoutCnt != CANDRVIF_TIMER_STOP) &&
		(CanDrvIF_Ctrl[controller].StateTimeoutCnt != 0U)) {
		CanDrvIF_Ctrl[controller].StateTimeoutCnt--;
	}

}

/************************************************************************************************/
/* Function name    : can_state_ctrl_start                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <cur_status> - The current operation state of CAN Driver Interface.       */
/*                     The following value can be passed to this function.                      */
/*                      CANDRVIF_STATE_STOP                                                     */
/*                      CANDRVIF_STATE_WAIT_FOR_STOP                                            */
/*                      CANDRVIF_STATE_MSG_RAM_ERR                                              */
/*                      CANDRVIF_STATE_TIMEOUT                                                  */
/*                      CANDRVIF_STATE_BUSOFF                                                   */
/*                                                                                              */
/*                     The upper function does not pass the following value.                    */
/*                      CANDRVIF_STATE_START                                                    */
/*                      CANDRVIF_STATE_WAIT_FOR_START                                           */
/*                      CANDRVIF_STATE_CNT                                                      */
/*                                                                                              */
/*                    <req_cmd> - A request command for controlling the operation state.        */
/*                     The following value can be passed to this function.                      */
/*                      CANDRVIF_CMD_START                                                      */
/*                      CANDRVIF_CMD_START_WITH_CHK                                             */
/*                                                                                              */
/*                     The upper function does not pass the following value.                    */
/*                      CANDRVIF_CMD_STOP                                                       */
/*                      CANDRVIF_CMD_CNT                                                        */
/*                                                                                              */
/* Return value     : This function returns the following value as new operation state.         */
/*                    - CANDRVIF_STATE_START                                                    */
/*                    - CANDRVIF_STATE_WAIT_FOR_START                                           */
/*                    - CANDRVIF_STATE_MSG_RAM_ERR                                              */
/*                                                                                              */
/* Description      : This function calls CanDrv_CtrlState() to open the CAN communication.     */
/*                    Then, this function calls CanDrv_CtrlState()                              */
/*                    to check if CAN controller is activated.                                  */
/*                                                                                              */
/*                    If this function confirms that CAN controller is activated,               */
/*                    CANDRVIF_STATE_START is returned.                                         */
/*                                                                                              */
/*                    If this function cannot confirm that CAN controller is activated          */
/*                    at this time, CANDRVIF_STATE_WAIT_FOR_START is returned                   */
/*                    in order to check the driver state again later.                           */
/*                    In this case, the timeout timer is started.                               */
/*                                                                                              */
/*                    If a message object error is detected during startup sequence,            */
/*                    CANDRVIF_STATE_MSG_RAM_ERR is returned.                                   */
/*                                                                                              */
/************************************************************************************************/
static UI_8 can_state_ctrl_start(UI_8 controller, UI_8 cur_status, UI_8 req_cmd)
{
	UI_8 new_status;
	UI_8 drv_status;

	can_clr_msg_ram_chk_failed_flg(controller);

	/* Start the CAN controller. req_cmd must be the same value as CANDRV_CMD_START or CANDRV_CMD_START_WITH_CHK */
	CanDrv_CtrlState(controller, req_cmd);
	/* Initialize the current TxMsgObj. */
	can_init_tx_msg_obj_info(controller);

	if (can_chk_msg_ram_chk_failed_flg(controller) != D_FALSE) {
		new_status = CANDRVIF_STATE_MSG_RAM_ERR;
	} else {
		drv_status = CanDrv_ChkState(controller);
		if (can_chk_msg_ram_chk_failed_flg(controller) != D_FALSE) {
			new_status = CANDRVIF_STATE_MSG_RAM_ERR;
		} else {
			if (drv_status == CANDRV_STATE_START) {
				new_status = CANDRVIF_STATE_START;
			} else {
				new_status = CANDRVIF_STATE_WAIT_FOR_START;
				CanDrvIF_Ctrl[controller].StateTimeoutCnt = CANDRVIF_TIMER_STATE_TIMEOUT;
			}
		}
	}

	return new_status;
}

/************************************************************************************************/
/* Function name    : can_state_ctrl_stop                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <cur_status> - The current operation state of CAN Driver Interface.       */
/*                     The following value can be passed to this function.                      */
/*                      CANDRVIF_STATE_START                                                    */
/*                      CANDRVIF_STATE_WAIT_FOR_START                                           */
/*                      CANDRVIF_STATE_MSG_RAM_ERR                                              */
/*                      CANDRVIF_STATE_TIMEOUT                                                  */
/*                      CANDRVIF_STATE_BUSOFF                                                   */
/*                                                                                              */
/*                     The upper function does not pass the following value.                    */
/*                      CANDRVIF_STATE_STOP                                                     */
/*                      CANDRVIF_STATE_WAIT_FOR_STOP                                            */
/*                      CANDRVIF_STATE_CNT                                                      */
/*                                                                                              */
/*                    <req_cmd> - A request command for controlling the operation state.        */
/*                     The following value can be passed to this function.                      */
/*                      CANDRVIF_CMD_STOP                                                       */
/*                                                                                              */
/*                     The upper function does not pass the following value.                    */
/*                      CANDRVIF_CMD_START                                                      */
/*                      CANDRVIF_CMD_START_WITH_CHK                                             */
/*                      CANDRVIF_CMD_CNT                                                        */
/*                                                                                              */
/* Return value     : This function returns the following value as new operation state.         */
/*                    - CANDRVIF_STATE_STOP                                                     */
/*                    - CANDRVIF_STATE_WAIT_FOR_STOP                                            */
/*                                                                                              */
/* Description      : This function calls CanDrv_CtrlState() to close the CAN communication.    */
/*                    Then, this function calls CanDrv_CtrlState()                              */
/*                    to check if CAN controller is deactivated.                                */
/*                                                                                              */
/*                    If this function confirms that CAN controller is deactivated,             */
/*                    CANDRVIF_STATE_STOP is returned.                                          */
/*                                                                                              */
/*                    If this function cannot confirm that CAN controller is deactivated        */
/*                    at this time, CANDRVIF_STATE_WAIT_FOR_STOP is returned                    */
/*                    in order to check the driver state again later.                           */
/*                    In this case, the timeout timer is started.                               */
/*                                                                                              */
/************************************************************************************************/
static UI_8 can_state_ctrl_stop(UI_8 controller, UI_8 cur_status, UI_8 req_cmd)
{
	UI_8 new_status;
	UI_8 drv_status;

	/* Stop the CAN controller. req_cmd must be the same value as CANDRV_CMD_STOP */
	CanDrv_CtrlState(controller, req_cmd);
	/* Initialize the current TxMsgObj. */
	can_init_tx_msg_obj_info(controller);

	drv_status = CanDrv_ChkState(controller);
	if (drv_status == CANDRV_STATE_STOP) {
		new_status = CANDRVIF_STATE_STOP;
	} else {
		new_status = CANDRVIF_STATE_WAIT_FOR_STOP;
		CanDrvIF_Ctrl[controller].StateTimeoutCnt = CANDRVIF_TIMER_STATE_TIMEOUT;
	}

	return new_status;
}

/************************************************************************************************/
/* Function name    : can_state_ctrl_wait_for_start                                             */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <cur_status> - The current operation state of CAN Driver Interface.       */
/*                     The following value can be passed to this function.                      */
/*                      CANDRVIF_STATE_WAIT_FOR_START                                           */
/*                                                                                              */
/*                     The upper function does not pass the following value.                    */
/*                      CANDRVIF_STATE_STOP                                                     */
/*                      CANDRVIF_STATE_START                                                    */
/*                      CANDRVIF_STATE_WAIT_FOR_STOP                                            */
/*                      CANDRVIF_STATE_MSG_RAM_ERR                                              */
/*                      CANDRVIF_STATE_TIMEOUT                                                  */
/*                      CANDRVIF_STATE_BUSOFF                                                   */
/*                      CANDRVIF_STATE_CNT                                                      */
/*                                                                                              */
/*                    <req_cmd> - A request command for controlling the operation state.        */
/*                     The following value can be passed to this function.                      */
/*                      CANDRVIF_CMD_START                                                      */
/*                      CANDRVIF_CMD_START_WITH_CHK                                             */
/*                      CANDRVIF_CMD_CNT                                                        */
/*                                                                                              */
/*                     The upper function does not pass the following value.                    */
/*                      CANDRVIF_CMD_STOP                                                       */
/*                                                                                              */
/* Return value     : This function returns the following value as new operation state.         */
/*                    - CANDRVIF_STATE_START                                                    */
/*                    - CANDRVIF_STATE_WAIT_FOR_START                                           */
/*                    - CANDRVIF_STATE_MSG_RAM_ERR                                              */
/*                    - CANDRVIF_STATE_TIMEOUT                                                  */
/*                                                                                              */
/* Description      : This function calls CanDrv_CtrlState()                                    */
/*                    to check if CAN controller is activated.                                  */
/*                                                                                              */
/*                    If this function confirms that CAN controller is activated,               */
/*                    CANDRVIF_STATE_START is returned.                                         */
/*                                                                                              */
/*                    If this function cannot confirm that CAN controller is activated          */
/*                    at this time, this function checks if the timeout time is expired.        */
/*                    If the timeout is detected, CANDRVIF_STATE_TIMEOUT is returned.           */
/*                                                                                              */
/*                    If the timeout is not detected, CANDRVIF_STATE_WAIT_FOR_START is returned */
/*                    in order to check the driver state again later.                           */
/*                                                                                              */
/*                    If a message object error is detected during startup sequence,            */
/*                    CANDRVIF_STATE_MSG_RAM_ERR is returned.                                   */
/*                                                                                              */
/************************************************************************************************/
static UI_8 can_state_ctrl_wait_for_start(UI_8 controller, UI_8 cur_status, UI_8 req_cmd)
{
	UI_8 new_status;
	UI_8 drv_status;

	drv_status = CanDrv_ChkState(controller);
	if (can_chk_msg_ram_chk_failed_flg(controller) != D_FALSE) {
		new_status = CANDRVIF_STATE_MSG_RAM_ERR;
		CanDrvIF_Ctrl[controller].StateTimeoutCnt = CANDRVIF_TIMER_STOP;
	} else {
		if (drv_status == CANDRV_STATE_START) {
			new_status = CANDRVIF_STATE_START;
			CanDrvIF_Ctrl[controller].StateTimeoutCnt = CANDRVIF_TIMER_STOP;
		} else {
			if (CanDrvIF_Ctrl[controller].StateTimeoutCnt == 0U) {
				new_status = CANDRVIF_STATE_TIMEOUT;
				CanDrvIF_Ctrl[controller].StateTimeoutCnt = CANDRVIF_TIMER_STOP;
			} else {
				new_status = cur_status;
			}
		}
	}

	return new_status;
}

/************************************************************************************************/
/* Function name    : can_state_ctrl_wait_for_stop                                              */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <cur_status> - The current operation state of CAN Driver Interface.       */
/*                     The following value can be passed to this function.                      */
/*                      CANDRVIF_STATE_WAIT_FOR_STOP                                            */
/*                                                                                              */
/*                     The upper function does not pass the following value.                    */
/*                      CANDRVIF_STATE_STOP                                                     */
/*                      CANDRVIF_STATE_START                                                    */
/*                      CANDRVIF_STATE_WAIT_FOR_START                                           */
/*                      CANDRVIF_STATE_MSG_RAM_ERR                                              */
/*                      CANDRVIF_STATE_TIMEOUT                                                  */
/*                      CANDRVIF_STATE_BUSOFF                                                   */
/*                      CANDRVIF_STATE_CNT                                                      */
/*                                                                                              */
/*                    <req_cmd> - A request command for controlling the operation state.        */
/*                     The following value can be passed to this function.                      */
/*                      CANDRVIF_CMD_STOP                                                       */
/*                      CANDRVIF_CMD_CNT                                                        */
/*                                                                                              */
/*                     The upper function does not pass the following value.                    */
/*                      CANDRVIF_CMD_START                                                      */
/*                      CANDRVIF_CMD_START_WITH_CHK                                             */
/*                                                                                              */
/* Return value     : This function returns the following value as new operation state.         */
/*                    - CANDRVIF_STATE_STOP                                                     */
/*                    - CANDRVIF_STATE_WAIT_FOR_STOP                                            */
/*                    - CANDRVIF_STATE_TIMEOUT                                                  */
/*                                                                                              */
/* Description      : This function calls CanDrv_CtrlState()                                    */
/*                    to check if CAN controller is deactivated.                                */
/*                                                                                              */
/*                    If this function confirms that CAN controller is deactivated,             */
/*                    CANDRVIF_STATE_STOP is returned.                                          */
/*                                                                                              */
/*                    If this function cannot confirm that CAN controller is deactivated        */
/*                    at this time, this function checks if the timeout time is expired.        */
/*                    If the timeout is detected, CANDRVIF_STATE_TIMEOUT is returned.           */
/*                                                                                              */
/*                    If the timeout is not detected, CANDRVIF_STATE_WAIT_FOR_STOP is returned  */
/*                    in order to check the driver state again later.                           */
/*                                                                                              */
/************************************************************************************************/
static UI_8 can_state_ctrl_wait_for_stop(UI_8 controller, UI_8 cur_status, UI_8 req_cmd)
{
	UI_8 new_status;
	UI_8 drv_status;

	drv_status = CanDrv_ChkState(controller);
	if (drv_status == CANDRV_STATE_STOP) {
		new_status = CANDRVIF_STATE_STOP;
		CanDrvIF_Ctrl[controller].StateTimeoutCnt = CANDRVIF_TIMER_STOP;
	} else {
		if (CanDrvIF_Ctrl[controller].StateTimeoutCnt == 0U) {
			new_status = CANDRVIF_STATE_TIMEOUT;
			CanDrvIF_Ctrl[controller].StateTimeoutCnt = CANDRVIF_TIMER_STOP;
		} else {
			new_status = cur_status;
		}
	}

	return new_status;
}

/************************************************************************************************/
/* Function name    : can_tx_chk_tx_timeout                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function checks if the transmission timeout occurs.                  */
/*                    All of the TxMsgObjs in the CAN controller index                          */
/*                    specified with <controller> is supervised.                                */
/*                    If the timeout is detected, TxTimeout is set to D_TRUE.                   */
/*                    A user can get the timeout sate via CanDrvIF_GetTxTimeoutFlg().           */
/*                                                                                              */
/************************************************************************************************/
static void can_tx_chk_tx_timeout(UI_8 controller)
{
	UI_16 tx_msg_obj_index;
	UI_16 mask_level;

	for (tx_msg_obj_index = 0U; tx_msg_obj_index < C_CanDrvIF_Cfg[controller].TxMsgObjCnt; tx_msg_obj_index++) {
		can_disable_intr(controller, &mask_level); /* DI */
		if ((CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt != CANDRVIF_TIMER_STOP) &&
			(CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt != 0U)) {
			CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt--;
		}
		if (CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt == 0U) {
			/* Tx Timeout */
			CanDrvIF_Ctrl[controller].TxTimeout = D_TRUE;
			CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt = CANDRVIF_TIMER_TX_TIMEOUT;
		}
		can_enable_intr(controller, mask_level); /* EI */
	}
}

/************************************************************************************************/
/* Function name    : can_tx_set_req                                                            */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/*                    <frame_format> - CAN frame format to be transmitted.                      */
/*                     CANDRVIF_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)            */
/*                     CANDRVIF_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)            */
/*                                                                                              */
/*                    <id> - CAN identifier to be transmitted.                                  */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                                                                                              */
/*                    <data_len> - Data length to be transmitted in byte                        */
/*                     0-64                                                                     */
/*                                                                                              */
/*                    <data_ptr> - Pointer to a memory location where                           */
/*                                 the transmission data is stored.                             */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function stores the transmission request                             */
/*                    to the internal request buffer and sets the TxPendingFlg.                 */
/*                                                                                              */
/************************************************************************************************/
static void can_tx_set_req(UI_16 tx_handle, UI_8 frame_format, UI_32 id, UI_8 data_len, const UI_8 data_ptr[])
{
	/* If the requested TxHandle is already queued, the current data will be overwritten. */
	CanDrvIF_TxMsg[tx_handle].FrameFormat = frame_format;
	CanDrvIF_TxMsg[tx_handle].Id = id;
	CanDrvIF_TxMsg[tx_handle].DataLen = data_len;
	(void)memcpy(CanDrvIF_TxMsg[tx_handle].DataPtr, data_ptr, (T_CANDRVIF_SIZE_T)data_len);

	/* Set the pending request flag */
	can_set_flg(tx_handle, CanDrvIF_TxBitFlg.TxPendingFlg);
}

/************************************************************************************************/
/* Function name    : can_tx_queue_handling                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <tx_msg_obj_index> - A transmission message object index.                 */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function finds Tx Handle which should be transmitted first.          */
/*                    If a valid Tx Handle is found, this function clears the TxPendingFlg      */
/*                    and TxMsgObj state is changed to CANDRVIFTX_STATE_SENDING.                */
/*                    After that, the actual transmission request is issued to CAN driver.      */
/*                                                                                              */
/************************************************************************************************/
static void can_tx_queue_handling(UI_8 controller, UI_16 tx_msg_obj_index)
{
	UI_16 tx_handle;

	/* Find the handle to be sent. */
	tx_handle = can_get_top_handle(CANDRVIFTX_BIT_FLG_INDEX_CNT, (const UI_16 *)CanDrvIF_TxBitFlg.TxPendingFlg, C_CanDrvIF_Cfg[controller].TxBitFlgTxMsgObjMaskPtr[tx_msg_obj_index]);
	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {
		/* A valid handle has been found. */
		/* Clear the pending flag and set the current tx object. */
		can_clr_flg(tx_handle, CanDrvIF_TxBitFlg.TxPendingFlg);
		CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxHandle = tx_handle;
		CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus = CANDRVIFTX_STATE_SENDING;

		/* Set the request to the driver. */
		can_tx_queue_transmit(controller, tx_msg_obj_index, tx_handle);
	}
}

/************************************************************************************************/
/* Function name    : can_tx_queue_transmit                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <tx_msg_obj_index> - A transmission message object index.                 */
/*                                                                                              */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function calls CanDrv_SetTxReq() to issue the transmission request.  */
/*                    In this function, transmission timeout timer is started.                  */
/*                                                                                              */
/************************************************************************************************/
static void can_tx_queue_transmit(UI_8 controller, UI_16 tx_msg_obj_index, UI_16 tx_handle)
{
	T_CanDrvIF_Msg *tx_msg_ptr;

	tx_msg_ptr = &CanDrvIF_TxMsg[tx_handle];

	/* Start timer and set the request data to the driver. */
	CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt = CANDRVIF_TIMER_TX_TIMEOUT;
	CanDrv_SetTxReq(controller, tx_msg_obj_index, tx_msg_ptr->FrameFormat, tx_msg_ptr->Id, tx_msg_ptr->DataLen, (const UI_8 *)tx_msg_ptr->DataPtr);
}

/************************************************************************************************/
/* Function name    : can_get_top_handle                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <flg_index_cnt> - The number of elements in bit flag array.               */
/*                                                                                              */
/*                    <flg> - Pointer to a bit flag array.                                      */
/*                                                                                              */
/*                    <flg_mask> - Pointer to a bit flag mask array                             */
/*                                                                                              */
/* Return value     : Handle index with the highest priority (Lower number)                     */
/*                    If no valid handle is found, CANDRVIF_HANDLE_INVALID is returned.         */
/*                                                                                              */
/* Description      : This function returns a Tx or Rx Handle index with the highest priority   */
/*                    with the NTZ method.                                                      */
/*                                                                                              */
/************************************************************************************************/
static UI_16 can_get_top_handle(UI_16 flg_index_cnt, const UI_16 flg[], const UI_16 flg_mask[])
{
	UI_16 flg_index;
	UI_16 valid_flags;
	UI_16 wk_ntz; /* Number of Training Zero (NTZ) */
	UI_16 handle;

	handle = CANDRVIF_HANDLE_INVALID;

	for (flg_index = 0U; flg_index < flg_index_cnt; flg_index++) {
		valid_flags = (UI_16)(flg[flg_index] & flg_mask[flg_index]);
		if (valid_flags != 0U) {
			/* Number of Training Zero (NTZ) */
			wk_ntz = ((UI_16)~valid_flags & (valid_flags - 1U));
			wk_ntz = (wk_ntz & 0x5555U) + ((wk_ntz & 0xAAAAU) >> 1U);
			wk_ntz = (wk_ntz & 0x3333U) + ((wk_ntz & 0xCCCCU) >> 2U);
			wk_ntz = (wk_ntz & 0x0F0FU) + ((wk_ntz & 0xF0F0U) >> 4U);
			wk_ntz = (wk_ntz & 0x00FFU) + ((wk_ntz & 0xFF00U) >> 8U);
			/* Get handle */
			handle = (flg_index * 16U) + wk_ntz;
			break;
		}
	}

	return handle;
}

/************************************************************************************************/
/* Function name    : can_set_flg                                                               */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <handle> - Tx or Rx Handle                                                */
/*                                                                                              */
/*                    [in-out]                                                                  */
/*                    <flg> - Pointer to a bit flag array in RAM.                               */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function sets the bit corresponded to the Handle                     */
/*                    in the bit flag array.                                                    */
/*                                                                                              */
/************************************************************************************************/
static void can_set_flg(UI_16 handle, UI_16 flg[])
{
	UI_16 flg_index;
	UI_16 flg_mask;

	flg_index = (UI_16)(handle >> 4U);
	flg_mask = (UI_16)1U << (handle & 0x000FU);

	flg[flg_index] |= flg_mask;
}

/************************************************************************************************/
/* Function name    : can_clr_flg                                                               */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <handle> - Tx or Rx Handle                                                */
/*                                                                                              */
/*                    [in-out]                                                                  */
/*                    <flg> - Pointer to a bit flag array in RAM.                               */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears the bit corresponded to the Handle                   */
/*                    in the bit flag array.                                                    */
/*                                                                                              */
/************************************************************************************************/
static void can_clr_flg(UI_16 handle, UI_16 flg[])
{
	UI_16 flg_index;
	UI_16 flg_mask;

	flg_index = (UI_16)(handle >> 4U);
	flg_mask = (UI_16)1U << (handle & 0x000FU);

	flg[flg_index] &= (UI_16)~flg_mask;
}

/************************************************************************************************/
/* Function name    : can_chk_flg                                                               */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <handle> - Tx or Rx Handle                                                */
/*                                                                                              */
/*                    <flg> - Pointer to a bit flag array.                                      */
/*                                                                                              */
/* Return value     : - D_FALSE : The corresponding bit is 0                                    */
/*                    - D_TRUE  : The corresponding bit is 1                                    */
/*                                                                                              */
/* Description      : This function checks if the bit corresponded to the Handle                */
/*                    in the bit flag array is set.                                             */
/*                    If the bit is set, this function returns D_TRUE, otherwise D_FALSE.       */
/*                                                                                              */
/************************************************************************************************/
static UI_8 can_chk_flg(UI_16 handle, const UI_16 flg[])
{
	UI_16 flg_index;
	UI_16 flg_mask;
	UI_8 bit;

	bit = D_FALSE;

	flg_index = (UI_16)(handle >> 4U);
	flg_mask = (UI_16)1U << (handle & 0x000FU);

	if ((flg[flg_index] & flg_mask) != 0U) {
		bit = D_TRUE;
	}

	return bit;
}

/************************************************************************************************/
/* Function name    : can_clr_all_flg                                                           */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <flg_index_cnt> - The number of elements in bit flag array.               */
/*                                                                                              */
/*                    <flg_mask> - Pointer to a bit flag mask array                             */
/*                                                                                              */
/*                    [in-out]                                                                  */
/*                    <flg> - Pointer to a bit flag array in RAM.                               */
/*                                                                                              */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears all bits in the bit flag array.                      */
/*                    Affected bits can be specified by using the bit flag mask array.          */
/*                                                                                              */
/************************************************************************************************/
static void can_clr_all_flg(UI_16 flg_index_cnt, UI_16 flg[], const UI_16 flg_mask[])
{
	UI_16 flg_index;

	for (flg_index = 0U; flg_index < flg_index_cnt; flg_index++) {
		flg[flg_index] &= (UI_16)~flg_mask[flg_index];
	}
}

/************************************************************************************************/
/* Function name    : can_chk_all_flg                                                           */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <flg_index_cnt> - The number of elements in bit flag array.               */
/*                                                                                              */
/*                    <flg> - Pointer to a bit flag array.                                      */
/*                                                                                              */
/*                    <flg_mask> - Pointer to a bit flag mask array                             */
/*                                                                                              */
/* Return value     : - D_FALSE : All bits are 0                                                */
/*                    - D_TRUE  : One or more bits are 1                                        */
/*                                                                                              */
/* Description      : This function checks if one or more bits in the bit flag array is 1.      */
/*                    If all bits are 0, this function returns D_FALSE, otherwise D_TRUE.       */
/*                    Bits should be checked can be specified by using the bit flag mask array. */
/*                                                                                              */
/************************************************************************************************/
static UI_8 can_chk_all_flg(UI_16 flg_index_cnt, const UI_16 flg[], const UI_16 flg_mask[])
{
	UI_16 flg_index;
	UI_8 chk_result;

	chk_result = D_FALSE;

	for (flg_index = 0U; flg_index < flg_index_cnt; flg_index++) {
		if ((flg[flg_index] & flg_mask[flg_index]) != 0U) {
			chk_result = D_TRUE;
			break;
		}
	}

	return chk_result;
}

/************************************************************************************************/
/* Function name    : can_rx_find_handle                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tbl_ptr> - Pointer to a structure                                        */
/*                                with Rx Handle search table information.                      */
/*                                                                                              */
/*                    <frame_format> - CAN frame format of the received message.                */
/*                     CANDRVIF_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)            */
/*                     CANDRVIF_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)            */
/*                                                                                              */
/*                    <id> - CAN identifier of the received message.                            */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                                                                                              */
/* Return value     : If a valid Rx Handle is found, the Rx Handle is returned.                 */
/*                    The valid Rx Handle range is from 0 to CANDRVIFRX_HANDLE_CNT - 1.         */
/*                                                                                              */
/*                    If a valid Rx Handle is not found, CANDRVIF_HANDLE_INVALID is returned.   */
/*                                                                                              */
/* Description      : This function searches the search tables to find a valid Rx Handle.       */
/*                    The search tables exist for each CAN frame format.                        */
/*                    First the corresponding Hash Search Table is searched.                    */
/*                    If a valid Rx Handle is not found then the corresponding                  */
/*                    Linear Search Table is searched.                                          */
/*                                                                                              */
/*                    If a valid Rx Handle is not found,                                        */
/*                    this function returnes CANDRVIF_HANDLE_INVALID.                           */
/*                                                                                              */
/************************************************************************************************/
static UI_16 can_rx_find_handle(const T_CanDrvIF_RxSearchTbl *tbl_ptr, UI_8 frame_format, UI_32 id)
{
	UI_16 rx_handle;

	rx_handle = CANDRVIF_HANDLE_INVALID;

	if (frame_format == CANDRVIF_CAN_STANDARD_FRAME) {
		/* ID Type : Standard(11-bit identifier) */
		/* Try to find a valid RxHandle from the hash tabel. */
		if ((tbl_ptr->IndexTblStdCnt != 0U) && (tbl_ptr->HashTblStdCnt != 0U)) {
			rx_handle = can_rx_hash_search(id, tbl_ptr->IndexTblStdCnt, tbl_ptr->IndexTblStdPtr, tbl_ptr->HashTblStdPtr);
		}
		/* If a valid RxHandle is not found, try to find a valid RxHandle from the linear table. */
		if ((rx_handle == CANDRVIF_HANDLE_INVALID) && (tbl_ptr->LinearTblStdCnt != 0U)) {
			rx_handle = can_rx_linear_search(id, tbl_ptr->LinearTblStdCnt, tbl_ptr->LinearTblStdPtr);
		}
	} else if (frame_format == CANDRVIF_CAN_EXTENDED_FRAME) {
		/* ID Type : Extended(29-bit identifier) */
		/* Try to find a valid RxHandle from the hash tabel. */
		if ((tbl_ptr->IndexTblExtCnt != 0U) && (tbl_ptr->HashTblExtCnt != 0U)) {
			rx_handle = can_rx_hash_search(id, tbl_ptr->IndexTblExtCnt, tbl_ptr->IndexTblExtPtr, tbl_ptr->HashTblExtPtr);
		}
		/* If a valid RxHandle is not found, try to find a valid RxHandle from the linear table. */
		if ((rx_handle == CANDRVIF_HANDLE_INVALID) && (tbl_ptr->LinearTblExtCnt != 0U)) {
			rx_handle = can_rx_linear_search(id, tbl_ptr->LinearTblExtCnt, tbl_ptr->LinearTblExtPtr);
		}
	} else {
		/* avoid MISRA warning */
	}

	return rx_handle;
}

/************************************************************************************************/
/* Function name    : can_rx_hash_search                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <id> - CAN identifier of the received message.                            */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                                                                                              */
/*                    <index_tbl_size> -  The number of elements in IndexTbl.                   */
/*                                                                                              */
/*                    <index_tbl> - Pointer to IndexTbl                                         */
/*                                                                                              */
/*                    <tbl> - Pointer to HashTbl                                                */
/*                                                                                              */
/*                                                                                              */
/* Return value     : If a valid Rx Handle is found, the Rx Handle is returned.                 */
/*                    The valid Rx Handle range is from 0 to CANDRVIFRX_HANDLE_CNT - 1.         */
/*                                                                                              */
/*                    If a valid Rx Handle is not found, CANDRVIF_HANDLE_INVALID is returned.   */
/*                                                                                              */
/* Description      : This function tries to find a valid Rx Handle                             */
/*                    with the following procedures.                                            */
/*                                                                                              */
/*                    Step1. Get <<TBL_INDEX>> = <index_tbl>[(<id> % <index_tbl_size>)]         */
/*                                                                                              */
/*                      - If <<TBL_INDEX>> == 0xFFFFU                                           */
/*                         ---> End of searching. No valid RxHandle was found.                  */
/*                      - If <<TBL_INDEX>> != 0xFFFFU                                           */
/*                         ---> Go to Step2                                                     */
/*                                                                                              */
/*                    Step2. Get <<VALID_ID>> = <tbl>[<<TBL_INDEX>>].IdInfo & 0x1FFFFFFFU       */
/*                                                                                              */
/*                      - If <<VALID_ID>> == <id>                                               */
/*                         ---> Get <<RxHandle>>                                                */
/*                              = <tbl>[<<TBL_INDEX>>].RxHandle                                 */
/*                              End of searching. A valid RxHandle(= <<RxHandle>>) was found.   */
/*                      - If <<VALID_ID>> != <id>                                               */
/*                         ---> Go to Step3                                                     */
/*                                                                                              */
/*                    Step3. Get <<STOP_MARK>> = <tbl>[<<TBL_INDEX>>].IdInfo & 0x80000000U      */
/*                                                                                              */
/*                      - If <<STOP_MARK>> != 0U                                                */
/*                         ---> End of searching. No valid RxHandle was found.                  */
/*                      - If <<STOP_MARK>> == 0U                                                */
/*                         ---> <<TBL_INDEX>> += 1U, then Go to Step2.                          */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                    CANDRVIF{x}_INDEX_TBL_{XXX}_CNT, C_CanDrvIF{x}_IndexTbl{Xxx} and          */
/*                    C_CanDrvIF{x}_HashTbl{Xxx} are passed as <index_tbl_size>, <index_tbl>    */
/*                    and <tbl> respectively.                                                   */
/*                                                                                              */
/*                    {x}   : Controller Index [0...(CANDRVIF_CONTROLLER_CNT - 1)]              */
/*                    {Xxx} : Frame Format [Std or Ext]                                         */
/*                    {XXX} : Frame Format [STD or EXT]                                         */
/*                                                                                              */
/*                    If a valid Rx Handle is not found,                                        */
/*                    this function returnes CANDRVIF_HANDLE_INVALID.                           */
/*                                                                                              */
/************************************************************************************************/
static UI_16 can_rx_hash_search(UI_32 id, UI_16 index_tbl_size, const UI_16 index_tbl[], const T_CanDrvIF_HashTbl tbl[])
{
	UI_16 rx_handle;
	UI_16 key;
	UI_16 index;
	UI_32 stored_id;
	UI_32 serch_end_bit;

	rx_handle = CANDRVIF_HANDLE_INVALID;

	key = (UI_16)(id % index_tbl_size);
	index = index_tbl[key];

	if (index != 0xFFFFU) {
		do {
			stored_id = tbl[index].IdInfo & 0x1FFFFFFFU;
			if (stored_id == id) {
				rx_handle = tbl[index].RxHandle;
				break;
			}
			serch_end_bit = tbl[index].IdInfo & 0x80000000U;
			index++;
		} while (serch_end_bit == 0U);
	}
	
	return rx_handle;
}

/************************************************************************************************/
/* Function name    : can_rx_linear_search                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <id> - CAN identifier of the received message.                            */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                                                                                              */
/*                    <tbl_size> -  The number of elements in LinearTbl.                        */
/*                                                                                              */
/*                    <tbl> - Pointer to LinearTbl                                              */
/*                                                                                              */
/*                                                                                              */
/* Return value     : If a valid Rx Handle is found, the Rx Handle is returned.                 */
/*                    The valid Rx Handle range is from 0 to CANDRVIFRX_HANDLE_CNT - 1.         */
/*                                                                                              */
/*                    If a valid Rx Handle is not found, CANDRVIF_HANDLE_INVALID is returned.   */
/*                                                                                              */
/* Description      : This function searches Linear Search Table to find a valid Rx Handle.     */
/*                                                                                              */
/*                    e.g.                                                                      */
/*                     If the <tbl> has the following parameters.                               */
/*                      .IdMask =  0x1FFFFFF0                                                   */
/*                      .IdInfo = 0x000007F0                                                    */
/*                     valid <id> is from 0x000007F0 to 0x000007FF.                             */
/*                                                                                              */
/*                                                                                              */
/*                    CANDRVIF{x}_LINEAR_TBL_{XXX}_CNT and C_CanDrvIF{x}_LinearTbl{Xxx} are     */
/*                    passed as <tbl_size> and <tbl> respectively.                              */
/*                                                                                              */
/*                    {x}   : Controller Index [0...(CANDRVIF_CONTROLLER_CNT - 1)]              */
/*                    {Xxx} : Frame Format [Std or Ext]                                         */
/*                    {XXX} : Frame Format [STD or EXT]                                         */
/*                                                                                              */
/*                    If a valid Rx Handle is not found,                                        */
/*                    this function returnes CANDRVIF_HANDLE_INVALID.                           */
/*                                                                                              */
/************************************************************************************************/
static UI_16 can_rx_linear_search(UI_32 id, UI_16 tbl_size, const T_CanDrvIF_LinearTbl tbl[])
{
	UI_16 rx_handle;
	UI_16 index;

	rx_handle = CANDRVIF_HANDLE_INVALID;

	for (index = 0U; index < tbl_size; index++) {
		if ((id & tbl[index].IdMask) == (tbl[index].IdInfo & tbl[index].IdMask)) {
			rx_handle = tbl[index].RxHandle;
			break;
		}
	}

	return rx_handle;
}

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
/************************************************************************************************/
/* Function name    : CanDrvIF_Init                                                             */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function initializes all of the internal memory.                     */
/*                    A user has to call this function before the other APIs                    */
/*                    of CAN Driver Interface are used.                                         */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_Init(void)
{
	can_init_memory();
}

/************************************************************************************************/
/* Function name    : CanDrvIF_InitController                                                   */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <cmd> - A request command for controlling the operation state.            */
/*                     CANDRVIF_CMD_START          : Start CAN startup sequence.                */
/*                     CANDRVIF_CMD_START_WITH_CHK : Start CAN startup sequence with RAM check. */
/*                     CANDRVIF_CMD_STOP           : Start CAN shutdown sequence                */
/*                                                                                              */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function receives the request command                                */
/*                    to control the operation state.                                           */
/*                    The actual state transition is done in CanDrvIF_Main().                   */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_InitController(const UI_8 controller, const UI_8 cmd)
{
	if ((controller < CANDRVIF_CONTROLLER_CNT) && (cmd < CANDRVIF_CMD_CNT)) {
		CanDrvIF_Ctrl[controller].ReqCmd = cmd;
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetState                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : - CANDRVIF_STATE_STOP           : CAN communication is closed             */
/*                                                     (Initial state).                         */
/*                                                                                              */
/*                    - CANDRVIF_STATE_START          : CAN communication is ready.             */
/*                                                                                              */
/*                    - CANDRVIF_STATE_WAIT_FOR_STOP  : Waiting for the CAN driver              */
/*                                                      to close CAN communication.             */
/*                                                                                              */
/*                    - CANDRVIF_STATE_WAIT_FOR_START : Waiting for the CAN driver              */
/*                                                      to open CAN communication.              */
/*                                                                                              */
/*                    - CANDRVIF_STATE_MSG_RAM_ERR    : Message ram error has been detected     */
/*                                                      during initialization sequence.         */
/*                                                                                              */
/*                    - CANDRVIF_STATE_TIMEOUT        : State transition timeout                */
/*                                                      has been detected.                      */
/*                                                                                              */
/*                    - CANDRVIF_STATE_BUSOFF         : Bus off error has been detected.        */
/*                                                                                              */
/*                    - CANDRVIF_STATE_CNT            : Invalid value                           */
/*                                                                                              */
/*                    If parameter is invalid, CANDRVIF_STATE_CNT is returned.                  */
/*                                                                                              */
/* Description      : This function returns the operation state of CAN Driver Interface.        */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetState(const UI_8 controller)
{
	UI_8 cur_status;

	cur_status = CANDRVIF_STATE_CNT;
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		cur_status = CanDrvIF_Ctrl[controller].Status;
	}

	return cur_status;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_SetTxReq                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/*                    <data_ptr> - Pointer to a memory location where                           */
/*                                 the transmission data is stored.                             */
/*                     If the data pointer is NULL, preconfigured data length must be zero.     */
/*                     Otherwise, this function ignores the transmission request.               */
/*                                                                                              */
/* Return value     : - CANDRVIF_NOT_OK : Transmission request has not been accepted.           */
/*                    - CANDRVIF_OK     : Transmission request has been accepted.               */
/*                    If parameters are invalid, CANDRVIF_NOT_OK is returned.                   */
/*                                                                                              */
/* Description      : This function receives a transmission request                             */
/*                    and stores it to the internal request buffer.                             */
/*                    A user can specify the transmission data.                                 */
/*                    The other parameters cannot be changed                                    */
/*                    from preconfigured CAN message information.                               */
/*                                                                                              */
/*                    If the request of the Tx Handle is already buffered,                      */
/*                    the current request is overwritten.                                       */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_SetTxReq(const UI_16 tx_handle, const UI_8 data_ptr[])
{
	UI_8 set_result;
	UI_8 controller;
	UI_8 frame_format;
	UI_32 id;
	UI_8 data_len;
	UI_16 mask_level;

	set_result = CANDRVIF_NOT_OK;

	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {

		data_len = C_CanDrvIF_TxCfg[tx_handle].DataLen;
		if (((data_ptr != D_NULL) && (data_len != 0U)) || (data_len == 0U)) {

			controller = C_CanDrvIF_TxCfg[tx_handle].Controller;
			frame_format = C_CanDrvIF_TxCfg[tx_handle].FrameFormat;
			id = C_CanDrvIF_TxCfg[tx_handle].Id;

			can_disable_intr(controller, &mask_level); /* DI */
			can_tx_set_req(tx_handle, frame_format, id, data_len, data_ptr);
			can_enable_intr(controller, mask_level); /* EI */

			set_result = CANDRVIF_OK;
		}
	}

	return set_result;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_SetTxDynamicReq                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/*                    <frame_format> - CAN frame format to be transmitted.                      */
/*                     CANDRVIF_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)            */
/*                     CANDRVIF_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)            */
/*                                                                                              */
/*                    <id> - CAN identifier to be transmitted.                                  */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                                                                                              */
/*                    <data_len> - Data length to be transmitted in byte                        */
/*                     0-64                                                                     */
/*                     If <data_len> exceeds the preconfigured transmission data length,        */
/*                     the transmission request is ignored.                                     */
/*                                                                                              */
/*                    <data_ptr> - Pointer to a memory location where                           */
/*                                 the transmission data is stored.                             */
/*                     If the data pointer is NULL, <data_len> must be zero.                    */
/*                     Otherwise, this function ignores the transmission request.               */
/*                                                                                              */
/* Return value     : - CANDRVIF_NOT_OK : Transmission request has not been accepted.           */
/*                    - CANDRVIF_OK     : Transmission request has been accepted.               */
/*                    If parameters are invalid, CANDRVIF_NOT_OK is returned.                   */
/*                                                                                              */
/* Description      : This function receives a transmission request                             */
/*                    and stores it to the internal request buffer.                             */
/*                    A user can specify CAN message information using the parameters           */
/*                    of this function instead of the preconfigured value.                      */
/*                                                                                              */
/*                    If the request of the Tx Handle is already buffered,                      */
/*                    the current request is overwritten.                                       */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_SetTxDynamicReq(const UI_16 tx_handle, const UI_8 frame_format, const UI_32 id, const UI_8 data_len, const UI_8 data_ptr[])
{
	UI_8 set_result;
	UI_8 controller;
	UI_16 mask_level;

	set_result = CANDRVIF_NOT_OK;

	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {
		if (((data_ptr != D_NULL) && (data_len <= C_CanDrvIF_TxCfg[tx_handle].DataLen)) || (data_len == 0U)) {
			if (frame_format < CANDRVIF_FRAME_FORMAT_CNT) {

				controller = C_CanDrvIF_TxCfg[tx_handle].Controller;

				can_disable_intr(controller, &mask_level); /* DI */
				can_tx_set_req(tx_handle, frame_format, id, data_len, data_ptr);
				can_enable_intr(controller, mask_level); /* EI */

				set_result = CANDRVIF_OK;
			}
		}
	}

	return set_result;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ClrAllTxReq                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function handles software cancellation and hardware cancellation     */
/*                    for all of the Tx Handle retated to the CAN controller index              */
/*                    specified with <controller>.                                              */
/*                                                                                              */
/*                    Software cancellation                                                     */
/*                     If a pending request of the Tx Handle exists in CAN Driver Interface's   */
/*                     internal request buffer. the request is removed                          */
/*                     then a User function is called if needed.                                */
/*                                                                                              */
/*                    Hardware cancellation                                                     */
/*                     If a transmission request of the Tx Handle is already issued to          */
/*                     CAN driver, CanDrv_ClrTxReq() is called to clear the transmission        */
/*                     request in the CAN controller.                                           */
/*                     In this case, TxMsgObj state related to the Tx Handle is changed to      */
/*                     CANDRVIFTX_STATE_CANCELLING. Then, the actual cancell completion is      */
/*                     confirmed in CanDrvIF_ActivateTx().                                      */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_ClrAllTxReq(const UI_8 controller)
{
	UI_16 tx_handle;
	UI_8 cancelled;
	UI_16 tx_msg_obj_index;
	UI_16 mask_level;

	if (controller < CANDRVIF_CONTROLLER_CNT) {

		/* Clear all pending requests in the specified controller. */
		for (tx_handle = 0U; tx_handle < CANDRVIFTX_HANDLE_CNT; tx_handle++) {
			if (C_CanDrvIF_TxCfg[tx_handle].Controller == controller) {

				cancelled = D_FALSE;
				can_disable_intr(controller, &mask_level); /* DI */
				if (can_chk_flg(tx_handle, (const UI_16 *)CanDrvIF_TxBitFlg.TxPendingFlg) != D_FALSE) {
					/* Clear a pending request. */
					can_clr_flg(tx_handle, CanDrvIF_TxBitFlg.TxPendingFlg);
					cancelled = D_TRUE;
				}
				can_enable_intr(controller, mask_level); /* EI */

				if (cancelled != D_FALSE) {
					/* A pending request has been cleared. Set the TxCancelNotificationFlg. */
					can_set_flg(tx_handle, CanDrvIF_TxBitFlg.TxCancelNotificationFlg);
					/* Check if this cancellation event need to be notified to the upper layer. */
					if (C_CanDrvIF_TxCfg[tx_handle].TxCancelNotificationFunc != D_NULL) {
						C_CanDrvIF_TxCfg[tx_handle].TxCancelNotificationFunc(tx_handle);
					}
				}
			}
		}

		for (tx_msg_obj_index = 0U; tx_msg_obj_index < C_CanDrvIF_Cfg[controller].TxMsgObjCnt; tx_msg_obj_index++) {
			/* Clear a request running in the CAN controller. */
			can_disable_intr(controller, &mask_level); /* DI */
			/* Check if a transmission request has been issued to the driver. */
			if (CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus == CANDRVIFTX_STATE_SENDING) {
				/* A cancel request has not been issued yet. Issue the cancel request. */
				CanDrv_ClrTxReq(controller, tx_msg_obj_index);
				/* Set the current transmission state to cancelling then stop the tx timer. */
				CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus = CANDRVIFTX_STATE_CANCELLING;
				CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt = CANDRVIF_TIMER_STOP;
			}
			can_enable_intr(controller, mask_level); /* EI */
		}
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ClrTxReq                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function handles software cancellation and hardware cancellation     */
/*                    for the Tx Handle specified with <tx_handle>.                             */
/*                                                                                              */
/*                    Software cancellation                                                     */
/*                     If a pending request of the Tx Handle exists in CAN Driver Interface's   */
/*                     internal request buffer. the request is removed                          */
/*                     then a User function is called if needed.                                */
/*                                                                                              */
/*                    Hardware cancellation                                                     */
/*                     If a transmission request of the Tx Handle is already issued to          */
/*                     CAN driver, CanDrv_ClrTxReq() is called to clear the transmission        */
/*                     request in the CAN controller.                                           */
/*                     In this case, TxMsgObj state related to the Tx Handle is changed to      */
/*                     CANDRVIFTX_STATE_CANCELLING. Then, the actual cancell completion is      */
/*                     confirmed in CanDrvIF_ActivateTx().                                      */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_ClrTxReq(const UI_16 tx_handle)
{
	UI_8 controller;
	UI_8 cancelled;
	UI_16 tx_msg_obj_index;
	UI_16 mask_level;

	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {

		controller = C_CanDrvIF_TxCfg[tx_handle].Controller;

		/* Clear a pending request of the specified tx handler. */
		cancelled = D_FALSE;
		can_disable_intr(controller, &mask_level); /* DI */
		if (can_chk_flg(tx_handle, (const UI_16 *)CanDrvIF_TxBitFlg.TxPendingFlg) != D_FALSE) {
			/* Clear a pending request. */
			can_clr_flg(tx_handle, CanDrvIF_TxBitFlg.TxPendingFlg);
			cancelled = D_TRUE;
		}
		can_enable_intr(controller, mask_level); /* EI */

		if (cancelled != D_FALSE) {
			/* A pending request has been cleared. Set the TxCancelNotificationFlg. */
			can_set_flg(tx_handle, CanDrvIF_TxBitFlg.TxCancelNotificationFlg);
			/* Check if this cancellation event need to be notified to the upper layer. */
			if (C_CanDrvIF_TxCfg[tx_handle].TxCancelNotificationFunc != D_NULL) {
				C_CanDrvIF_TxCfg[tx_handle].TxCancelNotificationFunc(tx_handle);
			}
		}


		/* Clear a request running in the CAN controller. */
		tx_msg_obj_index = C_CanDrvIF_TxCfg[tx_handle].TxMsgObjIndex;

		can_disable_intr(controller, &mask_level); /* DI */
		/* Check if a transmission request has been issued to the driver. */
		if (CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus == CANDRVIFTX_STATE_SENDING) {
			/* Check if the tx handle is in progress. */
			if (tx_handle == CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxHandle) {
				/* A cancel request has not been issued yet. Issue the cancel request. */
				CanDrv_ClrTxReq(controller, tx_msg_obj_index);
				/* Set the current transmission state to cancelling then stop the tx timer. */
				CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus = CANDRVIFTX_STATE_CANCELLING;
				CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt = CANDRVIF_TIMER_STOP;
			}
		}
		can_enable_intr(controller, mask_level); /* EI */
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ChkAllTxState                                                    */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : Each bit represents the current transmission state                        */
/*                    related to the CAN controller index specified with <controller>.          */
/*                    Return value is ORed with all of the Tx Handle's state                    */
/*                    in the specified CAN controller index.                                    */
/*                    Multiple bits coudld be 1.                                                */
/*                                                                                              */
/*                    - CANDRVIFTX_STATE_IDLE       : Bit position - 0000 0000b                 */
/*                       All of the Tx Handle are in state idle.                                */
/*                       No transmission handling is on going.                                  */
/*                                                                                              */
/*                    - CANDRVIFTX_STATE_SENDING    : Bit position - 0000 0001b                 */
/*                       One or more Tx Handle are being transmitted.                           */
/*                       One or more transmission handling are ongoing.                         */
/*                                                                                              */
/*                    - CANDRVIFTX_STATE_CANCELLING : Bit position - 0000 0002b                 */
/*                       One or more Tx Handle are being cancelled.                             */
/*                       One or more cancellation handling are ongoing.                         */
/*                                                                                              */
/*                    - CANDRVIFTX_STATE_WAITING    : Bit position - 0000 0004b                 */
/*                       One or more Tx Handle's requests are pending.                          */
/*                                                                                              */
/*                    If parameter is invalid, CANDRVIFTX_STATE_IDLE is returned.               */
/*                                                                                              */
/* Description      : This function returns the current transmission state of the Tx Handle     */
/*                    which are related to the CAN controller index                             */
/*                    specified with <controller>.                                              */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_ChkAllTxState(const UI_8 controller)
{
	UI_8 tx_status;
	UI_16 tx_msg_obj_index;
	UI_16 mask_level;

	tx_status = CANDRVIFTX_STATE_IDLE;

	if (controller < CANDRVIF_CONTROLLER_CNT) {

		can_disable_intr(controller, &mask_level); /* DI */
		for (tx_msg_obj_index = 0U; tx_msg_obj_index < C_CanDrvIF_Cfg[controller].TxMsgObjCnt; tx_msg_obj_index++) {
			tx_status |= CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus;
		}

		if (can_chk_all_flg(CANDRVIFTX_BIT_FLG_INDEX_CNT, (const UI_16 *)CanDrvIF_TxBitFlg.TxPendingFlg, C_CanDrvIF_Cfg[controller].TxBitFlgControllerMaskPtr) != D_FALSE) {
			tx_status |= CANDRVIFTX_STATE_WAITING;
		}
		can_enable_intr(controller, mask_level); /* EI */

	}

	return tx_status;

}

/************************************************************************************************/
/* Function name    : CanDrvIF_ChkTxState                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/* Return value     : Each bit represents the current transmission state of the Tx Handle       */
/*                    which is specified with <tx_handle>.                                      */
/*                    Multiple bits coudld be 1 but CANDRVIFTX_STATE_SENDING and                */
/*                    CANDRVIFTX_STATE_CANCELLING are mutually exclusive.                       */
/*                                                                                              */
/*                    - CANDRVIFTX_STATE_IDLE       : Bit position - 0000 0000b                 */
/*                       The Tx Handle is in state idle.                                        */
/*                       No transmission handling is on going.                                  */
/*                                                                                              */
/*                    - CANDRVIFTX_STATE_SENDING    : Bit position - 0000 0001b                 */
/*                       The Tx Handle is being transmitted.                                    */
/*                       A transmission handling is ongoing.                                    */
/*                                                                                              */
/*                    - CANDRVIFTX_STATE_CANCELLING : Bit position - 0000 0002b                 */
/*                       The Tx Handle is being cancelled.                                      */
/*                       A cancellation handling is ongoing.                                    */
/*                                                                                              */
/*                    - CANDRVIFTX_STATE_WAITING    : Bit position - 0000 0004b                 */
/*                       The Tx Handle's request is pending.                                    */
/*                                                                                              */
/*                    If parameter is invalid, CANDRVIFTX_STATE_IDLE is returned.               */
/*                                                                                              */
/* Description      : This function returns the current transmission state of the Tx Handle.    */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_ChkTxState(const UI_16 tx_handle)
{
	UI_8 tx_status;
	UI_8 controller;
	UI_16 tx_msg_obj_index;
	UI_16 mask_level;

	tx_status = CANDRVIFTX_STATE_IDLE;

	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {

		controller = C_CanDrvIF_TxCfg[tx_handle].Controller;
		tx_msg_obj_index = C_CanDrvIF_TxCfg[tx_handle].TxMsgObjIndex;

		can_disable_intr(controller, &mask_level); /* DI */
		if (tx_handle == CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxHandle) {
			tx_status = CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus;
		}
		if (can_chk_flg(tx_handle, (const UI_16 *)CanDrvIF_TxBitFlg.TxPendingFlg) != D_FALSE) {
			tx_status |= CANDRVIFTX_STATE_WAITING;
		}
		can_enable_intr(controller, mask_level); /* EI */

	}

	return tx_status;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetErrState                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : - CANDRVIF_ERR_STATE_ACTIVE : No error                                    */
/*                    - CANDRVIF_ERR_STATE_WARNING : Warning                                    */
/*                    - CANDRVIF_ERR_STATE_PASSIVE : Error Passive                              */
/*                    - CANDRVIF_ERR_STATE_BUSOFF : BusOff                                      */
/*                    If parameter is invalid, CANDRVIF_ERR_STATE_ACTIVE is returned.           */
/*                                                                                              */
/* Description      : This function gets the current error state via CanDrv_GetErrState()       */
/*                    and returns the obtained value.                                           */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetErrState(const UI_8 controller)
{
	UI_8 ret_val;

	ret_val = CANDRVIF_ERR_STATE_ACTIVE;
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		ret_val = CanDrv_GetErrState(controller);
	}

	return ret_val;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetTxErrCnt                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : Tx Error Count (0 - 256)                                                  */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function gets the current Tx Error Count via CanDrv_GetTxErrCnt()    */
/*                    and returns the obtained value.                                           */
/*                                                                                              */
/************************************************************************************************/
UI_16 CanDrvIF_GetTxErrCnt(const UI_8 controller)
{
	UI_16 ret_val;

	ret_val = 0U;
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		ret_val = CanDrv_GetTxErrCnt(controller);
	}

	return ret_val;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetRxErrCnt                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : Rx Error Count (0 - 128)                                                  */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function gets the current Rx Error Count via CanDrv_GetRxErrCnt()    */
/*                    and returns the obtained value.                                           */
/*                                                                                              */
/************************************************************************************************/
UI_16 CanDrvIF_GetRxErrCnt(const UI_8 controller)
{
	UI_16 ret_val;

	ret_val = 0U;
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		ret_val = CanDrv_GetRxErrCnt(controller);
	}

	return ret_val;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ChkTxConfirmation                                                */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/* Return value     : - D_FALSE : A transmission completion has not been confirmed.             */
/*                    - D_TRUE  : A transmission completion has been confirmed.                 */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns whether a transmission completion                   */
/*                    has been confirmed.                                                       */
/*                                                                                              */
/*                    This function reads and clears TxConfirmationFlg.                         */
/*                    Therefore, when multiple function call for one event is excecuted,        */
/*                    only the first function call retuns D_TRUE.                               */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_ChkTxConfirmation(const UI_16 tx_handle)
{
	UI_8 flg;
	UI_8 controller;
	UI_16 mask_level;

	flg = D_FALSE;
	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {

		controller = C_CanDrvIF_TxCfg[tx_handle].Controller;

		can_disable_intr(controller, &mask_level); /* DI */
		flg = can_chk_flg(tx_handle, (const UI_16 *)CanDrvIF_TxBitFlg.TxConfirmationFlg);
		can_clr_flg(tx_handle, CanDrvIF_TxBitFlg.TxConfirmationFlg);
		can_enable_intr(controller, mask_level); /* EI */

	}
	return flg;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ChkTxCancelNotification                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/* Return value     : - D_FALSE : A transmission cancellation has not completed.                */
/*                    - D_TRUE  : A transmission cancellation has completed.                    */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns whether a transmission cancellation has completed.  */
/*                                                                                              */
/*                    This function reads and clears TxCancelNotificationFlg.                   */
/*                    Therefore, when multiple function call for one event is excecuted,        */
/*                    only the first function call retuns D_TRUE.                               */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_ChkTxCancelNotification(const UI_16 tx_handle)
{
	UI_8 flg;
	UI_8 controller;
	UI_16 mask_level;

	flg = D_FALSE;
	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {

		controller = C_CanDrvIF_TxCfg[tx_handle].Controller;

		can_disable_intr(controller, &mask_level); /* DI */
		flg = can_chk_flg(tx_handle, (const UI_16 *)CanDrvIF_TxBitFlg.TxCancelNotificationFlg);
		can_clr_flg(tx_handle, CanDrvIF_TxBitFlg.TxCancelNotificationFlg);
		can_enable_intr(controller, mask_level); /* EI */

	}
	return flg;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetRxMsg                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_handle> - Rx Handle                                                   */
/*                                                                                              */
/*                    [out]                                                                     */
/*                    <rx_msg_ptr> - Pointer to a structure with RxMsg related data             */
/*                                   where the received message information shall be copied.    */
/*                                                                                              */
/*                     This parameter consists of the following data.                           */
/*                                                                                              */
/*                      .FrameFormat - CAN frame format of the received message.                */
/*                       CANDRVIF_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)          */
/*                       CANDRVIF_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)          */
/*                                                                                              */
/*                      .Id - CAN identifier of the received message.                           */
/*                       0x00000000 - 0x000007FF (11-bit identifier)                            */
/*                       0x00000000 - 0x1FFFFFFF (29-bit identifier)                            */
/*                                                                                              */
/*                      .DataLen - Data length of the received message in byte.                 */
/*                       0 - 64                                                                 */
/*                                                                                              */
/*                      .DataPtr - Pointer to where to store the received data buffer.          */
/*                       Only the data in the range of DataLen is valid.                        */
/*                                                                                              */
/*                     If the return value of this function is D_TRUE,                          */
/*                     this parameter is valid and user can use this.                           */
/*                                                                                              */
/*                                                                                              */
/* Return value     : - D_FALSE : A new message has not been received                           */
/*                                and <rx_msg_ptr> has invalid value.                           */
/*                                                                                              */
/*                    - D_TRUE  : A new message has been received                               */
/*                                and valid data can be read from <rx_msg_ptr>.                 */
/*                                                                                              */
/*                    If parameters are invalid, D_FALSE is returned.                           */
/*                                                                                              */
/* Description      : This function provides a user with the received message information.      */
/*                    First, this function checks if a new massage is received by reading       */
/*                    RxIndicationFlg.                                                          */
/*                    If RxIndicationFlg is set, the internal message buffer is copied          */
/*                    to the pointer speicified with the argument.                              */
/*                    Then, RxIndicationFlg is cleared in this function.                        */
/*                    Therefore, when multiple function call for one message reception          */
/*                    is excecuted, only the first function call retuns D_TRUE.                 */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetRxMsg(const UI_16 rx_handle, T_CanDrvIF_Msg *rx_msg_ptr)
{
	UI_8 flg;
	UI_8 controller;
	UI_16 mask_level;
	T_CanDrvIF_Msg *rx_msg_src_ptr;

	flg = D_FALSE;

	if ((rx_handle < CANDRVIFRX_HANDLE_CNT) && (rx_msg_ptr != D_NULL) && (rx_msg_ptr->DataPtr != D_NULL)) {

		controller = C_CanDrvIF_RxCfg[rx_handle].Controller;

		rx_msg_src_ptr = &CanDrvIF_RxMsg[rx_handle];

		can_disable_intr(controller, &mask_level); /* DI */

		if (can_chk_flg(rx_handle, (const UI_16 *)CanDrvIF_RxBitFlg.RxIndicationFlg) != D_FALSE) {
			rx_msg_ptr->FrameFormat = rx_msg_src_ptr->FrameFormat;
			rx_msg_ptr->Id = rx_msg_src_ptr->Id;
			rx_msg_ptr->DataLen = rx_msg_src_ptr->DataLen;
			(void)memcpy(rx_msg_ptr->DataPtr, rx_msg_src_ptr->DataPtr, (T_CANDRVIF_SIZE_T)rx_msg_src_ptr->DataLen);
			flg = D_TRUE;
			can_clr_flg(rx_handle, CanDrvIF_RxBitFlg.RxIndicationFlg);
		}

		can_enable_intr(controller, mask_level); /* EI */

	}

	return flg;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetTxOkFlg                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : - D_FALSE : A message has not been transmitted.                           */
/*                    - D_TRUE  : A message has been transmitted.                               */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the TxOk flag state.                                */
/*                    When CAN Driver Interface confirms transmission completion,               */
/*                    sets the TxOk flag.                                                       */
/*                    If a user needs to monitor this event continuously,                       */
/*                    a user has to call CanDrvIF_ClrTxOkFlg() to clear the flag                */
/*                    at the appropriate time.                                                  */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetTxOkFlg(const UI_8 controller)
{
	UI_8 flg;

	flg = D_FALSE;
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		flg = CanDrvIF_Ctrl[controller].TxOk;
	}

	return flg;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ClrTxOkFlg                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears the TxOk flag.                                       */
/*                    If a user needs to monitor this event continuously,                       */
/*                    this function shall be called after                                       */
/*                    CanDrvIF_GetTxOkFlg() returns D_TRUE.                                     */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_ClrTxOkFlg(const UI_8 controller)
{
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		CanDrvIF_Ctrl[controller].TxOk = D_FALSE;
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetRxOkFlg                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : - D_FALSE : A message has not been received.                              */
/*                    - D_TRUE  : A message has been received.                                  */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the RxOk flag state.                                */
/*                    When CAN Driver Interface receives a message from CAN driver,             */
/*                    sets the RxOk flag regardless of whether CAN Driver Interface finds       */
/*                    the valid RxHandle.                                                       */
/*                    If a user needs to monitor this event continuously,                       */
/*                    a user has to call CanDrvIF_ClrRxOkFlg() to clear the flag                */
/*                    at the appropriate time.                                                  */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetRxOkFlg(const UI_8 controller)
{
	UI_8 flg;

	flg = D_FALSE;
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		flg = CanDrvIF_Ctrl[controller].RxOk;
	}

	return flg;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ClrRxOkFlg                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears the RxOk flag.                                       */
/*                    If a user needs to monitor this event continuously,                       */
/*                    this function shall be called after                                       */
/*                    CanDrvIF_GetRxOkFlg() returns D_TRUE.                                     */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_ClrRxOkFlg(const UI_8 controller)
{
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		CanDrvIF_Ctrl[controller].RxOk = D_FALSE;
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetTxTimeoutFlg                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : - D_FALSE : A transmission timeout error has not been detected.           */
/*                    - D_TRUE  : A transmission timeout error has been detected.               */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the TxTimeout state.                                */
/*                    If CAN Driver Interface detects transmission timeout,                     */
/*                    the TxTimeout state shall be set to D_TRUE.                               */
/*                    A user can configure the thresould time for the timeout.                  */
/*                    If a user needs to monitor the error flag continuously,                   */
/*                    a user has to call CanDrvIF_ClrTxTimeoutFlg() to clear the flag           */
/*                    at the appropriate time.                                                  */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetTxTimeoutFlg(const UI_8 controller)
{
	UI_8 flg;

	flg = D_FALSE;
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		flg = CanDrvIF_Ctrl[controller].TxTimeout;
	}

	return flg;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ClrTxTimeoutFlg                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function sets the TxTimeout state to D_FALSE.                        */
/*                    If a user needs to monitor a transmission timeout error continuously,     */
/*                    this function shall be called after                                       */
/*                    CanDrvIF_GetTxTimeoutFlg() returns D_TRUE.                                */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_ClrTxTimeoutFlg(const UI_8 controller)
{
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		CanDrvIF_Ctrl[controller].TxTimeout = D_FALSE;
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetRxMsgLostFlg                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : - D_FALSE : A message overrun error has not been detected.                */
/*                    - D_TRUE  : A message overrun error has been detected.                    */
/*                    If parameter is invalid, D_FALSE is returned.                             */
/*                                                                                              */
/* Description      : This function returns the RxMsgLost flag state.                           */
/*                    If a user needs to monitor the error flag continuously,                   */
/*                    a user has to call CanDrvIF_ClrRxMsgLostFlg() to clear the flag           */
/*                    at the appropriate time.                                                  */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetRxMsgLostFlg(const UI_8 controller)
{
	UI_8 flg;

	flg = D_FALSE;
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		flg = CanDrvIF_Ctrl[controller].RxMsgLost;
	}

	return flg;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ClrRxMsgLostFlg                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function clears the RxMsgLost flag.                                  */
/*                    If a user needs to monitor a message overrun error continuously,          */
/*                    this function shall be called after                                       */
/*                    CanDrvIF_GetRxMsgLostFlg() returns D_TRUE.                                */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_ClrRxMsgLostFlg(const UI_8 controller)
{
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		CanDrvIF_Ctrl[controller].RxMsgLost = D_FALSE;
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_DisableIntr                                                      */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    [out]                                                                     */
/*                    <mask_level_ptr> - Pointer to a memory location,                          */
/*                                       where the current interrupt mask level will be stored. */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function shall be called in order to enter a critical section.       */
/*                    A user has to set the value of <mask_level_ptr> to CanDrvIF_EnableIntr()  */
/*                    to leave a critical section.                                              */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_DisableIntr(const UI_8 controller, UI_16 *mask_level_ptr)
{
	if ((controller < CANDRVIF_CONTROLLER_CNT) && (mask_level_ptr != D_NULL)) {
		can_disable_intr(controller, mask_level_ptr);
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_EnableIntr                                                       */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <mask_level> - Interrupt Mask Level to be set.                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function shall be called in order to leave a critical section.       */
/*                    A user has to set obtained value from                                     */
/*                    CanDrvIF_DisableIntr() to <mask_level>.                                   */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_EnableIntr(const UI_8 controller, const UI_16 mask_level)
{
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		can_enable_intr(controller, mask_level);
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetTxController                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/* Return value     : Preconfigured CAN controller index for the Tx Handle.                     */
/*                    If parameter is invalid, CANDRVIF_CONTROLLER_INVALID is returned.         */
/*                                                                                              */
/* Description      : This function returns CAN identifier that is preconfigured                */
/*                    and stored in C_CanDrvIF_TxCfg[].Controller.                              */
/*                    Valid range shall be configuration file dependent.                        */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetTxController(const UI_16 tx_handle)
{
	UI_8 controller;

	controller = CANDRVIF_CONTROLLER_INVALID;

	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {
		controller = C_CanDrvIF_TxCfg[tx_handle].Controller;
	}

	return controller;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetTxFrameFormat                                                 */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/* Return value     : Preconfigured CAN frame format for the Tx Handle.                         */
/*                    - CANDRVIF_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)           */
/*                    - CANDRVIF_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)           */
/*                    If parameter is invalid, CANDRVIF_FRAME_FORMAT_INVALID is returned.       */
/*                                                                                              */
/* Description      : This function returns CAN identifier that is preconfigured                */
/*                    and stored in C_CanDrvIF_TxCfg[].FrameFormat.                             */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetTxFrameFormat(const UI_16 tx_handle)
{
	UI_8 frame_format;

	frame_format = CANDRVIF_FRAME_FORMAT_INVALID;

	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {
		frame_format = C_CanDrvIF_TxCfg[tx_handle].FrameFormat;
	}

	return frame_format;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetTxId                                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/* Return value     : Preconfigured CAN identifier for the Tx Handle.                           */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                    If parameter is invalid, CANDRVIF_ID_INVALID is returned.                 */
/*                                                                                              */
/* Description      : This function returns CAN identifier that is preconfigured                */
/*                    and stored in C_CanDrvIF_TxCfg[].Id.                                      */
/*                                                                                              */
/************************************************************************************************/
UI_32 CanDrvIF_GetTxId(const UI_16 tx_handle)
{
	UI_32 id;

	id = CANDRVIF_ID_INVALID;

	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {
		id = C_CanDrvIF_TxCfg[tx_handle].Id;
	}

	return id;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetTxDataLen                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <tx_handle> - Tx Handle                                                   */
/*                                                                                              */
/* Return value     : Preconfigured tx data length for the Tx Handle (0 - 64).                  */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns tx data length that is preconfigured                */
/*                    and stored in C_CanDrvIF_TxCfg[].DataLen.                                 */
/*                    Valid range shall be from 0 byte to 64 bytes.                             */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetTxDataLen(const UI_16 tx_handle)
{
	UI_8 data_len;

	data_len = 0U;

	if (tx_handle < CANDRVIFTX_HANDLE_CNT) {
		data_len = C_CanDrvIF_TxCfg[tx_handle].DataLen;
	}

	return data_len;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetRxController                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_handle> - Rx Handle                                                   */
/*                                                                                              */
/* Return value     : Preconfigured CAN controller index for the Rx Handle.                     */
/*                    If parameter is invalid, CANDRVIF_CONTROLLER_INVALID is returned.         */
/*                                                                                              */
/* Description      : This function returns CAN identifier that is preconfigured                */
/*                    and stored in C_CanDrvIF_RxCfg[].Controller.                              */
/*                    Valid range shall be configuration file dependent.                        */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetRxController(const UI_16 rx_handle)
{
	UI_8 controller;

	controller = CANDRVIF_CONTROLLER_INVALID;

	if (rx_handle < CANDRVIFRX_HANDLE_CNT) {
		controller = C_CanDrvIF_RxCfg[rx_handle].Controller;
	}

	return controller;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetRxFrameFormat                                                 */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_handle> - Rx Handle                                                   */
/*                                                                                              */
/* Return value     : Preconfigured CAN frame format for the Rx Handle.                         */
/*                    - CANDRVIF_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)           */
/*                    - CANDRVIF_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)           */
/*                    If parameter is invalid, CANDRVIF_FRAME_FORMAT_INVALID is returned.       */
/*                                                                                              */
/* Description      : This function returns CAN identifier that is preconfigured                */
/*                    and stored in C_CanDrvIF_RxCfg[].FrameFormat.                             */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetRxFrameFormat(const UI_16 rx_handle)
{
	UI_8 frame_format;

	frame_format = CANDRVIF_FRAME_FORMAT_INVALID;

	if (rx_handle < CANDRVIFRX_HANDLE_CNT) {
		frame_format = C_CanDrvIF_RxCfg[rx_handle].FrameFormat;
	}

	return frame_format;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetRxId                                                          */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_handle> - Rx Handle                                                   */
/*                                                                                              */
/* Return value     : Preconfigured CAN identifier for the Rx Handle.                           */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                    If parameter is invalid, CANDRVIF_ID_INVALID is returned.                 */
/*                                                                                              */
/* Description      : This function returns CAN identifier that is preconfigured                */
/*                    and stored in C_CanDrvIF_RxCfg[].Id.                                      */
/*                                                                                              */
/************************************************************************************************/
UI_32 CanDrvIF_GetRxId(const UI_16 rx_handle)
{
	UI_32 id;

	id = CANDRVIF_ID_INVALID;

	if (rx_handle < CANDRVIFRX_HANDLE_CNT) {
		id = C_CanDrvIF_RxCfg[rx_handle].Id;
	}

	return id;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_GetRxDataLen                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <rx_handle> - Rx Handle                                                   */
/*                                                                                              */
/* Return value     : Preconfigured rx data length for the Rx Handle (0 - 64).                  */
/*                    If parameter is invalid, 0 is returned.                                   */
/*                                                                                              */
/* Description      : This function returns rx data length that is preconfigured                */
/*                    and stored in C_CanDrvIF_RxCfg[].DataLen.                                 */
/*                    Valid range shall be from 0 byte to 64 bytes.                             */
/*                                                                                              */
/************************************************************************************************/
UI_8 CanDrvIF_GetRxDataLen(const UI_16 rx_handle)
{
	UI_8 data_len;

	data_len = 0U;

	if (rx_handle < CANDRVIFRX_HANDLE_CNT) {
		data_len = C_CanDrvIF_RxCfg[rx_handle].DataLen;
	}

	return data_len;
}

/************************************************************************************************/
/* Function name    : CanDrvIF_IntrMain                                                         */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <intr_signal> - Interrupt signal                                          */
/*                                    This parameter is designed to be able to inform           */
/*                                    CAN driver of an appropriate interrupt reason.            */
/*                                    If a CAN controller uses different interrupt resources    */
/*                                    and CAN driver cannot identify the interrupt reasons      */
/*                                    by reading resisters, CAN Driver Interface can pass       */
/*                                    the reason via this parameter.                            */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function shall be called when CAN interrupt occurs                   */
/*                    and throws <controller> and <intr_signal> to CAN driver.                  */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_IntrMain(const UI_8 controller, const UI_8 intr_signal)
{
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		CanDrv_IntrHandler(controller, intr_signal);
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_Main                                                             */
/*                                                                                              */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function handles the main state transition of CAN Driver Interface.  */
/*                                                                                              */
/*                    Additionally, transmission timeout for each CAN controller index          */
/*                    is monitored in this function. If timeout occurs, a user can get          */
/*                    the error information via CanDrvIF_GetTxTimeoutFlg().                     */
/*                                                                                              */
/*                    This function is expected to be called every 10 msec (in timer task).     */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_Main(void)
{
	UI_8 controller;

	for (controller = 0U; controller < CANDRVIF_CONTROLLER_CNT; controller++) {

		/* Update the current state */
		can_state_handling(controller);

		/* Check if the tx timeout has occurred */
		can_tx_chk_tx_timeout(controller);
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ActivateTx                                                       */
/*                                                                                              */
/* Parameters       : None                                                                      */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : This function controls a transmission state based on a TxMsgObj.          */
/*                    TxMsgObj is identified by CAN controller index                            */
/*                    and its transmission message object index.                                */
/*                                                                                              */
/*                    If a TxMsgObj is in state CANDRVIFTX_STATE_IDLE,                          */
/*                    this function checks if the coresponding request is pending.              */
/*                    If a valid request exists, a new transmisson request is set               */
/*                    to CAN driver.                                                            */
/*                                                                                              */
/*                    If a TxMsgObj is in state CANDRVIFTX_STATE_CANCELLING,                    */
/*                    it means that CAN Driver Interface is waiting for cancel completion.      */
/*                    First, this function checks if CAN driver is in state idle                */
/*                    via CanDrv_ChkTxState().                                                  */
/*                    When CanDrv_ChkTxState() returns CANDRV_TX_STATE_IDLE,                    */
/*                    CAN Driver Interface considers that the cancellation completes.           */
/*                    In this case, the corresponding TxCancelNotificationFlg is set.           */
/*                    If a User function is registered, a user can receive the event            */
/*                    via the callback function.                                                */
/*                    After that, this function checks if the coresponding request is pending.  */
/*                    If a valid request exists, a new transmisson request is set               */
/*                    to CAN driver.                                                            */
/*                                                                                              */
/*                    If a TxMsgObj is in state CANDRVIFTX_STATE_SENDING,                       */
/*                    it means that a tramsmission process is ongoing in the CAN controller.    */
/*                    CAN Driver Interface shall wait for tramsmission completion.              */
/*                                                                                              */
/*                    This function is expected to be called every 10 msec (in timer task).     */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_ActivateTx(void)
{
	UI_8 controller;
	UI_16 tx_msg_obj_index;
	UI_16 tx_handle;
	UI_16 mask_level;

	for (controller = 0U; controller < CANDRVIF_CONTROLLER_CNT; controller++) {

		for (tx_msg_obj_index = 0U; tx_msg_obj_index < C_CanDrvIF_Cfg[controller].TxMsgObjCnt; tx_msg_obj_index++) {

			can_disable_intr(controller, &mask_level); /* DI */

			switch (CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus) {
			case CANDRVIFTX_STATE_IDLE:
				/* All of the transmission requests have been done */
				/* during tx confirmation processes (interrupt process chain). */
				/* Start transmission handling here. */
				can_tx_queue_handling(controller, tx_msg_obj_index);
				break;
			case CANDRVIFTX_STATE_CANCELLING:
				/* A cancel request has been issued to the driver. */
				if (CanDrv_ChkTxState(controller, tx_msg_obj_index) == CANDRV_TX_STATE_IDLE) {
					/* The cancellation has been confirmed. Get the last requested TxHandle. */
					tx_handle = CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxHandle;
					/* Set the current tx object state to idle. */
					CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus = CANDRVIFTX_STATE_IDLE;
					CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxHandle = CANDRVIF_HANDLE_INVALID;

					/* The cancellation has been confirmed. Set the TxCancelNotificationFlg. */
					can_set_flg(tx_handle, CanDrvIF_TxBitFlg.TxCancelNotificationFlg);
					/* Check if this cancellation event need to be notified to the upper layer. */
					if (C_CanDrvIF_TxCfg[tx_handle].TxCancelNotificationFunc != D_NULL) {
						C_CanDrvIF_TxCfg[tx_handle].TxCancelNotificationFunc(tx_handle);
					}
					/* Start the next transmission handling */
					can_tx_queue_handling(controller, tx_msg_obj_index);
				}
				break;
			case CANDRVIFTX_STATE_SENDING:
				/* A transmission process is ongoing in the CAN controller. */
				/* We cannnot start new transmission handling. */
				break;
			default:
				/* avoid MISRA warning */
				break;
			}

			can_enable_intr(controller, mask_level); /* EI */
		}
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_ControllerBusOff                                                 */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : If a bus off error is detected,                                           */
/*                    CAN driver calls this function in the CAN interrupt task.                 */
/*                                                                                              */
/*                    A user can get this error information via CanDrvIF_GetState()             */
/*                    i.e. CanDrvIF_GetState() returns CANDRVIF_STATE_BUSOFF.                   */
/*                                                                                              */
/*                    If a User function is registered, a user can receive the event            */
/*                    via the callback function.                                                */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_ControllerBusOff(const UI_8 controller)
{
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		CanDrvIF_Ctrl[controller].BusOff = D_TRUE;
		/* Check if this bus-off event need to be notified to the upper layer. */
		if (C_CanDrvIF_Cfg[controller].ControllerBusOffFunc != D_NULL) {
			C_CanDrvIF_Cfg[controller].ControllerBusOffFunc(controller);
		}
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_RxMsgLost                                                        */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : If a message overrun error is detected,                                   */
/*                    CAN driver calls this function in the CAN interrupt task.                 */
/*                    A user can get this error information via CanDrvIF_GetRxMsgLostFlg().     */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_RxMsgLost(const UI_8 controller)
{
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		CanDrvIF_Ctrl[controller].RxMsgLost = D_TRUE;
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_TxConfirmation                                                   */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <tx_msg_obj_index> - A transmission message object index.                 */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : When a requested message is transmitted correctly,                        */
/*                    CAN driver calls this function in the CAN interrupt task.                 */
/*                    CAN Driver Interface can confirm that the last requested TxHandle is      */
/*                    transmitted then sets the corresponding TxConfirmationFlg.                */
/*                    If a User function is registered, a user can receive the notification     */
/*                    via the callback function.                                                */
/*                                                                                              */
/*                    After that, CAN Driver Interface checks if a transmission request for     */
/*                    <controller> and <tx_msg_obj_index> is pending.                           */
/*                    If a valid request is pending, a new transmission request is set to       */
/*                    CAN driver in this function call.                                         */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_TxConfirmation(const UI_8 controller, const UI_16 tx_msg_obj_index)
{
	UI_16 tx_handle;

	if (controller < CANDRVIF_CONTROLLER_CNT) {
		/* A transmission has been completed. Set the TxOk flag. */
		CanDrvIF_Ctrl[controller].TxOk = D_TRUE;

		if (tx_msg_obj_index < C_CanDrvIF_Cfg[controller].TxMsgObjCnt) {
			/* Get the last requested TxHandle. */
			tx_handle = CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxHandle;
			/* Set the current tx object state to idle then stop the tx timer. */
			CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxStatus = CANDRVIFTX_STATE_IDLE;
			CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxHandle = CANDRVIF_HANDLE_INVALID;
			CanDrvIF_Ctrl[controller].TxMsgObjPtr[tx_msg_obj_index].TxTimeoutCnt = CANDRVIF_TIMER_STOP;

			if (tx_handle < CANDRVIFTX_HANDLE_CNT) {
				/* The requested transmission has been completed. Set the TxConfirmationFlg. */
				can_set_flg(tx_handle, CanDrvIF_TxBitFlg.TxConfirmationFlg);
				/* Check if this confirmation event need to be notified to the upper layer. */
				if (C_CanDrvIF_TxCfg[tx_handle].TxConfirmationFunc != D_NULL) {
					C_CanDrvIF_TxCfg[tx_handle].TxConfirmationFunc(tx_handle);
				}
			}
			/* Start the next transmission handling */
			can_tx_queue_handling(controller, tx_msg_obj_index);
		}
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_RxIndication                                                     */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/*                    <frame_format> - CAN frame format                                         */
/*                     CANDRV_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)              */
/*                     CANDRV_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)              */
/*                                                                                              */
/*                    <id> - CAN identifier.                                                    */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                                                                                              */
/*                    <data_length> - Rx data length.                                           */
/*                     0-64                                                                     */
/*                     If the received data length exceeds the preconfigured rx buffer size,    */
/*                     received data is not stored to the internal buffer at all.               */
/*                     In this case, RxIndicationFlg is not set but a User function             */
/*                     can be called if needed.                                                 */
/*                                                                                              */
/*                    <data_ptr> - Pointer to a memory location where                           */
/*                                 the received data is stored.                                 */
/*                     If the data pointer is NULL, <data_length> must be zero.                 */
/*                     Otherwise, this function intends to read data from null pointer.         */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : If a new message is received, CAN driver calls this function              */
/*                    in the CAN interrupt task.                                                */
/*                                                                                              */
/*                    This function try to find a valid RxHandle using <controller>,            */
/*                    <fram_format> and <id>.                                                   */
/*                    If a vald RxHandle is found, this function stores the received data       */
/*                    to the internal buffer then sets the correcponding RxIndicationFlg.       */
/*                    A user can get access to the internal buffer via CanDrvIF_GetRxMsg().     */
/*                    If a User function is registered, a user can receive a new message        */
/*                    via the callback function.                                                */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_RxIndication(const UI_8 controller, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[])
{
	UI_16 rx_handle;

	if (controller < CANDRVIF_CONTROLLER_CNT) {
		/* A reception has been completed. Set the RxOk flag. */
		CanDrvIF_Ctrl[controller].RxOk = D_TRUE;
		/* Try to find a valid RxHandle */
		rx_handle = can_rx_find_handle(C_CanDrvIF_Cfg[controller].RxSearchTblPtr, frame_format, id);
		if (rx_handle < CANDRVIFRX_HANDLE_CNT) {
			/* A valid RxHandle has been found. Check if the data can be stored in the data buffer. */
			if (data_length <= C_CanDrvIF_RxCfg[rx_handle].DataLen) {
				CanDrvIF_RxMsg[rx_handle].FrameFormat = frame_format;
				CanDrvIF_RxMsg[rx_handle].Id = id;
				CanDrvIF_RxMsg[rx_handle].DataLen = data_length;
				(void)memcpy(CanDrvIF_RxMsg[rx_handle].DataPtr, data_ptr, (T_CANDRVIF_SIZE_T)data_length);
				/* The received message has been stored. Set the RxIndicationFlg. */
				can_set_flg(rx_handle, CanDrvIF_RxBitFlg.RxIndicationFlg);
			}
			/* Check if this reception event need to be notified to the upper layer. */
			if (C_CanDrvIF_RxCfg[rx_handle].RxIndicationFunc != D_NULL) {
				C_CanDrvIF_RxCfg[rx_handle].RxIndicationFunc(rx_handle, frame_format, id, data_length, data_ptr);
			}
		}
	}
}

/************************************************************************************************/
/* Function name    : CanDrvIF_MsgRamChkFailed                                                  */
/*                                                                                              */
/* Parameters       : [in]                                                                      */
/*                    <controller> - A CAN controller index.                                    */
/*                                                                                              */
/* Return value     : None                                                                      */
/*                                                                                              */
/* Description      : If a problem is detected in the message objects                           */
/*                    during initialization process, CAN driver calls this function.            */
/*                    A user can get this error information via CanDrvIF_GetState()             */
/*                    i.e. CanDrvIF_GetState() returns CANDRVIF_STATE_MSG_RAM_ERR.              */
/*                                                                                              */
/************************************************************************************************/
void CanDrvIF_MsgRamChkFailed(const UI_8 controller)
{
	if (controller < CANDRVIF_CONTROLLER_CNT) {
		CanDrvIF_Ctrl[controller].MsgRamChkFailed = D_TRUE;
	}
}

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/
