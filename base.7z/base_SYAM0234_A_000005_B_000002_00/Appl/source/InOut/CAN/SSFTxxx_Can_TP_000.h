/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFTSTD                                                                   */
/* Copyright        : Nippon Seiki Co.,Ltd                                                      */
/*----------------------------------------------------------------------------------------------*/
/* Author           : PF1                                                                       */
/* Description      : Sample                                                                    */
/************************************************************************************************/



#ifndef SSFTXXX_CAN_TP_000_H
#define SSFTXXX_CAN_TP_000_H

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"

/************************************************************************************************/
/* Global Macros                                                                                */
/************************************************************************************************/
#define CANTP_MAIN_CYCLE (10U) /* 10 msec */

/* used addressing type */
#define CANTP_ADDR_TYPE_PHYSICAL   (0U)
#define CANTP_ADDR_TYPE_FUNCTIONAL (1U)

/* Definitions of <N_Result> */
/* This parameter contains tha status relating to the outcome of a service excecution. */
#define CANTP_N_RESULT_OK           (0x00U)
#define CANTP_N_RESULT_TIMEOUT_A    (0x01U)
#define CANTP_N_RESULT_TIMEOUT_BS   (0x02U)
#define CANTP_N_RESULT_TIMEOUT_CR   (0x03U)
#define CANTP_N_RESULT_WRONG_SN     (0x04U)
#define CANTP_N_RESULT_INVALID_FS   (0x05U)
#define CANTP_N_RESULT_UNEXP_PDU    (0x06U)
#define CANTP_N_RESULT_WFT_OVRN     (0x07U)
#define CANTP_N_RESULT_BUFFER_OVFLW (0x08U)
#define CANTP_N_RESULT_ERROR        (0x09U)

/* Data buffer type */
#define CANTP_BUF_TYPE_MAIN (0x00U)
#define CANTP_BUF_TYPE_SUB  (0x01U)
#define CANTP_BUF_TYPE_CNT  (2U)

/* Definitions for TP handle */
#define CANTP_HANDLE_DIAG (0x00U)
#define CANTP_HANDLE_CNT (1U)

/* Data size definition */
#define CANTP_DATA_LEN_DIAG (514U) /* 514 bytes */

/************************************************************************************************/
/* Global Data Types                                                                            */
/************************************************************************************************/
typedef struct
{
	UI_8 *DataPtr;
	UI_16 *DataLenPtr;
} T_CanTP_DataBuf;

/************************************************************************************************/
/* Global Data                                                                                  */
/************************************************************************************************/

/************************************************************************************************/
/* Global Constants                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
extern void CanTP_Init(void);
extern void CanTP_Main(void);

extern void CanTP_Enable(const UI_8 tp_handle, const UI_8 enable);

extern const T_CanTP_DataBuf* CanTP_GetDataBuf(const UI_8 tp_handle, const UI_8 buf_type);
extern UI_8 CanTP_SetTxReq(const UI_8 tp_handle, const UI_8 buf_type);
extern void CanTP_ReleaseBuf(const UI_8 tp_handle);

extern UI_8 CanTP_ChkFirstFrame(const UI_8 tp_handle);
extern UI_8 CanTP_ChkIndication(const UI_8 tp_handle);
extern UI_8 CanTP_ChkErrIndication(const UI_8 tp_handle);
extern UI_8 CanTP_GetRequestedAddrType(const UI_8 tp_handle);

extern UI_8 CanTP_ChkConfirmation(const UI_8 tp_handle);
extern UI_8 CanTP_ChkErrConfirmation(const UI_8 tp_handle);


extern void CanTP_TxCancelNotification(const UI_16 tx_handle);
extern void CanTP_TxConfirmation(const UI_16 tx_handle);
extern void CanTP_RxIndication(const UI_16 rx_handle, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[]);

#endif /* End Of ( #ifndef SSFTXXX_CAN_TP_000_H ) */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/

