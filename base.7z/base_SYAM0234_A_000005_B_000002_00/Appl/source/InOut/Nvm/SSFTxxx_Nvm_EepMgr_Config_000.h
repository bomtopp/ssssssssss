/************************************************************************************************/
/* Customer			: -																			*/
/* Model(Theme No.)	: SSFT																		*/
/*----------------------------------------------------------------------------------------------*/
/* CPU				: -																			*/
/* Date				: 2013/05/05																*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Masato Koide																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/*----------------------------------------------------------------------------------------------*/
/* update by		: 44567_kikuchi																*/
/* date				: 2020/08/27																*/
/************************************************************************************************/
#ifndef SSFTXXX_NVM_EEPMGR_CONFIG_H
#define SSFTXXX_NVM_EEPMGR_CONFIG_H

/*----------------------------------------------------------------------------------------------*/
/* MPU dependent include files																	*/
/*----------------------------------------------------------------------------------------------*/
#include "SSFTSTD_RL78Eep_Drv_001.h"

/*----------------------------------------------------------------------------------------------*/
/* Version information																			*/
/*----------------------------------------------------------------------------------------------*/
#define NVM_EEPMGR_CONFIG_H_VERSION		( 0x0203U )				/* NVM function Version = 0203 */

/*----------------------------------------------------------------------------------------------*/
/* APPL/BOOT information																		*/
/*----------------------------------------------------------------------------------------------*/
#define NVM_EEPMGR_CONFIG_APPL									/* NVM function for APPL */

/*----------------------------------------------------------------------------------------------*/
/* Project-dependent (for EEPROM)																*/
/*----------------------------------------------------------------------------------------------*/
/* Internal definition for SSFTSTD_Nvm_EepMgr, SSFTSTD_Nvm_EepDrvCtrl */
#define ENABLE_NWORD_READ				( 0U )					/* EEPROM continuous read (1:Apply, 0:Not apply) */

/*----------------------------------------------------------------------------------------------*/
/* EID																							*/
/*----------------------------------------------------------------------------------------------*/
#define END_EEPROM_INDEX				( 0x01C2U )

#ifdef NVM_EEPMGR_000_INTERNAL_DEFINE	/* Internal definition for SSFTSTD_Nvm_EepMgr_000.c */

#define EID_0000						( 0x0000U )				/* 0 */
#define EID_0001						( 0x0001U )				/* 1 */
#define EID_0002						( 0x0002U )				/* 2 */
#define EID_0003						( 0x0003U )				/* 3 */
#define EID_0004						( 0x0004U )				/* 4 */
#define EID_0005						( 0x0005U )				/* 5 */
#define EID_0006						( 0x0006U )				/* 6 */
#define EID_0007						( 0x0007U )				/* 7 */
#define EID_0008						( 0x0008U )				/* 8 */
#define EID_0009						( 0x0009U )				/* 9 */
#define EID_000A						( 0x000AU )				/* 10 */
#define EID_000B						( 0x000BU )				/* 11 */
#define EID_000C						( 0x000CU )				/* 12 */
#define EID_000D						( 0x000DU )				/* 13 */
#define EID_000E						( 0x000EU )				/* 14 */
#define EID_000F						( 0x000FU )				/* 15 */
#define EID_0010						( 0x0010U )				/* 16 */
#define EID_0011						( 0x0011U )				/* 17 */
#define EID_0012						( 0x0012U )				/* 18 */
#define EID_0013						( 0x0013U )				/* 19 */
#define EID_0014						( 0x0014U )				/* 20 */
#define EID_0015						( 0x0015U )				/* 21 */
#define EID_0016						( 0x0016U )				/* 22 */
#define EID_0017						( 0x0017U )				/* 23 */
#define EID_0018						( 0x0018U )				/* 24 */
#define EID_0019						( 0x0019U )				/* 25 */
#define EID_001A						( 0x001AU )				/* 26 */
#define EID_001B						( 0x001BU )				/* 27 */
#define EID_001C						( 0x001CU )				/* 28 */
#define EID_001D						( 0x001DU )				/* 29 */
#define EID_001E						( 0x001EU )				/* 30 */
#define EID_001F						( 0x001FU )				/* 31 */
#define EID_0020						( 0x0020U )				/* 32 */
#define EID_0021						( 0x0021U )				/* 33 */
#define EID_0022						( 0x0022U )				/* 34 */
#define EID_0023						( 0x0023U )				/* 35 */
#define EID_0024						( 0x0024U )				/* 36 */
#define EID_0025						( 0x0025U )				/* 37 */
#define EID_0026						( 0x0026U )				/* 38 */
#define EID_0027						( 0x0027U )				/* 39 */
#define EID_0028						( 0x0028U )				/* 40 */
#define EID_0029						( 0x0029U )				/* 41 */
#define EID_002A						( 0x002AU )				/* 42 */
#define EID_002B						( 0x002BU )				/* 43 */
#define EID_002C						( 0x002CU )				/* 44 */
#define EID_002D						( 0x002DU )				/* 45 */
#define EID_002E						( 0x002EU )				/* 46 */
#define EID_002F						( 0x002FU )				/* 47 */
#define EID_0030						( 0x0030U )				/* 48 */
#define EID_0031						( 0x0031U )				/* 49 */
#define EID_0032						( 0x0032U )				/* 50 */
#define EID_0033						( 0x0033U )				/* 51 */
#define EID_0034						( 0x0034U )				/* 52 */
#define EID_0035						( 0x0035U )				/* 53 */
#define EID_0036						( 0x0036U )				/* 54 */
#define EID_0037						( 0x0037U )				/* 55 */
#define EID_0038						( 0x0038U )				/* 56 */
#define EID_0039						( 0x0039U )				/* 57 */
#define EID_003A						( 0x003AU )				/* 58 */
#define EID_003B						( 0x003BU )				/* 59 */
#define EID_003C						( 0x003CU )				/* 60 */
#define EID_003D						( 0x003DU )				/* 61 */
#define EID_003E						( 0x003EU )				/* 62 */
#define EID_003F						( 0x003FU )				/* 63 */
#define EID_0040						( 0x0040U )				/* 64 */
#define EID_0041						( 0x0041U )				/* 65 */
#define EID_0042						( 0x0042U )				/* 66 */
#define EID_0043						( 0x0043U )				/* 67 */
#define EID_0044						( 0x0044U )				/* 68 */
#define EID_0045						( 0x0045U )				/* 69 */
#define EID_0046						( 0x0046U )				/* 70 */
#define EID_0047						( 0x0047U )				/* 71 */
#define EID_0048						( 0x0048U )				/* 72 */
#define EID_0049						( 0x0049U )				/* 73 */
#define EID_004A						( 0x004AU )				/* 74 */
#define EID_004B						( 0x004BU )				/* 75 */
#define EID_004C						( 0x004CU )				/* 76 */
#define EID_004D						( 0x004DU )				/* 77 */
#define EID_004E						( 0x004EU )				/* 78 */
#define EID_004F						( 0x004FU )				/* 79 */
#define EID_0050						( 0x0050U )				/* 80 */
#define EID_0051						( 0x0051U )				/* 81 */
#define EID_0052						( 0x0052U )				/* 82 */
#define EID_0053						( 0x0053U )				/* 83 */
#define EID_0054						( 0x0054U )				/* 84 */
#define EID_0055						( 0x0055U )				/* 85 */
#define EID_0056						( 0x0056U )				/* 86 */
#define EID_0057						( 0x0057U )				/* 87 */
#define EID_0058						( 0x0058U )				/* 88 */
#define EID_0059						( 0x0059U )				/* 89 */
#define EID_005A						( 0x005AU )				/* 90 */
#define EID_005B						( 0x005BU )				/* 91 */
#define EID_005C						( 0x005CU )				/* 92 */
#define EID_005D						( 0x005DU )				/* 93 */
#define EID_005E						( 0x005EU )				/* 94 */
#define EID_005F						( 0x005FU )				/* 95 */
#define EID_0060						( 0x0060U )				/* 96 */
#define EID_0061						( 0x0061U )				/* 97 */
#define EID_0062						( 0x0062U )				/* 98 */
#define EID_0063						( 0x0063U )				/* 99 */
#define EID_0064						( 0x0064U )				/* 100 */
#define EID_0065						( 0x0065U )				/* 101 */
#define EID_0066						( 0x0066U )				/* 102 */
#define EID_0067						( 0x0067U )				/* 103 */
#define EID_0068						( 0x0068U )				/* 104 */
#define EID_0069						( 0x0069U )				/* 105 */
#define EID_006A						( 0x006AU )				/* 106 */
#define EID_006B						( 0x006BU )				/* 107 */
#define EID_006C						( 0x006CU )				/* 108 */
#define EID_006D						( 0x006DU )				/* 109 */
#define EID_006E						( 0x006EU )				/* 110 */
#define EID_006F						( 0x006FU )				/* 111 */
#define EID_0070						( 0x0070U )				/* 112 */
#define EID_0071						( 0x0071U )				/* 113 */
#define EID_0072						( 0x0072U )				/* 114 */
#define EID_0073						( 0x0073U )				/* 115 */
#define EID_0074						( 0x0074U )				/* 116 */
#define EID_0075						( 0x0075U )				/* 117 */
#define EID_0076						( 0x0076U )				/* 118 */
#define EID_0077						( 0x0077U )				/* 119 */
#define EID_0078						( 0x0078U )				/* 120 */
#define EID_0079						( 0x0079U )				/* 121 */
#define EID_007A						( 0x007AU )				/* 122 */
#define EID_007B						( 0x007BU )				/* 123 */
#define EID_007C						( 0x007CU )				/* 124 */
#define EID_007D						( 0x007DU )				/* 125 */
#define EID_007E						( 0x007EU )				/* 126 */
#define EID_007F						( 0x007FU )				/* 127 */
#define EID_0080						( 0x0080U )				/* 128 */
#define EID_0081						( 0x0081U )				/* 129 */
#define EID_0082						( 0x0082U )				/* 130 */
#define EID_0083						( 0x0083U )				/* 131 */
#define EID_0084						( 0x0084U )				/* 132 */
#define EID_0085						( 0x0085U )				/* 133 */
#define EID_0086						( 0x0086U )				/* 134 */
#define EID_0087						( 0x0087U )				/* 135 */
#define EID_0088						( 0x0088U )				/* 136 */
#define EID_0089						( 0x0089U )				/* 137 */
#define EID_008A						( 0x008AU )				/* 138 */
#define EID_008B						( 0x008BU )				/* 139 */
#define EID_008C						( 0x008CU )				/* 140 */
#define EID_008D						( 0x008DU )				/* 141 */
#define EID_008E						( 0x008EU )				/* 142 */
#define EID_008F						( 0x008FU )				/* 143 */
#define EID_0090						( 0x0090U )				/* 144 */
#define EID_0091						( 0x0091U )				/* 145 */
#define EID_0092						( 0x0092U )				/* 146 */
#define EID_0093						( 0x0093U )				/* 147 */
#define EID_0094						( 0x0094U )				/* 148 */
#define EID_0095						( 0x0095U )				/* 149 */
#define EID_0096						( 0x0096U )				/* 150 */
#define EID_0097						( 0x0097U )				/* 151 */
#define EID_0098						( 0x0098U )				/* 152 */
#define EID_0099						( 0x0099U )				/* 153 */
#define EID_009A						( 0x009AU )				/* 154 */
#define EID_009B						( 0x009BU )				/* 155 */
#define EID_009C						( 0x009CU )				/* 156 */
#define EID_009D						( 0x009DU )				/* 157 */
#define EID_009E						( 0x009EU )				/* 158 */
#define EID_009F						( 0x009FU )				/* 159 */
#define EID_00A0						( 0x00A0U )				/* 160 */
#define EID_00A1						( 0x00A1U )				/* 161 */
#define EID_00A2						( 0x00A2U )				/* 162 */
#define EID_00A3						( 0x00A3U )				/* 163 */
#define EID_00A4						( 0x00A4U )				/* 164 */
#define EID_00A5						( 0x00A5U )				/* 165 */
#define EID_00A6						( 0x00A6U )				/* 166 */
#define EID_00A7						( 0x00A7U )				/* 167 */
#define EID_00A8						( 0x00A8U )				/* 168 */
#define EID_00A9						( 0x00A9U )				/* 169 */
#define EID_00AA						( 0x00AAU )				/* 170 */
#define EID_00AB						( 0x00ABU )				/* 171 */
#define EID_00AC						( 0x00ACU )				/* 172 */
#define EID_00AD						( 0x00ADU )				/* 173 */
#define EID_00AE						( 0x00AEU )				/* 174 */
#define EID_00AF						( 0x00AFU )				/* 175 */
#define EID_00B0						( 0x00B0U )				/* 176 */
#define EID_00B1						( 0x00B1U )				/* 177 */
#define EID_00B2						( 0x00B2U )				/* 178 */
#define EID_00B3						( 0x00B3U )				/* 179 */
#define EID_00B4						( 0x00B4U )				/* 180 */
#define EID_00B5						( 0x00B5U )				/* 181 */
#define EID_00B6						( 0x00B6U )				/* 182 */
#define EID_00B7						( 0x00B7U )				/* 183 */
#define EID_00B8						( 0x00B8U )				/* 184 */
#define EID_00B9						( 0x00B9U )				/* 185 */
#define EID_00BA						( 0x00BAU )				/* 186 */
#define EID_00BB						( 0x00BBU )				/* 187 */
#define EID_00BC						( 0x00BCU )				/* 188 */
#define EID_00BD						( 0x00BDU )				/* 189 */
#define EID_00BE						( 0x00BEU )				/* 190 */
#define EID_00BF						( 0x00BFU )				/* 191 */
#define EID_00C0						( 0x00C0U )				/* 192 */
#define EID_00C1						( 0x00C1U )				/* 193 */
#define EID_00C2						( 0x00C2U )				/* 194 */
#define EID_00C3						( 0x00C3U )				/* 195 */
#define EID_00C4						( 0x00C4U )				/* 196 */
#define EID_00C5						( 0x00C5U )				/* 197 */
#define EID_00C6						( 0x00C6U )				/* 198 */
#define EID_00C7						( 0x00C7U )				/* 199 */
#define EID_00C8						( 0x00C8U )				/* 200 */
#define EID_00C9						( 0x00C9U )				/* 201 */
#define EID_00CA						( 0x00CAU )				/* 202 */
#define EID_00CB						( 0x00CBU )				/* 203 */
#define EID_00CC						( 0x00CCU )				/* 204 */
#define EID_00CD						( 0x00CDU )				/* 205 */
#define EID_00CE						( 0x00CEU )				/* 206 */
#define EID_00CF						( 0x00CFU )				/* 207 */
#define EID_00D0						( 0x00D0U )				/* 208 */
#define EID_00D1						( 0x00D1U )				/* 209 */
#define EID_00D2						( 0x00D2U )				/* 210 */
#define EID_00D3						( 0x00D3U )				/* 211 */
#define EID_00D4						( 0x00D4U )				/* 212 */
#define EID_00D5						( 0x00D5U )				/* 213 */
#define EID_00D6						( 0x00D6U )				/* 214 */
#define EID_00D7						( 0x00D7U )				/* 215 */
#define EID_00D8						( 0x00D8U )				/* 216 */
#define EID_00D9						( 0x00D9U )				/* 217 */
#define EID_00DA						( 0x00DAU )				/* 218 */
#define EID_00DB						( 0x00DBU )				/* 219 */
#define EID_00DC						( 0x00DCU )				/* 220 */
#define EID_00DD						( 0x00DDU )				/* 221 */
#define EID_00DE						( 0x00DEU )				/* 222 */
#define EID_00DF						( 0x00DFU )				/* 223 */
#define EID_00E0						( 0x00E0U )				/* 224 */
#define EID_00E1						( 0x00E1U )				/* 225 */
#define EID_00E2						( 0x00E2U )				/* 226 */
#define EID_00E3						( 0x00E3U )				/* 227 */
#define EID_00E4						( 0x00E4U )				/* 228 */
#define EID_00E5						( 0x00E5U )				/* 229 */
#define EID_00E6						( 0x00E6U )				/* 230 */
#define EID_00E7						( 0x00E7U )				/* 231 */
#define EID_00E8						( 0x00E8U )				/* 232 */
#define EID_00E9						( 0x00E9U )				/* 233 */
#define EID_00EA						( 0x00EAU )				/* 234 */
#define EID_00EB						( 0x00EBU )				/* 235 */
#define EID_00EC						( 0x00ECU )				/* 236 */
#define EID_00ED						( 0x00EDU )				/* 237 */
#define EID_00EE						( 0x00EEU )				/* 238 */
#define EID_00EF						( 0x00EFU )				/* 239 */
#define EID_00F0						( 0x00F0U )				/* 240 */
#define EID_00F1						( 0x00F1U )				/* 241 */
#define EID_00F2						( 0x00F2U )				/* 242 */
#define EID_00F3						( 0x00F3U )				/* 243 */
#define EID_00F4						( 0x00F4U )				/* 244 */
#define EID_00F5						( 0x00F5U )				/* 245 */
#define EID_00F6						( 0x00F6U )				/* 246 */
#define EID_00F7						( 0x00F7U )				/* 247 */
#define EID_00F8						( 0x00F8U )				/* 248 */
#define EID_00F9						( 0x00F9U )				/* 249 */
#define EID_00FA						( 0x00FAU )				/* 250 */
#define EID_00FB						( 0x00FBU )				/* 251 */
#define EID_00FC						( 0x00FCU )				/* 252 */
#define EID_00FD						( 0x00FDU )				/* 253 */
#define EID_00FE						( 0x00FEU )				/* 254 */
#define EID_00FF						( 0x00FFU )				/* 255 */
#define EID_0100						( 0x0100U )				/* 256 */
#define EID_0101						( 0x0101U )				/* 257 */
#define EID_0102						( 0x0102U )				/* 258 */
#define EID_0103						( 0x0103U )				/* 259 */
#define EID_0104						( 0x0104U )				/* 260 */
#define EID_0105						( 0x0105U )				/* 261 */
#define EID_0106						( 0x0106U )				/* 262 */
#define EID_0107						( 0x0107U )				/* 263 */
#define EID_0108						( 0x0108U )				/* 264 */
#define EID_0109						( 0x0109U )				/* 265 */
#define EID_010A						( 0x010AU )				/* 266 */
#define EID_010B						( 0x010BU )				/* 267 */
#define EID_010C						( 0x010CU )				/* 268 */
#define EID_010D						( 0x010DU )				/* 269 */
#define EID_010E						( 0x010EU )				/* 270 */
#define EID_010F						( 0x010FU )				/* 271 */
#define EID_0110						( 0x0110U )				/* 272 */
#define EID_0111						( 0x0111U )				/* 273 */
#define EID_0112						( 0x0112U )				/* 274 */
#define EID_0113						( 0x0113U )				/* 275 */
#define EID_0114						( 0x0114U )				/* 276 */
#define EID_0115						( 0x0115U )				/* 277 */
#define EID_0116						( 0x0116U )				/* 278 */
#define EID_0117						( 0x0117U )				/* 279 */
#define EID_0118						( 0x0118U )				/* 280 */
#define EID_0119						( 0x0119U )				/* 281 */
#define EID_011A						( 0x011AU )				/* 282 */
#define EID_011B						( 0x011BU )				/* 283 */
#define EID_011C						( 0x011CU )				/* 284 */
#define EID_011D						( 0x011DU )				/* 285 */
#define EID_011E						( 0x011EU )				/* 286 */
#define EID_011F						( 0x011FU )				/* 287 */
#define EID_0120						( 0x0120U )				/* 288 */
#define EID_0121						( 0x0121U )				/* 289 */
#define EID_0122						( 0x0122U )				/* 290 */
#define EID_0123						( 0x0123U )				/* 291 */
#define EID_0124						( 0x0124U )				/* 292 */
#define EID_0125						( 0x0125U )				/* 293 */
#define EID_0126						( 0x0126U )				/* 294 */
#define EID_0127						( 0x0127U )				/* 295 */
#define EID_0128						( 0x0128U )				/* 296 */
#define EID_0129						( 0x0129U )				/* 297 */
#define EID_012A						( 0x012AU )				/* 298 */
#define EID_012B						( 0x012BU )				/* 299 */
#define EID_012C						( 0x012CU )				/* 300 */
#define EID_012D						( 0x012DU )				/* 301 */
#define EID_012E						( 0x012EU )				/* 302 */
#define EID_012F						( 0x012FU )				/* 303 */
#define EID_0130						( 0x0130U )				/* 304 */
#define EID_0131						( 0x0131U )				/* 305 */
#define EID_0132						( 0x0132U )				/* 306 */
#define EID_0133						( 0x0133U )				/* 307 */
#define EID_0134						( 0x0134U )				/* 308 */
#define EID_0135						( 0x0135U )				/* 309 */
#define EID_0136						( 0x0136U )				/* 310 */
#define EID_0137						( 0x0137U )				/* 311 */
#define EID_0138						( 0x0138U )				/* 312 */
#define EID_0139						( 0x0139U )				/* 313 */
#define EID_013A						( 0x013AU )				/* 314 */
#define EID_013B						( 0x013BU )				/* 315 */
#define EID_013C						( 0x013CU )				/* 316 */
#define EID_013D						( 0x013DU )				/* 317 */
#define EID_013E						( 0x013EU )				/* 318 */
#define EID_013F						( 0x013FU )				/* 319 */
#define EID_0140						( 0x0140U )				/* 320 */
#define EID_0141						( 0x0141U )				/* 321 */
#define EID_0142						( 0x0142U )				/* 322 */
#define EID_0143						( 0x0143U )				/* 323 */
#define EID_0144						( 0x0144U )				/* 324 */
#define EID_0145						( 0x0145U )				/* 325 */
#define EID_0146						( 0x0146U )				/* 326 */
#define EID_0147						( 0x0147U )				/* 327 */
#define EID_0148						( 0x0148U )				/* 328 */
#define EID_0149						( 0x0149U )				/* 329 */
#define EID_014A						( 0x014AU )				/* 330 */
#define EID_014B						( 0x014BU )				/* 331 */
#define EID_014C						( 0x014CU )				/* 332 */
#define EID_014D						( 0x014DU )				/* 333 */
#define EID_014E						( 0x014EU )				/* 334 */
#define EID_014F						( 0x014FU )				/* 335 */
#define EID_0150						( 0x0150U )				/* 336 */
#define EID_0151						( 0x0151U )				/* 337 */
#define EID_0152						( 0x0152U )				/* 338 */
#define EID_0153						( 0x0153U )				/* 339 */
#define EID_0154						( 0x0154U )				/* 340 */
#define EID_0155						( 0x0155U )				/* 341 */
#define EID_0156						( 0x0156U )				/* 342 */
#define EID_0157						( 0x0157U )				/* 343 */
#define EID_0158						( 0x0158U )				/* 344 */
#define EID_0159						( 0x0159U )				/* 345 */
#define EID_015A						( 0x015AU )				/* 346 */
#define EID_015B						( 0x015BU )				/* 347 */
#define EID_015C						( 0x015CU )				/* 348 */
#define EID_015D						( 0x015DU )				/* 349 */
#define EID_015E						( 0x015EU )				/* 350 */
#define EID_015F						( 0x015FU )				/* 351 */
#define EID_0160						( 0x0160U )				/* 352 */
#define EID_0161						( 0x0161U )				/* 353 */
#define EID_0162						( 0x0162U )				/* 354 */
#define EID_0163						( 0x0163U )				/* 355 */
#define EID_0164						( 0x0164U )				/* 356 */
#define EID_0165						( 0x0165U )				/* 357 */
#define EID_0166						( 0x0166U )				/* 358 */
#define EID_0167						( 0x0167U )				/* 359 */
#define EID_0168						( 0x0168U )				/* 360 */
#define EID_0169						( 0x0169U )				/* 361 */
#define EID_016A						( 0x016AU )				/* 362 */
#define EID_016B						( 0x016BU )				/* 363 */
#define EID_016C						( 0x016CU )				/* 364 */
#define EID_016D						( 0x016DU )				/* 365 */
#define EID_016E						( 0x016EU )				/* 366 */
#define EID_016F						( 0x016FU )				/* 367 */
#define EID_0170						( 0x0170U )				/* 368 */
#define EID_0171						( 0x0171U )				/* 369 */
#define EID_0172						( 0x0172U )				/* 370 */
#define EID_0173						( 0x0173U )				/* 371 */
#define EID_0174						( 0x0174U )				/* 372 */
#define EID_0175						( 0x0175U )				/* 373 */
#define EID_0176						( 0x0176U )				/* 374 */
#define EID_0177						( 0x0177U )				/* 375 */
#define EID_0178						( 0x0178U )				/* 376 */
#define EID_0179						( 0x0179U )				/* 377 */
#define EID_017A						( 0x017AU )				/* 378 */
#define EID_017B						( 0x017BU )				/* 379 */
#define EID_017C						( 0x017CU )				/* 380 */
#define EID_017D						( 0x017DU )				/* 381 */
#define EID_017E						( 0x017EU )				/* 382 */
#define EID_017F						( 0x017FU )				/* 383 */
#define EID_0180						( 0x0180U )				/* 384 */
#define EID_0181						( 0x0181U )				/* 385 */
#define EID_0182						( 0x0182U )				/* 386 */
#define EID_0183						( 0x0183U )				/* 387 */
#define EID_0184						( 0x0184U )				/* 388 */
#define EID_0185						( 0x0185U )				/* 389 */
#define EID_0186						( 0x0186U )				/* 390 */
#define EID_0187						( 0x0187U )				/* 391 */
#define EID_0188						( 0x0188U )				/* 392 */
#define EID_0189						( 0x0189U )				/* 393 */
#define EID_018A						( 0x018AU )				/* 394 */
#define EID_018B						( 0x018BU )				/* 395 */
#define EID_018C						( 0x018CU )				/* 396 */
#define EID_018D						( 0x018DU )				/* 397 */
#define EID_018E						( 0x018EU )				/* 398 */
#define EID_018F						( 0x018FU )				/* 399 */
#define EID_0190						( 0x0190U )				/* 400 */
#define EID_0191						( 0x0191U )				/* 401 */
#define EID_0192						( 0x0192U )				/* 402 */
#define EID_0193						( 0x0193U )				/* 403 */
#define EID_0194						( 0x0194U )				/* 404 */
#define EID_0195						( 0x0195U )				/* 405 */
#define EID_0196						( 0x0196U )				/* 406 */
#define EID_0197						( 0x0197U )				/* 407 */
#define EID_0198						( 0x0198U )				/* 408 */
#define EID_0199						( 0x0199U )				/* 409 */
#define EID_019A						( 0x019AU )				/* 410 */
#define EID_019B						( 0x019BU )				/* 411 */
#define EID_019C						( 0x019CU )				/* 412 */
#define EID_019D						( 0x019DU )				/* 413 */
#define EID_019E						( 0x019EU )				/* 414 */
#define EID_019F						( 0x019FU )				/* 415 */
#define EID_01A0						( 0x01A0U )				/* 416 */
#define EID_01A1						( 0x01A1U )				/* 417 */
#define EID_01A2						( 0x01A2U )				/* 418 */
#define EID_01A3						( 0x01A3U )				/* 419 */
#define EID_01A4						( 0x01A4U )				/* 420 */
#define EID_01A5						( 0x01A5U )				/* 421 */
#define EID_01A6						( 0x01A6U )				/* 422 */
#define EID_01A7						( 0x01A7U )				/* 423 */
#define EID_01A8						( 0x01A8U )				/* 424 */
#define EID_01A9						( 0x01A9U )				/* 425 */
#define EID_01AA						( 0x01AAU )				/* 426 */
#define EID_01AB						( 0x01ABU )				/* 427 */
#define EID_01AC						( 0x01ACU )				/* 428 */
#define EID_01AD						( 0x01ADU )				/* 429 */
#define EID_01AE						( 0x01AEU )				/* 430 */
#define EID_01AF						( 0x01AFU )				/* 431 */
#define EID_01B0						( 0x01B0U )				/* 432 */
#define EID_01B1						( 0x01B1U )				/* 433 */
#define EID_01B2						( 0x01B2U )				/* 434 */
#define EID_01B3						( 0x01B3U )				/* 435 */
#define EID_01B4						( 0x01B4U )				/* 436 */
#define EID_01B5						( 0x01B5U )				/* 437 */
#define EID_01B6						( 0x01B6U )				/* 438 */
#define EID_01B7						( 0x01B7U )				/* 439 */
#define EID_01B8						( 0x01B8U )				/* 440 */
#define EID_01B9						( 0x01B9U )				/* 441 */
#define EID_01BA						( 0x01BAU )				/* 442 */
#define EID_01BB						( 0x01BBU )				/* 443 */
#define EID_01BC						( 0x01BCU )				/* 444 */
#define EID_01BD						( 0x01BDU )				/* 445 */
#define EID_01BE						( 0x01BEU )				/* 446 */
#define EID_01BF						( 0x01BFU )				/* 447 */
#define EID_01C0						( 0x01C0U )				/* 448 */
#define EID_01C1						( 0x01C1U )				/* 449 */

typedef enum {
	EBID_00,
	EBID_01,
	EBID_02,
	EBID_03,
	EBID_04,
	EBID_05,
	EBID_06,
	EBID_07,
	EBID_08,
	EBID_09,
	EBID_0A,
	EBID_0B,
	EBID_0C,
	EBID_0D,
	EBID_0E,
	EBID_0F,
	EBID_10,
	EBID_11,
	EBID_12,
	EBID_13,
	EBID_14,
	EBID_15,
	EBID_16,
	EBID_17,
	EBID_18,
	EBID_19,
	EBID_1A,
	EBID_1B,
	EBID_1C,
	EBID_1D,
	EBID_1E,
	EBID_1F,
	EBID_20,
	EBID_21,
	EBID_22,
	EBID_23,
	EBID_24,
	EBID_25,
	END_EEPROM_DATA_BLOCK
} EEPROM_BLOCK_INDEX;

enum {
	DATA_MAPPING,
	PARITY_MAPPING,
	END_OF_MAPPING_TYPE
};

typedef struct {
	UI_16	image_top_addr;
	UI_16	eep_top_addr;
	UI_16	size;
} T_Eep_mapping_info_tbl;

typedef struct {
	UI_8					parity_exist;
	T_Eep_mapping_info_tbl	access_info[END_OF_MAPPING_TYPE];
} T_Eep_data_block_info;

#define NO_PARITY						( 0U )
#define PARITY_EXIST					( 1U )

static const T_Eep_data_block_info C_Blk_data_tbl[END_EEPROM_DATA_BLOCK] = 
{
	/* EBID_00 */
	{
		NO_PARITY,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0000,	0x0000U,	2U		},
		{	EID_0000,	0x0000U,	0U		}}
	},

	/* EBID_01 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0002,	0x0002U,	8U		},
		{	EID_000A,	0x000AU,	2U		}}
	},

	/* EBID_02 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_000C,	0x000CU,	8U		},
		{	EID_0014,	0x0014U,	2U		}}
	},

	/* EBID_03 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0016,	0x0016U,	8U		},
		{	EID_001E,	0x001EU,	2U		}}
	},

	/* EBID_04 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0020,	0x0020U,	8U		},
		{	EID_0028,	0x0028U,	2U		}}
	},

	/* EBID_05 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_002A,	0x002AU,	8U		},
		{	EID_0032,	0x0032U,	2U		}}
	},

	/* EBID_06 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0034,	0x0034U,	8U		},
		{	EID_003C,	0x003CU,	2U		}}
	},

	/* EBID_07 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_003E,	0x003EU,	8U		},
		{	EID_0046,	0x0046U,	2U		}}
	},

	/* EBID_08 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0048,	0x0048U,	8U		},
		{	EID_0050,	0x0050U,	2U		}}
	},

	/* EBID_09 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0052,	0x0052U,	8U		},
		{	EID_005A,	0x005AU,	2U		}}
	},

	/* EBID_0A */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_005C,	0x005CU,	8U		},
		{	EID_0064,	0x0064U,	2U		}}
	},

	/* EBID_0B */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0066,	0x0066U,	8U		},
		{	EID_006E,	0x006EU,	2U		}}
	},

	/* EBID_0C */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0070,	0x0070U,	8U		},
		{	EID_0078,	0x0078U,	2U		}}
	},

	/* EBID_0D */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_007A,	0x007AU,	8U		},
		{	EID_0082,	0x0082U,	2U		}}
	},

	/* EBID_0E */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0084,	0x0084U,	8U		},
		{	EID_008C,	0x008CU,	2U		}}
	},

	/* EBID_0F */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_008E,	0x008EU,	8U		},
		{	EID_0096,	0x0096U,	2U		}}
	},

	/* EBID_10 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0098,	0x0098U,	8U		},
		{	EID_00A0,	0x00A0U,	2U		}}
	},

	/* EBID_11 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_00A2,	0x00A2U,	8U		},
		{	EID_00AA,	0x00AAU,	2U		}}
	},

	/* EBID_12 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_00AC,	0x00ACU,	8U		},
		{	EID_00B4,	0x00B4U,	2U		}}
	},

	/* EBID_13 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_00B6,	0x00B6U,	8U		},
		{	EID_00BE,	0x00BEU,	2U		}}
	},

	/* EBID_14 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_00C0,	0x00C0U,	8U		},
		{	EID_00C8,	0x00C8U,	2U		}}
	},

	/* EBID_15 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_00CA,	0x00CAU,	8U		},
		{	EID_00D2,	0x00D2U,	2U		}}
	},

	/* EBID_16 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_00D4,	0x00DEU,	8U		},
		{	EID_00DC,	0x00E6U,	2U		}}
	},

	/* EBID_17 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_00DE,	0x00E8U,	8U		},
		{	EID_00E6,	0x00F0U,	2U		}}
	},

	/* EBID_18 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_00E8,	0x00F2U,	8U		},
		{	EID_00F0,	0x00FAU,	2U		}}
	},

	/* EBID_19 */
	{
		NO_PARITY,
		/* 	ImageTop	EETop		size	*/
		{{	EID_00F2,	0x0100U,	64U		},
		{	EID_00F2,	0x0100U,	0U		}}
	},

	/* EBID_1A */
	{
		NO_PARITY,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0132,	0x0140U,	40U		},
		{	EID_0132,	0x0140U,	0U		}}
	},

	/* EBID_1B */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_015A,	0x0168U,	8U		},
		{	EID_0162,	0x0170U,	2U		}}
	},

	/* EBID_1C */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0164,	0x0172U,	8U		},
		{	EID_016C,	0x017AU,	2U		}}
	},

	/* EBID_1D */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_016E,	0x017CU,	8U		},
		{	EID_0176,	0x0184U,	2U		}}
	},

	/* EBID_1E */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0178,	0x0186U,	8U		},
		{	EID_0180,	0x018EU,	2U		}}
	},

	/* EBID_1F */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0182,	0x0190U,	8U		},
		{	EID_018A,	0x0198U,	2U		}}
	},

	/* EBID_20 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_018C,	0x01A4U,	8U		},
		{	EID_0194,	0x01ACU,	2U		}}
	},

	/* EBID_21 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_0196,	0x01AEU,	8U		},
		{	EID_019E,	0x01B6U,	2U		}}
	},

	/* EBID_22 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_01A0,	0x01B8U,	8U		},
		{	EID_01A8,	0x01C0U,	2U		}}
	},

	/* EBID_23 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_01AA,	0x01C2U,	8U		},
		{	EID_01B2,	0x01CAU,	2U		}}
	},

	/* EBID_24 */
	{
		PARITY_EXIST,
		/* 	ImageTop	EETop		size	*/
		{{	EID_01B4,	0x01CCU,	8U		},
		{	EID_01BC,	0x01D4U,	2U		}}
	},

	/* EBID_25 */
	{
		NO_PARITY,
		/* 	ImageTop	EETop		size	*/
		{{	EID_01BE,	0x01FCU,	4U		},
		{	EID_01BE,	0x01FCU,	0U		}}
	}
};

#define NUM_OF_TARGET_BLK_SEARCH_TBL	( 0x1DU )
static const UI_8 C_Eep_target_blk_search_tbl[NUM_OF_TARGET_BLK_SEARCH_TBL] = 
{
	EBID_02,	/* EID_000F */
	EBID_03,	/* EID_001F */
	EBID_05,	/* EID_002F */
	EBID_07,	/* EID_003F */
	EBID_08,	/* EID_004F */
	EBID_0A,	/* EID_005F */
	EBID_0B,	/* EID_006F */
	EBID_0D,	/* EID_007F */
	EBID_0F,	/* EID_008F */
	EBID_10,	/* EID_009F */
	EBID_12,	/* EID_00AF */
	EBID_13,	/* EID_00BF */
	EBID_15,	/* EID_00CF */
	EBID_17,	/* EID_00DF */
	EBID_18,	/* EID_00EF */
	EBID_19,	/* EID_00FF */
	EBID_19,	/* EID_010F */
	EBID_19,	/* EID_011F */
	EBID_19,	/* EID_012F */
	EBID_1A,	/* EID_013F */
	EBID_1A,	/* EID_014F */
	EBID_1B,	/* EID_015F */
	EBID_1D,	/* EID_016F */
	EBID_1E,	/* EID_017F */
	EBID_20,	/* EID_018F */
	EBID_21,	/* EID_019F */
	EBID_23,	/* EID_01AF */
	EBID_25,	/* EID_01BF */
	EBID_25		/* EID_01C1 */
};

#define NO_PRIORITY						( 0U )
#define PRIORITY						( 1U )

typedef struct {
	UI_16	start_addr;		/* Start address of eeprom(Download source) */
	UI_16	byte_size;		/* Area size of eeprom(Download source) */
	UI_8	priority;		/* Priority of each area */
	UI_16	blockno_start;	/* First block of eeprom image(Download destination) */
	UI_16	blockno_end;	/* Last block of eeprom image(Download destination) */
} T_Download_area_info;

#define AREA_SIZE_MAX					( 0x0000U )				/* Maximum number of priority area size */
#define NUM_OF_DOWNLOAD_AREA			( 0x0005U )				/* Number of download area */
static const T_Download_area_info C_Download_area_tbl[NUM_OF_DOWNLOAD_AREA] = 
{
	{	0x0000U,	0x00D4U,	NO_PRIORITY,	EBID_00,	EBID_15	},
	{	0x00DEU,	0x001EU,	NO_PRIORITY,	EBID_16,	EBID_18	},
	{	0x0100U,	0x009AU,	NO_PRIORITY,	EBID_19,	EBID_1F	},
	{	0x01A4U,	0x0032U,	NO_PRIORITY,	EBID_20,	EBID_24	},
	{	0x01FCU,	0x0004U,	NO_PRIORITY,	EBID_25,	EBID_25	}
};

#endif	/* #ifdef NVM_EEPMGR_000_INTERNAL_DEFINE */

#endif	/* #ifndef SSFTXXX_NVM_EEPMGR_CONFIG_H */
