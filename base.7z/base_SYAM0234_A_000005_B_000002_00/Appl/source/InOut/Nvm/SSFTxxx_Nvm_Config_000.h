/************************************************************************************************/
/* Customer			: -																			*/
/* Model(Theme No.)	: SSFT																		*/
/*----------------------------------------------------------------------------------------------*/
/* CPU				: -																			*/
/* Date				: 2013/05/05																*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Masato Koide																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/*----------------------------------------------------------------------------------------------*/
/* update by		: 44567_kikuchi																*/
/* date				: 2020/08/27																*/
/************************************************************************************************/
#ifndef SSFTXXX_NVM_CONFIG_H
#define SSFTXXX_NVM_CONFIG_H

/************************************************************************************************/
/* Definition of Macro																			*/
/************************************************************************************************/
/*----------------------------------------------------------------------------------------------*/
/* Version information																			*/
/*----------------------------------------------------------------------------------------------*/
#define NVM_CONFIG_H_VERSION			( 0x0203U )				/* NVM function Version = 0203 */

/*----------------------------------------------------------------------------------------------*/
/* APPL/BOOT information																		*/
/*----------------------------------------------------------------------------------------------*/
#define NVM_CONFIG_APPL											/* NVM function for APPL */

/*----------------------------------------------------------------------------------------------*/
/* NVMID																						*/
/*----------------------------------------------------------------------------------------------*/
#define NVMID_VAR_PCB_ASSY				( 0x0000U )				/* 0	PCB ASSY��� */
#define NVMID_VAR_ODO_UNIT_YA			( 0x0001U )				/* 1	�����P�ʐؑ։� */
#define NVMID_VAR_WT_UNIT				( 0x0002U )				/* 2	���x�P�ʎg�p��� */
#define NVMID_VAR_FUEL_UNIT_GAL_MODE	( 0x0003U )				/* 3	�R��P�ʎg�p��� */
#define NVMID_VAR_YA_COMMUNICATION		( 0x0004U )				/* 4	�ʐM�����ݒ� */
#define NVMID_VAR_ENG_EUR4_ENA			( 0x0005U )				/* 5	EG WARNING EUR.4�Ή����ڐݒ� */
#define NVMID_FUEL_MARK_DISP_MORE		( 0x0006U )				/* 6	FUEL�}�[�N����ݒ� */
#define NVMID_VAR_ODO_INTEGRATED_RATE	( 0x0007U )				/* 7	ODO�ώZ��km */
#define NVMID_LCD_FLM_FRQ_SETTING		( 0x0008U )				/* 8	LCD�t���[�����g���ݒ� */
#define NVMID_LCD_PWM_FRQ_SETTING		( 0x0009U )				/* 9	PWM�������g���ݒ� */
#define NVMID_SP_DGTL_CHNG_RATE_KM		( 0x000AU )				/* 10	SP�ԑ��ϊ��W�� [km/h] */
#define NVMID_SP_DGTL_CHNG_RATE_MPH		( 0x000BU )				/* 11	SP�ԑ��ϊ��W�� [mph] */
#define NVMID_SP_COMMUNICATION_BOX		( 0x000CU )				/* 12	SP�ʐM�i�[�� */
#define NVMID_BK6_SP_DISPLAY_HOLD_TIME	( 0x000DU )				/* 13	SP�\���ێ����� */
#define NVMID_SP_ZERODISP_KM			( 0x000EU )				/* 14	SP����"0"�\�������ԑ� [km/h] */
#define NVMID_SP_ZERODISP_MPH			( 0x000FU )				/* 15	SP����"0"�\�������ԑ� [mph] */
#define NVMID_SP_DGTL_IN_ADJ1_KM		( 0x0010U )				/* 16	SP�w�x(����)�����_1 [km/h] */
#define NVMID_SP_DGTL_IN_ADJ2_KM		( 0x0011U )				/* 17	SP�w�x(����)�����_2 [km/h] */
#define NVMID_SP_DGTL_IN_ADJ3_KM		( 0x0012U )				/* 18	SP�w�x(����)�����_3 [km/h] */
#define NVMID_SP_DGTL_IN_ADJ4_KM		( 0x0013U )				/* 19	SP�w�x(����)�����_4 [km/h] */
#define NVMID_SP_DGTL_OUT_ADJ1_KM		( 0x0014U )				/* 20	SP�w�x(�o��)�����_1 [km/h] */
#define NVMID_SP_DGTL_OUT_ADJ2_KM		( 0x0015U )				/* 21	SP�w�x(�o��)�����_2 [km/h] */
#define NVMID_SP_DGTL_OUT_ADJ3_KM		( 0x0016U )				/* 22	SP�w�x(�o��)�����_3 [km/h] */
#define NVMID_SP_DGTL_OUT_ADJ4_KM		( 0x0017U )				/* 23	SP�w�x(�o��)�����_4 [km/h] */
#define NVMID_SP_DGTL_IN_ADJ1_MPH		( 0x0018U )				/* 24	SP�w�x(����)�����_1 [mph] */
#define NVMID_SP_DGTL_IN_ADJ2_MPH		( 0x0019U )				/* 25	SP�w�x(����)�����_2 [mph] */
#define NVMID_SP_DGTL_IN_ADJ3_MPH		( 0x001AU )				/* 26	SP�w�x(����)�����_3 [mph] */
#define NVMID_SP_DGTL_IN_ADJ4_MPH		( 0x001BU )				/* 27	SP�w�x(����)�����_4 [mph] */
#define NVMID_SP_DGTL_OUT_ADJ1_MPH		( 0x001CU )				/* 28	SP�w�x(�o��)�����_1 [mph] */
#define NVMID_SP_DGTL_OUT_ADJ2_MPH		( 0x001DU )				/* 29	SP�w�x(�o��)�����_2 [mph] */
#define NVMID_SP_DGTL_OUT_ADJ3_MPH		( 0x001EU )				/* 30	SP�w�x(�o��)�����_3 [mph] */
#define NVMID_SP_DGTL_OUT_ADJ4_MPH		( 0x001FU )				/* 31	SP�w�x(�o��)�����_4 [mph] */
#define NVMID_TA_COMMUNICATION_BOX		( 0x0020U )				/* 32	TA�ʐM�i�[�� */
#define NVMID_TA_DGTL_IN_ADJ1			( 0x0021U )				/* 33	TA��]��(����)�����_1 */
#define NVMID_TA_DGTL_IN_ADJ2			( 0x0022U )				/* 34	TA��]��(����)�����_2 */
#define NVMID_TA_DGTL_IN_ADJ3			( 0x0023U )				/* 35	TA��]��(����)�����_3 */
#define NVMID_TA_DGTL_IN_ADJ4			( 0x0024U )				/* 36	TA��]��(����)�����_4 */
#define NVMID_TA_DGTL_OUT_ADJ1			( 0x0025U )				/* 37	TA��]��(�o��)�����_1 */
#define NVMID_TA_DGTL_OUT_ADJ2			( 0x0026U )				/* 38	TA��]��(�o��)�����_2 */
#define NVMID_TA_DGTL_OUT_ADJ3			( 0x0027U )				/* 39	TA��]��(�o��)�����_3 */
#define NVMID_TA_DGTL_OUT_ADJ4			( 0x0028U )				/* 40	TA��]��(�o��)�����_4 */
#define NVMID_TA_DGTL_IDLE				( 0x0029U )				/* 41	�A�C�h���L�� */
#define NVMID_TA_DGTL_IDLE1_START		( 0x002AU )				/* 42	�����ݸސݒ���1�J�n�Z�O�ʒu */
#define NVMID_TA_DGTL_IDLE1_RANGE		( 0x002BU )				/* 43	�����ݸސݒ���1�Z�O�ʒu */
#define NVMID_TA_DGTL_IDLE1_DELAY		( 0x002CU )				/* 44	�����ݸސݒ���1�x���萔 */
#define NVMID_TA_DGTL_IDLE234_RANGE		( 0x002DU )				/* 45	�����ݸސݒ���2,3,4�Z�O�ʒu */
#define NVMID_TA_DGTL_IDLE2_DELAY		( 0x002EU )				/* 46	�����ݸސݒ���2�x���萔 */
#define NVMID_FUEL_CUT_AD				( 0x002FU )				/* 47	FUEL�f�����oAD */
#define NVMID_FUEL_SHORT_AD				( 0x0030U )				/* 48	FUEL�Z�����oAD */
#define NVMID_FUEL_LFW_ON_DLY			( 0x0031U )				/* 49	LFW ON �x������ */
#define NVMID_FUEL_LFW_OFF_DLY			( 0x0032U )				/* 50	LFW OFF �x������ */
#define NVMID_FUEL_DISP_TIME_YA			( 0x0033U )				/* 51	FUEL �x������ */
#define NVMID_FUEL_CHNG_AD1				( 0x0034U )				/* 52	FUEL����臒l [ 1��E A/D ] */
#define NVMID_FUEL_CHNG_AD2				( 0x0035U )				/* 53	FUEL����臒l [ 2��1 A/D ] */
#define NVMID_FUEL_CHNG_AD3				( 0x0036U )				/* 54	FUEL����臒l [ 3��2 A/D ] */
#define NVMID_FUEL_CHNG_AD4				( 0x0037U )				/* 55	FUEL����臒l [ 4��3 A/D ] */
#define NVMID_FUEL_CHNG_AD5				( 0x0038U )				/* 56	FUEL����臒l [ 5��4 A/D ] */
#define NVMID_FUEL_CHNG_AD6				( 0x0039U )				/* 57	FUEL����臒l [ 6��5 A/D ] */
#define NVMID_N_SW_COMP_TIME			( 0x003AU )				/* 58	N SW��r���� */
#define NVMID_GEAR_ABN_JUDGE_TIME		( 0x003BU )				/* 59	�M�A�|�W�ُ픻�莞�� */
#define NVMID_INSTFUEL_DISP_PERIOD		( 0x003CU )				/* 60	�u�ԔR��\���X�V���� */
#define NVMID_INSTFUEL_DISP_KM			( 0x003DU )				/* 61	�u�ԔR��\���J�n�ԑ� [km/h] */
#define NVMID_INSTFUEL_DISP_MILE		( 0x003EU )				/* 62	�u�ԔR��\���J�n�ԑ� [mph] */
#define NVMID_AVGFUEL_DISP_DIST			( 0x003FU )				/* 63	���ϔR��\���X�V���� */
#define NVMID_AVGFUEL_DISP_START		( 0x0040U )				/* 64	���ϔR��\���J�n���� */
#define NVMID_AVGFUEL_DISP_PERIOD		( 0x0041U )				/* 65	���ϔR��\���X�V���� */
#define NVMID_ITEMP_UP_DELAY_TIME		( 0x0042U )				/* 66	�x���萔 [ �㏸ ] */
#define NVMID_ITEMP_DOWN_DELAY_TIME		( 0x0043U )				/* 67	�x���萔 [ ���~ ] */
#define NVMID_ITEMP_DISP_LOCK_SP		( 0x0044U )				/* 68	�\�����b�N�ԑ� [ km/h ] */
#define NVMID_ITEMP_DISP_UPDATE_TIME	( 0x0045U )				/* 69	�\���X�V���� */
#define NVMID_ITEMP_CHNG_COF_1			( 0x0046U )				/* 70	�ϊ��W��1 */
#define NVMID_ITEMP_CHNG_COF_2			( 0x0047U )				/* 71	�ϊ��W��2 */
#define NVMID_FLSR_FR_OUT_DLY			( 0x0048U )				/* 72	�t���b�V���[�O�o�͒x�� */
#define NVMID_FLSR_RR_OUT_DLY			( 0x0049U )				/* 73	�t���b�V���[��o�͒x�� */
#define NVMID_FLSR_FR_OUT_DUTY			( 0x004AU )				/* 74	�t���b�V���[�O�o��Duty */
#define NVMID_FLSR_RR_OUT_DUTY			( 0x004BU )				/* 75	�t���b�V���[��o��Duty */
#define NVMID_FLSR_FR_OPN_DETECT		( 0x004CU )				/* 76	�t�����g�f�����oAD�l */
#define NVMID_FLSR_FR_OPN_RLSE			( 0x004DU )				/* 77	�t�����g�f������AD�l */
#define NVMID_FLSR_FR_SHT_DETECT		( 0x004EU )				/* 78	�t�����g�Z�����oAD�l */
#define NVMID_FLSR_FR_SHT_RLSE			( 0x004FU )				/* 79	�t�����g�Z������AD�l */
#define NVMID_FLSR_RR_OPN_DETECT		( 0x0050U )				/* 80	���A�f�����oAD�l */
#define NVMID_FLSR_RR_OPN_RLSE			( 0x0051U )				/* 81	���A�f������AD�l */
#define NVMID_FLSR_RR_SHT_DETECT		( 0x0052U )				/* 82	���A�Z�����oAD�l */
#define NVMID_FLSR_RR_SHT_RLSE			( 0x0053U )				/* 83	���A�Z������AD�l */
#define NVMID_CAN_TIME_OUT_EFCTV		( 0x0054U )				/* 84	CAN�^�C���A�E�g�G���[�L������[ A/D ] */
#define NVMID_CAN_TIME_OUT_UNAVLBL		( 0x0055U )				/* 85	CAN�^�C���A�E�g�G���[��������[ A/D ] */
#define NVMID_CAN_TIME_OUT_EFECTV_TIME	( 0x0056U )				/* 86	CAN�^�C���A�E�g�G���[���o�������L�����莞�� */
#define NVMID_CAN_TIME_OUT_UNAVLBL_TIME	( 0x0057U )				/* 87	CAN�^�C���A�E�g�G���[���o�L�����������莞�� */
#define NVMID_CAN_TRANS_START_DLY		( 0x0058U )				/* 88	CAN���M�x������ */
#define NVMID_INIT_USER_FUEL_UNIT		( 0x0059U )				/* 89	�R��P�ʐݒ菉���l */
#define NVMID_INIT_USER_ODO_UNIT		( 0x005AU )				/* 90	�����P�ʐݒ菉���l */
#define NVMID_INIT_USER_SHIFT_MODE		( 0x005BU )				/* 91	SHIFT�쓮�ݒ菉���l */
#define NVMID_INIT_USER_SHIFT_ON		( 0x005CU )				/* 92	SHIFT�쓮��]���ݒ菉���l */
#define NVMID_INIT_USER_SHIFT_OFF		( 0x005DU )				/* 93	SHIFT��~��]���ݒ菉���l */
#define NVMID_INIT_USER_SHIFT_ILL		( 0x005EU )				/* 94	SHIFT�����ݒ菉���l */
#define NVMID_INIT_BRIGHT_SETTING_STATE	( 0x005FU )				/* 95	BACKLIGHT�����ݒ菉���l */
#define NVMID_VOLTAGE_LO_DETECTION		( 0x0060U )				/* 96	��d�����oAD�l */
#define NVMID_VOLTAGE_LO_RLSE			( 0x0061U )				/* 97	��d������AD�l */
#define NVMID_BATT_AD_OFFSET			( 0x0062U )				/* 98	�d��AD �I�t�Z�b�g�l */
#define NVMID_SHIFT_ILL_LEVEL1			( 0x0063U )				/* 99	SHIFT�����ݒ背�x��1(��) */
#define NVMID_SHIFT_ILL_LEVEL2			( 0x0064U )				/* 100	SHIFT�����ݒ背�x��2 */
#define NVMID_SHIFT_ILL_LEVEL3			( 0x0065U )				/* 101	SHIFT�����ݒ背�x��3 */
#define NVMID_SHIFT_ILL_LEVEL4			( 0x0066U )				/* 102	SHIFT�����ݒ背�x��4 */
#define NVMID_SHIFT_ILL_LEVEL5			( 0x0067U )				/* 103	SHIFT�����ݒ背�x��5 */
#define NVMID_SHIFT_ILL_LEVEL6			( 0x0068U )				/* 104	SHIFT�����ݒ背�x��6(��) */
#define NVMID_SHIFT_REV_ON_HYS			( 0x0069U )				/* 105	SHIFT�쓮��]���q�X�e���V�X */
#define NVMID_SHIFT_REV_OFF_HYS			( 0x006AU )				/* 106	SHIFT��~��]���q�X�e���V�X */
#define NVMID_SHIFT_REV_MIN				( 0x006BU )				/* 107	SHIFT�ŏ���]�� */
#define NVMID_SHIFT_REV_MAX				( 0x006CU )				/* 108	SHIFT�ő��]�� */
#define NVMID_ODO_INTEGRATED_1			( 0x006DU )				/* 109	ODO�ώZ�l1 */
#define NVMID_ODO_INTEGRATED_2			( 0x006EU )				/* 110	ODO�ώZ�l2 */
#define NVMID_ODO_INTEGRATED_3			( 0x006FU )				/* 111	ODO�ώZ�l3 */
#define NVMID_ODO_INTEGRATED_4			( 0x0070U )				/* 112	ODO�ώZ�l4 */
#define NVMID_ODO_INTEGRATED_5			( 0x0071U )				/* 113	ODO�ώZ�l5 */
#define NVMID_ODO_INTEGRATED_6			( 0x0072U )				/* 114	ODO�ώZ�l6 */
#define NVMID_ODO_INTEGRATED_7			( 0x0073U )				/* 115	ODO�ώZ�l7 */
#define NVMID_ODO_INTEGRATED_8			( 0x0074U )				/* 116	ODO�ώZ�l8 */
#define NVMID_ODO_INTEGRATED_9			( 0x0075U )				/* 117	ODO�ώZ�l9 */
#define NVMID_ODO_INTEGRATED_10			( 0x0076U )				/* 118	ODO�ώZ�l10 */
#define NVMID_ODO_INTEGRATED_11			( 0x0077U )				/* 119	ODO�ώZ�l11 */
#define NVMID_ODO_INTEGRATED_12			( 0x0078U )				/* 120	ODO�ώZ�l12 */
#define NVMID_ODO_INTEGRATED_13			( 0x0079U )				/* 121	ODO�ώZ�l13 */
#define NVMID_ODO_INTEGRATED_14			( 0x007AU )				/* 122	ODO�ώZ�l14 */
#define NVMID_ODO_INTEGRATED_15			( 0x007BU )				/* 123	ODO�ώZ�l15 */
#define NVMID_ODO_INTEGRATED_16			( 0x007CU )				/* 124	ODO�ώZ�l16 */
#define NVMID_ODO_INTEGRATED_17			( 0x007DU )				/* 125	ODO�ώZ�l17 */
#define NVMID_ODO_INTEGRATED_18			( 0x007EU )				/* 126	ODO�ώZ�l18 */
#define NVMID_ODO_INTEGRATED_19			( 0x007FU )				/* 127	ODO�ώZ�l19 */
#define NVMID_ODO_INTEGRATED_20			( 0x0080U )				/* 128	ODO�ώZ�l20 */
#define NVMID_ODO_INTEGRATED_21			( 0x0081U )				/* 129	ODO�ώZ�l21 */
#define NVMID_ODO_INTEGRATED_22			( 0x0082U )				/* 130	ODO�ώZ�l22 */
#define NVMID_ODO_INTEGRATED_23			( 0x0083U )				/* 131	ODO�ώZ�l23 */
#define NVMID_ODO_INTEGRATED_24			( 0x0084U )				/* 132	ODO�ώZ�l24 */
#define NVMID_ODO_INTEGRATED_25			( 0x0085U )				/* 133	ODO�ώZ�l25 */
#define NVMID_ODO_INTEGRATED_26			( 0x0086U )				/* 134	ODO�ώZ�l26 */
#define NVMID_ODO_INTEGRATED_27			( 0x0087U )				/* 135	ODO�ώZ�l27 */
#define NVMID_ODO_INTEGRATED_28			( 0x0088U )				/* 136	ODO�ώZ�l28 */
#define NVMID_ODO_INTEGRATED_29			( 0x0089U )				/* 137	ODO�ώZ�l29 */
#define NVMID_ODO_INTEGRATED_30			( 0x008AU )				/* 138	ODO�ώZ�l30 */
#define NVMID_ODO_INTEGRATED_31			( 0x008BU )				/* 139	ODO�ώZ�l31 */
#define NVMID_ODO_INTEGRATED_32			( 0x008CU )				/* 140	ODO�ώZ�l32 */
#define NVMID_ODO_LESS_1				( 0x008DU )				/* 141	ODO�����l1 */
#define NVMID_ODO_LESS_1_PARITY			( 0x008EU )				/* 142	ODO�����l1���è */
#define NVMID_ODO_LESS_2				( 0x008FU )				/* 143	ODO�����l2 */
#define NVMID_ODO_LESS_2_PARITY			( 0x0090U )				/* 144	ODO�����l2���è */
#define NVMID_ODO_LESS_3				( 0x0091U )				/* 145	ODO�����l3 */
#define NVMID_ODO_LESS_3_PARITY			( 0x0092U )				/* 146	ODO�����l3���è */
#define NVMID_ODO_LESS_4				( 0x0093U )				/* 147	ODO�����l4 */
#define NVMID_ODO_LESS_4_PARITY			( 0x0094U )				/* 148	ODO�����l4���è */
#define NVMID_ODO_LESS_5				( 0x0095U )				/* 149	ODO�����l5 */
#define NVMID_ODO_LESS_5_PARITY			( 0x0096U )				/* 150	ODO�����l5���è */
#define NVMID_ODO_LESS_6				( 0x0097U )				/* 151	ODO�����l6 */
#define NVMID_ODO_LESS_6_PARITY			( 0x0098U )				/* 152	ODO�����l6���è */
#define NVMID_ODO_LESS_7				( 0x0099U )				/* 153	ODO�����l7 */
#define NVMID_ODO_LESS_7_PARITY			( 0x009AU )				/* 154	ODO�����l7���è */
#define NVMID_ODO_LESS_8				( 0x009BU )				/* 155	ODO�����l8 */
#define NVMID_ODO_LESS_8_PARITY			( 0x009CU )				/* 156	ODO�����l8���è */
#define NVMID_ODO_LESS_9				( 0x009DU )				/* 157	ODO�����l9 */
#define NVMID_ODO_LESS_9_PARITY			( 0x009EU )				/* 158	ODO�����l9���è */
#define NVMID_ODO_LESS_10				( 0x009FU )				/* 159	ODO�����l10 */
#define NVMID_ODO_LESS_10_PARITY		( 0x00A0U )				/* 160	ODO�����l10���è */
#define NVMID_ODO_INTEGRATE_TRIP1		( 0x00A1U )				/* 161	TRIP1ؾ�Ď�ODO�ώZ�l [km] */
#define NVMID_ODO_LESS_TRIP1			( 0x00A2U )				/* 162	TRIP1ؾ�Ď�ODO�����l [km] */
#define NVMID_ODO_INTEGRATE_TRIP2		( 0x00A3U )				/* 163	TRIP2ؾ�Ď�ODO�ώZ�l [km] */
#define NVMID_ODO_LESS_TRIP2			( 0x00A4U )				/* 164	TRIP2ؾ�Ď�ODO�����l [km] */
#define NVMID_ODO_INTEGRATE_TRIPF		( 0x00A5U )				/* 165	F-Trip�\��������������ODO�ώZ�l [km] */
#define NVMID_ODO_LESS_TRIPF			( 0x00A6U )				/* 166	F-Trip�\��������������ODO�����l [km] */
#define NVMID_ODO_INTEGRATE_TRIPF_LFW	( 0x00A7U )				/* 167	LFW������ODO�ώZ�l [km] */
#define NVMID_ODO_LESS_TRIPF_LFW		( 0x00A8U )				/* 168	LFW������ODO�����l [km] */
#define NVMID_TRIPF_RESERVE_DELAY_COUNT	( 0x00A9U )				/* 169	���U�[�u�x���J�E���g�I����� */
#define NVMID_TRIPF_RESERVE_MODE		( 0x00AAU )				/* 170	���U�[�u��� */
#define NVMID_STORE_USER_DISP_MODE		( 0x00ABU )				/* 171	���ݕ\�����[�h���� */
#define NVMID_STORE_USER_DISP_MODE_OLD	( 0x00ACU )				/* 172	�ߋ��\�����[�h���� */
#define NVMID_STORE_USER_FUEL_UNIT		( 0x00ADU )				/* 173	�R��P�ʐݒ�L���l */
#define NVMID_STORE_USER_ODO_UNIT		( 0x00AEU )				/* 174	�����P�ʐݒ�L���l */
#define NVMID_STORE_USER_SHIFT_MODE		( 0x00AFU )				/* 175	SHIFT�쓮�ݒ� */
#define NVMID_STORE_USER_SHIFT_ON		( 0x00B0U )				/* 176	SHIFT�쓮��]���ݒ� */
#define NVMID_STORE_USER_SHIFT_OFF		( 0x00B1U )				/* 177	SHIFT��~��]���ݒ� */
#define NVMID_STORE_USER_SHIFT_ILL		( 0x00B2U )				/* 178	SHIFT�����ݒ� */
#define NVMID_BACKLIGHT_SETTING_STATE	( 0x00B3U )				/* 179	BACKLIGHT�����ݒ� */
#define NVMID_HIGH_BEAM_ON_AD			( 0x00B4U )				/* 180	HIGH BEAM SW ON���o A/D */
#define NVMID_HIGH_BEAM_OFF_AD			( 0x00B5U )				/* 181	HIGH BEAM SW OFF���o A/D */
#define NVMID_TURN_IN_RVRS_JUDGE_AD		( 0x00B6U )				/* 182	���SW���͔��]�΍􏈗�����pA/D */
#define NVMID_TURN_INTRMTNT_H			( 0x00B7U )				/* 183	�Ԍ����� H���� */
#define NVMID_TURN_INTRMTNT_L			( 0x00B8U )				/* 184	�Ԍ����� L���� */
#define NVMID_BRIGHT_DUTY1				( 0x00B9U )				/* 185	�ݒ�1 �f���[�e�B�� */
#define NVMID_BRIGHT_DUTY2				( 0x00BAU )				/* 186	�ݒ�2 �f���[�e�B�� */
#define NVMID_BRIGHT_DUTY3				( 0x00BBU )				/* 187	�ݒ�3 �f���[�e�B�� */
#define NVMID_BRIGHT_DUTY4				( 0x00BCU )				/* 188	�ݒ�4 �f���[�e�B�� */
#define NVMID_BRIGHT_DUTY5				( 0x00BDU )				/* 189	�ݒ�5 �f���[�e�B�� */
#define NVMID_BRIGHT_DUTY6				( 0x00BEU )				/* 190	�ݒ�6 �f���[�e�B�� */
#define NVMID_WT_DISP_TURN_ON			( 0x00BFU )				/* 191	�_���\���ؑ։��x[��] */
#define NVMID_WT_DISP_BLINK_ON			( 0x00C0U )				/* 192	�_�ŕ\���ؑ։��x[��] */
#define NVMID_WT_DISP_HI				( 0x00C1U )				/* 193	Hi�\���ؑ։��x[��] */
#define NVMID_WT_UPDATE_TIME			( 0x00C2U )				/* 194	�\���X�V���� */
#define NVMID_CTEMP_CHNG_COF_1			( 0x00C3U )				/* 195	�ϊ��W��1 */
#define NVMID_CTEMP_CHNG_COF_2			( 0x00C4U )				/* 196	�ϊ��W��2 */
#define NVMID_OIL_KMASKEGSP1			( 0x00C5U )				/* 197	�}�X�N��]��1 */
#define NVMID_OIL_KMASKEGSP2			( 0x00C6U )				/* 198	�}�X�N��]��2 */
#define NVMID_OIL_KMASKEGSP3			( 0x00C7U )				/* 199	�}�X�N��]��3 */
#define NVMID_OIL_KMASKWT1				( 0x00C8U )				/* 200	�}�X�N���� */
#define NVMID_OIL_SW_OPEN_TA			( 0x00C9U )				/* 201	�f�����o EG��]�� */
#define NVMID_OIL_SW_OPEN_TIME			( 0x00CAU )				/* 202	�f�����o���莞�� */
#define NVMID_EEP_VER_FORMAT			( 0x00CBU )				/* 203	̫�ϯ�Ver */
#define NVMID_EEP_VER_DATA				( 0x00CCU )				/* 204	�ް�Ver */
#define NVMID_EEP_VER_MAP				( 0x00CDU )				/* 205	EEPROMϯ��Ver */
#define END_NVMID_INDEX					( 0x00CEU )				/* 206 */

/*----------------------------------------------------------------------------------------------*/
/* Project-dependent (for NVM, EEPROM)															*/
/*----------------------------------------------------------------------------------------------*/
/* Internal definition for SSFTSTD_Nvm_Main, SSFTSTD_Nvm_EepMgr, SSFTSTD_Nvm_EepDrvCtrl */
#if defined(NVM_MAIN_000_INTERNAL_DEFINE)||defined(NVM_EEPMGR_000_INTERNAL_DEFINE)||defined(NVM_EEPDRVCTRL_INTERNAL_DEFINE)

#define ENABLE_DF_ACCESS				( 0U )					/* DataFlash access fuction (1:Apply, 0:Not apply) */

#endif

/*----------------------------------------------------------------------------------------------*/
/* Project-dependent (for NVM)																	*/
/*----------------------------------------------------------------------------------------------*/
#ifdef NVM_MAIN_000_INTERNAL_DEFINE	/* Internal definition for SSFTSTD_Nvm_Main */

#define NVM_DEVICE_EEPROM										/* NVM device:EEPROM */
#define ENABLE_SIGNED_RANGECHK			( 1U )					/* Signed range check (1:Apply, 0:Not apply) */
#define NVM_TBL_SIZE_MIN										/* ROM reduced Version */
#define ENABLE_NVM_BYTE_ACCESS									/* Apply BYTE access interface fuction */
#define ENABLE_NVM_WORD_ACCESS									/* Apply WORD access interface fuction */
#define ENABLE_NVM_DWORD_ACCESS									/* Apply DWORD access interface fuction */

/*----------------------------------------------------------------------------------------------*/
/* Fixed definition for NVM table																*/
/*----------------------------------------------------------------------------------------------*/
#define UNSIGN							( 0U )					/* Unsigned NVM data */
#define SIGN							( 1U )					/* Signed NVM data */
#define RANGE_CHK_TBL_NONE				( 0U )					/* No range check */
#define RANGE_CHK_TBL_X					( 1U )					/* range check table (less than 1Byte) */
#define RANGE_CHK_TBL_BYTE				( 2U )					/* range check table (1Byte) */
#define RANGE_CHK_TBL_WORD				( 3U )					/* range check table (2Byte) */
#define RANGE_CHK_TBL_DWORD				( 4U )					/* range check table (4Byte) */

/************************************************************************************************/
/* Definition of Internal Data Type																*/
/************************************************************************************************/
/* Range check table (less than 1Byte) */
typedef struct {
	UI_8	x_min;
	UI_8	x_max;
	UI_8	x_value;
} T_Nvm_appl_range_check_uix;

/* Range check table (1Byte) */
typedef struct {
	UI_8	byte_min;
	UI_8	byte_max;
	UI_8	byte_value;
} T_Nvm_appl_range_check_ui8;

/* Range check table (2Byte) */
typedef struct {
	UI_16	word_min;
	UI_16	word_max;
	UI_16	word_value;
} T_Nvm_appl_range_check_ui16;

/* Range check table (4Byte) */
typedef struct {
	UI_32	dword_min;
	UI_32	dword_max;
	UI_32	dword_value;
} T_Nvm_appl_range_check_ui32;

#ifdef NVM_TBL_SIZE_MIN
/* NVM access table (ROM reduced Version) */
typedef struct {
	UI_16		e_id;					/* 0-0xFFFF:Max 64K[Byte address] */
	BITFIELD	start_bit:3;			/* 0-7 */
	BITFIELD	length:6;				/* 0-32 */
	BITFIELD	type:3;					/* 1-4 */
	BITFIELD	shift_val:3;			/* 0-7 */
	BITFIELD	sign:2;					/* 0-1 */
	BITFIELD	default_data_table:3;	/* 0-4 */
	UI_16		default_data_index;		/* 0-0xFFFF:Mak 64K[Data] */
} T_Nvm_appl_data_interface;
#else
/* NVM access table (Standard Version) */
typedef struct {
	UI_16	e_id;
	UI_8	start_bit;
	UI_8	length;
	UI_8	type;
	UI_8	shift_val;
	UI_8	sign;
	UI_8	default_data_table;
	UI_16	default_data_index;
} T_Nvm_appl_data_interface;
#endif

/************************************************************************************************/
/* Definition of Internal Constant Data															*/
/************************************************************************************************/
/*----------------------------------------------------------------------------------------------*/
/* definition of data table																		*/
/*----------------------------------------------------------------------------------------------*/
static const T_Nvm_appl_data_interface C_Nvm_appldata_interface_tbl[] = 
{
	{	0x0000U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_PCB_ASSY */
	{	0x0002U,	0U,	2U,		1U,	6U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_ODO_UNIT_YA */
	{	0x0002U,	4U,	2U,		1U,	2U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_WT_UNIT */
	{	0x0002U,	6U,	2U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_FUEL_UNIT_GAL_MODE */
	{	0x0003U,	0U,	2U,		1U,	6U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_YA_COMMUNICATION */
	{	0x0004U,	4U,	2U,		1U,	2U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* VAR_ENG_EUR4_ENA */
	{	0x0005U,	0U,	2U,		1U,	6U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* FUEL_MARK_DISP_MORE */
	{	0x0006U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		0U	},	/* VAR_ODO_INTEGRATED_RATE */
	{	0x0008U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		0U	},	/* LCD_FLM_FRQ_SETTING */
	{	0x0009U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		1U	},	/* LCD_PWM_FRQ_SETTING */
	{	0x000CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* SP_DGTL_CHNG_RATE_KM */
	{	0x000EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* SP_DGTL_CHNG_RATE_MPH */
	{	0x0010U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		2U	},	/* SP_COMMUNICATION_BOX */
	{	0x0011U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		3U	},	/* BK6_SP_DISPLAY_HOLD_TIME */
	{	0x0012U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		4U	},	/* SP_ZERODISP_KM */
	{	0x0013U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		5U	},	/* SP_ZERODISP_MPH */
	{	0x0016U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		1U	},	/* SP_DGTL_IN_ADJ1_KM */
	{	0x0018U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		2U	},	/* SP_DGTL_IN_ADJ2_KM */
	{	0x001AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		3U	},	/* SP_DGTL_IN_ADJ3_KM */
	{	0x001CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		4U	},	/* SP_DGTL_IN_ADJ4_KM */
	{	0x0020U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		5U	},	/* SP_DGTL_OUT_ADJ1_KM */
	{	0x0022U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		6U	},	/* SP_DGTL_OUT_ADJ2_KM */
	{	0x0024U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		7U	},	/* SP_DGTL_OUT_ADJ3_KM */
	{	0x0026U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		8U	},	/* SP_DGTL_OUT_ADJ4_KM */
	{	0x002AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		9U	},	/* SP_DGTL_IN_ADJ1_MPH */
	{	0x002CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		10U	},	/* SP_DGTL_IN_ADJ2_MPH */
	{	0x002EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		11U	},	/* SP_DGTL_IN_ADJ3_MPH */
	{	0x0030U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		12U	},	/* SP_DGTL_IN_ADJ4_MPH */
	{	0x0034U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		13U	},	/* SP_DGTL_OUT_ADJ1_MPH */
	{	0x0036U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		14U	},	/* SP_DGTL_OUT_ADJ2_MPH */
	{	0x0038U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		15U	},	/* SP_DGTL_OUT_ADJ3_MPH */
	{	0x003AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		16U	},	/* SP_DGTL_OUT_ADJ4_MPH */
	{	0x0040U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		6U	},	/* TA_COMMUNICATION_BOX */
	{	0x0048U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		17U	},	/* TA_DGTL_IN_ADJ1 */
	{	0x004AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		18U	},	/* TA_DGTL_IN_ADJ2 */
	{	0x004CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		19U	},	/* TA_DGTL_IN_ADJ3 */
	{	0x004EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		20U	},	/* TA_DGTL_IN_ADJ4 */
	{	0x0052U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		21U	},	/* TA_DGTL_OUT_ADJ1 */
	{	0x0054U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		22U	},	/* TA_DGTL_OUT_ADJ2 */
	{	0x0056U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		23U	},	/* TA_DGTL_OUT_ADJ3 */
	{	0x0058U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		24U	},	/* TA_DGTL_OUT_ADJ4 */
	{	0x005CU,	0U,	1U,		1U,	7U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* TA_DGTL_IDLE */
	{	0x005EU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		7U	},	/* TA_DGTL_IDLE1_START */
	{	0x0060U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		8U	},	/* TA_DGTL_IDLE1_RANGE */
	{	0x0061U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		9U	},	/* TA_DGTL_IDLE1_DELAY */
	{	0x0062U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		10U	},	/* TA_DGTL_IDLE234_RANGE */
	{	0x0063U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		11U	},	/* TA_DGTL_IDLE2_DELAY */
	{	0x0066U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		25U	},	/* FUEL_CUT_AD */
	{	0x0068U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		26U	},	/* FUEL_SHORT_AD */
	{	0x006AU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		12U	},	/* FUEL_LFW_ON_DLY */
	{	0x006BU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		13U	},	/* FUEL_LFW_OFF_DLY */
	{	0x006DU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		14U	},	/* FUEL_DISP_TIME_YA */
	{	0x0070U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		27U	},	/* FUEL_CHNG_AD1 */
	{	0x0072U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		28U	},	/* FUEL_CHNG_AD2 */
	{	0x0074U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		29U	},	/* FUEL_CHNG_AD3 */
	{	0x0076U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		30U	},	/* FUEL_CHNG_AD4 */
	{	0x007AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		31U	},	/* FUEL_CHNG_AD5 */
	{	0x007CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		32U	},	/* FUEL_CHNG_AD6 */
	{	0x0086U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		15U	},	/* N_SW_COMP_TIME */
	{	0x0089U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		16U	},	/* GEAR_ABN_JUDGE_TIME */
	{	0x008EU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		17U	},	/* INSTFUEL_DISP_PERIOD */
	{	0x0090U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* INSTFUEL_DISP_KM */
	{	0x0091U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* INSTFUEL_DISP_MILE */
	{	0x0092U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		18U	},	/* AVGFUEL_DISP_DIST */
	{	0x0093U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		19U	},	/* AVGFUEL_DISP_START */
	{	0x0094U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		20U	},	/* AVGFUEL_DISP_PERIOD */
	{	0x0098U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ITEMP_UP_DELAY_TIME */
	{	0x0099U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ITEMP_DOWN_DELAY_TIME */
	{	0x009AU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		21U	},	/* ITEMP_DISP_LOCK_SP */
	{	0x009CU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ITEMP_DISP_UPDATE_TIME */
	{	0x009EU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		22U	},	/* ITEMP_CHNG_COF_1 */
	{	0x009FU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		23U	},	/* ITEMP_CHNG_COF_2 */
	{	0x00A2U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		24U	},	/* FLSR_FR_OUT_DLY */
	{	0x00A3U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		25U	},	/* FLSR_RR_OUT_DLY */
	{	0x00A4U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* FLSR_FR_OUT_DUTY */
	{	0x00A5U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* FLSR_RR_OUT_DUTY */
	{	0x00ACU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		33U	},	/* FLSR_FR_OPN_DETECT */
	{	0x00AEU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		34U	},	/* FLSR_FR_OPN_RLSE */
	{	0x00B0U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		35U	},	/* FLSR_FR_SHT_DETECT */
	{	0x00B2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		36U	},	/* FLSR_FR_SHT_RLSE */
	{	0x00B6U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		37U	},	/* FLSR_RR_OPN_DETECT */
	{	0x00B8U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		38U	},	/* FLSR_RR_OPN_RLSE */
	{	0x00BAU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		39U	},	/* FLSR_RR_SHT_DETECT */
	{	0x00BCU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		40U	},	/* FLSR_RR_SHT_RLSE */
	{	0x00C0U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		41U	},	/* CAN_TIME_OUT_EFCTV */
	{	0x00C2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		42U	},	/* CAN_TIME_OUT_UNAVLBL */
	{	0x00C4U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		26U	},	/* CAN_TIME_OUT_EFECTV_TIME */
	{	0x00C5U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		27U	},	/* CAN_TIME_OUT_UNAVLBL_TIME */
	{	0x00C6U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		28U	},	/* CAN_TRANS_START_DLY */
	{	0x00CBU,	0U,	2U,		1U,	6U,	UNSIGN,	RANGE_CHK_TBL_X,		0U	},	/* INIT_USER_FUEL_UNIT */
	{	0x00CBU,	2U,	2U,		1U,	4U,	UNSIGN,	RANGE_CHK_TBL_X,		1U	},	/* INIT_USER_ODO_UNIT */
	{	0x00CCU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		29U	},	/* INIT_USER_SHIFT_MODE */
	{	0x00CDU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		30U	},	/* INIT_USER_SHIFT_ON */
	{	0x00CEU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		31U	},	/* INIT_USER_SHIFT_OFF */
	{	0x00CFU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		32U	},	/* INIT_USER_SHIFT_ILL */
	{	0x00D0U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		33U	},	/* INIT_BRIGHT_SETTING_STATE */
	{	0x00D4U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		43U	},	/* VOLTAGE_LO_DETECTION */
	{	0x00D6U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		44U	},	/* VOLTAGE_LO_RLSE */
	{	0x00D8U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* BATT_AD_OFFSET */
	{	0x00DEU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		34U	},	/* SHIFT_ILL_LEVEL1 */
	{	0x00DFU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		35U	},	/* SHIFT_ILL_LEVEL2 */
	{	0x00E0U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		36U	},	/* SHIFT_ILL_LEVEL3 */
	{	0x00E1U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		37U	},	/* SHIFT_ILL_LEVEL4 */
	{	0x00E2U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		38U	},	/* SHIFT_ILL_LEVEL5 */
	{	0x00E3U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		39U	},	/* SHIFT_ILL_LEVEL6 */
	{	0x00E4U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		40U	},	/* SHIFT_REV_ON_HYS */
	{	0x00E5U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		41U	},	/* SHIFT_REV_OFF_HYS */
	{	0x00E8U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		42U	},	/* SHIFT_REV_MIN */
	{	0x00E9U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		43U	},	/* SHIFT_REV_MAX */
	{	0x00F2U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_1 */
	{	0x00F4U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_2 */
	{	0x00F6U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_3 */
	{	0x00F8U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_4 */
	{	0x00FAU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_5 */
	{	0x00FCU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_6 */
	{	0x00FEU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_7 */
	{	0x0100U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_8 */
	{	0x0102U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_9 */
	{	0x0104U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_10 */
	{	0x0106U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_11 */
	{	0x0108U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_12 */
	{	0x010AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_13 */
	{	0x010CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_14 */
	{	0x010EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_15 */
	{	0x0110U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_16 */
	{	0x0112U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_17 */
	{	0x0114U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_18 */
	{	0x0116U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_19 */
	{	0x0118U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_20 */
	{	0x011AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_21 */
	{	0x011CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_22 */
	{	0x011EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_23 */
	{	0x0120U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_24 */
	{	0x0122U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_25 */
	{	0x0124U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_26 */
	{	0x0126U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_27 */
	{	0x0128U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_28 */
	{	0x012AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_29 */
	{	0x012CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_30 */
	{	0x012EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_31 */
	{	0x0130U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_INTEGRATED_32 */
	{	0x0132U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_1 */
	{	0x0134U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_1_PARITY */
	{	0x0136U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_2 */
	{	0x0138U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_2_PARITY */
	{	0x013AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_3 */
	{	0x013CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_3_PARITY */
	{	0x013EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_4 */
	{	0x0140U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_4_PARITY */
	{	0x0142U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_5 */
	{	0x0144U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_5_PARITY */
	{	0x0146U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_6 */
	{	0x0148U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_6_PARITY */
	{	0x014AU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_7 */
	{	0x014CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_7_PARITY */
	{	0x014EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_8 */
	{	0x0150U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_8_PARITY */
	{	0x0152U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_9 */
	{	0x0154U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_9_PARITY */
	{	0x0156U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_10 */
	{	0x0158U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_10_PARITY */
	{	0x015AU,	0U,	24U,	3U,	0U,	UNSIGN,	RANGE_CHK_TBL_DWORD,	0U	},	/* ODO_INTEGRATE_TRIP1 */
	{	0x015EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIP1 */
	{	0x0164U,	0U,	24U,	3U,	0U,	UNSIGN,	RANGE_CHK_TBL_DWORD,	1U	},	/* ODO_INTEGRATE_TRIP2 */
	{	0x0168U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIP2 */
	{	0x016EU,	0U,	24U,	3U,	0U,	UNSIGN,	RANGE_CHK_TBL_DWORD,	2U	},	/* ODO_INTEGRATE_TRIPF */
	{	0x0172U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIPF */
	{	0x0178U,	0U,	24U,	3U,	0U,	UNSIGN,	RANGE_CHK_TBL_DWORD,	3U	},	/* ODO_INTEGRATE_TRIPF_LFW */
	{	0x017CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* ODO_LESS_TRIPF_LFW */
	{	0x017EU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		44U	},	/* TRIPF_RESERVE_DELAY_COUNT */
	{	0x017FU,	0U,	2U,		1U,	6U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* TRIPF_RESERVE_MODE */
	{	0x0182U,	0U,	4U,		1U,	4U,	UNSIGN,	RANGE_CHK_TBL_X,		2U	},	/* STORE_USER_DISP_MODE */
	{	0x0182U,	4U,	4U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_X,		3U	},	/* STORE_USER_DISP_MODE_OLD */
	{	0x0183U,	0U,	2U,		1U,	6U,	UNSIGN,	RANGE_CHK_TBL_X,		4U	},	/* STORE_USER_FUEL_UNIT */
	{	0x0183U,	2U,	2U,		1U,	4U,	UNSIGN,	RANGE_CHK_TBL_X,		5U	},	/* STORE_USER_ODO_UNIT */
	{	0x0184U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		45U	},	/* STORE_USER_SHIFT_MODE */
	{	0x0185U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		46U	},	/* STORE_USER_SHIFT_ON */
	{	0x0186U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		47U	},	/* STORE_USER_SHIFT_OFF */
	{	0x0187U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		48U	},	/* STORE_USER_SHIFT_ILL */
	{	0x0188U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		49U	},	/* BACKLIGHT_SETTING_STATE */
	{	0x018CU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		45U	},	/* HIGH_BEAM_ON_AD */
	{	0x018EU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		46U	},	/* HIGH_BEAM_OFF_AD */
	{	0x0190U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_WORD,		47U	},	/* TURN_IN_RVRS_JUDGE_AD */
	{	0x0192U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		50U	},	/* TURN_INTRMTNT_H */
	{	0x0193U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		51U	},	/* TURN_INTRMTNT_L */
	{	0x0196U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		52U	},	/* BRIGHT_DUTY1 */
	{	0x0197U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		53U	},	/* BRIGHT_DUTY2 */
	{	0x0198U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		54U	},	/* BRIGHT_DUTY3 */
	{	0x0199U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		55U	},	/* BRIGHT_DUTY4 */
	{	0x019AU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		56U	},	/* BRIGHT_DUTY5 */
	{	0x019BU,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		57U	},	/* BRIGHT_DUTY6 */
	{	0x01A0U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		58U	},	/* WT_DISP_TURN_ON */
	{	0x01A1U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		59U	},	/* WT_DISP_BLINK_ON */
	{	0x01A2U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		60U	},	/* WT_DISP_HI */
	{	0x01A4U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		61U	},	/* WT_UPDATE_TIME */
	{	0x01A6U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		62U	},	/* CTEMP_CHNG_COF_1 */
	{	0x01A7U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		63U	},	/* CTEMP_CHNG_COF_2 */
	{	0x01AAU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* OIL_KMASKEGSP1 */
	{	0x01ACU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* OIL_KMASKEGSP2 */
	{	0x01AEU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* OIL_KMASKEGSP3 */
	{	0x01B0U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* OIL_KMASKWT1 */
	{	0x01B4U,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* OIL_SW_OPEN_TA */
	{	0x01B6U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_BYTE,		64U	},	/* OIL_SW_OPEN_TIME */
	{	0x01BEU,	0U,	16U,	2U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* EEP_VER_FORMAT */
	{	0x01C0U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	},	/* EEP_VER_DATA */
	{	0x01C1U,	0U,	8U,		1U,	0U,	UNSIGN,	RANGE_CHK_TBL_NONE,		0U	}	/* EEP_VER_MAP */
};

static const T_Nvm_appl_range_check_uix C_Range_Check_X_Tbl[] = 
{
	{	0x01U,	0x02U,	0x01U	},	/* INIT_USER_FUEL_UNIT */
	{	0x01U,	0x02U,	0x01U	},	/* INIT_USER_ODO_UNIT */
	{	0x01U,	0x08U,	0x01U	},	/* STORE_USER_DISP_MODE */
	{	0x01U,	0x08U,	0x01U	},	/* STORE_USER_DISP_MODE_OLD */
	{	0x01U,	0x02U,	0x02U	},	/* STORE_USER_FUEL_UNIT */
	{	0x01U,	0x02U,	0x02U	}	/* STORE_USER_ODO_UNIT */
};

static const T_Nvm_appl_range_check_ui8 C_Range_Check_8_Tbl[] = 
{
	{	0x00U,	0x05U,	0x02U	},	/* LCD_FLM_FRQ_SETTING */
	{	0x00U,	0x01U,	0x01U	},	/* LCD_PWM_FRQ_SETTING */
	{	0x10U,	0x60U,	0x10U	},	/* SP_COMMUNICATION_BOX */
	{	0x01U,	0xFFU,	0x20U	},	/* BK6_SP_DISPLAY_HOLD_TIME */
	{	0x00U,	0x0AU,	0x03U	},	/* SP_ZERODISP_KM */
	{	0x00U,	0x0AU,	0x03U	},	/* SP_ZERODISP_MPH */
	{	0x01U,	0x08U,	0x08U	},	/* TA_COMMUNICATION_BOX */
	{	0x01U,	0x14U,	0x01U	},	/* TA_DGTL_IDLE1_START */
	{	0x01U,	0x0AU,	0x01U	},	/* TA_DGTL_IDLE1_RANGE */
	{	0x04U,	0xFEU,	0x04U	},	/* TA_DGTL_IDLE1_DELAY */
	{	0x01U,	0x0AU,	0x01U	},	/* TA_DGTL_IDLE234_RANGE */
	{	0x04U,	0xFEU,	0x04U	},	/* TA_DGTL_IDLE2_DELAY */
	{	0x01U,	0xFFU,	0x01U	},	/* FUEL_LFW_ON_DLY */
	{	0x01U,	0xFFU,	0x01U	},	/* FUEL_LFW_OFF_DLY */
	{	0x01U,	0xFFU,	0x01U	},	/* FUEL_DISP_TIME_YA */
	{	0x01U,	0xFFU,	0x32U	},	/* N_SW_COMP_TIME */
	{	0x09U,	0xFEU,	0x0AU	},	/* GEAR_ABN_JUDGE_TIME */
	{	0x01U,	0xF0U,	0x08U	},	/* INSTFUEL_DISP_PERIOD */
	{	0x01U,	0xFFU,	0x50U	},	/* AVGFUEL_DISP_DIST */
	{	0x01U,	0xFFU,	0x0AU	},	/* AVGFUEL_DISP_START */
	{	0x01U,	0xF0U,	0x08U	},	/* AVGFUEL_DISP_PERIOD */
	{	0x01U,	0xFFU,	0x14U	},	/* ITEMP_DISP_LOCK_SP */
	{	0x01U,	0xFFU,	0xA0U	},	/* ITEMP_CHNG_COF_1 */
	{	0x01U,	0xFFU,	0x1EU	},	/* ITEMP_CHNG_COF_2 */
	{	0x00U,	0x3CU,	0x00U	},	/* FLSR_FR_OUT_DLY */
	{	0x00U,	0x3CU,	0x00U	},	/* FLSR_RR_OUT_DLY */
	{	0x00U,	0xFFU,	0x23U	},	/* CAN_TIME_OUT_EFECTV_TIME */
	{	0x00U,	0xFFU,	0x23U	},	/* CAN_TIME_OUT_UNAVLBL_TIME */
	{	0x00U,	0xFFU,	0x23U	},	/* CAN_TRANS_START_DLY */
	{	0x01U,	0x03U,	0x01U	},	/* INIT_USER_SHIFT_MODE */
	{	0x1EU,	0x3CU,	0x1EU	},	/* INIT_USER_SHIFT_ON */
	{	0x1EU,	0x3CU,	0x1EU	},	/* INIT_USER_SHIFT_OFF */
	{	0x01U,	0x06U,	0x03U	},	/* INIT_USER_SHIFT_ILL */
	{	0x01U,	0x06U,	0x04U	},	/* INIT_BRIGHT_SETTING_STATE */
	{	0x01U,	0xFFU,	0x27U	},	/* SHIFT_ILL_LEVEL1 */
	{	0x01U,	0xFFU,	0x52U	},	/* SHIFT_ILL_LEVEL2 */
	{	0x01U,	0xFFU,	0x7EU	},	/* SHIFT_ILL_LEVEL3 */
	{	0x01U,	0xFFU,	0xA9U	},	/* SHIFT_ILL_LEVEL4 */
	{	0x01U,	0xFFU,	0xD5U	},	/* SHIFT_ILL_LEVEL5 */
	{	0x01U,	0xFFU,	0xFFU	},	/* SHIFT_ILL_LEVEL6 */
	{	0x00U,	0x05U,	0x00U	},	/* SHIFT_REV_ON_HYS */
	{	0x00U,	0x05U,	0x00U	},	/* SHIFT_REV_OFF_HYS */
	{	0x1EU,	0x3CU,	0x1EU	},	/* SHIFT_REV_MIN */
	{	0x1EU,	0x3CU,	0x1EU	},	/* SHIFT_REV_MAX */
	{	0x00U,	0x01U,	0x00U	},	/* TRIPF_RESERVE_DELAY_COUNT */
	{	0x01U,	0x03U,	0x01U	},	/* STORE_USER_SHIFT_MODE */
	{	0x1EU,	0x3CU,	0x1EU	},	/* STORE_USER_SHIFT_ON */
	{	0x1EU,	0x3CU,	0x1EU	},	/* STORE_USER_SHIFT_OFF */
	{	0x01U,	0x06U,	0x06U	},	/* STORE_USER_SHIFT_ILL */
	{	0x01U,	0x06U,	0x06U	},	/* BACKLIGHT_SETTING_STATE */
	{	0x01U,	0xFFU,	0x01U	},	/* TURN_INTRMTNT_H */
	{	0x01U,	0xFFU,	0x01U	},	/* TURN_INTRMTNT_L */
	{	0x01U,	0xFFU,	0x1AU	},	/* BRIGHT_DUTY1 */
	{	0x01U,	0xFFU,	0x48U	},	/* BRIGHT_DUTY2 */
	{	0x01U,	0xFFU,	0x76U	},	/* BRIGHT_DUTY3 */
	{	0x01U,	0xFFU,	0xA4U	},	/* BRIGHT_DUTY4 */
	{	0x01U,	0xFFU,	0xD2U	},	/* BRIGHT_DUTY5 */
	{	0x01U,	0xFFU,	0xFFU	},	/* BRIGHT_DUTY6 */
	{	0x01U,	0xFFU,	0x28U	},	/* WT_DISP_TURN_ON */
	{	0x01U,	0xFFU,	0x74U	},	/* WT_DISP_BLINK_ON */
	{	0x01U,	0xFFU,	0x8AU	},	/* WT_DISP_HI */
	{	0x00U,	0x30U,	0x05U	},	/* WT_UPDATE_TIME */
	{	0x01U,	0xFFU,	0xA0U	},	/* CTEMP_CHNG_COF_1 */
	{	0x01U,	0xFFU,	0x1EU	},	/* CTEMP_CHNG_COF_2 */
	{	0x00U,	0x14U,	0x07U	}	/* OIL_SW_OPEN_TIME */
};

static const T_Nvm_appl_range_check_ui16 C_Range_Check_16_Tbl[] = 
{
	{	0x000AU,	0xFEFFU,	0x000AU	},	/* VAR_ODO_INTEGRATED_RATE */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_IN_ADJ1_KM */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_IN_ADJ2_KM */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_IN_ADJ3_KM */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_IN_ADJ4_KM */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_OUT_ADJ1_KM */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_OUT_ADJ2_KM */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_OUT_ADJ3_KM */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_OUT_ADJ4_KM */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_IN_ADJ1_MPH */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_IN_ADJ2_MPH */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_IN_ADJ3_MPH */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_IN_ADJ4_MPH */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_OUT_ADJ1_MPH */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_OUT_ADJ2_MPH */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_OUT_ADJ3_MPH */
	{	0x0001U,	0x0C80U,	0x0C80U	},	/* SP_DGTL_OUT_ADJ4_MPH */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_DGTL_IN_ADJ1 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_DGTL_IN_ADJ2 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_DGTL_IN_ADJ3 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_DGTL_IN_ADJ4 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_DGTL_OUT_ADJ1 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_DGTL_OUT_ADJ2 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_DGTL_OUT_ADJ3 */
	{	0x0001U,	0x4E20U,	0x4E20U	},	/* TA_DGTL_OUT_ADJ4 */
	{	0x0001U,	0x03FEU,	0x0001U	},	/* FUEL_CUT_AD */
	{	0x0001U,	0x03FEU,	0x03FEU	},	/* FUEL_SHORT_AD */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD1 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD2 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD3 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD4 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD5 */
	{	0x0001U,	0x03FFU,	0x0001U	},	/* FUEL_CHNG_AD6 */
	{	0x0001U,	0x03FEU,	0x0017U	},	/* FLSR_FR_OPN_DETECT */
	{	0x0001U,	0x03FEU,	0x0018U	},	/* FLSR_FR_OPN_RLSE */
	{	0x0001U,	0x03FEU,	0x0324U	},	/* FLSR_FR_SHT_DETECT */
	{	0x0001U,	0x03FEU,	0x0323U	},	/* FLSR_FR_SHT_RLSE */
	{	0x0001U,	0x03FEU,	0x0017U	},	/* FLSR_RR_OPN_DETECT */
	{	0x0001U,	0x03FEU,	0x0018U	},	/* FLSR_RR_OPN_RLSE */
	{	0x0001U,	0x03FEU,	0x0324U	},	/* FLSR_RR_SHT_DETECT */
	{	0x0001U,	0x03FEU,	0x0323U	},	/* FLSR_RR_SHT_RLSE */
	{	0x0000U,	0x03FFU,	0x0001U	},	/* CAN_TIME_OUT_EFCTV */
	{	0x0000U,	0x03FFU,	0x0000U	},	/* CAN_TIME_OUT_UNAVLBL */
	{	0x0001U,	0x03FEU,	0x015AU	},	/* VOLTAGE_LO_DETECTION */
	{	0x0001U,	0x03FEU,	0x015BU	},	/* VOLTAGE_LO_RLSE */
	{	0x0001U,	0x03FEU,	0x0243U	},	/* HIGH_BEAM_ON_AD */
	{	0x0001U,	0x03FEU,	0x0244U	},	/* HIGH_BEAM_OFF_AD */
	{	0x0001U,	0x03FEU,	0x01B0U	}	/* TURN_IN_RVRS_JUDGE_AD */
};

static const T_Nvm_appl_range_check_ui32 C_Range_Check_32_Tbl[] = 
{
	{	0x00000000UL,	0x0018B820UL,	0x00000000UL	},	/* ODO_INTEGRATE_TRIP1 */
	{	0x00000000UL,	0x0018B820UL,	0x00000000UL	},	/* ODO_INTEGRATE_TRIP2 */
	{	0x00000000UL,	0x0018B820UL,	0x00000000UL	},	/* ODO_INTEGRATE_TRIPF */
	{	0x00000000UL,	0x0018B820UL,	0x00000000UL	}	/* ODO_INTEGRATE_TRIPF_LFW */
};

#endif	/* #ifdef NVM_MAIN_000_INTERNAL_DEFINE */

#endif	/* #ifndef SSFTXXX_NVM_CONFIG_H */
