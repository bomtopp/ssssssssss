/************************************************************************************************/
/* Customer : -																					*/
/* Model(Thema No.): SSFTSTD																	*/
/*----------------------------------------------------------------------------------------------*/
/* CPU -																						*/
/* Date 2014/04/21																				*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by Masato Koide																	*/
/* Copyrights Nippon Seiki Co.,Ltd																*/
/*----------------------------------------------------------------------------------------------*/
/* Update by	: 41734_m_koide																	*/
/* Date			: 2015/11/05																	*/
/* Version		: [020301]																		*/
/* Note			:																				*/
/************************************************************************************************/
#ifndef SSFTSTD_NVM_IF_H
#define SSFTSTD_NVM_IF_H

#include "SSFTSTD_Type.h"
#include "SSFTxxx_Nvm_Config_000.h"

/*================================================================================================*/
/* $$$$	Definition of Type                                                                        */
/*================================================================================================*/
/* �f�[�^�t���b�V�����ڃA�N�Z�X�p */
typedef UI_32 T_Nvm_addr;			/* �A�h���X���:32bit */
typedef UI_32 T_Nvm_data;			/* �f�[�^�T�C�Y:32bit */

/*================================================================================================*/
/* $$$$	Definition of Structure                                                                   */
/*================================================================================================*/

/*================================================================================================*/
/* $$$$	Definition of Macro                                                                       */
/*================================================================================================*/
#define NVM_IF_H_VERSION	( 0x0203U )		/* Nvm�@�\�o�[�W���� */

#define NVM_NO_ERR		(0x00U)			/* �G���[���� */
#define NVM_PTY_ERR		(0x01U)			/* �p���e�B�G���[ */
#define NVM_WR_ERR		(0x02U)			/* �������݃G���[ */
#define NVM_RANGE_ERR	(0x04U)			/* �͈̓`�F�b�N�G���[ */

#define	NVM_DIRECT_SUCCESS		(0U)	/* NVM���ڏ������݌���(����) */
#define	NVM_DIRECT_FAILURE		(1U)	/* NVM���ڏ������݌���(���s) */
#define	NVM_DIRECT_OPERATING	(2U)	/* NVM���ڏ������݌���(�������ݒ�) */

#define NVM_HALT_WRCTRL	(0x00U)		/* HALT:�����݃R���g���[���[��~ */
#define NVM_HALT_WRREQ	(0x01U)		/* HALT:�����ݗv���֎~ */

/*================================================================================================*/
/* $$$$	Declaration of Function Prototype                                                         */
/*================================================================================================*/

extern void Nvm_Init(E_INIT_TYPE type);
extern void Nvm_Main(void);
extern void Nvm_Intr(void);
extern SI_8 Nvm_SetByteApplData(const UI_16 nvm_id, const UI_8 value);
extern SI_8 Nvm_SetWordApplData(const UI_16 nvm_id, const UI_16 value);
extern SI_8 Nvm_SetDWordApplData(const UI_16 nvm_id, const UI_32 value);
extern SI_8 Nvm_CompelSetByteApplData(const UI_16 nvm_id, const UI_8 value);
extern SI_8 Nvm_CompelSetWordApplData(const UI_16 nvm_id, const UI_16 value);
extern SI_8 Nvm_CompelSetDWordApplData(const UI_16 nvm_id, const UI_32 value);
extern UI_8 Nvm_GetByteApplData(const UI_16 nvm_id, SI_8 *stat);
extern UI_16 Nvm_GetWordApplData(const UI_16 nvm_id, SI_8 *stat);
extern UI_32 Nvm_GetDWordApplData(const UI_16 nvm_id, SI_8 *stat);
extern UI_16 Nvm_GetDirectWordData(const UI_16 logical_addr, SI_8 *stat);
extern SI_8 Nvm_SetDirectWordData(const UI_16 logical_addr, const UI_16 value);
extern UI_8 Nvm_GetDirectWrStat(void);
extern UI_8 Nvm_GetApplErrStat(const UI_16 nvm_id, SI_8 *stat);
extern UI_8 Nvm_GetApplWrStat(const UI_16 nvm_id, SI_8 *stat);
extern void Nvm_SetHalt(const UI_8 mode);
extern void Nvm_ClrHalt(const UI_8 mode);
extern UI_8 Nvm_GetDataCorrection(void);
extern SI_8 Nvm_GetBusyStat(void);
extern UI_8 Nvm_GetErrExistence(void);
extern SI_8 Nvm_GetOperationState(void);
extern T_Nvm_data Nvm_GetDirectData(const T_Nvm_addr physical_addr, SI_8 *stat );
extern SI_8 Nvm_SetDirectData(const T_Nvm_addr physical_addr, const T_Nvm_data wr_data );
extern SI_8 Nvm_SetDirectErase(const UI_8 sect );
extern UI_8 Nvm_GetDirectStat(void);

/*================================================================================================*/
/* $$$$	Definition of Variable                                                                    */
/*================================================================================================*/

#endif /* SSFTSTD_NVM_IF_H */
