/************************************************************************************************/
/* Customer : -																					*/
/* Model(Thema No.): SSFTSTD																	*/
/*----------------------------------------------------------------------------------------------*/
/* CPU -																						*/
/* Date 2014/04/21																				*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by Masato Koide																	*/
/* Copyrights Nippon Seiki Co.,Ltd																*/
/*----------------------------------------------------------------------------------------------*/
/* Update by	: 41734_m_koide																	*/
/* Date			: 2015/11/05																	*/
/* Version		: [020201]																		*/
/* Note			:																				*/
/************************************************************************************************/
#ifndef	SSFTSTD_NVM_EEPDRVCTRL_H
#define	SSFTSTD_NVM_EEPDRVCTRL_H

#include "SSFTSTD_Type.h"
#include "SSFTxxx_Nvm_EepMgr_Config_000.h"
#include "SSFTxxx_Nvm_Config_000.h"
#include <string.h>

/*================================================================================================*/
/* $$$$	Definition of Type                                                                        */
/*================================================================================================*/

/*================================================================================================*/
/* $$$$	Definition of Structure                                                                   */
/*================================================================================================*/

/*================================================================================================*/
/* $$$$	Definition of Macro                                                                       */
/*================================================================================================*/
#define	NVM_EEPDRVCTRL_H_VERSION	( 0x0203U )		/* Nvm�@�\�o�[�W���� */

#define	EEP_WRITE_IDLE		(0U)		/* EEPROM��������IDLE��� */
#define	EEP_SET_WRITE_REQ	(1U)		/* EEPROM�������ݗv����̍ςݏ�� */
#define	EEP_WRITE_PROGRESS	(2U)		/* EEPROM�������ݎ��s�� */

#define	NO_EEP_WRITING		(0U)		/* EEPROM�������݂Ȃ� */
#define	EEP_WRITING_SUCCESS	(1U)		/* EEPROM�������ݐ��� */
#define	EEP_WRITING_FAILURE	(2U)		/* EEPROM�������ݎ��s */

/*================================================================================================*/
/* $$$$	Declaration of Function Prototype                                                         */
/*================================================================================================*/
extern void NvmMgr_WrCtrl_Reset(void);
extern void NvmMgr_WrCtrl_Wakeup(void);
extern void NvmMgr_WrCtrl_Process(void);
extern UI_8 NvmMgr_WrCtrl_GetWrResult(void);
extern UI_8 NvmMgr_WrCtrl_GetWrStat(void);
extern void NvmMgr_WrCtrl_SetWordWrReq(UI_16 byte_addr, UI_16 value);
extern void NvmMgr_WrCtrl_SetBindByteWrReq(UI_16 byte_addr, UI_8 value);
extern void NvmMgr_WrCtrl_SetByteWrReq(UI_16 byte_addr, UI_8 value);
extern void NvmMgr_WrCtrl_StopWriting(void);
extern UI_8 NvmMgr_WrCtrl_GetWrVerifiedData(UI_8 *data_ptr);

extern void NvmMgr_DrvIf_WriteEnable(UI_8 enabler);
extern UI_16 NvmMgr_DrvIf_ReadWord(UI_16 byte_addr);
#if ENABLE_NWORD_READ					/* �A�����[�h�Ή����A���� */
extern void NvmMgr_DrvIf_NWord( const UI_16 byte_addr, const UI_16 read_byte_size, UI_8 read_byte_data[] );
#endif
extern SI_8 NvmMgr_DrvIf_NWordFastFinish(void);

/*================================================================================================*/
/* $$$$	Definition of Variable                                                                    */
/*================================================================================================*/

#endif	/* #ifndef	SSFTSTD_NVM_EEPDRVCTRL_H */

