/************************************************************************************************/
/* Customer : -																					*/
/* Model(Thema No.): SSFTSTD																	*/
/*----------------------------------------------------------------------------------------------*/
/* CPU -																						*/
/* Date 2014/04/21																				*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by Masato Koide																	*/
/* Copyrights Nippon Seiki Co.,Ltd																*/
/*----------------------------------------------------------------------------------------------*/
/* Update by	: 41734_m_koide																	*/
/* Date			: 2015/11/15																	*/
/* Version		: [020201]																		*/
/* Note			:																				*/
/************************************************************************************************/
#ifndef	SSFTSTD_NVM_EEPMGR_H
#define	SSFTSTD_NVM_EEPMGR_H

#include "SSFTSTD_Type.h"
#include "SSFTxxx_Nvm_EepMgr_Config_000.h"
#include "SSFTxxx_Nvm_Config_000.h"

#include <string.h>

/*================================================================================================*/
/* $$$$	Definition of Type                                                                        */
/*================================================================================================*/

/*================================================================================================*/
/* $$$$	Definition of Structure                                                                   */
/*================================================================================================*/

/*================================================================================================*/
/* $$$$	Definition of Macro                                                                       */
/*================================================================================================*/
#define	NVM_EEPMGR_H_VERSION		( 0x0203U )		/* Nvm�@�\�o�[�W���� */

#define NVM_MGR_DIRECT_SUCCESS		( 0U )	/* NVM���ڃA�N�Z�X����(����)			*/
#define NVM_MGR_DIRECT_FAILURE		( 1U )	/* NVM���ڃA�N�Z�X����(���s)			*/
#define NVM_MGR_DIRECT_OPERATING	( 2U )	/* NVM���ڃA�N�Z�X����(�A�N�Z�X��)		*/

/*================================================================================================*/
/* $$$$	Declaration of Function Prototype                                                         */
/*================================================================================================*/
extern void Nvm_Mgr_Init(E_INIT_TYPE type);
extern void Nvm_Mgr_Main(void);
extern void Nvm_Mgr_Intr(void);

extern void Nvm_Mgr_SetByte( const UI_16 e_id, const UI_8 wr_data);
extern UI_8 Nvm_Mgr_GetByte( const UI_16 e_id );
extern UI_16 Nvm_Mgr_GetDirectWord(const UI_16 addr, SI_8 *stat);
extern SI_8 Nvm_Mgr_SetDirectWord(const UI_16 addr, const UI_16 value);
extern UI_8 Nvm_Mgr_GetDirectWrStat(void);
extern SI_8 Nvm_Mgr_GetRdErr(const UI_16 e_id, const UI_16 size);
extern SI_8 Nvm_Mgr_GetWrErr(const UI_16 e_id, const UI_16 size);
extern SI_8 Nvm_Mgr_GetWrStat(const UI_16 e_id, const UI_16 size);
extern void Nvm_Mgr_SetWritePending(void);
extern void Nvm_Mgr_ClrWritePending(void);
extern UI_8 Nvm_Mgr_GetDataCorrection(void);
extern SI_8 Nvm_Mgr_GetBusyStat(void);

extern UI_32 Nvm_Mgr_GetDirectDFData(const UI_32 addr, SI_8 *stat);
extern SI_8 Nvm_Mgr_SetDirectDFData(const UI_32 addr, const UI_32 wr_data);
extern SI_8 Nvm_Mgr_SetDirectDFErase(const UI_8 sect );
extern UI_8 Nvm_Mgr_GetDirectDFStat(void);

extern SI_8 Nvm_Mgr_GetOperationState(void);

/*================================================================================================*/
/* $$$$	Definition of Variable                                                                    */
/*================================================================================================*/

#endif	/* #ifndef	SSFTSTD_NVM_EEPMGR_H */
