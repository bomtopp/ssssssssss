/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SYAM																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Arisaka																	*/
/* Date 			: 2018/05/15																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: UART����@�\�C���N���[�h�w�b�_											*/
/*************************************************************************************************/
#ifndef	__XXX_UARTCTRL_INC_H__
#define	__XXX_UARTCTRL_INC_H__

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include <string.h>
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Type.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	UARTCTRL_INTERNAL

#include <string.h>
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Com_P5_101.h"
#include "SSFTSTD_RL78Uart_Drv_001.h"
#include "SYAMxxx_UartCtrl_Config_101.h"
#include "SYAMSTD_UartCtrl_IF_101.h"
#include "SYAMSTD_UartCtrl_P5_101.h"

#endif	/* UARTCTRL_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	UARTCTRL_MAIN_INTERNAL

#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Type.h"
#include "SYAM0234_SysIn_IF_101.h"
#include "SYAM0234_SysCtrl_IF_101.h"
#include "SYAM0234_DataMgr_IF_101.h"
#include "SYAMxxx_UartCtrl_Config_101.h"
#include "SYAMSTD_UartCtrl_IF_101.h"
#include "SYAMSTD_UartCtrl_P5_101.h"
#include "SYAMSTD_UartCtrl_Main_101.h"

#endif	/* UARTCTRL_MAIN_INTERNAL */

#endif	/* __XXX_UARTCTRL_INC_H__ */

