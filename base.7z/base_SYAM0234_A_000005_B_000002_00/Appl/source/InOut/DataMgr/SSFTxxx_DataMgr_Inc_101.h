/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SSFT																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Arisaka																	*/
/* Date 			: 2018/05/15																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: �f�[�^�Ǘ��@�\�C���N���[�h�w�b�_											*/
/*************************************************************************************************/
#ifndef	__XXX_DATAMGR_INC_H__
#define	__XXX_DATAMGR_INC_H__

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	DATAMGR_C_INTERNAL

#include "SSFTxxx_DataMgr_Config_101.h"
#include "SYAM0234_DataMgr_IF_101.h"
#include "SYAM0234_DataMgr_Main_101.h"
#include "SYAM0129_DataMgr_P5_101.h"
#include "SSFTSTD_Nvm_IF.h"
#include "SYAMSTD_FuelTrip_IF_101.h"
#include "SSFTSTD_Com_P5_101.h"

#endif	/* DATAMGR_C_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	DATAMGR_MAIN_INTERNAL

#include "SSFTSTD_Nvm_IF.h"

#include "SSFTxxx_DataMgr_Config_101.h"
#include "SYAM0234_DataMgr_IF_101.h"
#include "SYAM0129_DataMgr_P5_101.h"
#include "SYAM0234_DataMgr_Main_101.h"
#include "SSFTSTD_OdoTrip_IF_101.h"
#if DATAMGR_SHIFT == DATAMGR_ENABLE
/* #include "SSZVxxx_ShiftUp_IF.h" */		/* ShiftTmming�҂� */
#endif
#include "SYAM0234_ProdTest_Main_102.h"
#include "SYAM0234_DispCtrl_Main_101.h"
#include "SYAMSTD_FuelTrip_IF_101.h"
#endif	/* DATAMGR_MAIN_INTERNAL */

#endif	/* __XXX_DATAMGR_INC_H__ */

