/************************************************************************************************/
/* File name		: SSFTSTD_System.h															*/
/* Description		: ���ʃV�X�e���w�b�_�t�@�C��												*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: �n�� �F��			 														*/
/* Date 			: 2004/01/08																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Note 			: 																			*/
/*----------------------------------------------------------------------------------------------*/
/* Update by		: $Author: Sato Yusuke (A01A091212) $												*/
/* Date 			: $Date: 2020/03/02 10:15:06ICT $											*/
/* Version			: $Revision: 1.1 $														*/
/************************************************************************************************/
#ifndef	__SYSTEM__
#define	__SYSTEM__

/************************************************************************************************/
/* �C���N���[�h�t�@�C��																			*/
/************************************************************************************************/
#include "SSFTSTD_type.h"								/* �f�[�^�^�w�b�_						*/

/************************************************************************************************/
/* �}�N����`																					*/
/************************************************************************************************/
#define MET_OK				((UI_8)1)
#define MET_NG				((UI_8)0)
#define MET_ON				((UI_8)1)
#define MET_OFF				((UI_8)0)
#define MET_TRUE			((UI_8)1)
#define MET_FALSE			((UI_8)0)
#define MET_HI				((UI_8)1)
#define MET_LOW				((UI_8)0)

#define U_ON                ((UI_8)1)
#define U_OFF               ((UI_8)0)

#define		N_OK			((SI_8)0)					/* OK									*/
#define		N_NG			((SI_8)-1)					/* NG									*/

#define		N_TRUE			((B_8)1)					/* �^									*/
#define		N_FALSE			((B_8)0)					/* �U									*/

#define		N_ON			((UI_8)1)					/* ON									*/
#define		N_OFF			((UI_8)0)					/* OFF									*/

#define		N_NON_EDGE		((UI_8)0)					/* �ω��G�b�W�Ȃ�						*/
#define		N_ON_EDGE		((UI_8)1)					/* OFF��ON�ω��G�b�W					*/
#define		N_OFF_EDGE		((UI_8)2)					/* ON��OFF�ω��G�b�W					*/

#define		N_ON_ACTL		((UI_8)0)					/* �A�N�e�B�uL��ON						*/
#define		N_OFF_ACTL		((UI_8)1)					/* �A�N�e�B�uL��OFF						*/

#define		N_ON_ACTH		((UI_8)1)					/* �A�N�e�B�uH��ON						*/
#define		N_OFF_ACTH		((UI_8)0)					/* �A�N�e�B�uH��OFF						*/

#define		N_HIGH			((UI_8)1)					/* �n�C���x��							*/
#define		N_LOW			((UI_8)0)					/* ���E���x��							*/

#define		N_ENABLE		((UI_8)1)					/* ����									*/
#define		N_DISABLE		((UI_8)0)					/* �֎~									*/

#define		N_NULL			0							/* �k��									*/

#define		N_PI			3.1415926535				/* �~����								*/

#define		INIDISP_NON ((UI_8) 0)						/* �����_��������						*/
#define		INIDISP_END ((UI_8) 1)						/* �����_������							*/

#define		SEL_KM ((UI_8) 0)							/* km									*/
#define		SEL_MI ((UI_8) 1)							/* mile									*/

#define		SEL_C ((UI_8) 0)							/* �ێ�									*/
#define		SEL_F ((UI_8) 1)							/* �؎�									*/

#endif /* __SYSTEM__ */
