/************************************************************************************************/
/* File name		: SSFTSTD_MacroFunc.h														*/
/* Description		: �W���g���݊֐��}�N����`�t�@�C��											*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: 					 														*/
/* Date 			: 																			*/
/* Copyrights		: Copyright(C) 2012 Nippon Seiki Co.,Ltd. All Rights Reserved.              */
/* Note 			: 																			*/
/************************************************************************************************/
#ifndef __SSFTSTD_MACROFUNC_H__
#define __SSFTSTD_MACROFUNC_H__

/************************************************************************************************/
/* �C���N���[�h�錾																				*/
/************************************************************************************************/
#ifdef __H8SX__									/* H8 Series	*/
#include	<machine.h>
#elif defined(__RL78_CA78K0R__)					/* RL78 Series(CA78K0R)	*/
#pragma EI
#pragma DI
#pragma NOP
#endif

/************************************************************************************************/
/* �����݋֎~�E����																				*/
/************************************************************************************************/
#ifdef __H8SX__									/* H8 Series	*/
#define		D_EI()			set_imask_exr(0)
#define		D_DI()			set_imask_exr(7)

#elif defined __F2FR__							/* F2MC-16, FR Series	*/
#define 	D_EI()			__EI()
#define		D_DI()			__DI()

#elif defined (__V8DJ3__) || defined (__V8DJ4__)	/* V850E/DJ3, V850E2/DJ4	*/
#define 	D_EI()			__EI()
#define		D_DI()			__DI()

#elif defined(__RL78_CA78K0R__)					/* RL78 Series(CA78K0R)	*/
#define 	D_EI()			EI()
#define		D_DI()			DI()

#elif defined(__RL78_CCRL__)					/* RL78 Series(CC-RL) */
#define 	D_EI()			__EI()
#define		D_DI()			__DI()

#else
  /* DO NOT place any command. */
#endif


/************************************************************************************************/
/* NOP																							*/
/************************************************************************************************/
#ifdef __H8SX__									/* H8 Series	*/
#define		D_NOP()			nop()

#elif defined __F2FR__							/* F2MC-16, FR Series	*/
#define		D_NOP()			__wait_nop()

#elif defined (__V8DJ3__) || defined (__V8DJ4__)	/* V850E/DJ3, V850E2/DJ4	*/
#define		D_NOP()			__nop()

#elif defined(__RL78_CA78K0R__)					/* RL78 Series(CA78K0R)	*/
#define		D_NOP()			NOP()

#elif defined(__RL78_CCRL__)					/* RL78 Series(CC-RL) */
#define		D_NOP()			__nop()

#else
  /* DO NOT place any command. */
#endif


#endif /* __SSFTSTD_MACROFUNC_H__ */
