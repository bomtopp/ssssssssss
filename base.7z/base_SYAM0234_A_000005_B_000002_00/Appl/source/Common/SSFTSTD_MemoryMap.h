/************************************************************************************************/
/* File name		: SSFTSTD_Memory_Map.h														*/
/* Description		: Header File for Memory Mapping 											*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Yutaka Kaneko		 														*/
/* Date 			: 2011/12/22																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Note 			: 																			*/
/*----------------------------------------------------------------------------------------------*/
/* Update by		: $Author: Miyaguti Yoko (A01A038020) $												*/
/* Date 			: $Date: 2017/11/24 07:26:18ICT $											*/
/* Version			: $Revision: 1.1 $														*/
/************************************************************************************************/
/*
   [Note]
  -----------------------------------------------------------------------------------------------
   MISRA-C:1998 VIOLATION - RULE 92   (adv)
   MISRA-C:2004 VIOLATION - RULE 19.6 (req) 
   #undef shall not be used.
   Justification:
     Implemented according to NS Software Re-use strategy in SDES-F-B-002.
     "The file SSFTSTD_MemoryMap.h shall undefine the module specific memory allocation key 
     words for starting or stopping a section."

  -----------------------------------------------------------------------------------------------
   MISRA-C:1998 VIOLATION - RULE 87   (req)
   MISRA-C:2004 VIOLATION - RULE 19.1 (adv)
   #include statements in a file should only be preceded by other preprocessor directives or comments.
   Justification:
      Implemented according to NS Software Re-use strategy in SDES-F-B-002.
      "The inclusion of SSFTSTD_MemoryMap.h within the code is a MISRA violation. 
      As neither executable code nor symbols are included (only pragmas),
      this violation is an approved exception without side effects."

  -----------------------------------------------------------------------------------------------
  [Section Type]
	RAM0SEC			: RAM0 section [see SDES-F-B-002]
	RAM1SEC			: RAM1 section [see SDES-F-B-002]
	RAM2SEC			: RAM2 section [see SDES-F-B-002]
	RAM3SEC			: RAM3 section [see SDES-F-B-002]
	RAM4SEC			: RAM4 section [see SDES-F-B-002]
	RAM0_CLOCKSEC	: RAM0 section for clock task.
	RAM0_FASTUPDSEC	: Information in RAM0 section updated every 10 msec.
	RAM0_INTERVALSEC: Information in RAM0 section updated in sleep mode.
	RAM1_INTERVALSEC: Information in RAM1 section updated in sleep mode.
	RAMBACKSEC		: BackUp RAM section
  -----------------------------------------------------------------------------------------------
  [How to Use]
	�J���v���W�F�N�g�ɂč̗p���ꂽ�}�C�R���ɓK��������ׂɈȉ��̃I�v�V��������K���ȃp�����[�^��
	�I�����A��������̃p�����[�^�Ƃ��Ē�`���邱�ƁB

    Select parameter in following options to adapt the micro which is adopted in your project.
	And then, define the parameter on your IDE ( Integrated Development Environment. )

#define __H8SX__                  Renesas H8 series          
#define __V8DJ4__                 Renesas V850 series        
#define __F2FR__                  Fujitsu FR series          
#define __RL78_CCRL__             Renesas RL78 series (CC-RL Compiler)

  -----------------------------------------------------------------------------------------------
*/


/* for error handling */
#define MEMMAP_ERROR

/***********************
 * SECTION DEFINITIONS *
 ***********************/
/* Sections definition in RAM */

#ifdef START_SEC_RAM0SEC
  #undef START_SEC_RAM0SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAM0SEC
#elif defined __F2FR__
  #pragma segment DATA=RAM0SEC
#elif defined __V8DJ3__
  #pragma section sdata "RAM0SEC" begin
#elif defined __V8DJ4__
  #pragma section sdata "RAM0SEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAM0SEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAM0SEC
  #undef STOP_SEC_RAM0SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAM0SEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif


#elif defined START_SEC_RAM1SEC
  #undef START_SEC_RAM1SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAM1SEC
#elif defined __F2FR__
  #pragma segment DATA=RAM1SEC
#elif defined __V8DJ3__
  #pragma section sdata "RAM1SEC" begin
#elif defined __V8DJ4__
  #pragma section sdata "RAM1SEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAM1SEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAM1SEC
  #undef STOP_SEC_RAM1SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAM1SEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif


#elif defined START_SEC_RAM2SEC
  #undef START_SEC_RAM2SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAM2SEC
#elif defined __F2FR__
  #pragma segment DATA=RAM2SEC
#elif defined __V8DJ3__
  #pragma section sdata "RAM2SEC" begin
#elif defined __V8DJ4__
  #pragma section data "RAM2SEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAM2SEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAM2SEC
  #undef STOP_SEC_RAM2SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAM2SEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif


#elif defined START_SEC_RAM3SEC
  #undef START_SEC_RAM3SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAM3SEC
#elif defined __F2FR__
  #pragma segment DATA=RAM3SEC
#elif defined __V8DJ3__
  #pragma section sdata "RAM3SEC" begin
#elif defined __V8DJ4__
  #pragma section sdata "RAM3SEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAM3SEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAM3SEC
  #undef STOP_SEC_RAM3SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAM3SEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif


#elif defined START_SEC_RAM4SEC
  #undef START_SEC_RAM4SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAM4SEC
#elif defined __F2FR__
  #pragma segment DATA=RAM4SEC
#elif defined __V8DJ3__
  #pragma section sdata "RAM4SEC" begin
#elif defined __V8DJ4__
  #pragma section sdata "RAM4SEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAM4SEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAM4SEC
  #undef STOP_SEC_RAM4SEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAM4SEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif


#elif defined START_SEC_RAM0_CLOCKSEC
  #undef START_SEC_RAM0_CLOCKSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAM0_CLOCKSEC
#elif defined __F2FR__
  #pragma segment DATA=RAM0_CLOCKSEC
#elif defined __V8DJ3__
  #pragma section sdata "RAM0_CLOCKSEC" begin
#elif defined __V8DJ4__
  #pragma section sdata "RAM0_CLOCKSEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAM0_CLOCKSEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAM0_CLOCKSEC
  #undef STOP_SEC_RAM0_CLOCKSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAM0_CLOCKSEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif


#elif defined START_SEC_RAM0_FASTUPDSEC
  #undef START_SEC_RAM0_FASTUPDSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAM0_FASTUPDSEC
#elif defined __F2FR__
  #pragma segment DATA=RAM0_FASTUPDSEC
#elif defined __V8DJ3__
  #pragma section sdata "RAM0_FASTUPDSEC" begin
#elif defined __V8DJ4__
  #pragma section sdata "RAM0_FASTUPDSEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAM0_FASTUPDSEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAM0_FASTUPDSEC
  #undef STOP_SEC_RAM0_FASTUPDSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAM0_FASTUPDSEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif


#elif defined START_SEC_RAM0_INTERVALSEC
  #undef START_SEC_RAM0_INTERVALSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAM0_INTERVALSEC
#elif defined __F2FR__
  #pragma segment DATA=RAM0_INTERVALSEC
#elif defined __V8DJ3__
  #pragma section sdata "RAM0_INTERVALSEC" begin
#elif defined __V8DJ4__
  #pragma section sdata "RAM0_INTERVALSEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAM0_INTERVALSEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAM0_INTERVALSEC
  #undef STOP_SEC_RAM0_INTERVALSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAM0_INTERVALSEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif


#elif defined START_SEC_RAM1_INTERVALSEC
  #undef START_SEC_RAM1_INTERVALSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAM1_INTERVALSEC
#elif defined __F2FR__
  #pragma segment DATA=RAM1_INTERVALSEC
#elif defined __V8DJ3__
  #pragma section sdata "RAM1_INTERVALSEC" begin
#elif defined __V8DJ4__
  #pragma section sdata "RAM1_INTERVALSEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAM1_INTERVALSEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAM1_INTERVALSEC
  #undef STOP_SEC_RAM1_INTERVALSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAM1_INTERVALSEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif


#elif defined START_SEC_RAMBACKSEC
  #undef START_SEC_RAMBACKSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section RAMBACKSEC
#elif defined __F2FR__
  #pragma segment DATA=RAMBACKSEC
#elif defined __V8DJ3__
  #pragma section sdata "RAMBACKSEC" begin
#elif defined __V8DJ4__
  #pragma section data "RAMBACKSEC"
#elif defined(__RL78_CCRL__)
  #pragma section bss RAMBACKSEC
#else
  /* DO NOT place any command. */
#endif

#elif defined STOP_SEC_RAMBACKSEC
  #undef STOP_SEC_RAMBACKSEC
  #undef MEMMAP_ERROR
#ifdef __H8SX__
  #pragma section
#elif defined __F2FR__
  #pragma segment DATA
#elif defined __V8DJ3__
  #pragma section sdata "RAMBACKSEC" end
#elif defined __V8DJ4__
  #pragma section default
#elif defined(__RL78_CCRL__)
  #pragma section
#else
  /* DO NOT place any command. */
#endif

#endif


/* output error command to lead to the comiling error */
#ifdef MEMMAP_ERROR
  #error "SSFTSTD_MemoryMap.h, wrong pragma command"
#endif


