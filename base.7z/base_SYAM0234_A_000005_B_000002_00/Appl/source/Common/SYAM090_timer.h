
#ifndef	TIMER_H_
#define	TIMER_H_	"0.01"


//##################################//
//	�@ Configuration				//
//----------------------------------//
//	�^�C�}�����ݎ���				//
//	���C����������					//
//##################################//
#define	TM_INTERRUPT	500			// 500��sec
#define	TM_MAIN			10				// 10msec
#define	TM_SCEDULE		(TM_MAIN * 4)	// main 4����


//--------------------------------------------------
#define	TM_INT_1MS		(     1000UL / TM_INTERRUPT)	// ��
#define	TM_INT_2MS		(     2000UL / TM_INTERRUPT)
#define	TM_INT_3MS		(     3000UL / TM_INTERRUPT)	// ��
#define	TM_INT_4MS		(     4000UL / TM_INTERRUPT)
#define	TM_INT_5MS		(     5000UL / TM_INTERRUPT)	// ��
#define	TM_INT_6MS		(     6000UL / TM_INTERRUPT)
#define	TM_INT_7MS		(     7000UL / TM_INTERRUPT)	// ��
#define	TM_INT_8MS		(     8000UL / TM_INTERRUPT)
#define	TM_INT_9MS		(     9000UL / TM_INTERRUPT)	// ��
//----------------------
#define	TM_INT_10MS		(    10000UL / TM_INTERRUPT)
#define	TM_INT_20MS		(    20000UL / TM_INTERRUPT)
#define	TM_INT_30MS		(    30000UL / TM_INTERRUPT)
#define	TM_INT_40MS		(    40000UL / TM_INTERRUPT)
#define	TM_INT_50MS		(    50000UL / TM_INTERRUPT)
#define	TM_INT_60MS		(    60000UL / TM_INTERRUPT)
#define	TM_INT_70MS		(    70000UL / TM_INTERRUPT)
#define	TM_INT_80MS		(    80000UL / TM_INTERRUPT)
#define	TM_INT_90MS		(    90000UL / TM_INTERRUPT)
//----------------------
#define	TM_INT_100MS	(   100000UL / TM_INTERRUPT)
#define	TM_INT_200MS	(   200000UL / TM_INTERRUPT)
#define	TM_INT_300MS	(   300000UL / TM_INTERRUPT)
#define	TM_INT_400MS	(   400000UL / TM_INTERRUPT)
#define	TM_INT_500MS	(   500000UL / TM_INTERRUPT)
#define	TM_INT_600MS	(   600000UL / TM_INTERRUPT)
#define	TM_INT_700MS	(   700000UL / TM_INTERRUPT)
#define	TM_INT_800MS	(   800000UL / TM_INTERRUPT)
#define	TM_INT_900MS	(   900000UL / TM_INTERRUPT)
//----------------------
#define	TM_INT_1S		(  1000000UL / TM_INTERRUPT)
#define	TM_INT_2S		(  2000000UL / TM_INTERRUPT)
#define	TM_INT_3S		(  3000000UL / TM_INTERRUPT)
#define	TM_INT_4S		(  4000000UL / TM_INTERRUPT)
#define	TM_INT_5S		(  5000000UL / TM_INTERRUPT)
#define	TM_INT_6S		(  6000000UL / TM_INTERRUPT)
#define	TM_INT_7S		(  7000000UL / TM_INTERRUPT)
#define	TM_INT_8S		(  8000000UL / TM_INTERRUPT)
#define	TM_INT_9S		(  9000000UL / TM_INTERRUPT)
//----------------------
#define	TM_INT_10S		( 10000000UL / TM_INTERRUPT)
#define	TM_INT_20S		( 20000000UL / TM_INTERRUPT)
#define	TM_INT_30S		( 30000000UL / TM_INTERRUPT)
#define	TM_INT_40S		( 40000000UL / TM_INTERRUPT)
#define	TM_INT_50S		( 50000000UL / TM_INTERRUPT)
#define	TM_INT_60S		( 60000000UL / TM_INTERRUPT)
#define	TM_INT_70S		( 70000000UL / TM_INTERRUPT)
#define	TM_INT_80S		( 80000000UL / TM_INTERRUPT)
#define	TM_INT_90S		( 90000000UL / TM_INTERRUPT)
//----------------------
#define	TM_INT_100S		(100000000UL / TM_INTERRUPT)
#define	TM_INT_200S		(200000000UL / TM_INTERRUPT)
#define	TM_INT_300S		(300000000UL / TM_INTERRUPT)
#define	TM_INT_400S		(400000000UL / TM_INTERRUPT)
#define	TM_INT_500S		(500000000UL / TM_INTERRUPT)
#define	TM_INT_600S		(600000000UL / TM_INTERRUPT)
#define	TM_INT_700S		(700000000UL / TM_INTERRUPT)
#define	TM_INT_800S		(800000000UL / TM_INTERRUPT)
#define	TM_INT_900S		(900000000UL / TM_INTERRUPT)


//-----------------------------------------------------
#define	TM_MAIN_5MS		(      5UL / TM_MAIN)
#define	TM_MAIN_10MS	(     10UL / TM_MAIN)
#define	TM_MAIN_20MS	(     20UL / TM_MAIN)
#define	TM_MAIN_30MS	(     30UL / TM_MAIN)
#define	TM_MAIN_40MS	(     40UL / TM_MAIN)
#define	TM_MAIN_50MS	(     50UL / TM_MAIN)
#define	TM_MAIN_60MS	(     60UL / TM_MAIN)
#define	TM_MAIN_70MS	(     70UL / TM_MAIN)
#define	TM_MAIN_80MS	(     80UL / TM_MAIN)
#define	TM_MAIN_90MS	(     90UL / TM_MAIN)
//----------------------
#define	TM_MAIN_100MS	(    100UL / TM_MAIN)
#define	TM_MAIN_200MS	(    200UL / TM_MAIN)
#define	TM_MAIN_300MS	(    300UL / TM_MAIN)
#define	TM_MAIN_400MS	(    400UL / TM_MAIN)
#define	TM_MAIN_500MS	(    500UL / TM_MAIN)
#define	TM_MAIN_600MS	(    600UL / TM_MAIN)
#define	TM_MAIN_700MS	(    700UL / TM_MAIN)
#define	TM_MAIN_800MS	(    800UL / TM_MAIN)
#define	TM_MAIN_900MS	(    900UL / TM_MAIN)
//----------------------
#define	TM_MAIN_1S		(   1000UL / TM_MAIN)
#define	TM_MAIN_2S		(   2000UL / TM_MAIN)
#define	TM_MAIN_3S		(   3000UL / TM_MAIN)
#define	TM_MAIN_4S		(   4000UL / TM_MAIN)
#define	TM_MAIN_5S		(   5000UL / TM_MAIN)
#define	TM_MAIN_6S		(   6000UL / TM_MAIN)
#define	TM_MAIN_7S		(   7000UL / TM_MAIN)
#define	TM_MAIN_8S		(   8000UL / TM_MAIN)
#define	TM_MAIN_9S		(   9000UL / TM_MAIN)
//----------------------
#define	TM_MAIN_10S		(  10000UL / TM_MAIN)
#define	TM_MAIN_20S		(  20000UL / TM_MAIN)
#define	TM_MAIN_30S		(  30000UL / TM_MAIN)
#define	TM_MAIN_40S		(  40000UL / TM_MAIN)
#define	TM_MAIN_50S		(  50000UL / TM_MAIN)
#define	TM_MAIN_60S		(  60000UL / TM_MAIN)
#define	TM_MAIN_70S		(  70000UL / TM_MAIN)
#define	TM_MAIN_80S		(  80000UL / TM_MAIN)
#define	TM_MAIN_90S		(  90000UL / TM_MAIN)
//----------------------
#define	TM_MAIN_100S	( 100000UL / TM_MAIN)
#define	TM_MAIN_200S	( 200000UL / TM_MAIN)
#define	TM_MAIN_300S	( 300000UL / TM_MAIN)
#define	TM_MAIN_400S	( 400000UL / TM_MAIN)
#define	TM_MAIN_500S	( 500000UL / TM_MAIN)
#define	TM_MAIN_600S	( 600000UL / TM_MAIN)
#define	TM_MAIN_700S	( 700000UL / TM_MAIN)
#define	TM_MAIN_800S	( 800000UL / TM_MAIN)
#define	TM_MAIN_900S	( 900000UL / TM_MAIN)
//----------------------
#define	TM_MAIN_1000S	(1000000UL / TM_MAIN)
#define	TM_MAIN_2000S	(2000000UL / TM_MAIN)
#define	TM_MAIN_3000S	(3000000UL / TM_MAIN)
#define	TM_MAIN_4000S	(4000000UL / TM_MAIN)
#define	TM_MAIN_5000S	(5000000UL / TM_MAIN)
#define	TM_MAIN_6000S	(6000000UL / TM_MAIN)
#define	TM_MAIN_7000S	(7000000UL / TM_MAIN)
#define	TM_MAIN_8000S	(8000000UL / TM_MAIN)
#define	TM_MAIN_9000S	(9000000UL / TM_MAIN)










#endif	  // TIMER_H_
