/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFT                                                                      */
/*----------------------------------------------------------------------------------------------*/
/* CPU              : RL78/D1A Series                                                           */
/* Date             : 2017/04/21                                                                */
/*----------------------------------------------------------------------------------------------*/
/* Programmed by    : NSCS                                                                      */
/* Copyrights       : Nippon Seiki Co.,Ltd                                                      */
/*----------------------------------------------------------------------------------------------*/
/* Update by        : NSCS                                                                      */
/* Date             : 2017/5/17                                                                 */
/* Note             : Bug Fixes                                                                 */
/*                    Modify value of Macro below.                                              */
/*                    �ECANDRV_MCTRL_MOW : 0x0100U �� 0x0010U                                   */
/*----------------------------------------------------------------------------------------------*/
/* Update by        : NSCS                                                                      */
/* Date             : 2017/5/22                                                                 */
/* Note             : Bug Fixes                                                                 */
/*                    Delete the clearing of GOM when recovery from bus off.                    */
/*                    Modify the OPMODE to only set the INITMODE.                               */
/*                    �Ecan_handle_status_interrupt()                                           */
/*                    Changed to clear GOM to startup sequence implementation by                */
/*                    "abolish GOM clearing at recovery from bus off"                           */
/*                    �Ecan_init_controller()                                                   */
/*                    Modify value of Macro below.                                              */
/*                    �ECANDRV_SET_CTRL_INIT : 0x8100U �� 0x0100U                               */
/*----------------------------------------------------------------------------------------------*/
/* Update by        : NSCS                                                                      */
/* Date             : 2017/5/26                                                                 */
/* Note             : Bug Fixes                                                                 */
/*                    Modify method to get recive error counter.                                */
/*                    �ECanDrv_GetRxErrCnt()                                                    */
/*                    Modify to don't clear the GOM when startup sequence.                      */
/*                    �Ecan_init_controller()                                                   */
/*                    Modify to don't set the RDY bit to 1 when an unused message buffer.       */
/*                    �Ecan_set_msg_obj_cfg()                                                   */
/*                    Modify to clear the RDY bit when check the RAM.                           */
/*                    �Ecan_check_msg_obj_ram()                                                 */
/*----------------------------------------------------------------------------------------------*/
/* Update by        : NSCS                                                                      */
/* Date             : 2017/6/19                                                                 */
/* Note             : Bug Fixes                                                                 */
/*                    Modify to clear the DN/MOW bit after read a message.                      */
/*                    Modify to don't call back a receiving message when the MOW bit equal 1.   */
/*                    �Ecan_handle_reception_interrupt()                                        */
/*----------------------------------------------------------------------------------------------*/
/* Update by        : NSCS                                                                      */
/* Date             : 2017/8/7                                                                  */
/* Note             : Bug Fixes                                                                 */
/*                    Delete redundant cast processing.                                         */
/*                    �ECanDrv_IntrHandler()                                                    */
/*                    Delete unnecessary arg.                                                   */
/*                    �Ecan_check_msg_handler_register()                                        */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2019/06/10                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/*----------------------------------------------------------------------------------------------*/
/* Update by        : $Author: Sato Yusuke (A01A091212) $                                                            */
/* Date             : $Date: 2020/03/02 10:15:06ICT $                                                              */
/* Version          : $Revision: 1.1 $                                                          */
/************************************************************************************************/



/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#define SSFTSTD_RL78CAN_DRV_000_INTERNAL
#include "SSFTSTD_RL78Can_Drv_000.h"


#define RL78_CAN_DRV_C (0x2101U)
#if (!((RL78_CAN_DRV_C == RL78_CAN_DRV_H) && (RL78_CAN_DRV_C == RL78_CAN_DRV_CFG_H)))
	#error "Driver version is different.(xxx.c, xxx.h, config.h)"
#endif


/************************************************************************************************/
/* Local Macros                                                                                 */
/************************************************************************************************/
#define CANDRV_OK     ((UI_8)0x00U)
#define CANDRV_NOT_OK ((UI_8)0x01U)

/* Definitions for can hardware access */
/* clear all bits in the registers */
#define CANDRV_CLR_ALL ((UI_16)0x0000U) /* 00000000 00000000 */

/* Definitions to set a bit in the CAN Control Register */
#define CANDRV_SET_GMCTRL_GOM	((UI_16)(0x0100U))
#define CANDRV_GMCTRL_GOM		((UI_16)(0x0001U))
#define CANDRV_GMCTRL_EFSD		((UI_16)(0x0002U))
#define CANDRV_CLR_GMCTRL_GOM	((UI_16)(0x0001U))
#define CANDRV_SET_IE_INIT		((UI_16)(0x0700U))
#define CANDRV_SET_CTRL_INIT	((UI_16)(0x0100U))
#define CANDRV_CTRL_OPMODE		((UI_16)(0x0007U))
#define CANDRV_CTRL_OPMODE_NORM	((UI_16)(0x0001U))
#define CANDRV_CLR_CTRL_OPMODE	((UI_16)(0x0007U))
#define CANDRV_SET_MCTRL_INIT	((UI_16)(0x0816U))
#define CANDRV_SET_MCTRL_RDY	((UI_16)(0x0100U))
#define CANDRV_SET_MCTRL_TRQ	((UI_16)(0x0200U))
#define CANDRV_CLR_MCTRL_RDY	((UI_16)(0x0001U))
#define CANDRV_CLR_MCTRL_TRQ	((UI_16)(0x0002U))
#define CANDRV_CLR_MCTRL_DN		((UI_16)(0x0004U))
#define CANDRV_CLR_MCTRL_DN_MOW	((UI_16)(0x0014U))
#define CANDRV_MCTRL_RDY		((UI_16)(0x0001U))
#define CANDRV_MCTRL_TRQ		((UI_16)(0x0002U))
#define CANDRV_MCTRL_MOW		((UI_16)(0x0010U))
#define CANDRV_SET_MDLC_INIT	((UI_8)(0x00U))
#define CANDRV_SET_MCONF_RTR	((UI_8)(0x40U))
#define CANDRV_SET_MCONF_MA0	((UI_8)(0x01U))
#define CANDRV_CLR_MCONF_MA0	((UI_8)(0x00U))
#define CANDRV_SET_MIDH_IDE		((UI_16)(0x8000U))
#define CANDRV_INFO_BOFF		((UI_8)(0x10U))
#define CANDRV_INFO_TX_ERR_PASSIVE	((UI_8)(0x0CU))
#define CANDRV_INFO_RX_ERR_PASSIVE	((UI_8)(0x03U))
#define CANDRV_INFO_TX_ERR_WARN	((UI_8)(0x04U))
#define CANDRV_INFO_RX_ERR_WARN	((UI_8)(0x01U))
#define CANDRV_CLR_INTS_CAN_WAKEUP	((UI_16)(0x0020U))
#define CANDRV_CLR_INTS_ARB_LOSS	((UI_16)(0x0010U))
#define CANDRV_CLR_INTS_PROTOCOL	((UI_16)(0x0008U))
#define CANDRV_CLR_INTS_ERR_STATUS	((UI_16)(0x0004U))
#define CANDRV_CLR_INTS_RECV		((UI_16)(0x0002U))
#define CANDRV_CLR_INTS_TRANS		((UI_16)(0x0001U))
#define CANDRV_CLR_ILLEGAL_INTS		((UI_16)(0x0038U))
#define CANDRV_RGPT_ROVF		((UI_16)(0x0001U))
#define CANDRV_RGPT_RHPM		((UI_16)(0x0002U))
#define CANDRV_TGPT_TOVF		((UI_16)(0x0001U))
#define CANDRV_TGPT_THPM		((UI_16)(0x0002U))
#define CANDRV_ERC_REPS			((UI_16)(0x8000U))
#define CANDRV_ERC_REC			((UI_16)(0x7F00U))

#define CANDRV_RECV_GUARDTIMER	((UI_8)(23U))
#define CANDRV_TRANS_GUARDTIMER	((UI_8)(6U))

/* Definitions to check a bit in the CnINTS Register */
#define CANDRV_INTS_NO_INTERRUPT ((UI_16)0x0000U)
#define CANDRV_INTS_STATUS_INTERRUPT ((UI_16)0x004U)
#define CANDRV_INTS_RECV_INTERRUPT ((UI_16)0x002U)
#define CANDRV_INTS_TRANS_INTERRUPT ((UI_16)0x001U)

/* Definitions for the register and the Message Object RAM check */
#define CANDRV_TEST_PATTERN_CNT ((UI_8)3U)
#define CANDRV_MASK_MCONF_FOR_TEST ((UI_8)0xF9U) /* 11111001 */
#define CANDRV_MASK_MIDH_FOR_TEST ((UI_16)0x9FFFU) /* 10011111 11111111 */

/************************************************************************************************/
/* Local Data Types                                                                             */
/************************************************************************************************/
typedef struct
{
	UI_16 Val;
	UI_8 DlcVal;
} T_CanDrv_TestPattern;

/************************************************************************************************/
/* Local Data                                                                                   */
/************************************************************************************************/

/************************************************************************************************/
/* Local Constants                                                                              */
/************************************************************************************************/
/* The value 0xA cannot be used as the test pattern because setting more than 8 to DLC is not allowed. */
static const T_CanDrv_TestPattern C_CanDrv_TestPattern[CANDRV_TEST_PATTERN_CNT] =
{
	/* Val, DlcVal */
	{0xAAAAU, 0x08U},
	{0x5555U, 0x05U},
	{0x0000U, 0x00U}
};

static const T_CanDrv_MsgObjCfg C_CanDrv_UnusedMsgObjCfg = 
{
	/* MCONF, MIDH, MIDL */
	(UI_8)(CANDRV_CLR_MCONF_MA0), 
	CANDRV_CLR_ALL,
	CANDRV_CLR_ALL
};

static const T_CanDrv_MsgObjCfg C_CanDrv_TxMsgObjCfg = 
{
	/* MCONF, MIDH, MIDL */
	(UI_8)(CANDRV_SET_MCONF_MA0), 
	CANDRV_CLR_ALL,
	CANDRV_CLR_ALL
};


/************************************************************************************************/
/* Local Function Declarations                                                                  */
/************************************************************************************************/
static const T_CanDrv_AddrMap * can_get_controller_ptr(UI_8 controller);

static void can_init_controller(UI_8 controller, UI_8 verification);
static UI_8 can_check_msg_obj_ram(const T_CanDrv_AddrMap *can_ptr, UI_16 message_number);
static UI_8 can_check_msg_handler_register(volatile const UI_16 *reg_ptr);
static void can_stop_controller(UI_8 controller);
static void can_stop_all_controller(void);

static UI_8 can_init_message_obj(const T_CanDrv_ControllerCfg *cfg_ptr, const T_CanDrv_AddrMap *can_ptr, UI_8 verification);
static void can_set_msg_obj_cfg(const T_CanDrv_AddrMap *can_ptr, UI_16 message_number, const T_CanDrv_MsgObjCfg *msg_obj_cfg_ptr);

static void can_handle_status_interrupt(UI_8 controller, const T_CanDrv_AddrMap *can_ptr);
static void can_handle_reception_interrupt(UI_8 controller, const T_CanDrv_AddrMap *can_ptr);
static void can_handle_transmission_interrupt(UI_8 controller, const T_CanDrv_AddrMap *can_ptr);
static void can_handle_illegal_interrupt(const T_CanDrv_AddrMap *can_ptr);


/************************************************************************************************/
/* Local Functions                                                                              */
/************************************************************************************************/
/************************************************************************************************/
/* Function name    : can_get_controller_ptr                                                    */
/* Description      :                                                                           */
/* Argument         : <controller> - CAN controller identification number                       */
/* Return value     : Pointer to CAN basis address                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static const T_CanDrv_AddrMap * can_get_controller_ptr(UI_8 controller)
{
	return C_CanDrv_ControllerCfg[controller]->CanBasisAddr;
}

/************************************************************************************************/
/* Function name    : can_init_controller                                                       */
/*                                                                                              */
/* Description      : This function controls the CAN controller startup sequence.               */
/*                                                                                              */
/*                    First of all, the CAN Controller will enter the initialization mode       */
/*                    by clearing the OPMODE bit in the CnCTRL register.                        */
/*                                                                                              */
/*                    Then, the Status register will be read to clear the interrupt factor      */
/*                    just in case. After that, the register will be initialized.               */
/*                                                                                              */
/*                    The bit timing register (CnBTR) and the baud rate prescaler               */
/*                    register (CnBRP) will be set with the pre configured values.              */
/*                                                                                              */
/*                    After that, all of the message object will be initialized                 */
/*                    according to the preconfigured settings.                                  */
/*                    If the verification request is set, the message object RAM check will be  */
/*                    executed in this initialization process.                                  */
/*                    If a problem is detected in the message objects, a callback function      */
/*                    will be called via the macro named CANDRV_CALLBACK_MSG_RAM_CHK_FAILED.    */
/*                                                                                              */
/*                    When all of the message object is initialized correctly,                  */
/*                    the Operation Mode  (OPMODE) will be set.                                 */
/*                                                                                              */
/*                    After that, the CAN Interrupt (CINTS) will be enabled.                    */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/*                    <verification> - message object RAM verification request                  */
/*                     D_FALSE : The verification is not required.                              */
/*                     D_TRUE : The verification is required.                                   */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : NSCS                                                                      */
/* Date             : 2017/05/22                                                                */
/* Note             : Bug Fixes                                                                 */
/*                    Changed to clear GOM to startup sequence implementation by                */
/*                    "abolish GOM clearing at recovery from bus off"                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : NSCS                                                                      */
/* Date             : 2017/5/26                                                                 */
/* Note             : Bug Fixes                                                                 */
/*                    Modify to don't clear the GOM when startup sequence.                      */
/************************************************************************************************/
static void can_init_controller(UI_8 controller, UI_8 verification)
{
	const T_CanDrv_AddrMap *can_ptr;
	const T_CanDrv_ControllerCfg *cfg_ptr;
	UI_8 check_result;

	/* Get access to the CAN controller configurations */
	cfg_ptr = C_CanDrv_ControllerCfg[controller];
	/* Get access to the CAN Controller */
	can_ptr = can_get_controller_ptr(controller);

	/* Set CnGMCS register */
	*can_ptr->CxGMCS = cfg_ptr->ClockSelect;

	/* Set CnGMCTRL register (Set GOM = 1) */
	*can_ptr->CxGMCTRL = CANDRV_SET_GMCTRL_GOM;

	/* Set CnBRP register */
	*can_ptr->CxBRP = cfg_ptr->BaudRate;
	/* Set CnBTR register */
	*can_ptr->CxBTR = cfg_ptr->BitTiming;
	
	/* Set CnIE register */
	*can_ptr->CxIE = CANDRV_SET_IE_INIT;

	/* Set CnMASK register */
	*can_ptr->CxMASK1L = cfg_ptr->Mask1L;
	*can_ptr->CxMASK1H = cfg_ptr->Mask1H;
	*can_ptr->CxMASK2L = cfg_ptr->Mask2L;
	*can_ptr->CxMASK2H = cfg_ptr->Mask2H;
	*can_ptr->CxMASK3L = cfg_ptr->Mask3L;
	*can_ptr->CxMASK3H = cfg_ptr->Mask3H;
	*can_ptr->CxMASK4L = cfg_ptr->Mask4L;
	*can_ptr->CxMASK4H = cfg_ptr->Mask4H;

	/* Initialize message buffers */
	check_result = can_init_message_obj(cfg_ptr, can_ptr, verification);
	if (check_result != CANDRV_OK) {
		/* Some message objects are corrupted. */
		/* Since the corrupted message objects have been disabled in the sub functions, */
		/* an additional disabling process is not required here. */

		/* Notify the upper layer of message RAM check failed. */
		CANDRV_CALLBACK_MSG_RAM_CHK_FAILED(controller);
	} else {
		/* All of the message objects have been initialized correctly. */

		/* Set CnCTRL register (set OPMODE) */
		*can_ptr->CxCTRL = CANDRV_SET_CTRL_INIT;
	}
}

/************************************************************************************************/
/* Function name    : can_check_msg_obj_ram                                                     */
/*                                                                                              */
/* Description      : This function verifies whether the message object RAM is corrupted        */
/*                    and returns the result.                                                   */
/*                                                                                              */
/*                    The message object RAM which is related to the following information      */
/*                    will be verified.                                                         */
/*                    - CAN identifier                                                          */
/*                    - CAN data itself                                                         */
/*                    - CAN data length                                                         */
/*                    - CAN config                                                              */
/*                                                                                              */
/*                    At first, the test pattern value will be written to                       */
/*                    the message object RAM.                                                   */
/*                    After that, the message object RAM will be read again.                    */
/*                    If the read value is not identical to the test pattern value,             */
/*                    the function will return CANDRV_NOT_OK.                                   */
/*                                                                                              */
/* Argument         : <can_ptr> - Pointer to the CAN control register.                          */
/*                                                                                              */
/*                    <message_number> - An identification number of the message object.        */
/*                                                                                              */
/* Return value     : CANDRV_OK : a message object RAM was not corrupted.                       */
/*                    CANDRV_NOT_OK : a message object RAM was corrupted.                       */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : NSCS                                                                      */
/* Date             : 2017/5/26                                                                 */
/* Note             : Bug Fixes                                                                 */
/*                    Modify to clear the RDY bit when check the RAM.                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2019/06/07                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/************************************************************************************************/
static UI_8 can_check_msg_obj_ram(const T_CanDrv_AddrMap *can_ptr, UI_16 message_number)
{
	UI_8 check_result;
	UI_8 test_pattern_index;
	UI_8 mconf;
	UI_16 midh;
	
	check_result = CANDRV_OK;
	for (test_pattern_index = 0U; test_pattern_index < CANDRV_TEST_PATTERN_CNT; test_pattern_index++) {

		mconf = (UI_8)(C_CanDrv_TestPattern[test_pattern_index].Val) & CANDRV_MASK_MCONF_FOR_TEST;
		midh = C_CanDrv_TestPattern[test_pattern_index].Val & CANDRV_MASK_MIDH_FOR_TEST;

		/* Clear RDY bit */
		can_ptr->MsgBuf[message_number-1U]->CxMCTRL = CANDRV_CLR_MCTRL_RDY;

		/* Write Test Pattern into the CAN Register */
		/* Set CnMCONFm, CnMIDLm, CnMIDHm, CnMDB0m-CnMDB7m, CnMDLCm */
		can_ptr->MsgBuf[message_number-1U]->CxMCONF = mconf;
		can_ptr->MsgBuf[message_number-1U]->CxMIDL = C_CanDrv_TestPattern[test_pattern_index].Val;
		can_ptr->MsgBuf[message_number-1U]->CxMIDH = midh;
		can_ptr->MsgBuf[message_number-1U]->CxMDB[0] = (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val;
		can_ptr->MsgBuf[message_number-1U]->CxMDB[1] = (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val;
		can_ptr->MsgBuf[message_number-1U]->CxMDB[2] = (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val;
		can_ptr->MsgBuf[message_number-1U]->CxMDB[3] = (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val;
		can_ptr->MsgBuf[message_number-1U]->CxMDB[4] = (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val;
		can_ptr->MsgBuf[message_number-1U]->CxMDB[5] = (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val;
		can_ptr->MsgBuf[message_number-1U]->CxMDB[6] = (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val;
		can_ptr->MsgBuf[message_number-1U]->CxMDB[7] = (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val;
		can_ptr->MsgBuf[message_number-1U]->CxMDLC = C_CanDrv_TestPattern[test_pattern_index].DlcVal;

		if ((can_ptr->MsgBuf[message_number-1U]->CxMCONF != mconf)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMIDL != C_CanDrv_TestPattern[test_pattern_index].Val)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMIDH != midh)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMDB[0] != (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMDB[1] != (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMDB[2] != (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMDB[3] != (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMDB[4] != (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMDB[5] != (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMDB[6] != (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMDB[7] != (UI_8)C_CanDrv_TestPattern[test_pattern_index].Val)
		|| (can_ptr->MsgBuf[message_number-1U]->CxMDLC != C_CanDrv_TestPattern[test_pattern_index].DlcVal)) {
			/* Stop validating the registers and set the error indication. */
			check_result = CANDRV_NOT_OK;
		}
	}
	return check_result;
}

/************************************************************************************************/
/* Function name    : can_check_msg_handler_register                                            */
/*                                                                                              */
/* Description      : This function returns whether a bit in the message handler registers      */
/*                    is set. The function can check the following registers.                   */
/*                     TRQ                                                                      */
/*                                                                                              */
/* Argument         : <reg_ptr> - Pointer to a CAN message handler register                     */
/*                     This pointer shall be the start address of the following registers.      */
/*                     TRQ                                                                      */
/*                                                                                              */
/* Return value     : D_FALSE : a corresponding bit is not set                                  */
/*                    D_TRUE : a corresponding bit is set                                       */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static UI_8 can_check_msg_handler_register(volatile const UI_16 *reg_ptr)
{
	UI_8 ret_val;
	UI_16 flags;

	/* Initialize the return value. A corresponding bit is not set */
	ret_val = D_FALSE;

	flags = *reg_ptr;
	if ((flags & CANDRV_MCTRL_TRQ) != 0U) {
		/* The bit is set */
		ret_val = D_TRUE;
	}

	return ret_val;
}

/************************************************************************************************/
/* Function name    : can_stop_controller                                                       */
/*                                                                                              */
/* Description      : This function disables the CAN controller.                                */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void can_stop_controller(UI_8 controller)
{
	const T_CanDrv_AddrMap *can_ptr;

	/* Get access to the CAN Controller */
	can_ptr = can_get_controller_ptr(controller);

	/* INIT mode */
	*can_ptr->CxCTRL = CANDRV_CLR_CTRL_OPMODE;

	/* Clear GOM bit */
	*can_ptr->CxGMCTRL = CANDRV_CLR_GMCTRL_GOM;
}

/************************************************************************************************/
/* Function name    : can_stop_all_controller                                                   */
/*                                                                                              */
/* Description      : When this function is called, all of the CAN controller will be disabled. */
/* Argument         : void                                                                      */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
static void can_stop_all_controller(void)
{
	UI_8 controller;

	/* Stop all of the CAN Controllers */
	for (controller = 0U; controller < (UI_8)CANDRV_CONTROLLER_CNT; controller++) {
		can_stop_controller(controller);
	}
}

/************************************************************************************************/
/* Function name    : can_init_message_obj                                                      */
/*                                                                                              */
/* Description      : This function initialize all of the message object.                       */
/*                                                                                              */
/*                    If a message object is configured as a transmission object,               */
/*                    the message object will be initialized with the fixed settings.           */
/*                                                                                              */
/*                    If a message object is configured as a reception object,                  */
/*                    the message object will be initialized with the pre configured settings.  */
/*                                                                                              */
/*                    If a message object is not used, the message object will be initialized   */
/*                    with the fixed disabled settings.                                         */
/*                                                                                              */
/*                    If required, the verification of the used message object RAM              */
/*                    will be executed.                                                         */
/*                    If an error is detected during the verification,                          */
/*                    the function will disabled the corrupted message objects and              */
/*                    return CANDRV_NOT_OK.                                                     */
/*                                                                                              */
/* Argument         : <cfg_ptr> - Pointer to the CAN controller configurations                  */
/*                                                                                              */
/*                    <can_ptr> - Pointer to the CAN control register.                          */
/*                                                                                              */
/*                    <verification> - message object RAM verification request                  */
/*                     D_FALSE : The verification is not required.                              */
/*                     D_TRUE : The verification is required.                                   */
/*                                                                                              */
/* Return value     : verification result                                                       */
/*                     CANDRV_OK : There were no corrupted message object.                      */
/*                     CANDRV_NOT_OK : There were some corrupted message objects.               */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2018/11/05                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/************************************************************************************************/
static UI_8 can_init_message_obj(const T_CanDrv_ControllerCfg *cfg_ptr, const T_CanDrv_AddrMap *can_ptr, UI_8 verification)
{
	UI_16 message_number;
	UI_16 rx_msg_obj_index;
	UI_8 check_result;
	UI_8 ret_val;

	ret_val = CANDRV_OK;

	/* Initialize the all message objects. The message number starts from 1. */
	for (message_number = 1U; message_number <= cfg_ptr->MsgObjCnt; message_number++) {

		/* Check if the message object is used for Tx or Rx */
		if (((cfg_ptr->TxTopMsgNum <= message_number) && (message_number <= cfg_ptr->TxBottomMsgNum)) ||
			((cfg_ptr->RxTopMsgNum <= message_number) && (message_number <= cfg_ptr->RxBottomMsgNum))) {
			check_result = CANDRV_OK;
			/* If required, the verification of the 'USED' CAN Message Object RAM will be executed here. */
			if (verification != D_FALSE) {
				check_result = can_check_msg_obj_ram(can_ptr, message_number);
			}
			if (check_result != CANDRV_OK) {
				/* The CAN Message Object was corrupted. Disable the object and set the return value to NOT_OK. */
				ret_val = CANDRV_NOT_OK;
				can_set_msg_obj_cfg(can_ptr, message_number, &C_CanDrv_UnusedMsgObjCfg);
			} else {
				if ((cfg_ptr->TxTopMsgNum <= message_number) && (message_number <= cfg_ptr->TxBottomMsgNum)) {
					/* Initialize the message object as a transmission object. */
					can_set_msg_obj_cfg(can_ptr, message_number, &C_CanDrv_TxMsgObjCfg);
				} else {
					/* Initialize the message object as a reception object. */
					rx_msg_obj_index = message_number - cfg_ptr->RxTopMsgNum;
					can_set_msg_obj_cfg(can_ptr, message_number, &cfg_ptr->RxMsgObjCfgPtr[rx_msg_obj_index]);
				}
			}
		} else {
			/* This message object is not used. Disable the object. */
			can_set_msg_obj_cfg(can_ptr, message_number, &C_CanDrv_UnusedMsgObjCfg);
		}
	}

	return ret_val;
}


/************************************************************************************************/
/* Function name    : can_set_msg_obj_cfg                                                       */
/*                                                                                              */
/* Description      : In this function, the message object specified will be initialized        */
/*                    with the argument                                                         */
/*                                                                                              */
/* Argument         : <can_ptr> - Pointer to the CAN control register.                          */
/*                                                                                              */
/*                    <message_number> - An identification number of the message object.        */
/*                                                                                              */
/*                    <msg_obj_cfg_ptr> - Pointer to the Message Object Configurations.         */
/*                                                                                              */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : NSCS                                                                      */
/* Date             : 2017/5/26                                                                 */
/* Note             : Bug Fixes                                                                 */
/*                    Modify to don't set the RDY bit to 1 when unused message buffer.          */
/************************************************************************************************/
static void can_set_msg_obj_cfg(const T_CanDrv_AddrMap *can_ptr, UI_16 message_number, const T_CanDrv_MsgObjCfg *msg_obj_cfg_ptr)
{
	/* Clear RDY bit */
	can_ptr->MsgBuf[message_number-1U]->CxMCTRL = CANDRV_CLR_MCTRL_RDY;

	/* Set CnMCONFm register */
	can_ptr->MsgBuf[message_number-1U]->CxMCONF = msg_obj_cfg_ptr->MCONF;

	/* Set CnMIDHm register */
	can_ptr->MsgBuf[message_number-1U]->CxMIDH = msg_obj_cfg_ptr->MIDH;
	/* Set CnMIDLm register */
	can_ptr->MsgBuf[message_number-1U]->CxMIDL = msg_obj_cfg_ptr->MIDL;

	/* Set CnMDLCm register */
	can_ptr->MsgBuf[message_number-1U]->CxMDLC = CANDRV_SET_MDLC_INIT;

	/* Set CnMDBm register */
	can_ptr->MsgBuf[message_number-1U]->CxMDB[0] = 0x00U;
	can_ptr->MsgBuf[message_number-1U]->CxMDB[1] = 0x00U;
	can_ptr->MsgBuf[message_number-1U]->CxMDB[2] = 0x00U;
	can_ptr->MsgBuf[message_number-1U]->CxMDB[3] = 0x00U;
	can_ptr->MsgBuf[message_number-1U]->CxMDB[4] = 0x00U;
	can_ptr->MsgBuf[message_number-1U]->CxMDB[5] = 0x00U;
	can_ptr->MsgBuf[message_number-1U]->CxMDB[6] = 0x00U;
	can_ptr->MsgBuf[message_number-1U]->CxMDB[7] = 0x00U;

	/* Set CnMCTRLm register */
	can_ptr->MsgBuf[message_number-1U]->CxMCTRL = CANDRV_SET_MCTRL_INIT;

	if ((msg_obj_cfg_ptr->MCONF & CANDRV_SET_MCONF_MA0) == CANDRV_SET_MCONF_MA0) {
		/* Set RDY bit */
		can_ptr->MsgBuf[message_number-1U]->CxMCTRL = CANDRV_SET_MCTRL_RDY;
	}
}

/************************************************************************************************/
/* Function name    : can_handle_status_interrupt                                               */
/*                                                                                              */
/* Description      : If the CAN controller detects status error,                               */
/*                    this function will be called in the status interrupt process.             */
/*                                                                                              */
/*                    When the CAN bus-off error is confirmed, a callback function will be      */
/*                    called via the macro named CANDRV_CALLBACK_CONTROLLER_BUSOFF.             */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/*                    <can_ptr> - Pointer to the CAN control register.                          */
/*                                                                                              */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : NSCS                                                                      */
/* Date             : 2017/05/22                                                                */
/* Note             : Bug Fixes                                                                 */
/*                    Delete the clearing of GOM when recovery from bus off.                    */
/*                    Modify the OPMODE to only set the INITMODE.                               */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2019/06/06                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/************************************************************************************************/
static void can_handle_status_interrupt(UI_8 controller, const T_CanDrv_AddrMap *can_ptr)
{
	UI_16 cxinfo;
	UI_16 tx_msg_obj_index;
	UI_16 tx_msg_obj_count;

	/* Calculate the count of the message object for transmission */
	tx_msg_obj_count = (C_CanDrv_ControllerCfg[controller]->TxBottomMsgNum-C_CanDrv_ControllerCfg[controller]->TxTopMsgNum) + 1U;

	/* Read Status register to check if BOFF bit is set */
	cxinfo = *can_ptr->CxINFO;

	/* Clear CnINTS2 */
	*can_ptr->CxINTS = CANDRV_CLR_INTS_ERR_STATUS;

	if ((cxinfo & CANDRV_INFO_BOFF) == CANDRV_INFO_BOFF) {
		for (tx_msg_obj_index = 0U; tx_msg_obj_index < tx_msg_obj_count; tx_msg_obj_index++) {
			/* Clear all TRQ bits */
			CanDrv_ClrTxReq(controller, tx_msg_obj_index);
		}
		/* Set C0CTRL register (Clear OPMODE) */
		*can_ptr->CxCTRL = CANDRV_CLR_CTRL_OPMODE;
		/* Notify the upper layer that the CAN Bus-off error occurred. */
		CANDRV_CALLBACK_CONTROLLER_BUSOFF(controller);
	}
}

/************************************************************************************************/
/* Function name    : can_handle_reception_interrupt                                            */
/*                                                                                              */
/* Description      : When new CAN message is received, this function will be called            */
/*                    in the rx interrupt process.                                              */
/*                                                                                              */
/*                    The corresponding interrupt factor will be cleared in the function.       */
/*                                                                                              */
/*                    The function will read the received DATA and DLC and                      */
/*                    build the CAN identifier according to the received frame format           */
/*                    (CAN Standard or CAN Extended).                                           */
/*                                                                                              */
/*                    If the message lost is detected, a callback function will be called       */
/*                    via the macro named  CANDRV_CALLBACK_RX_MSG_LOST.                         */
/*                    The CANDRV_CALLBACK_RX_MSG_LOST callback function is called only once,    */
/*                    even if messages are lost multiple times from the same message object.    */
/*                                                                                              */
/*                    After that, a callback function will be called via the macro named        */
/*                    CANDRV_CALLBACK_RX_INDICATION in order to forward the received message.   */
/*                    However, if message loss occurs more than once on the same message object,*/
/*                    the number of times of message lost - 1 callback function is called.      */
/*                    At this time, the same data may be transferred multiple times.            */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/*                    <can_ptr> - Pointer to the CAN control register.                          */
/*                                                                                              */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : NSCS                                                                      */
/* Date             : 2017/5/26                                                                 */
/* Note             : Bug Fixes                                                                 */
/*                    Modify to clear the DN/MOW bit after read a message.                      */
/*                    Modify to don't call back a receiving message when the MOW bit equal 1.   */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2019/06/07                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/************************************************************************************************/
static void can_handle_reception_interrupt(UI_8 controller, const T_CanDrv_AddrMap *can_ptr)
{
	UI_16 idl;
	UI_16 idh;
	UI_8 frame_format;
	UI_32 id;
	UI_8 length;
	UI_8 rx_data[8];
	UI_8 i;
	UI_16 rgpt;
	UI_16 mctrl;
	UI_16 message_buffer_number;
	UI_8 mdlc;
	UI_8 recv_timer;

	/* Clear CnINTS1 */
	*can_ptr->CxINTS = CANDRV_CLR_INTS_RECV;

	/* Read CnRGPT register */
	rgpt = *can_ptr->CxRGPT;

	recv_timer = 0U;

	/* RHPM = 1? */
	while (((rgpt & CANDRV_RGPT_RHPM) != CANDRV_RGPT_RHPM) &&
			(recv_timer < CANDRV_RECV_GUARDTIMER)) {

		recv_timer++;

		/* ROVF = 1? */
		if ((rgpt & CANDRV_RGPT_ROVF) == CANDRV_RGPT_ROVF) {
			/* Clear ROVF bit */
			*can_ptr->CxRGPT = CANDRV_RGPT_ROVF;
		}

		message_buffer_number = ((rgpt & 0xFF00U) >> 8);

		/* Read CnMDLCm registers */
		mdlc = can_ptr->MsgBuf[message_buffer_number]->CxMDLC;
		length = (mdlc & 0x0FU);
		if (8U < length) {
			length = 8U;
		}
		/* Read CnMDATAxm registers */
		for (i = 0U; i < length; i++) {
			rx_data[i] = can_ptr->MsgBuf[message_buffer_number]->CxMDB[i];
		}

		/* Read CnMIDLm, CnMIDHm registers */
		idl = can_ptr->MsgBuf[message_buffer_number]->CxMIDL;
		idh = can_ptr->MsgBuf[message_buffer_number]->CxMIDH;
		if ((idh & CANDRV_SET_MIDH_IDE) != CANDRV_SET_MIDH_IDE) {
			/* CAN Standard */
			frame_format = CANDRV_CAN_STANDARD_FRAME;
			id = (UI_32)(((UI_32)idh >> 2U) & 0x000007FFU);
		} else {
			/* CAN Extended */
			frame_format = CANDRV_CAN_EXTENDED_FRAME;
			id = (UI_32)((((UI_32)idh << 16U) & 0x1FFF0000U) | (UI_32)idl);
		}

		/* Check if the overrun occurred by reading MOW bit in CnMCTRLm */
		mctrl = can_ptr->MsgBuf[message_buffer_number]->CxMCTRL;
		if ((mctrl & CANDRV_MCTRL_MOW) == CANDRV_MCTRL_MOW) {
			/* Clear DN/MOW bit */
			can_ptr->MsgBuf[message_buffer_number]->CxMCTRL = CANDRV_CLR_MCTRL_DN_MOW;

			/* Notify the upper layer that some received messages were lost. */
			CANDRV_CALLBACK_RX_MSG_LOST(controller);
		} else {
			/* Clear DN bit */
			can_ptr->MsgBuf[message_buffer_number]->CxMCTRL = CANDRV_CLR_MCTRL_DN;

			/* Notify the upper layer of a message reception. */
			CANDRV_CALLBACK_RX_INDICATION(controller, frame_format, id, length, (const UI_8 *)&rx_data[0]);
		}

		rgpt = *can_ptr->CxRGPT;
	}
}

/************************************************************************************************/
/* Function name    : can_handle_transmission_interrupt                                         */
/*                                                                                              */
/* Description      : When a requested CAN message is transmitted correctly,                    */
/*                    this function will be called in the tx interrupt process.                 */
/*                                                                                              */
/*                    The corresponding interrupt factor will be cleared in the function.       */
/*                                                                                              */
/*                    After that, a callback function will be called via the macro named        */
/*                    CANDRV_CALLBACK_TX_CONFIRMATION.                                          */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/*                    <can_ptr> - Pointer to the CAN control register.                          */
/*                                                                                              */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2019/06/03                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/************************************************************************************************/
static void can_handle_transmission_interrupt(UI_8 controller, const T_CanDrv_AddrMap *can_ptr)
{
	UI_16 tx_msg_obj_index;
	UI_16 message_buffer_number;
	UI_16 tgpt;
	UI_8 trans_timer;

	trans_timer = 0U;

	/* Clear CnINTS0 */
	*can_ptr->CxINTS = CANDRV_CLR_INTS_TRANS;

	do {
		trans_timer++;

		/* Read Transmit History List information */
		tgpt = *can_ptr->CxTGPT;

		/* Is Transmit History List overflow? */
		if ((tgpt & CANDRV_TGPT_TOVF) == CANDRV_TGPT_TOVF) {
			/* Clear overflow status */
			*can_ptr->CxTGPT = CANDRV_TGPT_TOVF;
		}

		/* Is there a new message in the Transmit History List? */
		if ((tgpt & CANDRV_TGPT_THPM) != CANDRV_TGPT_THPM) {
			message_buffer_number = ((tgpt & 0xFF00U) >> 8);

			if ((message_buffer_number+1U) >= C_CanDrv_ControllerCfg[controller]->TxTopMsgNum) {
				/* Calculate a object index from the specified message number. */
				tx_msg_obj_index = (message_buffer_number+1U) - C_CanDrv_ControllerCfg[controller]->TxTopMsgNum;

				/* Notify the upper layer that a transmission has been confirmed. */
				CANDRV_CALLBACK_TX_CONFIRMATION(controller, tx_msg_obj_index);
			}
		}
	} while (((tgpt & CANDRV_TGPT_THPM) != CANDRV_TGPT_THPM) && (trans_timer < CANDRV_TRANS_GUARDTIMER));
}

/************************************************************************************************/
/* Function name    : can_handle_illegal_interrupt                                              */
/*                                                                                              */
/* Description      : If an unexpected interrupt number is read, this function will be called   */
/*                    and the corresponding interrupt factor will be cleared.                   */
/*                                                                                              */
/* Argument         : <can_ptr> - Pointer to the CAN control register.                          */
/*                                                                                              */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2019/06/07                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/************************************************************************************************/
static void can_handle_illegal_interrupt(const T_CanDrv_AddrMap *can_ptr)
{
	/* Clear CnINTS5,CnINTS4,CnINTS3 */
	*can_ptr->CxINTS = CANDRV_CLR_ILLEGAL_INTS;
}


/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
/************************************************************************************************/
/* Function name    : CanDrv_Init                                                               */
/*                                                                                              */
/* Description      : This function will deactivate all of the CAN controllers                  */
/*                    when the initialization type is E_INIT_RESET or E_INIT_WAKEUP.            */
/*                                                                                              */
/* Argument         : <req> - Initialization type (The reason why this function was called)     */
/*                     E_INIT_RESET : CPU reset occurred.                                       */
/*                     E_INIT_WAKEUP : The upper layer detected the wakeup event.               */
/*                     E_INIT_IGN_ON : The upper layer detected that the ignition key state was */
/*                                     changed to ON.                                           */
/*                     E_INIT_RET_NORMAL_VOL : The upper layer detected that                    */
/*                                             the voltage state was recovered.                 */
/*                     E_INIT_INTERVAL_WAKEUP : The upper layer detected                        */
/*                                              the intermittent-wakeup event.                  */
/*                                                                                              */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanDrv_Init(const E_INIT_TYPE req)
{
	switch (req) {
	case E_INIT_RESET:
	case E_INIT_WAKEUP:
		/* Init CAN Controller */
		can_stop_all_controller();
		break;
	case E_INIT_IGN_ON:
	case E_INIT_RET_NORMAL_VOL:
	case E_INIT_INTERVAL_WAKEUP:
	default:
		break;
	}
}

/************************************************************************************************/
/* Function name    : CanDrv_Refresh                                                            */
/*                                                                                              */
/* Description      :                                                                           */
/* Argument         : void                                                                      */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanDrv_Refresh(void)
{
	/* NOP */
}

/************************************************************************************************/
/* Function name    : CanDrv_Sleep                                                              */
/*                                                                                              */
/* Description      : When this functions is called, all of the CAN controllers                 */
/*                    will be deactivated.                                                      */
/* Argument         : void                                                                      */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanDrv_Sleep(void)
{
	can_stop_all_controller();
}


/************************************************************************************************/
/* Function name    : CanDrv_CtrlState                                                          */
/*                                                                                              */
/* Description      : This function activates or deactivates the CAN controller.                */
/* Argument         : <controller> - CAN controller identification number                       */
/*                    <cmd> - A request command for controlling the CAN controller state.       */
/*                     CANDRV_CMD_START : Start CAN startup sequence.                           */
/*                     CANDRV_CMD_START_WITH_CHK : Start CAN startup sequence with RAM check.   */
/*                     CANDRV_CMD_STOP : Start CAN shutdown sequence                            */
/*                                                                                              */
/* Return value     :                                                                           */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanDrv_CtrlState(const UI_8 controller, const UI_8 cmd)
{
	if (controller < (UI_8)CANDRV_CONTROLLER_CNT) {
		/* If an unknown format request is set, the driver will regard it as a Stop request. */
		switch (cmd) {
		case CANDRV_CMD_START:
			/* Initialize the CAN Controller without the register check. */
			can_init_controller(controller, D_FALSE);
			break;
		case CANDRV_CMD_START_WITH_CHK:
			/* Initialize the CAN Controller with the register check. */
			can_init_controller(controller, D_TRUE);
			break;
		case CANDRV_CMD_STOP:
		default:
			/* Clear the OPMODE bit in the CnCTRL register in order to stop the CAN functions. */
			can_stop_controller(controller);
			break;
		}
	}
}

/************************************************************************************************/
/* Function name    : CanDrv_ChkState                                                           */
/*                                                                                              */
/* Description      : This function returns the current state of the CAN controller.            */
/* Argument         : <controller> - CAN controller identification number                       */
/* Return value     : The current state of the CAN controller.                                  */
/*                     CANDRV_STATE_STOP : The controller has been deactivated.                 */
/*                     CANDRV_STATE_START : The controller has been activated.                  */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_8 CanDrv_ChkState(const UI_8 controller)
{
	const T_CanDrv_AddrMap *can_ptr;
	UI_16 ctrl;
	UI_8 ret_val;

	/* If the argument is invalid, the function will return Stop. */
	ret_val = CANDRV_STATE_STOP;

	if (controller < (UI_8)CANDRV_CONTROLLER_CNT) {

		/* Get access to the CAN Controller */
		can_ptr = can_get_controller_ptr(controller);

		/* Check the OPMODE bit in the CnCTRL register */
		ctrl = *can_ptr->CxCTRL;
		if ((ctrl & CANDRV_CTRL_OPMODE) == CANDRV_CTRL_OPMODE_NORM) {
			/* OPMODE bit is 001. --- Start */
			ret_val = CANDRV_STATE_START;
		} else {
			/* OPMODE bit is 000. --- Stop */
			ret_val = CANDRV_STATE_STOP;
		}
	}

	return ret_val;
}

/************************************************************************************************/
/* Function name    : CanDrv_SetTxReq                                                           */
/*                                                                                              */
/* Description      : When this function is called, a requested data will be                    */
/*                    transmitted to the CAN bus.                                               */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/*                    <tx_msg_obj_index> - Index number of msg_obj for tx (0- )                 */
/*                                                                                              */
/*                    <frame_format> - CAN frame format                                         */
/*                     CANDRV_CAN_STANDARD_FRAME : CAN Standard(11-bit identifier)              */
/*                     CANDRV_CAN_EXTENDED_FRAME : CAN Extended(29-bit identifier)              */
/*                                                                                              */
/*                    <id> - CAN identifier.                                                    */
/*                     0x00000000 - 0x000007FF (11-bit identifier)                              */
/*                     0x00000000 - 0x1FFFFFFF (29-bit identifier)                              */
/*                                                                                              */
/*                    <data_length> - Tx data length.                                           */
/*                     0-8                                                                      */
/*                     If the requested data length is more than 8,                             */
/*                     this driver will ignore the request.                                     */
/*                                                                                              */
/*                    <data_ptr> - Pointer to Tx data buffer.                                   */
/*                     If the requested data pointer is NULL,                                   */
/*                     the requested data length shall be zero.                                 */
/*                     Otherwise, this driver will ignore the request.                          */
/*                                                                                              */
/* Return value     : void                                                                      */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2019/06/10                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/************************************************************************************************/
void CanDrv_SetTxReq(const UI_8 controller, const UI_16 tx_msg_obj_index, const UI_8 frame_format, const UI_32 id, 
																				const UI_8 data_length, const UI_8 data_ptr[])
{
	UI_16 message_number;
	const T_CanDrv_AddrMap *can_ptr;
	UI_16 idh;
	UI_16 idl;
	UI_16 work_id;
	UI_16 mctrl_trq;
	UI_8 i;
	UI_8 mconf;

	if ((controller < (UI_8)CANDRV_CONTROLLER_CNT) &&
		(((data_ptr != D_NULL) && (data_length <= 8U)) || (data_length == 0U))) {

		/* Calculate a message number from the specified object index. */
		message_number = C_CanDrv_ControllerCfg[controller]->TxTopMsgNum + tx_msg_obj_index;

		/* Check if the message number is pre configured as a transmit object. */
		if (message_number <= C_CanDrv_ControllerCfg[controller]->TxBottomMsgNum) {

			/* Get access to the CAN Controller */
			can_ptr = can_get_controller_ptr(controller);

			/* Clear RDY bit */
			can_ptr->MsgBuf[message_number-1U]->CxMCTRL = CANDRV_CLR_MCTRL_RDY;

			/* If an unknown format request is set, the driver will regard it as a CAN Standard Frame request. */
			switch (frame_format) {
			case CANDRV_CAN_STANDARD_FRAME:
				/* CAN Standard Frame (11-bit identifier) */
				idl = 0U;
				work_id = (UI_16)((0x000007FFU & id) << 2U);
				idh = work_id;
				mctrl_trq = CANDRV_SET_MCTRL_TRQ;
				break;
			case CANDRV_CAN_EXTENDED_FRAME:
				/* CAN Extended Frame (29-bit identifier) */
				idl = (UI_16)id;
				work_id = (UI_16)((id & 0x1FFF0000U) >> 16U);
				idh = (CANDRV_SET_MIDH_IDE | work_id);
				mctrl_trq = CANDRV_SET_MCTRL_TRQ;
				break;
			default:
				/* Invalid Frame Format. Disable message object. */
				/* Set ID=0 */
				idl = CANDRV_CLR_ALL;
				idh = CANDRV_CLR_ALL;
				mctrl_trq = CANDRV_CLR_MCTRL_TRQ;
				break;
			}

			/* Set CnMDATAxm register */
			for (i = 0U; i < data_length; i++) {
				can_ptr->MsgBuf[message_number-1U]->CxMDB[i] = data_ptr[i];
			}

			/* Set CnMDLCm register */
			can_ptr->MsgBuf[message_number-1U]->CxMDLC = data_length;

			/* Clear RTR bit of CnMCONFm register */
			mconf = can_ptr->MsgBuf[message_number-1U]->CxMCONF;
			mconf &= (UI_8)(~CANDRV_SET_MCONF_RTR);
			can_ptr->MsgBuf[message_number-1U]->CxMCONF = mconf;

			/* Set CnMIDLm and CnMIDHm registers */
			can_ptr->MsgBuf[message_number-1U]->CxMIDL = idl;
			can_ptr->MsgBuf[message_number-1U]->CxMIDH = idh;

			/* Set RDY bit */
			can_ptr->MsgBuf[message_number-1U]->CxMCTRL = CANDRV_SET_MCTRL_RDY;

			/* Set TRQ bit */
			can_ptr->MsgBuf[message_number-1U]->CxMCTRL = mctrl_trq;
		}
	}
}

/************************************************************************************************/
/* Function name    : CanDrv_ClrTxReq                                                           */
/*                                                                                              */
/* Description      : When this function is called, a pending transmission request              */
/*                    will be removed from the CAN controller.                                  */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                    <tx_msg_obj_index> - Index number of msg_obj for tx (0- )                 */
/* Return value     : void                                                                      */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2018/11/05                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/************************************************************************************************/
void CanDrv_ClrTxReq(const UI_8 controller, const UI_16 tx_msg_obj_index)
{
	UI_16 message_number;
	const T_CanDrv_AddrMap *can_ptr;

	if (controller < (UI_8)CANDRV_CONTROLLER_CNT) {

		/* Calculate a message number from the specified object index. */
		message_number = C_CanDrv_ControllerCfg[controller]->TxTopMsgNum + tx_msg_obj_index;

		/* Check if the message number is pre configured as a transmit object. */
		if (message_number <= C_CanDrv_ControllerCfg[controller]->TxBottomMsgNum) {

			/* Get access to the CAN Controller */
			can_ptr = can_get_controller_ptr(controller);

			/* Clear TRQ bit */
			can_ptr->MsgBuf[message_number-1U]->CxMCTRL = CANDRV_CLR_MCTRL_TRQ;
		}
	}
}

/************************************************************************************************/
/* Function name    : CanDrv_ChkTxState                                                         */
/*                                                                                              */
/* Description      : This function returns the current transmission state.                     */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                    <tx_msg_obj_index> - Index number of msg_obj for tx (0- )                 */
/*                                                                                              */
/* Return value     : CANDRV_TX_STATE_IDLE : The transmission request is not currently being    */
/*                                           processed.                                         */
/*                                                                                              */
/*                    CANDRV_TX_STATE_PENDING : The transmission request is currently being     */
/*                                              processed.                                      */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2018/11/05                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/************************************************************************************************/
UI_8 CanDrv_ChkTxState(const UI_8 controller, const UI_16 tx_msg_obj_index)
{
	UI_16 message_number;
	UI_8 tx_status;
	UI_8 bit_status;
	const T_CanDrv_AddrMap *can_ptr;

	tx_status = CANDRV_TX_STATE_IDLE;

	if (controller < (UI_8)CANDRV_CONTROLLER_CNT) {

		/* Calculate a message number from the specified object index. */
		message_number = C_CanDrv_ControllerCfg[controller]->TxTopMsgNum + tx_msg_obj_index;

		/* Check if the message number is pre configured as a transmit object. */
		if (message_number <= C_CanDrv_ControllerCfg[controller]->TxBottomMsgNum) {

			/* Get access to the CAN Controller */
			can_ptr = can_get_controller_ptr(controller);

			/* This driver reads the message control register (CnMCTRL) */
			/* to confirm the current transmission state */
			bit_status = can_check_msg_handler_register(&can_ptr->MsgBuf[message_number-1U]->CxMCTRL);
			if (bit_status != D_FALSE) {
				tx_status = CANDRV_TX_STATE_PENDING;
			}
		}
	}

	return tx_status;
}

/************************************************************************************************/
/* Function name    : CanDrv_GetErrState                                                        */
/*                                                                                              */
/* Description      : This function returns the current error state.                            */
/*                    If the argument is invalid, the function will return                      */
/*                    CANDRV_ERR_STATE_ACTIVE.                                                  */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/* Return value     : CANDRV_ERR_STATE_ACTIVE : No error                                        */
/*                    CANDRV_ERR_STATE_WARNING : Warning                                        */
/*                    CANDRV_ERR_STATE_PASSIVE : Error Passive                                  */
/*                    CANDRV_ERR_STATE_BUSOFF : BusOff                                          */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_8 CanDrv_GetErrState(const UI_8 controller)
{
	UI_8 ret_val;
	UI_16 cxinfo;
	const T_CanDrv_AddrMap *can_ptr;

	/* If the argument is invalid, the function will return Active. */
	ret_val = CANDRV_ERR_STATE_ACTIVE;

	if (controller < (UI_8)CANDRV_CONTROLLER_CNT) {

		/* Get access to the CAN Controller */
		can_ptr = can_get_controller_ptr(controller);

		cxinfo = *can_ptr->CxINFO;

		if ((cxinfo & CANDRV_INFO_BOFF) == CANDRV_INFO_BOFF) {
			ret_val = CANDRV_ERR_STATE_BUSOFF;

		} else if ((cxinfo & CANDRV_INFO_TX_ERR_PASSIVE) == CANDRV_INFO_TX_ERR_PASSIVE) {
			ret_val = CANDRV_ERR_STATE_PASSIVE;

		} else if ((cxinfo & CANDRV_INFO_RX_ERR_PASSIVE) == CANDRV_INFO_RX_ERR_PASSIVE) {
			ret_val = CANDRV_ERR_STATE_PASSIVE;

		} else if ((cxinfo & CANDRV_INFO_TX_ERR_WARN) == CANDRV_INFO_TX_ERR_WARN) {
			ret_val = CANDRV_ERR_STATE_WARNING;

		} else if ((cxinfo & CANDRV_INFO_RX_ERR_WARN) == CANDRV_INFO_RX_ERR_WARN) {
			ret_val = CANDRV_ERR_STATE_WARNING;

		} else {
			/* No error bit is set. --- ACTIVE */
			ret_val = CANDRV_ERR_STATE_ACTIVE;

		}
	}

	return ret_val;
}

/************************************************************************************************/
/* Function name    : CanDrv_GetTxErrCnt                                                        */
/*                                                                                              */
/* Description      : This function returns the current Tx Error Count.                         */
/*                    If the argument is invalid, the function will return 0.                   */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/* Return value     : Tx Error Count (0 - 256)                                                  */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_16 CanDrv_GetTxErrCnt(const UI_8 controller)
{
	const T_CanDrv_AddrMap *can_ptr;
	UI_16 cxinfo;
	UI_16 cxerc;
	UI_16 tx_error_counter;

	/* If the argument is invalid, the function will return 0. */
	tx_error_counter = 0U;

	if (controller < (UI_8)CANDRV_CONTROLLER_CNT) {
		/* Get access to the CAN Controller */
		can_ptr = can_get_controller_ptr(controller);

		cxinfo = *can_ptr->CxINFO;
		cxerc = *can_ptr->CxERC;

		/* Check the transmission error counter. */
		if ((cxinfo & CANDRV_INFO_BOFF) == CANDRV_INFO_BOFF) {
			/* The BOFF bit in the CnINFO is set (BusOff). The actual value has reached 256. */
			tx_error_counter = 256U;
		} else {
			tx_error_counter = (cxerc & 0x00FFU);
		}
	}

	return tx_error_counter;
}

/************************************************************************************************/
/* Function name    : CanDrv_GetRxErrCnt                                                        */
/*                                                                                              */
/* Description      : This function returns the current Rx Error Count.                         */
/*                    If the argument is invalid, the function will return 0.                   */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/* Return value     : Rx Error Count (0 - 128)                                                  */
/*                                                                                              */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
UI_16 CanDrv_GetRxErrCnt(const UI_8 controller)
{
	const T_CanDrv_AddrMap *can_ptr;
	UI_16 cxerc;
	UI_16 rx_error_counter;

	/* If the argument is invalid, the function will return 0. */
	rx_error_counter = 0U;

	if (controller < (UI_8)CANDRV_CONTROLLER_CNT) {
		/* Get access to the CAN Controller */
		can_ptr = can_get_controller_ptr(controller);

		cxerc = *can_ptr->CxERC;

		/* Check the receive error counter. */
		if ((cxerc & CANDRV_ERC_REPS) == CANDRV_ERC_REPS) {
			/* The REPS bit in the CnERC is set. The actual value has reached 128. */
			rx_error_counter = 128U;
		} else {
			rx_error_counter = ((cxerc & CANDRV_ERC_REC) >> 8U);
		}
	}

	return rx_error_counter;
}

/************************************************************************************************/
/* Function name    : CanDrv_IntrHandler                                                        */
/*                                                                                              */
/* Description      : Called by CAN Interrupt service routine                                   */
/*                    Check for the interrupt reason (interrupt ID: INTID)                      */
/*                    Handle appropriate interrupt:                                             */
/*                     - Status interrupt (BusOff)                                              */
/*                     - Message reception                                                      */
/*                     - Transmission confirmation                                              */
/*                                                                                              */
/*                    If busoff error is detected, a callback function will be called           */
/*                    via the macro named CANDRV_CALLBACK_CONTROLLER_BUSOFF                     */
/*                                                                                              */
/*                    If the transmission is confirmed, a callback function will be called      */
/*                    via the macro named CANDRV_CALLBACK_TX_CONFIRMATION                       */
/*                                                                                              */
/*                    If new message is received, a callback function will be called            */
/*                    via the macro named CANDRV_CALLBACK_RX_INDICATION                         */
/*                    If message lost is detected during Rx interrupt, a callback function will */
/*                    be called via the macro named CANDRV_CALLBACK_RX_MSG_LOST                 */
/*                                                                                              */
/*                    The above mentioned callback functions shall be                           */
/*                    implemented in the upper layer.                                           */
/*                                                                                              */
/* Argument         : <controller> - CAN controller identification number                       */
/*                                                                                              */
/*                    <intr_signal> - Interrupt signal                                          */
/*                                    The driver checks whether the parameter is identical to   */
/*                                    CANDRV_INTR_SIGNAL_CAN.                                   */
/*                                                                                              */
/* Return value     : void                                                                      */
/* Programmed by    : NSCS                                                                      */
/* Date             : 2017/04/21                                                                */
/* Note             :                                                                           */
/************************************************************************************************/
void CanDrv_IntrHandler(const UI_8 controller, const UI_8 intr_signal)
{
	const T_CanDrv_AddrMap *can_ptr;
	UI_16 intr_stat;

	/* Check if the arguments are valid. */
	if ((controller < (UI_8)CANDRV_CONTROLLER_CNT) && (intr_signal == CANDRV_INTR_SIGNAL_CAN)) {

		/* Get access to the CAN Controller */
		can_ptr = can_get_controller_ptr(controller);

		/* Read the interrupt register to identify the reason for the interrupt. */
		intr_stat = *can_ptr->CxINTS;

		/* When the function is called, all interrupts will be handled within the following loop. */
		while (intr_stat != CANDRV_INTS_NO_INTERRUPT) {

			if ((intr_stat & CANDRV_INTS_STATUS_INTERRUPT) == CANDRV_INTS_STATUS_INTERRUPT) {
				/* CAN Status Interrupt */
				can_handle_status_interrupt(controller, can_ptr);

			} else if ((intr_stat & CANDRV_INTS_TRANS_INTERRUPT) == CANDRV_INTS_TRANS_INTERRUPT) {
				/* The transmission has been confirmed. (Transmission completed) */
				can_handle_transmission_interrupt(controller, can_ptr);

			} else if ((intr_stat & CANDRV_INTS_RECV_INTERRUPT) == CANDRV_INTS_RECV_INTERRUPT) {
				/* A new message has been received. */
				can_handle_reception_interrupt(controller, can_ptr);

			} else {
				/* Illegal Interrupt. -- There should not be a corresponding interrupt reason. */
				can_handle_illegal_interrupt(can_ptr);

			}

			/* Read the interrupt register again. */
			intr_stat = *can_ptr->CxINTS;

		}
	}
}

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/
