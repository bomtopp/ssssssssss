/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFT                                                                      */
/*----------------------------------------------------------------------------------------------*/
/* CPU              : RL78/D1A Series                                                           */
/* Date             : 2017/04/21                                                                */
/*----------------------------------------------------------------------------------------------*/
/* Programmed by    : NSCS                                                                      */
/* Copyrights       : Nippon Seiki Co.,Ltd                                                      */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2018/11/05                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/*----------------------------------------------------------------------------------------------*/
/* Update by        : $Author: Sato Yusuke (A01A091212) $                                                            */
/* Date             : $Date: 2020/03/02 10:15:07ICT $                                                              */
/* Version          : $Revision: 1.1 $                                                          */
/************************************************************************************************/



#ifndef SSFTSTD_RL78CAN_DRV_000_H
#define SSFTSTD_RL78CAN_DRV_000_H

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"
#include "SSFTxxx_RL78Can_DrvCfg_000.h"

/************************************************************************************************/
/* Global Macros                                                                                */
/************************************************************************************************/
#define RL78_CAN_DRV_H (0x2101U)
#ifdef _VERSION_CONST_DEFINE
UI_8 const C_CANDRV_VER[6] = {		/* CAN Driver Version No(xxyyzz = 210101) */
	0x02U,
	0x01U,
	0x00U,
	0x01U,
	0x00U,
	0x01U
};
#endif /* _VERSION_CONST_DEFINE */


/* Definitions to be used as an operation command for CanDrv_CtrlState() */
#define CANDRV_CMD_STOP              ((UI_8)0x00U) /* Start CAN shutdown sequence */
#define CANDRV_CMD_START             ((UI_8)0x01U) /* Start CAN startup sequence */
#define CANDRV_CMD_START_WITH_CHK    ((UI_8)0x02U) /* Start CAN startup sequence (A verification of the message RAM is executed during the startup sequence.) */


/* Definitions for checking the return value of CanDrv_ChkState().*/
#define CANDRV_STATE_STOP          ((UI_8)0x00U)
#define CANDRV_STATE_START_TO_STOP ((UI_8)0x01U)
#define CANDRV_STATE_STOP_TO_START ((UI_8)0x02U)
#define CANDRV_STATE_START         ((UI_8)0x03U)

/* Definitions for checking the return value of CanDrv_ChkTxState().*/
#define CANDRV_TX_STATE_IDLE    ((UI_8)0x00U)
#define CANDRV_TX_STATE_PENDING ((UI_8)0x01U)


/* Definitions of CAN Frame Format */
#define CANDRV_CAN_STANDARD_FRAME   ((UI_8)0x00U) /* CAN Standard(11-bit identifier) */
#define CANDRV_CAN_EXTENDED_FRAME   ((UI_8)0x01U) /* CAN Extended(29-bit identifier) */


/* Definitions for checking the return value of CanDrv_GetErrState().*/
#define CANDRV_ERR_STATE_ACTIVE  ((UI_8)0x00U) /* No error */
#define CANDRV_ERR_STATE_WARNING ((UI_8)0x01U) /* Warning */
#define CANDRV_ERR_STATE_PASSIVE ((UI_8)0x02U) /* Error Passive */
#define CANDRV_ERR_STATE_BUSOFF  ((UI_8)0x03U) /* BusOff */

/* Definitions to be used for identifying the interrupt signal (reason) in CanDrv_IntrHandler(). */
#define CANDRV_INTR_SIGNAL_CAN         ((UI_8)0x00U) /* Rx, Tx, Status */

/************************************************************************************************/
/* Global Data Types                                                                            */
/************************************************************************************************/

/************************************************************************************************/
/* Global Data                                                                                  */
/************************************************************************************************/

/************************************************************************************************/
/* Global Constants                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/
extern void CanDrv_Init(const E_INIT_TYPE req);
extern void CanDrv_Refresh(void);
extern void CanDrv_Sleep(void);

extern void CanDrv_CtrlState(const UI_8 controller, const UI_8 cmd);
extern UI_8 CanDrv_ChkState(const UI_8 controller);

extern void CanDrv_SetTxReq(const UI_8 controller, const UI_16 tx_msg_obj_index, const UI_8 frame_format, const UI_32 id, 
																				const UI_8 data_length, const UI_8 data_ptr[]);
extern void CanDrv_ClrTxReq(const UI_8 controller, const UI_16 tx_msg_obj_index);
extern UI_8 CanDrv_ChkTxState(const UI_8 controller, const UI_16 tx_msg_obj_index);

extern UI_8 CanDrv_GetErrState(const UI_8 controller);
extern UI_16 CanDrv_GetTxErrCnt(const UI_8 controller);
extern UI_16 CanDrv_GetRxErrCnt(const UI_8 controller);

extern void CanDrv_IntrHandler(const UI_8 controller, const UI_8 intr_signal);



#endif /* SSFTSTD_RL78CAN_DRV_000_H */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/

