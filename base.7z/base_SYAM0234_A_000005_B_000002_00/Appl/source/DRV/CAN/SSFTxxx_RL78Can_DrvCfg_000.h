/************************************************************************************************/
/* Customer         : Standard module                                                           */
/* Model(Theme No.) : SSFT                                                                      */
/*----------------------------------------------------------------------------------------------*/
/* CPU              : RL78/D1A Series                                                           */
/* Date             : 2017/04/21                                                                */
/*----------------------------------------------------------------------------------------------*/
/* Programmed by    : NSCS                                                                      */
/* Copyrights       : Nippon Seiki Co.,Ltd                                                      */
/*----------------------------------------------------------------------------------------------*/
/* Update by        : NSCS                                                                      */
/* Date             : 2017/5/16                                                                 */
/* Note             : Bug Fixes                                                                 */
/*                    Modify value of Macro below.                                              */
/*                    �ECANDRV0_BTR : 0x2208U �� 0x220BU                                        */
/*                    �ECANDRV1_BTR : 0x2208U �� 0x220BU                                        */
/*                    �ECANDRV0_BRP : 0x0FU �� 0x00U                                            */
/*                    �ECANDRV1_BRP : 0x0FU �� 0x00U                                            */
/*                    �ECANDRV0_MASK1H/CANDRV0_MASK2H/CANDRV0_MASK3H/CANDRV0_MASK4H/            */
/*                      CANDRV1_MASK1H/CANDRV1_MASK2H/CANDRV1_MASK3H/CANDRV1_MASK4H             */
/*                              : 0x01FFU �� 0x1FFFU                                            */
/*----------------------------------------------------------------------------------------------*/
/* Updated by       : CRESCO T.Suyama                                                           */
/* Date             : 2019/06/06                                                                */
/* Note             : Modify to allocate multiple TX buffers to the message object.             */
/*----------------------------------------------------------------------------------------------*/
/* Update by        : $Author: Sato Yusuke (A01A091212) $                                                            */
/* Date             : $Date: 2020/03/02 10:15:07ICT $                                                              */
/* Version          : $Revision: 1.1 $                                                          */
/************************************************************************************************/



#ifndef SSFTXXX_RL78CAN_DRVCFG_000_H
#define SSFTXXX_RL78CAN_DRVCFG_000_H

/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_RL78IoReg_CpuType_001.h"

/************************************************************************************************/
/* Global Macros                                                                                */
/************************************************************************************************/

/* Identification numbers of the channels */
#define CANDRV_CONTROLLER_0 (0U) /* CAN0 */
#if defined(__F10DPL_) || defined(__F10DPK_) || defined(__F10DPJ_)

#define CANDRV_CONTROLLER_CNT (2U)
#define CANDRV_CONTROLLER_1 (1U) /* CAN1 */

#else

#define CANDRV_CONTROLLER_CNT (1U)

#endif

/************************************************************************************************/
/* Global Data Types                                                                            */
/************************************************************************************************/

/************************************************************************************************/
/* Global Data                                                                                  */
/************************************************************************************************/

/************************************************************************************************/
/* Global Constants                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/* Global Functions                                                                             */
/************************************************************************************************/

/************************************************************************************************/
/*                                                                                              */
/* The section below is related to the CAN Driver.                                              */
/*                                                                                              */
/************************************************************************************************/
#ifdef SSFTSTD_RL78CAN_DRV_000_INTERNAL
/************************************************************************************************/
/* Include Section                                                                              */
/************************************************************************************************/
#include "SSFTSTD_Can_DrvIF_000.h"

/************************************************************************************************/
/* Local Macros                                                                                 */
/************************************************************************************************/
#define RL78_CAN_DRV_CFG_H (0x2101U)

/************************************************************************************************/
/* CAN0 (USER can change the following contents)                                                */
/************************************************************************************************/
#define CANDRV0_GMCS (0x02U)
#define CANDRV0_BTR (0x220BU)
#define CANDRV0_BRP (0x00U)
#define CANDRV0_MASK1H (0x1FFFU)
#define CANDRV0_MASK1L (0xFFFFU)
#define CANDRV0_MASK2H (0x1FFFU)
#define CANDRV0_MASK2L (0xFFFFU)
#define CANDRV0_MASK3H (0x1FFFU)
#define CANDRV0_MASK3L (0xFFFFU)
#define CANDRV0_MASK4H (0x1FFFU)
#define CANDRV0_MASK4L (0xFFFFU)
#define CANDRV0_TX_TOP_MSG_NUM (1U)
#define CANDRV0_TX_BOTTOM_MSG_NUM (3U)
#define CANDRV0_RX_TOP_MSG_NUM (4U)
#define CANDRV0_RX_BOTTOM_MSG_NUM (16U)

/************************************************************************************************/
/* CAN0 (USER do not have to change the following contents)                                     */
/************************************************************************************************/
#define CANDRV0_MSG_OBJ_CNT (16U)

#if ((CANDRV0_TX_TOP_MSG_NUM < 1U) || (CANDRV0_MSG_OBJ_CNT < CANDRV0_TX_TOP_MSG_NUM))
#error "CANDRV0_TX_TOP_MSG_NUM"
#endif

#if ((CANDRV0_TX_BOTTOM_MSG_NUM < 1U) || (CANDRV0_MSG_OBJ_CNT < CANDRV0_TX_BOTTOM_MSG_NUM))
#error "CANDRV0_TX_BOTTOM_MSG_NUM"
#endif

#if ((CANDRV0_RX_TOP_MSG_NUM < 1U) || (CANDRV0_MSG_OBJ_CNT < CANDRV0_RX_TOP_MSG_NUM))
#error "CANDRV0_RX_TOP_MSG_NUM"
#endif

#if ((CANDRV0_RX_BOTTOM_MSG_NUM < 1U) || (CANDRV0_MSG_OBJ_CNT < CANDRV0_RX_BOTTOM_MSG_NUM))
#error "CANDRV0_RX_BOTTOM_MSG_NUM"
#endif

#if (CANDRV0_TX_TOP_MSG_NUM > CANDRV0_TX_BOTTOM_MSG_NUM)
#error "CANDRV0_TX_TOP_MSG_NUM > CANDRV0_TX_BOTTOM_MSG_NUM"
#endif

#if (CANDRV0_RX_TOP_MSG_NUM > CANDRV0_RX_BOTTOM_MSG_NUM)
#error "CANDRV0_RX_TOP_MSG_NUM > CANDRV0_RX_BOTTOM_MSG_NUM"
#endif

#define CANDRV0_TX_MSG_OBJ_CNT ((CANDRV0_TX_BOTTOM_MSG_NUM - CANDRV0_TX_TOP_MSG_NUM) + 1U)
#define CANDRV0_RX_MSG_OBJ_CNT ((CANDRV0_RX_BOTTOM_MSG_NUM - CANDRV0_RX_TOP_MSG_NUM) + 1U)

#if (6U < CANDRV0_TX_MSG_OBJ_CNT)
#error "CANDRV0_TX_MSG_OBJ_CNT"
#endif

/************************************************************************************************/
/* CAN1 (USER can change the following contents)                                                */
/************************************************************************************************/
#define CANDRV1_GMCS (0x02U)
#define CANDRV1_BTR (0x220BU)
#define CANDRV1_BRP (0x00U)
#define CANDRV1_MASK1H (0x1FFFU)
#define CANDRV1_MASK1L (0xFFFFU)
#define CANDRV1_MASK2H (0x1FFFU)
#define CANDRV1_MASK2L (0xFFFFU)
#define CANDRV1_MASK3H (0x1FFFU)
#define CANDRV1_MASK3L (0xFFFFU)
#define CANDRV1_MASK4H (0x1FFFU)
#define CANDRV1_MASK4L (0xFFFFU)
#define CANDRV1_TX_TOP_MSG_NUM (1U)
#define CANDRV1_TX_BOTTOM_MSG_NUM (1U)
#define CANDRV1_RX_TOP_MSG_NUM (2U)
#define CANDRV1_RX_BOTTOM_MSG_NUM (16U)

/************************************************************************************************/
/* CAN1 (USER do not have to change the following contents)                                     */
/************************************************************************************************/
#define CANDRV1_MSG_OBJ_CNT (16U)

#if ((CANDRV1_TX_TOP_MSG_NUM < 1U) || (CANDRV1_MSG_OBJ_CNT < CANDRV1_TX_TOP_MSG_NUM))
#error "CANDRV1_TX_TOP_MSG_NUM"
#endif

#if ((CANDRV1_TX_BOTTOM_MSG_NUM < 1U) || (CANDRV1_MSG_OBJ_CNT < CANDRV1_TX_BOTTOM_MSG_NUM))
#error "CANDRV1_TX_BOTTOM_MSG_NUM"
#endif

#if ((CANDRV1_RX_TOP_MSG_NUM < 1U) || (CANDRV1_MSG_OBJ_CNT < CANDRV1_RX_TOP_MSG_NUM))
#error "CANDRV1_RX_TOP_MSG_NUM"
#endif

#if ((CANDRV1_RX_BOTTOM_MSG_NUM < 1U) || (CANDRV1_MSG_OBJ_CNT < CANDRV1_RX_BOTTOM_MSG_NUM))
#error "CANDRV1_RX_BOTTOM_MSG_NUM"
#endif

#if (CANDRV1_TX_TOP_MSG_NUM > CANDRV1_TX_BOTTOM_MSG_NUM)
#error "CANDRV1_TX_TOP_MSG_NUM > CANDRV1_TX_BOTTOM_MSG_NUM"
#endif

#if (CANDRV1_RX_TOP_MSG_NUM > CANDRV1_RX_BOTTOM_MSG_NUM)
#error "CANDRV1_RX_TOP_MSG_NUM > CANDRV1_RX_BOTTOM_MSG_NUM"
#endif

#define CANDRV1_TX_MSG_OBJ_CNT ((CANDRV1_TX_BOTTOM_MSG_NUM - CANDRV1_TX_TOP_MSG_NUM) + 1U)
#define CANDRV1_RX_MSG_OBJ_CNT ((CANDRV1_RX_BOTTOM_MSG_NUM - CANDRV1_RX_TOP_MSG_NUM) + 1U)

#if (6U < CANDRV1_TX_MSG_OBJ_CNT)
#error "CANDRV1_TX_MSG_OBJ_CNT"
#endif

/************************************************************************************************/
/* Local Data Types                                                                             */
/************************************************************************************************/
/* Map structures of CAN Controller */
typedef volatile struct
{
	UI_8	CxMDB[8];		/* CAN message data byte register */
	UI_8	CxMDLC;			/* CAN message data length register */
	UI_8	CxMCONF;		/* CAN message configuration register */
	UI_16	CxMIDL;			/* CAN message ID register */
	UI_16	CxMIDH;			/* CAN message ID register */
	UI_16	CxMCTRL;		/* CAN message control register */
} T_CanDrv_MsgBufAddrMap;

typedef struct {
	volatile __near UI_16  *	CxGMCTRL;	/* CAN global module control register */
	volatile __near UI_16  *	CxGMABT;	/* CAN global automatic block transmission control register */
	volatile __near UI_8   *	CxGMABTD;	/* CAN global automatic block transmission delay setting register */
	volatile __near UI_8   *	CxGMCS;		/* CAN global module clock select register */
	volatile __near UI_16  *	CxMASK1L;	/* CAN module mask 1 register */
	volatile __near UI_16  *	CxMASK1H;	/* CAN module mask 1 register */
	volatile __near UI_16  *	CxMASK2L;	/* CAN module mask 2 register */
	volatile __near UI_16  *	CxMASK2H;	/* CAN module mask 2 register */
	volatile __near UI_16  *	CxMASK3L;	/* CAN module mask 3 register */
	volatile __near UI_16  *	CxMASK3H;	/* CAN module mask 3 register */
	volatile __near UI_16  *	CxMASK4L;	/* CAN module mask 4 register */
	volatile __near UI_16  *	CxMASK4H;	/* CAN module mask 4 register */
	volatile __near UI_16  *	CxCTRL;		/* CAN module control register */
	volatile __near UI_8   *	CxLEC;		/* CAN module last error code register */
	volatile __near UI_8   *	CxINFO;		/* CAN module information register */
	volatile __near UI_16  *	CxERC;		/* CAN module error counter register */
	volatile __near UI_16  *	CxIE;		/* CAN module interrupt enable register */
	volatile __near UI_16  *	CxINTS;		/* CAN module interrupt status register */
	volatile __near UI_8   *	CxBRP;		/* CAN module bit rate prescaler register */
	volatile __near UI_16  *	CxBTR;		/* CAN module bit rate register */
	volatile __near UI_8   *	CxLIPT;		/* CAN module last in-pointer register */
	volatile __near UI_16  *	CxRGPT;		/* CAN module receive history list register */
	volatile __near UI_8   *	CxLOPT;		/* CAN module last out-pointer register */
	volatile __near UI_16  *	CxTGPT;		/* CAN module transmit history list register */
	volatile __near UI_16  *	CxTS;		/* CAN module time stamp register */
	T_CanDrv_MsgBufAddrMap *	MsgBuf[16];	/* Message Buffer register */
} T_CanDrv_AddrMap;

typedef struct
{
	UI_8  MCONF;
	UI_16 MIDH;
	UI_16 MIDL;

} T_CanDrv_MsgObjCfg;

typedef struct
{
	const T_CanDrv_AddrMap * CanBasisAddr;
	UI_8  ClockSelect;
	UI_16 BitTiming;
	UI_8  BaudRate;
	UI_16 MsgObjCnt;
	const T_CanDrv_MsgObjCfg *RxMsgObjCfgPtr;
	UI_16 TxTopMsgNum;
	UI_16 TxBottomMsgNum;
	UI_16 RxTopMsgNum;
	UI_16 RxBottomMsgNum;
	UI_16 Mask1H;
	UI_16 Mask1L;
	UI_16 Mask2H;
	UI_16 Mask2L;
	UI_16 Mask3H;
	UI_16 Mask3L;
	UI_16 Mask4H;
	UI_16 Mask4L;

} T_CanDrv_ControllerCfg;

/************************************************************************************************/
/* Local Data                                                                                   */
/************************************************************************************************/

/************************************************************************************************/
/* Local Constants                                                                              */
/************************************************************************************************/
/* MCONF: OWS, RTR, MT2-0, MA0 */
/* MIDH: IDE, ID28-16 */
/* MIDL: ID15-0 */

/* CAN0 */
static const T_CanDrv_MsgObjCfg C_CanDrv0_RxMsgObjCfg[CANDRV0_RX_MSG_OBJ_CNT + 1U] =
{
	/* MCONF, MIDH, MIDL */

	{0x91U, ( 0x0401U << 2 ) , 0x0000U}, /* Index:  0 */
	{0x91U, ( 0x023AU << 2 ) , 0x0000U}, /* Index:  1 */
	{0x91U, ( 0x023EU << 2 ) , 0x0000U}, /* Index:  2 */
	{0x91U, ( 0x0209U << 2 ) , 0x0000U}, /* Index:  3 */
	{0x91U, ( 0x0215U << 2 ) , 0x0000U}, /* Index:  4 */
	{0x91U, ( 0x022AU << 2 ) , 0x0000U}, /* Index:  5 */
	{0x91U, ( 0x020AU << 2 ) , 0x0000U}, /* Index:  6 */
	{0x91U, ( 0x0216U << 2 ) , 0x0000U}, /* Index:  7 */
	{0x91U, ( 0x0245U << 2 ) , 0x0000U}, /* Index:  8 */
	{0x91U, ( 0x0600U << 2 ) , 0x0000U}, /* Index:  9 */
	{0x91U, ( 0x07DFU << 2 ) , 0x0000U}, /* Index: 10 */
	{0x91U, 0x0U, 0x0000U}, /* Index: 11 */
	{0x91U, 0x0U, 0x0000U}, /* Index: 12 */

	{0x00U, 0x0000U, 0x0000U}, /* dummy */
};

/* CAN1 */
static const T_CanDrv_MsgObjCfg C_CanDrv1_RxMsgObjCfg[CANDRV1_RX_MSG_OBJ_CNT + 1U] =
{
	/* MCONF, MIDH, MIDL */

	{0x91U, 0x0000U, 0x0000U}, /* Index:  0 */
	{0x91U, 0x0000U, 0x0000U}, /* Index:  1 */
	{0x91U, 0x0000U, 0x0000U}, /* Index:  2 */
	{0x91U, 0x0000U, 0x0000U}, /* Index:  3 */
	{0x91U, 0x0000U, 0x0000U}, /* Index:  4 */
	{0x91U, 0x0000U, 0x0000U}, /* Index:  5 */
	{0x91U, 0x0000U, 0x0000U}, /* Index:  6 */
	{0x91U, 0x0000U, 0x0000U}, /* Index:  7 */
	{0x91U, 0x0000U, 0x0000U}, /* Index:  8 */
	{0x91U, 0x0000U, 0x0000U}, /* Index:  9 */
	{0x91U, 0x0000U, 0x0000U}, /* Index: 10 */
	{0x91U, 0x0000U, 0x0000U}, /* Index: 11 */
	{0x91U, 0x0000U, 0x0000U}, /* Index: 12 */
	{0x91U, 0x0000U, 0x0000U}, /* Index: 13 */
	{0x91U, 0x0000U, 0x0000U}, /* Index: 14 */

	{0x00U, 0x0000U, 0x0000U}, /* dummy */
};

static const T_CanDrv_AddrMap C_CanDrv_AddrMap_CAN0 =
{
	(volatile __near UI_16  *)&C0GMCTRL,	/* C0GMCTRL */
	(volatile __near UI_16  *)&C0GMABT,		/* C0GMABT */
	(volatile __near UI_8  *)&C0GMABTD,		/* C0GMABTD */
	(volatile __near UI_8  *)&C0GMCS,		/* C0GMCS */
	(volatile __near UI_16  *)&C0MASK1L,	/* C0MASK1L */
	(volatile __near UI_16  *)&C0MASK1H,	/* C0MASK1H */
	(volatile __near UI_16  *)&C0MASK2L,	/* C0MASK2L */
	(volatile __near UI_16  *)&C0MASK2H,	/* C0MASK2H */
	(volatile __near UI_16  *)&C0MASK3L,	/* C0MASK3L */
	(volatile __near UI_16  *)&C0MASK3H,	/* C0MASK3H */
	(volatile __near UI_16  *)&C0MASK4L,	/* C0MASK4L */
	(volatile __near UI_16  *)&C0MASK4H,	/* C0MASK4H */
	(volatile __near UI_16  *)&C0CTRL,		/* C0CTRL */
	(volatile __near UI_8  *)&C0LEC,		/* C0LEC */
	(volatile __near UI_8  *)&C0INFO,		/* C0INFO */
	(volatile __near UI_16  *)&C0ERC,		/* C0ERC */
	(volatile __near UI_16  *)&C0IE,		/* C0IE */
	(volatile __near UI_16  *)&C0INTS,		/* C0INTS */
	(volatile __near UI_8  *)&C0BRP,		/* C0BRP */
	(volatile __near UI_16  *)&C0BTR,		/* C0BTR */
	(volatile __near UI_8  *)&C0LIPT,		/* C0LIPT */
	(volatile __near UI_16  *)&C0RGPT,		/* C0RGPT */
	(volatile __near UI_8  *)&C0LOPT,		/* C0LOPT */
	(volatile __near UI_16  *)&C0TGPT,		/* C0TGPT */
	(volatile __near UI_16  *)&C0TS,		/* C0TS */
	{
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0100,	/* MsgBuf[0] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0101,	/* MsgBuf[1] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0102,	/* MsgBuf[2] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0103,	/* MsgBuf[3] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0104,	/* MsgBuf[4] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0105,	/* MsgBuf[5] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0106,	/* MsgBuf[6] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0107,	/* MsgBuf[7] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0108,	/* MsgBuf[8] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0109,	/* MsgBuf[9] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0110,	/* MsgBuf[10] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0111,	/* MsgBuf[11] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0112,	/* MsgBuf[12] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0113,	/* MsgBuf[13] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0114,	/* MsgBuf[14] */
		(T_CanDrv_MsgBufAddrMap *)&C0MDB0115	/* MsgBuf[15] */
	}
};

#if defined(__F10DPL_) || defined(__F10DPK_) || defined(__F10DPJ_)
static const T_CanDrv_AddrMap C_CanDrv_AddrMap_CAN1 =
{
	(volatile __near UI_16  *)&C1GMCTRL,	/* C1GMCTRL */
	(volatile __near UI_16  *)&C1GMABT,		/* C1GMABT */
	(volatile __near UI_8  *)&C1GMABTD,		/* C1GMABTD */
	(volatile __near UI_8  *)&C1GMCS,		/* C1GMCS */
	(volatile __near UI_16  *)&C1MASK1L,	/* C1MASK1L */
	(volatile __near UI_16  *)&C1MASK1H,	/* C1MASK1H */
	(volatile __near UI_16  *)&C1MASK2L,	/* C1MASK2L */
	(volatile __near UI_16  *)&C1MASK2H,	/* C1MASK2H */
	(volatile __near UI_16  *)&C1MASK3L,	/* C1MASK3L */
	(volatile __near UI_16  *)&C1MASK3H,	/* C1MASK3H */
	(volatile __near UI_16  *)&C1MASK4L,	/* C1MASK4L */
	(volatile __near UI_16  *)&C1MASK4H,	/* C1MASK4H */
	(volatile __near UI_16  *)&C1CTRL,		/* C1CTRL */
	(volatile __near UI_8  *)&C1LEC,		/* C1LEC */
	(volatile __near UI_8  *)&C1INFO,		/* C1INFO */
	(volatile __near UI_16  *)&C1ERC,		/* C1ERC */
	(volatile __near UI_16  *)&C1IE,		/* C1IE */
	(volatile __near UI_16  *)&C1INTS,		/* C1INTS */
	(volatile __near UI_8  *)&C1BRP,		/* C1BRP */
	(volatile __near UI_16  *)&C1BTR,		/* C1BTR */
	(volatile __near UI_8  *)&C1LIPT,		/* C1LIPT */
	(volatile __near UI_16  *)&C1RGPT,		/* C1RGPT */
	(volatile __near UI_8  *)&C1LOPT,		/* C1LOPT */
	(volatile __near UI_16  *)&C1TGPT,		/* C1TGPT */
	(volatile __near UI_16  *)&C1TS,		/* C1TS */
	{
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0100,	/* MsgBuf[0] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0101,	/* MsgBuf[1] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0102,	/* MsgBuf[2] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0103,	/* MsgBuf[3] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0104,	/* MsgBuf[4] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0105,	/* MsgBuf[5] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0106,	/* MsgBuf[6] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0107,	/* MsgBuf[7] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0108,	/* MsgBuf[8] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0109,	/* MsgBuf[9] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0110,	/* MsgBuf[10] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0111,	/* MsgBuf[11] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0112,	/* MsgBuf[12] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0113,	/* MsgBuf[13] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0114,	/* MsgBuf[14] */
		(T_CanDrv_MsgBufAddrMap *)&C1MDB0115	/* MsgBuf[15] */
	}
};
#endif

static const T_CanDrv_ControllerCfg C_CanDrv_Cfg_CAN0 =
{
		/* CanBasisAddr */
		&C_CanDrv_AddrMap_CAN0,
		/* ClockSelect */
		CANDRV0_GMCS,
		/* BitTiming */
		CANDRV0_BTR,
		/* BaudRate */
		CANDRV0_BRP,
		/* MsgObjCnt */
		CANDRV0_MSG_OBJ_CNT,
		/* RxMsgObjCfgPtr */
		&C_CanDrv0_RxMsgObjCfg[0],
		/* TxTopMsgNum */
		CANDRV0_TX_TOP_MSG_NUM,
		/* TxBottomMsgNum */
		CANDRV0_TX_BOTTOM_MSG_NUM,
		/* RxTopMsgNum */
		CANDRV0_RX_TOP_MSG_NUM,
		/* RxBottomMsgNum */
		CANDRV0_RX_BOTTOM_MSG_NUM,
		/* Mask1H */
		CANDRV0_MASK1H,
		/* Mask1L */
		CANDRV0_MASK1L,
		/* Mask2H */
		CANDRV0_MASK2H,
		/* Mask2L */
		CANDRV0_MASK2L,
		/* Mask3H */
		CANDRV0_MASK3H,
		/* Mask3L */
		CANDRV0_MASK3L,
		/* Mask4H */
		CANDRV0_MASK4H,
		/* Mask4L */
		CANDRV0_MASK4L,
};

#if defined(__F10DPL_) || defined(__F10DPK_) || defined(__F10DPJ_)
static const T_CanDrv_ControllerCfg C_CanDrv_Cfg_CAN1 =
{
		/* CanBasisAddr */
		&C_CanDrv_AddrMap_CAN1,
		/* ClockSelect */
		CANDRV1_GMCS,
		/* BitTiming */
		CANDRV1_BTR,
		/* BaudRate */
		CANDRV1_BRP,
		/* MsgObjCnt */
		CANDRV1_MSG_OBJ_CNT,
		/* RxMsgObjCfgPtr */
		&C_CanDrv1_RxMsgObjCfg[0],
		/* TxTopMsgNum */
		CANDRV1_TX_TOP_MSG_NUM,
		/* TxBottomMsgNum */
		CANDRV1_TX_BOTTOM_MSG_NUM,
		/* RxTopMsgNum */
		CANDRV1_RX_TOP_MSG_NUM,
		/* RxBottomMsgNum */
		CANDRV1_RX_BOTTOM_MSG_NUM,
		/* Mask1H */
		CANDRV1_MASK1H,
		/* Mask1L */
		CANDRV1_MASK1L,
		/* Mask2H */
		CANDRV1_MASK2H,
		/* Mask2L */
		CANDRV1_MASK2L,
		/* Mask3H */
		CANDRV1_MASK3H,
		/* Mask3L */
		CANDRV1_MASK3L,
		/* Mask4H */
		CANDRV1_MASK4H,
		/* Mask4L */
		CANDRV1_MASK4L,
};
#endif

static const T_CanDrv_ControllerCfg *C_CanDrv_ControllerCfg[CANDRV_CONTROLLER_CNT] =
{
#if defined(__F10DPL_) || defined(__F10DPK_) || defined(__F10DPJ_)
	/* CANDRV_CONTROLLER_0 */ &C_CanDrv_Cfg_CAN0,
	/* CANDRV_CONTROLLER_1 */ &C_CanDrv_Cfg_CAN1
#else
	/* CANDRV_CONTROLLER_0 */ &C_CanDrv_Cfg_CAN0
#endif
};


/************************************************************************************************/
/* Callback Functions                                                                            */
/************************************************************************************************/
/* void XXX_ControllerBusOff(const UI_8 controller) */
#define CANDRV_CALLBACK_CONTROLLER_BUSOFF CanDrvIF_ControllerBusOff

/* void XXX_RxMsgLost(const UI_8 controller) */
#define CANDRV_CALLBACK_RX_MSG_LOST CanDrvIF_RxMsgLost

/* void XXX_TxConfirmation(const UI_8 controller, const UI_16 tx_msg_obj_index) */
#define CANDRV_CALLBACK_TX_CONFIRMATION CanDrvIF_TxConfirmation

/* void XXX_RxIndication(const UI_8 controller, const UI_8 frame_format, const UI_32 id, const UI_8 data_length, const UI_8 data_ptr[]) */
#define CANDRV_CALLBACK_RX_INDICATION CanDrvIF_RxIndication

/* void XXX_MsgRamChkFailed(const UI_8 controller) */
#define CANDRV_CALLBACK_MSG_RAM_CHK_FAILED CanDrvIF_MsgRamChkFailed









#endif /* SSFTSTD_RL78CAN_DRV_000_INTERNAL */

#endif /* SSFTXXX_RL78CAN_DRVCFG_000_H */

/************************************************************************************************/
/*                                         END OF FILE                                          */
/************************************************************************************************/

