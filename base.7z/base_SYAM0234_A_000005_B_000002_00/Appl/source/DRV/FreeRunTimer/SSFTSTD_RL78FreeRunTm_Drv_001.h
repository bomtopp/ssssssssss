/************************************************************************************************/
/* �q�於		:	�W�����W���[��																*/
/* �@�햼		:	SSFT																		*/
/* ϲ�ݿ��ðϖ�	:	PF																			*/
/*==============================================================================================*/
/* �쐬̧�ٖ�	:	SSFTSTD_RL78FreeRunTm_Drv_001.h												*/
/* 				:	�ذ�������ײ��ͯ��															*/
/*==============================================================================================*/
/* �Ώ�ϲ��		:	RL78 Series																	*/
/*==============================================================================================*/
/* �쐬�ް�ޮ�	:	010101																		*/
/* �쐬�N����	:	2013.08.09																	*/
/* �쐬��		:	K.Watanabe																	*/
/*----------------------------------------------------------------------------------------------*/
/* �ύX����		:																				*/
/* [010101]		:	�V�K�쐬																	*/
/*				:	S_SS038_�d�l�ύX_�s��Ǘ��V�[�g No.11										*/
/* [020101]		:	S_SS038_�d�l�ύX_�s��Ǘ��V�[�g No.27										*/
/*				:	S_SS038_�d�l�ύX_�s��Ǘ��V�[�g No.31										*/
/*				:	S_SS038_�d�l�ύX_�s��Ǘ��V�[�g No.34										*/
/* [020103]		:	S_SS038_�d�l�ύX_�s��Ǘ��V�[�g No.66										*/
/*----------------------------------------------------------------------------------------------*/
/* Update by		: $Author: Miyaguti Yoko (A01A038020) $															*/
/* Date 			: $Date: 2017/11/27 10:01:23ICT $																*/
/* Version			: $Revision: 1.2 $															*/
/************************************************************************************************/
#ifndef __RL78_FREERUNTIMER_DRV_H__
#define __RL78_FREERUNTIMER_DRV_H__

/*** START_INC ***/
/********************************************************************************/
/*   Include File                                                               */
/*------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                          */
/********************************************************************************/
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"
#include "SSFTxxx_RL78FreeRunTm_DrvConfig_001.h"


typedef UI_16	T_FreeRun_Cnt;	/* �}�C�R���ɍ��킹�� T_FreeRun_Cnt���`     */

/*==============================================================================*/
/*	�O���萔																	*/
/*==============================================================================*/
#ifdef	_VERSION_CONST_DEFINE
UI_8 const C_FREERUNTIMERDRV_VER[6] = {	/* FreeRunTimer�h���C�o �h���C�o�o�[�W����No(200501) */
	0x02U,								/* xx "2" */
	0x00U,								/* xx "0" */
	0x00U,								/* yy "0" */
	0x05U,								/* yy "5" */
	0x00U,								/* zz "0" */
	0x01U								/* zz "1" */
};
#endif	/*	_VERSION_CONST_DEFINE 	*/

/*==============================================================================*/
/*	define��`�i�O�����J�j														*/
/*==============================================================================*/
#define RL78_FREERUNTIMER_DRV_H		(0x2005U)					/* �Q�Ƌ֎~ */

/* �ذ����ώ��s��� */
#define	N_START_FREERUN	(0x01U)	/* �ذ����� ��϶��ĊJ�n */
#define	N_STOP_FREERUN	(0x00U)	/* �ذ����� ��϶��Ē�~ */

/*==============================================================================*/
/*	�֐��������ߐ錾�i�O�����J�j												*/
/*==============================================================================*/

extern void FreeRunTmDrv_Init( E_INIT_TYPE req );
extern void FreeRunTmDrv_Sleep( void );
extern void FreeRunTmDrv_Refresh( void );

extern void FreeRunTmDrv_Ctrl(E_FREERUN_CHA ch, T_FreeRun_Cnt max, UI_8 act );
extern T_FreeRun_Cnt FreeRunTmDrv_GetTmData(E_FREERUN_CHA ch);
extern UI_8 FreeRunTmDrv_GetOvfInfo(E_FREERUN_CHA ch);
#ifdef FREE_RUN_INTR
extern void FreeRunTmDrv_ReqIntrClr(E_FREERUN_CHA ch);
#endif	/* FREE_RUN_INTR */
#ifdef FREE_RUN_INTR
extern UI_8 FreeRunTmDrv_GetIntr(E_FREERUN_CHA ch);
#endif	/* FREE_RUN_INTR */
extern SI_8 FreeRunTmDrv_InCapt( E_INPUTCAPDRV_CH ch, T_FreeRun_Cnt *in_capt);
extern void FreeRunTmDrv_ReqInCaptIntrClr(E_INPUTCAPDRV_CH ch);
extern UI_8 FreeRunTmDrv_GetInCaptIntr(E_INPUTCAPDRV_CH ch);
#ifdef PWM_DRV_APPLY_ENABLE
extern void PWMDrv_Init( E_INIT_TYPE req );
extern void PWMDrv_Refresh( void );
extern void PWMDrv_Sleep( void );
extern SI_8 PWMDrv_SetDutyCycle( E_PWM_DRV_PPG_CH ch, UI_16 cycle, UI_16 duty );
extern SI_8 PWMDrv_ReqIntrClr( E_PWM_DRV_PPG_CH ch );
extern SI_8 PWMDrv_ReqIntrDisable( E_PWM_DRV_PPG_CH ch );
extern SI_8 PWMDrv_ReqIntrEnable( E_PWM_DRV_PPG_CH ch );
#ifdef PWM_DRV_DUTY_CYCLE_SYNC_APPLY_ENABLE
extern SI_8 PWMDrv_SetDutyCycleSync( E_PWM_DRV_PPG_CH ch1, UI_16 cycle, UI_16 duty1, E_PWM_DRV_PPG_CH ch2, UI_16 duty2 );
#endif	/* PWM_DRV_DUTY_CYCLE_SYNC_APPLY_ENABLE */
#endif	/* PWM_DRV_APPLY_ENABLE */


#endif	/*	__RL78_FREERUNTIMER_DRV_H__ 	*/

