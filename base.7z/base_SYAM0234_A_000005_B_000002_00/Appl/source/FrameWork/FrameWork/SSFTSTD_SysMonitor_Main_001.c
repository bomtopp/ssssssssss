/************************************************************************************************/
/* File name		: SSFTSTD_SysMonitor_Main_001.c												*/
/* Description		: System state monitoring module (e.g.Runaway...)							*/
/*----------------------------------------------------------------------------------------------*/
/* Customer			: NS Standard Soft															*/
/* Model(Theme No.)	: NSPF																		*/
/*----------------------------------------------------------------------------------------------*/
/* CPU				: -																			*/
/* Date				: 2015/05/21																*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: A.Izu																		*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Note				: 																			*/
/*----------------------------------------------------------------------------------------------*/
/* Update by        : $Author: A01A040975 $                                               */
/* Date             : $Date: 2015/09/02 18:28:02ICT $                                           */
/* Version          : $Revision: 1.1 $                                                       */
/************************************************************************************************/

/************************************************************************************************/
/* Header files																					*/
/************************************************************************************************/
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"

#define SYS_MONITOR_INTERNAL
#include "SSFTSTD_SysMonitor_Main_001.h"

/************************************************************************************************/
/* Internal data structure definitions															*/
/************************************************************************************************/
/* None */

/************************************************************************************************/
/* Internal macro definitions																	*/
/************************************************************************************************/
/* None */

/************************************************************************************************/
/* Static variables																				*/
/************************************************************************************************/

static UI_16 S_monitoring_cnt[E_MONITORING_TASK_MAX];					/* Monitoring counter */

/************************************************************************************************/
/* Internal functions						 													*/
/************************************************************************************************/
/* None */

/************************************************************************************************/
/* Internal constants						 													*/
/************************************************************************************************/
/* None */

/************************************************************************************************/
/* Working functions																			*/
/************************************************************************************************/
/************************************************************************************************/
/* Function name	: void SysMonitor_Init( const E_INIT_TYPE req )								*/
/* Description		: Initialize the SystemMonitorFunction										*/
/* Argument			: E_INIT_TYPE			req		: Start-up type								*/
/* Return value		: None																		*/
/* Programmed by	: A.Izu																		*/
/* Date				: 2015/05/21																*/
/* Note				: None																		*/
/************************************************************************************************/
void SysMonitor_Init( const E_INIT_TYPE req )
{
	UI_8 i;						/* Loop counter */
	
	switch ( req ) {
	case E_INIT_RESET:			/* CPU Reset */
	case E_INIT_WAKEUP:			/* Wakeup (External interrupt) */
		
		/* Initialize static variables */
		for (i = 0U; i < (UI_8)E_MONITORING_TASK_MAX; i++) {
			S_monitoring_cnt[i] = 0U;
		}
		
		break;
	case E_INIT_IGN_ON:				/* Ignition on */
		break;
	case E_INIT_RET_NORMAL_VOL:		/* Return from the low voltage */
		break;
	case E_INIT_INTERVAL_WAKEUP:	/* Intermittent interrupt(In standby mode) */
		break;
	default:						/* Other */
		break;
	}
}

/************************************************************************************************/
/* Function name	: void SysMonitor_RunawayMonitoring(void)									*/
/* Description		: Runaway monitoring														*/
/* Argument			: None																		*/
/* Return value		: None																		*/
/* Programmed by	: A.Izu																		*/
/* Date				: 2015/05/21																*/
/* Note				: None																		*/
/************************************************************************************************/
void SysMonitor_RunawayMonitoring(void)
{
	UI_8 i;						/* Loop counter */
	
	/* Count the runaway monitoring counter */
	for (i = 0U; i < (UI_8)E_MONITORING_TASK_MAX; i++) {
		S_monitoring_cnt[i]++;
	}
}

/************************************************************************************************/
/* Function name	: SI_8 SysMonitor_JdgRunaway(void)											*/
/* Description		: Judge runaway																*/
/* Argument			: None																		*/
/* Return value		: SI_8	jdg_result		: Determination result								*/
/* Programmed by	: A.Izu																		*/
/* Date				: 2015/05/21																*/
/* Note				: None																		*/
/************************************************************************************************/
SI_8 SysMonitor_JdgRunaway(void)
{
	SI_8 jdg_result;			/* Judge result(Return value) */
	UI_8 i;						/* Loop counter */
	
	jdg_result = D_OK;
	
	for (i = 0U; i < (UI_8)E_MONITORING_TASK_MAX; i++) {
		if (C_Runaway_detection_val[i] <= S_monitoring_cnt[i]) {
			/* In case of runaway */
			jdg_result = D_NG;
		}
	}
	
	return jdg_result;
}

/************************************************************************************************/
/* Function name	: void SysMonitor_ClrMonitoringCnt(const E_MONITORING_TASK task_no)			*/
/* Description		: Clear monitoring count(By task number)									*/
/* Argument			: E_MONITORING_TASK	task_no		: Task number								*/
/* Return value		: None																		*/
/* Programmed by	: A.Izu																		*/
/* Date				: 2015/05/21																*/
/* Note				: Call each interrupt function.												*/
/************************************************************************************************/
void SysMonitor_ClrMonitoringCnt(const E_MONITORING_TASK task_no)
{
	if (task_no < E_MONITORING_TASK_MAX) {
		/* Within the range of E_MONITORING_TASK */
		S_monitoring_cnt[task_no] = 0U;				/* Clear monitoring count */
	}
}

/************************************************************************************************/
/* External interface functions																	*/
/************************************************************************************************/
/* None */

/************************************************************************************************/
/* Internal functions			 																*/
/************************************************************************************************/
/* None */
