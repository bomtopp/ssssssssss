/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SSFT																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Nguyen Ba Duc Tin (A01A093579)																*/
/* Date 			: 2018/05/16																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: �V�X�e�����͋@�\�C���N���[�h�w�b�_										*/
/*************************************************************************************************/
#ifndef	__XXX_SYSIN_INC_H__
#define	__XXX_SYSIN_INC_H__

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          				*/
/************************************************************************************************/
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"

#include "SSFTSTD_RL78Adc_Drv_001.h"
#include "SYAM0220_RL78Port_Drv_001.h"
#include "SYAM0234_SysIn_IF_101.h"
#include "SSFTxxx_SysIn_Config_101.h"

#define	DEFINITION_VARIABLES
#include "SYAM0234_SysIn_P5_101.h"
#include "SYAM0234_SysIn_Main_101.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	SYSIN_P5_C										/* 2�d���̒�`�h�~:�V�X�e�����̓R�A���i�̂ݎQ�Ƃ����` */
#include "SSFTSTD_MacroFunc.h"
#include "SSFTSTD_RL78Intr_Drv_001.h"
#endif	/* End of SYSIN_P5_C */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	SYSIN_MAIN_C
/* #include	"SYAM0183_InCapt_Main_101.h" */
#include	"SYAM0234_DataMgr_IF_101.h"
/* #include	"SSFTSTD_RL78_PT6586_LCD_Drv.h" */
#include	"SYAMSTD_UartCtrl_IF_101.h"
#include	"SYAM0234_ProdTest_Main_102.h"
#include	"SYAMSTD_InstFuel_IF_101.h"
#include	"SYAM0234_DataMgr_IF_101.h"
#include	"SKAM0087_Fuel_Main_101.h"
#include	"SSFTxxx_Can_Ctrl_000.h"
#include	"SYAM0234_CanCtrl_IF_000.h"
#include	"SYAM0220_ServiceProtocol.h"
#include	"SSFTSTD_WaterTemp_Main_101.h"
#include	"SYAM0220_OutTemp_Main_101.h"
#include	"SYAM0220_QSS_Main_101.h"
#include	"SYAM0129_EngineWarn_Main_101.h"
#include	"SYAM0220_Neutral_Ind_Main_101.h"
#include	"SYAM0220_Gear_IF_101.h"
#include	"SYAMSTD_AvgFuel_IF_101.h"
#endif	/* SYSIN_MAIN_C */

#endif	/* __XXX_SYSIN_INC_H__ */

