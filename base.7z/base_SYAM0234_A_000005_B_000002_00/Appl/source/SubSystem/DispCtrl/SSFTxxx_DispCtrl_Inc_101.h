/************************************************************************************************/
/* �q�於		:	�W�����W���[��																*/
/* �@�햼		:	SSFT																		*/
/* ϲ�ݿ��ðϖ�	:	PF																			*/
/*==============================================================================================*/
/* �쐬̧�ٖ�	:	SSFTxxx_DispCtrl_Inc_101.h													*/
/* 				:	�\������@�\�@�\�O���t�@�C���C���N���[�w�b�_								*/
/*==============================================================================================*/
/* �Ώ�ϲ��		:	2R�W��																		*/
/*==============================================================================================*/
/* �쐬�ް�ޮ�	:	010101																		*/
/* �쐬�N����	:	2014.10.xx																	*/
/* �쐬��		:	NSCS																		*/
/*----------------------------------------------------------------------------------------------*/
/* �ύX����		:																				*/
/* [010101]		:	�V�K�쐬																	*/
/************************************************************************************************/
#ifndef	__XXX_DISPCTRL_INC_H__
#define	__XXX_DISPCTRL_INC_H__


/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include <string.h>
#include "SSFTSTD_Macro.h"
#include "SSFTxxx_DispCtrl_Config_101.h"

#include "SYAM0220_Fuel_P5_101.h"			/* FUEL�@�\ */
#include "SYAM0220_Sp_IF_102.h"				/* SPEED�@�\ */
#include "SYAM0234_SysIn_IF_101.h"			/* �V�X�e�����͋@�\ */
#include "SYAM0234_SysCtrl_IF_101.h"			/* �V�X�e������@�\ */
#include "SYAM0234_DataMgr_IF_101.h"		/* �f�[�^�Ǘ��@�\ */
#include "SYAM0234_ProdTest_Main_102.h"		/* ���Y�ݔ��@�\ */
#include "SSFTSTD_OdoTrip_IF_101.h"			/* ODOTRIP�@�\ */
#include "SYAM0220_LcdOut_Main_P5_101.h"	/* LCD�o�͋@�\ */
#include "SSFTSTD_Com_P5_101.h"				/* ���ʋ@�\ */
#include "SYAM0129_VVA_IF_101.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	DISPCTRL_P5_INTERNAL

#include "SYAM0234_DispCtrl_Main_101.h"

#define	DEFINITION_VARIABLES
#include "SHPM229_DispCtrl_P5_101.h"

#endif	/* DISPCTRL_P5_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	DISPCTRL_MAIN_INTERNAL

#include "SHPM229_DispCtrl_P5_101.h"

#include "SSFTxxx_Gear_Config_101.h"
#include "SYAM0220_Gear_IF_101.h"
#include "SYAMSTD_UartCtrl_IF_101.h"

#define	DEFINITION_VARIABLES
#include "SYAM0234_DispCtrl_Main_101.h"
#include "SYAMSTD_AvgFuel_IF_101.h"
#include "SYAMSTD_InstFuel_IF_101.h"
#include "SYAMxxx_InstFuel_Config_101.h"
/* #include "SYAMSTD_AvgSp_IF_101.h" */
/* #include "SYAMxxx_AvgSp_Config_101.h" */
#include "SYAMSTD_FuelTrip_IF_101.h"
#include "SSFTSTD_Ta_IF_102.h"
#include "SYAM0220_WaterTemp_IF_101.h"
#include "SYAM0234_OutTemp_IF_101.h"
#include "SYAM0220_EngineWarn_IF_101.h"
#include "SYAM0220_Neutral_Ind_IF_101.h"
#include "SSFTSTD_RL78IoReg_CpuType_001.h"
#include "SYAM0220_RL78Port_Drv_001.h"
#include "SSFTSTD_Clock_Main_001.h"
/* #include "SSFTxxx_IlmCtrl_Config_101.h" */
/* #include "SYAM0129_ABS_Main_101.h" */
/* #include "SYAM0129_VVA_IF_101.h" */
#include "SYAM0220_ShiftTiming_IF_101.h"
#include "SSFTxxx_LedOut_Config_101.h"
#include "SYAM0234_ProdTest_Main_102.h"
#include "SYAM0234_Flasher_Main_101.h"
#include "SYAM0220_illumination_TASK.h"
#include "SYAM0234_CanCtrl_IF_000.h"
#include "SYAM0220_QSS_IF_101.h"
#include "SYAM0220_oil_press_TASK.h"
#endif	/* DISPCTRL_MAIN_INTERNAL */



#endif	/* __XXX_DISPCTRL_INC_H__ */

