/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SSFT																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Y.Kikuchi																	*/
/* Date 			: 2018/06/05																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: SPEED�@�\�C���N���[�h�w�b�_												*/
/*************************************************************************************************/
#ifndef	SSFTXXX_SP_INC_H
#define	SSFTXXX_SP_INC_H

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	SP_P5_INTERNAL

#include <string.h>
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Com_P5_101.h"
#include "SYAM0220_Sp_IF_102.h"
#include "SSFTxxx_Sp_Config_102.h"
#include "SSFTSTD_Sp_P5_102.h"

#endif	/* SP_P5_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	SP_MAIN_INTERNAL

#include <string.h>
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Com_P5_101.h"
#include "SYAM0234_DataMgr_IF_101.h"
#include "SYAM0234_SysIn_IF_101.h"

#include "SSFTxxx_Sp_Config_102.h"

#if SP_INPUT_TYPE == SP_INCAPT_PERIODICAL_PULSE		/* �������͎� */
#include "SSFTSTD_InCapt_Main_101.h"
#include "SSFTSTD_InCapt_P5_101.h"
#endif

#if SP_INPUT_TYPE == SP_UART_COMMUNICATION_PULSE	/* SP�p���X���͎� */
#include "SYAMSTD_UartCtrl_IF_101.h"
#endif

#if SP_JDG_COMMUNICATION_MODE == SP_ENABLE			/* �ʐM���[�h����L���� */
#include "SYAMSTD_UartCtrl_IF_101.h"
#endif

#if SP_PROC_FORCEDOUT == SP_ENABLE					/* �w�x�������L���� */
#include "SYAM0234_SysCtrl_IF_101.h"
#endif

#if SP_OUTPUT_TYPE == SP_ANALOG_OUTPUT				/* �A�i���O�o�͎��L�� */
#include "SSFTSTD_Gauge_IF_101.h"
#endif

#if SP_INPUT_TYPE == SP_CAN_COMMUNICATION_PULSE		/* SP�p���X���͎� */
#include "SYAM0234_CanCtrl_IF_000.h"
#include "SSFTSTD_MacroFunc.h"
#endif

#include "SSFTSTD_Sp_P5_102.h"
#include "SYAM0220_Sp_IF_102.h"
#include "SSFTSTD_Sp_Main_102.h"

#endif	/* SP_MAIN_INTERNAL */

#endif	/* SSFTXXX_SP_INC_H */

