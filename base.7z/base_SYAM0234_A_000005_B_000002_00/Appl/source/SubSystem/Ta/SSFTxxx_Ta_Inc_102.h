/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SSFT																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: K.Wada																	*/
/* Date 			: 2018/03/13																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: TACHO�@�\�C���N���[�h�w�b�_												*/
/*************************************************************************************************/
#ifndef	__XXX_TA_INC_H__
#define	__XXX_TA_INC_H__

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include <string.h>
#include "SSFTSTD_Macro.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	TA_P5_INTERNAL

#include "SSFTSTD_Com_P5_101.h"
#include "SSFTxxx_Ta_Config_102.h"
#include "SSFTSTD_Ta_P5_102.h"
#include "SSFTSTD_Ta_Main_102.h"
#include "SSFTSTD_Ta_IF_102.h"

#endif	/* TA_P5_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	TA_MAIN_INTERNAL

#include "SSFTxxx_Ta_Config_102.h"

#include "SSFTSTD_Com_P5_101.h"
#include "SSFTSTD_Ta_P5_102.h"

#include "SYAM0234_DataMgr_IF_101.h"
#include "SSFTSTD_Ta_Main_102.h"
#include "SSFTSTD_Ta_IF_102.h"
#include "SYAM0234_SysIn_IF_101.h"

#if TA_INPUT_TYPE == TA_INCAPT_PERIODICAL_PULSE		/* �p���X���͎� */
#include "SSFTSTD_InCapt_Main_101.h"
#include "SSFTSTD_InCapt_P5_101.h"
#endif

#if TA_INPUT_TYPE == TA_UART_REVOLUTIONS_NUM		/* �ʐM(UART)���͎� */
#include "SYAMSTD_UartCtrl_IF_101.h"
#endif

#if TA_JDG_COMMUNICATION_MODE == TA_ENABLE			/* �ʐM���[�h����L���� */
#include "SYAMSTD_UartCtrl_IF_101.h"
#endif

#if TA_PROC_FORCEDOUT == TA_ENABLE					/* �w�x�������L���� */
#include "SYAM0234_SysCtrl_IF_101.h"
#endif

#if TA_OUTPUT_TYPE == TA_ANALOG_OUTPUT				/* �A�i���O�o�͎��L�� */
#include "SSFTSTD_Gauge_IF_101.h"
#endif

#if TA_INPUT_TYPE == TA_CAN_REVOLUTIONS_NUM		/* �ʐM(CAN)���͎� */
#include "SYAM0234_CanCtrl_IF_000.h"
#endif


#endif	/* TA_MAIN_INTERNAL */

#endif	/* __XXX_TA_INC_H__ */

