/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SYAM																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: Arisaka																	*/
/* Date 			: 2018/05/18																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: TRCOM�@�\�C���N���[�h�w�b�_												*/
/*************************************************************************************************/
#ifndef	SYAMXXX_TRCOM_INC_H
#define	SYAMXXX_TRCOM_INC_H

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include "SSFTSTD_Macro.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	TRCOM_P5_INTERNAL

#include "SSFTSTD_Macro.h"

#define TRCOM_INTERNAL
#include "SYAMSTD_Trcom_IF_101.h"

#define	DEFINITION_VARIABLES
#include "SYAMSTD_Trcom_P5_101.h"

#endif	/* TRCOM_P5_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	TRCOM_MAIN_INTERNAL

#include "SSFTSTD_Macro.h"
#include "SYAM0234_SysIn_IF_101.h"
#include "SYAM0234_DataMgr_IF_101.h"
#include "SYAMSTD_UartCtrl_IF_101.h"

#define TRCOM_INTERNAL
#include "SYAMxxx_Trcom_Config_101.h"
#include "SYAMSTD_Trcom_P5_101.h"

#define	DEFINITION_VARIABLES
#include "SYAMSTD_Trcom_IF_101.h"

#define	DEFINITION_VARIABLES
#include "SYAMSTD_Trcom_Main_101.h"

#endif	/* TRCOM_MAIN_INTERNAL */

#endif	/* SYAMXXX_TRCOM_INC_H */

