/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SSFT																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: K.Wada																	*/
/* Date 			: 2018/03/13																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: OdoTrip�@�\�C���N���[�h�w�b�_												*/
/*************************************************************************************************/
#ifndef	__XXX_ODOTRIP_INC_H__
#define	__XXX_ODOTRIP_INC_H__


/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	ODOTRIP_P5_INTERNAL

#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"
#include "SSFTSTD_Com_P5_101.h"

#include "SSFTxxx_OdoTrip_Config_101.h"
#include "SSFTSTD_OdoTrip_IF_101.h"
#include "SSFTSTD_OdoTrip_Main_101.h"
#include "SSFTSTD_OdoTrip_P5_101.h"

#endif	/* ODOTRIP_P5_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	ODOTRIP_MAIN_INTERNAL

#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"
#include "SYAMSTD_Trcom_IF_101.h"
#include "SYAM0234_DataMgr_IF_101.h"
#include "SYAM0234_SysCtrl_IF_101.h"
#include "SSFTxxx_OdoTrip_Config_101.h"
#include "SSFTSTD_OdoTrip_IF_101.h"
#include "SSFTSTD_OdoTrip_P5_101.h"
#include "SSFTSTD_OdoTrip_Main_101.h"

#endif	/* ODOTRIP_MAIN_INTERNAL */

#endif	/* __XXX_ODOTRIP_INC_H__ */

