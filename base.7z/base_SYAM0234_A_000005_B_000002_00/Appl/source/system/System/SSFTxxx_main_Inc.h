/************************************************************************************************/
/* Customer		: �W�����W���[��																*/
/* Project Name	: SSFT																			*/
/* Theme Name	: PF																			*/
/*----------------------------------------------------------------------------------------------*/
/* File name	: SSFTxxx_main_Inc.h															*/
/* Description	: main �w�b�_																	*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          : RL78 Series																	*/
/*----------------------------------------------------------------------------------------------*/
/* Note 		: �C���N���[�h����w�b�_��OEM�ˑ�												*/
/*----------------------------------------------------------------------------------------------*/
/* Update by	: $Author: Nguyen Quoc_Khanh (B08A000035) $													*/
/* Date 		: $Date: 2020/07/28 15:59:54ICT $												*/
/* Version		: $Revision: 1.1 $															*/
/************************************************************************************************/
#ifndef __SSFTXXX_MAIN_INC_H__
#define __SSFTXXX_MAIN_INC_H__

/* START_INC */
#include "SSFTSTD_MacroFunc.h"
#include "SSFTSTD_Type.h"

#include "SSFTSTD_Framework_ObjMng.h"
#include "SSFTSTD_RL78Wdt_Drv_001.h"
#include "SSFTSTD_RL78FreeRunTm_Drv_001.h"		/* FreeRunTimer�h���C�o */
#include "SYAM0220_Framework_ObjMng_Config.h"
#include "SSFTSTD_Can_DrvIF_000.h"				/* CAN�h���C�o */

#include "SYAM0234_main.h"

/* END_INC */
#endif  /* __SSFTXXX_MAIN_INC_H__ */
