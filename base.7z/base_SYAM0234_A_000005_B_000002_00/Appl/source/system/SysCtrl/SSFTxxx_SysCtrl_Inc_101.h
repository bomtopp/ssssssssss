/************************************************************************************************/
/* Customer			: �W�����W���[��															*/
/* Project Name		: SSFT																		*/
/* Theme Name		: PF																		*/
/*----------------------------------------------------------------------------------------------*/
/* MPU          	: 2R�W��																	*/
/*----------------------------------------------------------------------------------------------*/
/* Programmed by	: K.Wada																	*/
/* Date 			: 2018/03/13																*/
/* Copyrights		: Nippon Seiki Co.,Ltd														*/
/* Description		: SycCtrl�@�\�C���N���[�h�w�b�_												*/
/*************************************************************************************************/
#ifndef	__XXX_SYSCTRL_INC_H__
#define	__XXX_SYSCTRL_INC_H__

/************************************************************************************************/
/*   Include File                                                                               */
/*----------------------------------------------------------------------------------------------*/
/*      ͯ�ް̧�ق̲ݸٰ�ޕ��́A���Ļ�قɋL�ڂ��邱��                                          */
/************************************************************************************************/
#include "SSFTSTD_Type.h"
#include "SSFTSTD_Macro.h"
#include "SSFTxxx_SysCtrl_Config_101.h"
#include "SYAM0234_SysCtrl_IF_101.h"

/*----------------------------------------------------------------------------------------------*/
/*	�R�A���i																					*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	SYSCTRL_P5_INTERNAL

#include "SYAM0220_SysCtrl_Main_101.h"

#define	DEFINITION_VARIABLES
#include "SSFTSTD_SysCtrl_P5_101.h"

#endif	/* SYSCTRL_P5_INTERNAL */

/*----------------------------------------------------------------------------------------------*/
/*	�t�����g�G���h���i																			*/
/*----------------------------------------------------------------------------------------------*/
#ifdef	SYSCTRL_MAIN_INTERNAL

#include "SSFTSTD_SysCtrl_P5_101.h"

#define	DEFINITION_VARIABLES
#include "SYAM0220_SysCtrl_Main_101.h"

#include "SYAM0234_SysIn_IF_101.h"
#include "SYAM0234_DispCtrl_Main_101.h"
#include "SYAM0234_ProdTest_Main_102.h"
#include "SSFTxxx_RL78Port_DrvConfig_001.h"
#include "SYAM0220_RL78Port_Drv_001.h"

#endif	/* SYSCTRL_MAIN_INTERNAL */

#endif	/* __XXX_SYSCTRL_INC_H__ */

